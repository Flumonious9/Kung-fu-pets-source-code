package android.arch.core.internal;

import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;
import java.util.Iterator;
import java.util.Map;
import java.util.WeakHashMap;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class SafeIterableMap<K, V> implements Iterable<Map.Entry<K, V>> {
  private Entry<K, V> mEnd;
  
  private WeakHashMap<SupportRemove<K, V>, Boolean> mIterators = new WeakHashMap<SupportRemove<K, V>, Boolean>();
  
  private int mSize = 0;
  
  private Entry<K, V> mStart;
  
  public Iterator<Map.Entry<K, V>> descendingIterator() {
    DescendingIterator<K, V> descendingIterator = new DescendingIterator<K, V>(this.mEnd, this.mStart);
    this.mIterators.put(descendingIterator, Boolean.valueOf(false));
    return descendingIterator;
  }
  
  public Map.Entry<K, V> eldest() {
    return this.mStart;
  }
  
  public boolean equals(Object paramObject) {
    if (paramObject == this)
      return true; 
    if (!(paramObject instanceof SafeIterableMap))
      return false; 
    SafeIterableMap safeIterableMap = (SafeIterableMap)paramObject;
    if (size() != safeIterableMap.size())
      return false; 
    Iterator<Map.Entry<K, V>> iterator = iterator();
    Iterator<Object> iterator1 = safeIterableMap.iterator();
    while (iterator.hasNext() && iterator1.hasNext()) {
      Map.Entry entry = iterator.next();
      Object object = iterator1.next();
      if ((entry == null && object != null) || (entry != null && !entry.equals(object)))
        return false; 
    } 
    return (!iterator.hasNext() && !iterator1.hasNext());
  }
  
  protected Entry<K, V> get(K paramK) {
    Entry<K, V> entry;
    for (entry = this.mStart; entry != null; entry = entry.c) {
      if (entry.a.equals(paramK))
        return entry; 
    } 
    return entry;
  }
  
  @NonNull
  public Iterator<Map.Entry<K, V>> iterator() {
    AscendingIterator<K, V> ascendingIterator = new AscendingIterator<K, V>(this.mStart, this.mEnd);
    this.mIterators.put(ascendingIterator, Boolean.valueOf(false));
    return ascendingIterator;
  }
  
  public IteratorWithAdditions iteratorWithAdditions() {
    IteratorWithAdditions iteratorWithAdditions = new IteratorWithAdditions();
    this.mIterators.put(iteratorWithAdditions, Boolean.valueOf(false));
    return iteratorWithAdditions;
  }
  
  public Map.Entry<K, V> newest() {
    return this.mEnd;
  }
  
  protected Entry<K, V> put(@NonNull K paramK, @NonNull V paramV) {
    Entry<K, V> entry = new Entry<K, V>(paramK, paramV);
    this.mSize = 1 + this.mSize;
    if (this.mEnd == null) {
      this.mStart = entry;
      this.mEnd = this.mStart;
      return entry;
    } 
    this.mEnd.c = entry;
    entry.d = this.mEnd;
    this.mEnd = entry;
    return entry;
  }
  
  public V putIfAbsent(@NonNull K paramK, @NonNull V paramV) {
    Entry<K, V> entry = get(paramK);
    if (entry != null)
      return entry.b; 
    put(paramK, paramV);
    return null;
  }
  
  public V remove(@NonNull K paramK) {
    Entry<K, V> entry = get(paramK);
    if (entry == null)
      return null; 
    this.mSize = -1 + this.mSize;
    if (!this.mIterators.isEmpty()) {
      Iterator<SupportRemove<K, V>> iterator = this.mIterators.keySet().iterator();
      while (iterator.hasNext())
        ((SupportRemove<K, V>)iterator.next()).supportRemove(entry); 
    } 
    if (entry.d != null) {
      entry.d.c = entry.c;
    } else {
      this.mStart = entry.c;
    } 
    if (entry.c != null) {
      entry.c.d = entry.d;
    } else {
      this.mEnd = entry.d;
    } 
    entry.c = null;
    entry.d = null;
    return entry.b;
  }
  
  public int size() {
    return this.mSize;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("[");
    Iterator<Map.Entry<K, V>> iterator = iterator();
    while (iterator.hasNext()) {
      stringBuilder.append(((Map.Entry)iterator.next()).toString());
      if (iterator.hasNext())
        stringBuilder.append(", "); 
    } 
    stringBuilder.append("]");
    return stringBuilder.toString();
  }
  
  static class AscendingIterator<K, V> extends ListIterator<K, V> {
    AscendingIterator(SafeIterableMap.Entry<K, V> param1Entry1, SafeIterableMap.Entry<K, V> param1Entry2) {
      super(param1Entry1, param1Entry2);
    }
    
    SafeIterableMap.Entry<K, V> a(SafeIterableMap.Entry<K, V> param1Entry) {
      return param1Entry.c;
    }
    
    SafeIterableMap.Entry<K, V> b(SafeIterableMap.Entry<K, V> param1Entry) {
      return param1Entry.d;
    }
  }
  
  private static class DescendingIterator<K, V> extends ListIterator<K, V> {
    DescendingIterator(SafeIterableMap.Entry<K, V> param1Entry1, SafeIterableMap.Entry<K, V> param1Entry2) {
      super(param1Entry1, param1Entry2);
    }
    
    SafeIterableMap.Entry<K, V> a(SafeIterableMap.Entry<K, V> param1Entry) {
      return param1Entry.d;
    }
    
    SafeIterableMap.Entry<K, V> b(SafeIterableMap.Entry<K, V> param1Entry) {
      return param1Entry.c;
    }
  }
  
  static class Entry<K, V> implements Map.Entry<K, V> {
    @NonNull
    final K a;
    
    @NonNull
    final V b;
    
    Entry<K, V> c;
    
    Entry<K, V> d;
    
    Entry(@NonNull K param1K, @NonNull V param1V) {
      this.a = param1K;
      this.b = param1V;
    }
    
    public boolean equals(Object param1Object) {
      if (param1Object == this)
        return true; 
      if (!(param1Object instanceof Entry))
        return false; 
      Entry entry = (Entry)param1Object;
      return (this.a.equals(entry.a) && this.b.equals(entry.b));
    }
    
    @NonNull
    public K getKey() {
      return this.a;
    }
    
    @NonNull
    public V getValue() {
      return this.b;
    }
    
    public V setValue(V param1V) {
      throw new UnsupportedOperationException("An entry modification is not supported");
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(this.a);
      stringBuilder.append("=");
      stringBuilder.append(this.b);
      return stringBuilder.toString();
    }
  }
  
  private class IteratorWithAdditions implements SupportRemove<K, V>, Iterator<Map.Entry<K, V>> {
    private boolean mBeforeStart = true;
    
    private SafeIterableMap.Entry<K, V> mCurrent;
    
    private IteratorWithAdditions(SafeIterableMap this$0) {}
    
    public boolean hasNext() {
      if (this.mBeforeStart) {
        SafeIterableMap.Entry entry1 = SafeIterableMap.a(this.a);
        boolean bool1 = false;
        if (entry1 != null)
          bool1 = true; 
        return bool1;
      } 
      SafeIterableMap.Entry<K, V> entry = this.mCurrent;
      boolean bool = false;
      if (entry != null) {
        SafeIterableMap.Entry<K, V> entry1 = this.mCurrent.c;
        bool = false;
        if (entry1 != null)
          bool = true; 
      } 
      return bool;
    }
    
    public Map.Entry<K, V> next() {
      if (this.mBeforeStart) {
        this.mBeforeStart = false;
        this.mCurrent = SafeIterableMap.a(this.a);
      } else {
        SafeIterableMap.Entry entry;
        if (this.mCurrent != null) {
          entry = this.mCurrent.c;
        } else {
          entry = null;
        } 
        this.mCurrent = entry;
      } 
      return this.mCurrent;
    }
    
    public void supportRemove(@NonNull SafeIterableMap.Entry<K, V> param1Entry) {
      if (param1Entry == this.mCurrent) {
        boolean bool;
        this.mCurrent = this.mCurrent.d;
        if (this.mCurrent == null) {
          bool = true;
        } else {
          bool = false;
        } 
        this.mBeforeStart = bool;
      } 
    }
  }
  
  private static abstract class ListIterator<K, V> implements SupportRemove<K, V>, Iterator<Map.Entry<K, V>> {
    SafeIterableMap.Entry<K, V> a;
    
    SafeIterableMap.Entry<K, V> b;
    
    ListIterator(SafeIterableMap.Entry<K, V> param1Entry1, SafeIterableMap.Entry<K, V> param1Entry2) {
      this.a = param1Entry2;
      this.b = param1Entry1;
    }
    
    private SafeIterableMap.Entry<K, V> nextNode() {
      return (this.b == this.a || this.a == null) ? null : a(this.b);
    }
    
    abstract SafeIterableMap.Entry<K, V> a(SafeIterableMap.Entry<K, V> param1Entry);
    
    abstract SafeIterableMap.Entry<K, V> b(SafeIterableMap.Entry<K, V> param1Entry);
    
    public boolean hasNext() {
      return (this.b != null);
    }
    
    public Map.Entry<K, V> next() {
      SafeIterableMap.Entry<K, V> entry = this.b;
      this.b = nextNode();
      return entry;
    }
    
    public void supportRemove(@NonNull SafeIterableMap.Entry<K, V> param1Entry) {
      if (this.a == param1Entry && param1Entry == this.b) {
        this.b = null;
        this.a = null;
      } 
      if (this.a == param1Entry)
        this.a = b(this.a); 
      if (this.b == param1Entry)
        this.b = nextNode(); 
    }
  }
  
  static interface SupportRemove<K, V> {
    void supportRemove(@NonNull SafeIterableMap.Entry<K, V> param1Entry);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\core\internal\SafeIterableMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */