package android.arch.lifecycle;

public abstract class ViewModel {
  protected void onCleared() {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\ViewModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */