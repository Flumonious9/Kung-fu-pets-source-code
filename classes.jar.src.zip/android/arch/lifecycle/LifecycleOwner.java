package android.arch.lifecycle;

import android.support.annotation.NonNull;

public interface LifecycleOwner {
  @NonNull
  Lifecycle getLifecycle();
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\LifecycleOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */