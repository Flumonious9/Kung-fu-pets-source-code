package android.arch.lifecycle;

import android.support.annotation.MainThread;
import android.support.annotation.NonNull;

public abstract class Lifecycle {
  @MainThread
  public abstract void addObserver(@NonNull LifecycleObserver paramLifecycleObserver);
  
  @MainThread
  @NonNull
  public abstract State getCurrentState();
  
  @MainThread
  public abstract void removeObserver(@NonNull LifecycleObserver paramLifecycleObserver);
  
  public enum Event {
    ON_ANY, ON_CREATE, ON_DESTROY, ON_PAUSE, ON_RESUME, ON_START, ON_STOP;
    
    static {
      ON_PAUSE = new Event("ON_PAUSE", 3);
      ON_STOP = new Event("ON_STOP", 4);
      ON_DESTROY = new Event("ON_DESTROY", 5);
      ON_ANY = new Event("ON_ANY", 6);
      Event[] arrayOfEvent = new Event[7];
      arrayOfEvent[0] = ON_CREATE;
      arrayOfEvent[1] = ON_START;
      arrayOfEvent[2] = ON_RESUME;
      arrayOfEvent[3] = ON_PAUSE;
      arrayOfEvent[4] = ON_STOP;
      arrayOfEvent[5] = ON_DESTROY;
      arrayOfEvent[6] = ON_ANY;
      $VALUES = arrayOfEvent;
    }
  }
  
  public enum State {
    DESTROYED, CREATED, INITIALIZED, RESUMED, STARTED;
    
    static {
      RESUMED = new State("RESUMED", 4);
      State[] arrayOfState = new State[5];
      arrayOfState[0] = DESTROYED;
      arrayOfState[1] = INITIALIZED;
      arrayOfState[2] = CREATED;
      arrayOfState[3] = STARTED;
      arrayOfState[4] = RESUMED;
      $VALUES = arrayOfState;
    }
    
    public boolean isAtLeast(@NonNull State param1State) {
      return (compareTo(param1State) >= 0);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\Lifecycle.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */