package android.arch.lifecycle;

import android.support.annotation.Nullable;

public interface Observer<T> {
  void onChanged(@Nullable T paramT);
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\Observer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */