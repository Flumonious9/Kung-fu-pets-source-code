package android.arch.lifecycle;

import android.support.annotation.NonNull;

public interface ViewModelStoreOwner {
  @NonNull
  ViewModelStore getViewModelStore();
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\ViewModelStoreOwner.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */