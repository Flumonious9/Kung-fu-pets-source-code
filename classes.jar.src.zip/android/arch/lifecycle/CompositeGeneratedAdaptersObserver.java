package android.arch.lifecycle;

import android.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class CompositeGeneratedAdaptersObserver implements GenericLifecycleObserver {
  private final GeneratedAdapter[] mGeneratedAdapters;
  
  CompositeGeneratedAdaptersObserver(GeneratedAdapter[] paramArrayOfGeneratedAdapter) {
    this.mGeneratedAdapters = paramArrayOfGeneratedAdapter;
  }
  
  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    MethodCallsLogger methodCallsLogger = new MethodCallsLogger();
    GeneratedAdapter[] arrayOfGeneratedAdapter1 = this.mGeneratedAdapters;
    int i = arrayOfGeneratedAdapter1.length;
    byte b1 = 0;
    for (byte b2 = 0; b2 < i; b2++)
      arrayOfGeneratedAdapter1[b2].callMethods(paramLifecycleOwner, paramEvent, false, methodCallsLogger); 
    GeneratedAdapter[] arrayOfGeneratedAdapter2 = this.mGeneratedAdapters;
    int j = arrayOfGeneratedAdapter2.length;
    while (b1 < j) {
      arrayOfGeneratedAdapter2[b1].callMethods(paramLifecycleOwner, paramEvent, true, methodCallsLogger);
      b1++;
    } 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\CompositeGeneratedAdaptersObserver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */