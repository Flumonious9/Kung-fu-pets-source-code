package android.arch.lifecycle;

import android.support.annotation.Nullable;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

class ClassesInfoCache {
  private static final int CALL_TYPE_NO_ARG = 0;
  
  private static final int CALL_TYPE_PROVIDER = 1;
  
  private static final int CALL_TYPE_PROVIDER_WITH_EVENT = 2;
  
  static ClassesInfoCache a = new ClassesInfoCache();
  
  private final Map<Class, CallbackInfo> mCallbackMap = (Map)new HashMap<Class<?>, CallbackInfo>();
  
  private final Map<Class, Boolean> mHasLifecycleMethods = (Map)new HashMap<Class<?>, Boolean>();
  
  private CallbackInfo createInfo(Class paramClass, @Nullable Method[] paramArrayOfMethod) {
    Class clazz = paramClass.getSuperclass();
    HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
    if (clazz != null) {
      CallbackInfo callbackInfo1 = b(clazz);
      if (callbackInfo1 != null)
        hashMap.putAll(callbackInfo1.b); 
    } 
    Class[] arrayOfClass = paramClass.getInterfaces();
    int i = arrayOfClass.length;
    for (byte b1 = 0; b1 < i; b1++) {
      for (Map.Entry<MethodReference, Lifecycle.Event> entry : (b(arrayOfClass[b1])).b.entrySet())
        verifyAndPutHandler((Map)hashMap, (MethodReference)entry.getKey(), (Lifecycle.Event)entry.getValue(), paramClass); 
    } 
    if (paramArrayOfMethod == null)
      paramArrayOfMethod = getDeclaredMethods(paramClass); 
    int j = paramArrayOfMethod.length;
    byte b2 = 0;
    boolean bool = false;
    while (b2 < j) {
      Method method = paramArrayOfMethod[b2];
      OnLifecycleEvent onLifecycleEvent = method.<OnLifecycleEvent>getAnnotation(OnLifecycleEvent.class);
      if (onLifecycleEvent != null) {
        byte b;
        Class[] arrayOfClass1 = method.getParameterTypes();
        if (arrayOfClass1.length > 0) {
          if (arrayOfClass1[0].isAssignableFrom(LifecycleOwner.class)) {
            b = 1;
          } else {
            throw new IllegalArgumentException("invalid parameter type. Must be one and instanceof LifecycleOwner");
          } 
        } else {
          b = 0;
        } 
        Lifecycle.Event event = onLifecycleEvent.value();
        if (arrayOfClass1.length > 1)
          if (arrayOfClass1[1].isAssignableFrom(Lifecycle.Event.class)) {
            if (event == Lifecycle.Event.ON_ANY) {
              b = 2;
            } else {
              throw new IllegalArgumentException("Second arg is supported only for ON_ANY value");
            } 
          } else {
            throw new IllegalArgumentException("invalid parameter type. second arg must be an event");
          }  
        if (arrayOfClass1.length <= 2) {
          verifyAndPutHandler((Map)hashMap, new MethodReference(b, method), event, paramClass);
          bool = true;
        } else {
          throw new IllegalArgumentException("cannot have more than 2 params");
        } 
      } 
      b2++;
    } 
    CallbackInfo callbackInfo = new CallbackInfo((Map)hashMap);
    this.mCallbackMap.put(paramClass, callbackInfo);
    this.mHasLifecycleMethods.put(paramClass, Boolean.valueOf(bool));
    return callbackInfo;
  }
  
  private Method[] getDeclaredMethods(Class paramClass) {
    try {
      return paramClass.getDeclaredMethods();
    } catch (NoClassDefFoundError noClassDefFoundError) {
      throw new IllegalArgumentException("The observer class has some methods that use newer APIs which are not available in the current OS version. Lifecycles cannot access even other methods so you should make sure that your observer classes only access framework classes that are available in your min API level OR use lifecycle:compiler annotation processor.", noClassDefFoundError);
    } 
  }
  
  private void verifyAndPutHandler(Map<MethodReference, Lifecycle.Event> paramMap, MethodReference paramMethodReference, Lifecycle.Event paramEvent, Class paramClass) {
    Lifecycle.Event event = paramMap.get(paramMethodReference);
    if (event == null || paramEvent == event) {
      if (event == null)
        paramMap.put(paramMethodReference, paramEvent); 
      return;
    } 
    Method method = paramMethodReference.b;
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(method.getName());
    stringBuilder.append(" in ");
    stringBuilder.append(paramClass.getName());
    stringBuilder.append(" already declared with different @OnLifecycleEvent value: previous");
    stringBuilder.append(" value ");
    stringBuilder.append(event);
    stringBuilder.append(", new value ");
    stringBuilder.append(paramEvent);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  boolean a(Class paramClass) {
    if (this.mHasLifecycleMethods.containsKey(paramClass))
      return ((Boolean)this.mHasLifecycleMethods.get(paramClass)).booleanValue(); 
    Method[] arrayOfMethod = getDeclaredMethods(paramClass);
    int i = arrayOfMethod.length;
    for (byte b = 0; b < i; b++) {
      if ((OnLifecycleEvent)arrayOfMethod[b].<OnLifecycleEvent>getAnnotation(OnLifecycleEvent.class) != null) {
        createInfo(paramClass, arrayOfMethod);
        return true;
      } 
    } 
    this.mHasLifecycleMethods.put(paramClass, Boolean.valueOf(false));
    return false;
  }
  
  CallbackInfo b(Class paramClass) {
    CallbackInfo callbackInfo = this.mCallbackMap.get(paramClass);
    return (callbackInfo != null) ? callbackInfo : createInfo(paramClass, null);
  }
  
  static class CallbackInfo {
    final Map<Lifecycle.Event, List<ClassesInfoCache.MethodReference>> a;
    
    final Map<ClassesInfoCache.MethodReference, Lifecycle.Event> b;
    
    CallbackInfo(Map<ClassesInfoCache.MethodReference, Lifecycle.Event> param1Map) {
      this.b = param1Map;
      this.a = new HashMap<Lifecycle.Event, List<ClassesInfoCache.MethodReference>>();
      for (Map.Entry<ClassesInfoCache.MethodReference, Lifecycle.Event> entry : param1Map.entrySet()) {
        Lifecycle.Event event = (Lifecycle.Event)entry.getValue();
        List<ClassesInfoCache.MethodReference> list = this.a.get(event);
        if (list == null) {
          list = new ArrayList();
          this.a.put(event, list);
        } 
        list.add((ClassesInfoCache.MethodReference)entry.getKey());
      } 
    }
    
    private static void invokeMethodsForEvent(List<ClassesInfoCache.MethodReference> param1List, LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event, Object param1Object) {
      if (param1List != null)
        for (int i = -1 + param1List.size(); i >= 0; i--)
          ((ClassesInfoCache.MethodReference)param1List.get(i)).a(param1LifecycleOwner, param1Event, param1Object);  
    }
    
    void a(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event, Object param1Object) {
      invokeMethodsForEvent(this.a.get(param1Event), param1LifecycleOwner, param1Event, param1Object);
      invokeMethodsForEvent(this.a.get(Lifecycle.Event.ON_ANY), param1LifecycleOwner, param1Event, param1Object);
    }
  }
  
  static class MethodReference {
    final int a;
    
    final Method b;
    
    MethodReference(int param1Int, Method param1Method) {
      this.a = param1Int;
      this.b = param1Method;
      this.b.setAccessible(true);
    }
    
    void a(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event, Object param1Object) {
      try {
        switch (this.a) {
          case 2:
            this.b.invoke(param1Object, new Object[] { param1LifecycleOwner, param1Event });
            return;
          case 1:
            this.b.invoke(param1Object, new Object[] { param1LifecycleOwner });
            return;
          case 0:
            this.b.invoke(param1Object, new Object[0]);
            return;
        } 
      } catch (InvocationTargetException invocationTargetException) {
        throw new RuntimeException("Failed to call observer method", invocationTargetException.getCause());
      } catch (IllegalAccessException illegalAccessException) {
        throw new RuntimeException(illegalAccessException);
      } 
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object != null) {
        if (getClass() != param1Object.getClass())
          return false; 
        MethodReference methodReference = (MethodReference)param1Object;
        return (this.a == methodReference.a && this.b.getName().equals(methodReference.b.getName()));
      } 
      return false;
    }
    
    public int hashCode() {
      return 31 * this.a + this.b.getName().hashCode();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\ClassesInfoCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */