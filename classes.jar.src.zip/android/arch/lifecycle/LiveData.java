package android.arch.lifecycle;

import android.arch.core.executor.ArchTaskExecutor;
import android.arch.core.internal.SafeIterableMap;
import android.support.annotation.MainThread;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import java.util.Map;

public abstract class LiveData<T> {
  private static final Object NOT_SET = new Object();
  
  private int mActiveCount = 0;
  
  private volatile Object mData = NOT_SET;
  
  private final Object mDataLock = new Object();
  
  private boolean mDispatchInvalidated;
  
  private boolean mDispatchingValue;
  
  private SafeIterableMap<Observer<T>, ObserverWrapper> mObservers = new SafeIterableMap();
  
  private volatile Object mPendingData = NOT_SET;
  
  private final Runnable mPostValueRunnable = new Runnable(this) {
      public void run() {
        synchronized (LiveData.a(this.a)) {
          Object object = LiveData.b(this.a);
          LiveData.a(this.a, LiveData.a());
          this.a.setValue(object);
          return;
        } 
      }
    };
  
  private int mVersion = -1;
  
  private static void assertMainThread(String paramString) {
    if (ArchTaskExecutor.getInstance().isMainThread())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Cannot invoke ");
    stringBuilder.append(paramString);
    stringBuilder.append(" on a background");
    stringBuilder.append(" thread");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void considerNotify(ObserverWrapper paramObserverWrapper) {
    if (!paramObserverWrapper.d)
      return; 
    if (!paramObserverWrapper.a()) {
      paramObserverWrapper.a(false);
      return;
    } 
    if (paramObserverWrapper.e >= this.mVersion)
      return; 
    paramObserverWrapper.e = this.mVersion;
    paramObserverWrapper.c.onChanged((T)this.mData);
  }
  
  private void dispatchingValue(@Nullable ObserverWrapper paramObserverWrapper) {
    if (this.mDispatchingValue) {
      this.mDispatchInvalidated = true;
      return;
    } 
    this.mDispatchingValue = true;
    while (true) {
      this.mDispatchInvalidated = false;
      if (paramObserverWrapper != null) {
        considerNotify(paramObserverWrapper);
        paramObserverWrapper = null;
      } else {
        SafeIterableMap.IteratorWithAdditions<Map.Entry> iteratorWithAdditions = this.mObservers.iteratorWithAdditions();
        while (iteratorWithAdditions.hasNext()) {
          considerNotify((ObserverWrapper)((Map.Entry)iteratorWithAdditions.next()).getValue());
          if (this.mDispatchInvalidated)
            break; 
        } 
      } 
      if (!this.mDispatchInvalidated) {
        this.mDispatchingValue = false;
        return;
      } 
    } 
  }
  
  @Nullable
  public T getValue() {
    Object object = this.mData;
    return (T)((object != NOT_SET) ? object : null);
  }
  
  int getVersion() {
    return this.mVersion;
  }
  
  public boolean hasActiveObservers() {
    return (this.mActiveCount > 0);
  }
  
  public boolean hasObservers() {
    return (this.mObservers.size() > 0);
  }
  
  @MainThread
  public void observe(@NonNull LifecycleOwner paramLifecycleOwner, @NonNull Observer<T> paramObserver) {
    if (paramLifecycleOwner.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED)
      return; 
    LifecycleBoundObserver lifecycleBoundObserver = new LifecycleBoundObserver(this, paramLifecycleOwner, paramObserver);
    ObserverWrapper observerWrapper = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, lifecycleBoundObserver);
    if (observerWrapper == null || observerWrapper.a(paramLifecycleOwner)) {
      if (observerWrapper != null)
        return; 
      paramLifecycleOwner.getLifecycle().addObserver(lifecycleBoundObserver);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  @MainThread
  public void observeForever(@NonNull Observer<T> paramObserver) {
    AlwaysActiveObserver alwaysActiveObserver = new AlwaysActiveObserver(this, paramObserver);
    ObserverWrapper observerWrapper = (ObserverWrapper)this.mObservers.putIfAbsent(paramObserver, alwaysActiveObserver);
    if (observerWrapper == null || !(observerWrapper instanceof LifecycleBoundObserver)) {
      if (observerWrapper != null)
        return; 
      alwaysActiveObserver.a(true);
      return;
    } 
    throw new IllegalArgumentException("Cannot add the same observer with different lifecycles");
  }
  
  protected void onActive() {}
  
  protected void onInactive() {}
  
  protected void postValue(T paramT) {
    synchronized (this.mDataLock) {
      boolean bool;
      if (this.mPendingData == NOT_SET) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mPendingData = paramT;
      if (!bool)
        return; 
      ArchTaskExecutor.getInstance().postToMainThread(this.mPostValueRunnable);
      return;
    } 
  }
  
  @MainThread
  public void removeObserver(@NonNull Observer<T> paramObserver) {
    assertMainThread("removeObserver");
    ObserverWrapper observerWrapper = (ObserverWrapper)this.mObservers.remove(paramObserver);
    if (observerWrapper == null)
      return; 
    observerWrapper.b();
    observerWrapper.a(false);
  }
  
  @MainThread
  public void removeObservers(@NonNull LifecycleOwner paramLifecycleOwner) {
    assertMainThread("removeObservers");
    for (Map.Entry entry : this.mObservers) {
      if (((ObserverWrapper)entry.getValue()).a(paramLifecycleOwner))
        removeObserver((Observer<T>)entry.getKey()); 
    } 
  }
  
  @MainThread
  protected void setValue(T paramT) {
    assertMainThread("setValue");
    this.mVersion = 1 + this.mVersion;
    this.mData = paramT;
    dispatchingValue(null);
  }
  
  private class AlwaysActiveObserver extends ObserverWrapper {
    AlwaysActiveObserver(LiveData this$0, Observer<T> param1Observer) {
      super(this$0, param1Observer);
    }
    
    boolean a() {
      return true;
    }
  }
  
  class LifecycleBoundObserver extends ObserverWrapper implements GenericLifecycleObserver {
    @NonNull
    final LifecycleOwner a;
    
    LifecycleBoundObserver(LiveData this$0, @NonNull LifecycleOwner param1LifecycleOwner, Observer<T> param1Observer) {
      super(this$0, param1Observer);
      this.a = param1LifecycleOwner;
    }
    
    boolean a() {
      return this.a.getLifecycle().getCurrentState().isAtLeast(Lifecycle.State.STARTED);
    }
    
    boolean a(LifecycleOwner param1LifecycleOwner) {
      return (this.a == param1LifecycleOwner);
    }
    
    void b() {
      this.a.getLifecycle().removeObserver(this);
    }
    
    public void onStateChanged(LifecycleOwner param1LifecycleOwner, Lifecycle.Event param1Event) {
      if (this.a.getLifecycle().getCurrentState() == Lifecycle.State.DESTROYED) {
        this.b.removeObserver(this.c);
        return;
      } 
      a(a());
    }
  }
  
  private abstract class ObserverWrapper {
    final Observer<T> c;
    
    boolean d;
    
    int e = -1;
    
    ObserverWrapper(LiveData this$0, Observer<T> param1Observer) {
      this.c = param1Observer;
    }
    
    void a(boolean param1Boolean) {
      boolean bool;
      if (param1Boolean == this.d)
        return; 
      this.d = param1Boolean;
      int i = LiveData.c(this.f);
      byte b = 1;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      LiveData liveData = this.f;
      int j = LiveData.c(liveData);
      if (!this.d)
        b = -1; 
      LiveData.a(liveData, j + b);
      if (bool && this.d)
        this.f.onActive(); 
      if (LiveData.c(this.f) == 0 && !this.d)
        this.f.onInactive(); 
      if (this.d)
        LiveData.a(this.f, this); 
    }
    
    abstract boolean a();
    
    boolean a(LifecycleOwner param1LifecycleOwner) {
      return false;
    }
    
    void b() {}
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\LiveData.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */