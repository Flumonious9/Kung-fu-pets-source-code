package android.arch.lifecycle;

class FullLifecycleObserverAdapter implements GenericLifecycleObserver {
  private final FullLifecycleObserver mObserver;
  
  FullLifecycleObserverAdapter(FullLifecycleObserver paramFullLifecycleObserver) {
    this.mObserver = paramFullLifecycleObserver;
  }
  
  public void onStateChanged(LifecycleOwner paramLifecycleOwner, Lifecycle.Event paramEvent) {
    switch (null.a[paramEvent.ordinal()]) {
      default:
        return;
      case 7:
        throw new IllegalArgumentException("ON_ANY must not been send by anybody");
      case 6:
        this.mObserver.onDestroy(paramLifecycleOwner);
        return;
      case 5:
        this.mObserver.onStop(paramLifecycleOwner);
        return;
      case 4:
        this.mObserver.onPause(paramLifecycleOwner);
        return;
      case 3:
        this.mObserver.onResume(paramLifecycleOwner);
        return;
      case 2:
        this.mObserver.onStart(paramLifecycleOwner);
        return;
      case 1:
        break;
    } 
    this.mObserver.onCreate(paramLifecycleOwner);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\arch\lifecycle\FullLifecycleObserverAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */