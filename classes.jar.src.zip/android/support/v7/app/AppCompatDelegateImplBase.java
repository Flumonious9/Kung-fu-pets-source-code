package android.support.v7.app;

import android.app.Activity;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.support.v7.appcompat.R;
import android.support.v7.view.ActionMode;
import android.support.v7.view.SupportMenuInflater;
import android.support.v7.view.WindowCallbackWrapper;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.widget.TintTypedArray;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.Window;

@RequiresApi(14)
abstract class AppCompatDelegateImplBase extends AppCompatDelegate {
  private static final boolean SHOULD_INSTALL_EXCEPTION_HANDLER;
  
  private static boolean sInstalledExceptionHandler;
  
  private static final int[] sWindowBackgroundStyleable = new int[] { 16842836 };
  
  final Context a;
  
  final Window b;
  
  final Window.Callback c;
  
  final Window.Callback d;
  
  final AppCompatCallback e;
  
  ActionBar f;
  
  MenuInflater g;
  
  boolean h;
  
  boolean i;
  
  boolean j;
  
  boolean k;
  
  boolean l;
  
  private boolean mEatKeyUpEvent;
  
  private boolean mIsDestroyed;
  
  private boolean mIsStarted;
  
  private CharSequence mTitle;
  
  AppCompatDelegateImplBase(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback) {
    this.a = paramContext;
    this.b = paramWindow;
    this.e = paramAppCompatCallback;
    this.c = this.b.getCallback();
    if (!(this.c instanceof AppCompatWindowCallbackBase)) {
      this.d = a(this.c);
      this.b.setCallback(this.d);
      TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, null, sWindowBackgroundStyleable);
      Drawable drawable = tintTypedArray.getDrawableIfKnown(0);
      if (drawable != null)
        this.b.setBackgroundDrawable(drawable); 
      tintTypedArray.recycle();
      return;
    } 
    throw new IllegalStateException("AppCompat has already installed itself into the Window");
  }
  
  final ActionBar a() {
    return this.f;
  }
  
  abstract ActionMode a(ActionMode.Callback paramCallback);
  
  Window.Callback a(Window.Callback paramCallback) {
    return (Window.Callback)new AppCompatWindowCallbackBase(this, paramCallback);
  }
  
  abstract void a(int paramInt, Menu paramMenu);
  
  abstract void a(CharSequence paramCharSequence);
  
  abstract boolean a(int paramInt, KeyEvent paramKeyEvent);
  
  abstract boolean a(KeyEvent paramKeyEvent);
  
  public boolean applyDayNight() {
    return false;
  }
  
  abstract boolean b(int paramInt, Menu paramMenu);
  
  final Context getActionBarThemedContext() {
    Context context;
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null) {
      context = actionBar.getThemedContext();
    } else {
      context = null;
    } 
    if (context == null)
      context = this.a; 
    return context;
  }
  
  public final ActionBarDrawerToggle.Delegate getDrawerToggleDelegate() {
    return new ActionBarDrawableToggleImpl(this);
  }
  
  public MenuInflater getMenuInflater() {
    if (this.g == null) {
      Context context;
      initWindowDecorActionBar();
      if (this.f != null) {
        context = this.f.getThemedContext();
      } else {
        context = this.a;
      } 
      this.g = (MenuInflater)new SupportMenuInflater(context);
    } 
    return this.g;
  }
  
  public ActionBar getSupportActionBar() {
    initWindowDecorActionBar();
    return this.f;
  }
  
  final CharSequence getTitle() {
    return (this.c instanceof Activity) ? ((Activity)this.c).getTitle() : this.mTitle;
  }
  
  final Window.Callback getWindowCallback() {
    return this.b.getCallback();
  }
  
  abstract void initWindowDecorActionBar();
  
  final boolean isDestroyed() {
    return this.mIsDestroyed;
  }
  
  public boolean isHandleNativeActionModesEnabled() {
    return false;
  }
  
  final boolean isStarted() {
    return this.mIsStarted;
  }
  
  public void onDestroy() {
    this.mIsDestroyed = true;
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {}
  
  public void onStart() {
    this.mIsStarted = true;
  }
  
  public void onStop() {
    this.mIsStarted = false;
  }
  
  public void setHandleNativeActionModesEnabled(boolean paramBoolean) {}
  
  public void setLocalNightMode(int paramInt) {}
  
  public final void setTitle(CharSequence paramCharSequence) {
    this.mTitle = paramCharSequence;
    a(paramCharSequence);
  }
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT < 21) {
      bool = true;
    } else {
      bool = false;
    } 
    SHOULD_INSTALL_EXCEPTION_HANDLER = bool;
    if (SHOULD_INSTALL_EXCEPTION_HANDLER && !sInstalledExceptionHandler) {
      Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler(Thread.getDefaultUncaughtExceptionHandler()) {
            private boolean shouldWrapException(Throwable param1Throwable) {
              if (param1Throwable instanceof Resources.NotFoundException) {
                String str = param1Throwable.getMessage();
                boolean bool = false;
                if (str != null) {
                  if (!str.contains("drawable")) {
                    boolean bool1 = str.contains("Drawable");
                    bool = false;
                    return bool1 ? true : bool;
                  } 
                } else {
                  return bool;
                } 
              } else {
                return false;
              } 
              return true;
            }
            
            public void uncaughtException(Thread param1Thread, Throwable param1Throwable) {
              if (shouldWrapException(param1Throwable)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append(param1Throwable.getMessage());
                stringBuilder.append(". If the resource you are trying to use is a vector resource, you may be referencing it in an unsupported way. See AppCompatDelegate.setCompatVectorFromResourcesEnabled() for more info.");
                Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
                notFoundException.initCause(param1Throwable.getCause());
                notFoundException.setStackTrace(param1Throwable.getStackTrace());
                this.a.uncaughtException(param1Thread, (Throwable)notFoundException);
                return;
              } 
              this.a.uncaughtException(param1Thread, param1Throwable);
            }
          });
      sInstalledExceptionHandler = true;
    } 
  }
  
  private class ActionBarDrawableToggleImpl implements ActionBarDrawerToggle.Delegate {
    ActionBarDrawableToggleImpl(AppCompatDelegateImplBase this$0) {}
    
    public Context getActionBarThemedContext() {
      return this.a.getActionBarThemedContext();
    }
    
    public Drawable getThemeUpIndicator() {
      Context context = getActionBarThemedContext();
      int[] arrayOfInt = new int[1];
      arrayOfInt[0] = R.attr.homeAsUpIndicator;
      TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(context, null, arrayOfInt);
      Drawable drawable = tintTypedArray.getDrawable(0);
      tintTypedArray.recycle();
      return drawable;
    }
    
    public boolean isNavigationVisible() {
      ActionBar actionBar = this.a.getSupportActionBar();
      return (actionBar != null && (0x4 & actionBar.getDisplayOptions()) != 0);
    }
    
    public void setActionBarDescription(int param1Int) {
      ActionBar actionBar = this.a.getSupportActionBar();
      if (actionBar != null)
        actionBar.setHomeActionContentDescription(param1Int); 
    }
    
    public void setActionBarUpIndicator(Drawable param1Drawable, int param1Int) {
      ActionBar actionBar = this.a.getSupportActionBar();
      if (actionBar != null) {
        actionBar.setHomeAsUpIndicator(param1Drawable);
        actionBar.setHomeActionContentDescription(param1Int);
      } 
    }
  }
  
  class AppCompatWindowCallbackBase extends WindowCallbackWrapper {
    AppCompatWindowCallbackBase(AppCompatDelegateImplBase this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.a.a(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean dispatchKeyShortcutEvent(KeyEvent param1KeyEvent) {
      return (super.dispatchKeyShortcutEvent(param1KeyEvent) || this.a.a(param1KeyEvent.getKeyCode(), param1KeyEvent));
    }
    
    public void onContentChanged() {}
    
    public boolean onCreatePanelMenu(int param1Int, Menu param1Menu) {
      return (param1Int == 0 && !(param1Menu instanceof MenuBuilder)) ? false : super.onCreatePanelMenu(param1Int, param1Menu);
    }
    
    public boolean onMenuOpened(int param1Int, Menu param1Menu) {
      super.onMenuOpened(param1Int, param1Menu);
      this.a.b(param1Int, param1Menu);
      return true;
    }
    
    public void onPanelClosed(int param1Int, Menu param1Menu) {
      super.onPanelClosed(param1Int, param1Menu);
      this.a.a(param1Int, param1Menu);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      MenuBuilder menuBuilder;
      if (param1Menu instanceof MenuBuilder) {
        menuBuilder = (MenuBuilder)param1Menu;
      } else {
        menuBuilder = null;
      } 
      if (param1Int == 0 && menuBuilder == null)
        return false; 
      if (menuBuilder != null)
        menuBuilder.setOverrideVisibleItems(true); 
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (menuBuilder != null)
        menuBuilder.setOverrideVisibleItems(false); 
      return bool;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AppCompatDelegateImplBase.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */