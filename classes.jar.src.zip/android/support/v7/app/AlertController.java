package android.support.v7.app;

import android.content.Context;
import android.content.DialogInterface;
import android.content.res.TypedArray;
import android.database.Cursor;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.support.v4.widget.NestedScrollView;
import android.support.v7.appcompat.R;
import android.support.v7.widget.LinearLayoutCompat;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewStub;
import android.view.Window;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.CursorAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;
import java.lang.ref.WeakReference;

class AlertController {
  final AppCompatDialog a;
  
  ListView b;
  
  Button c;
  
  Message d;
  
  Button e;
  
  Message f;
  
  Button g;
  
  Message h;
  
  NestedScrollView i;
  
  ListAdapter j;
  
  int k = -1;
  
  int l;
  
  int m;
  
  private int mAlertDialogLayout;
  
  private final View.OnClickListener mButtonHandler = new View.OnClickListener(this) {
      public void onClick(View param1View) {
        Message message;
        if (param1View == this.a.c && this.a.d != null) {
          message = Message.obtain(this.a.d);
        } else if (param1View == this.a.e && this.a.f != null) {
          message = Message.obtain(this.a.f);
        } else if (param1View == this.a.g && this.a.h != null) {
          message = Message.obtain(this.a.h);
        } else {
          message = null;
        } 
        if (message != null)
          message.sendToTarget(); 
        this.a.p.obtainMessage(1, this.a.a).sendToTarget();
      }
    };
  
  private final int mButtonIconDimen;
  
  private Drawable mButtonNegativeIcon;
  
  private CharSequence mButtonNegativeText;
  
  private Drawable mButtonNeutralIcon;
  
  private CharSequence mButtonNeutralText;
  
  private int mButtonPanelLayoutHint = 0;
  
  private int mButtonPanelSideLayout;
  
  private Drawable mButtonPositiveIcon;
  
  private CharSequence mButtonPositiveText;
  
  private final Context mContext;
  
  private View mCustomTitleView;
  
  private Drawable mIcon;
  
  private int mIconId = 0;
  
  private ImageView mIconView;
  
  private CharSequence mMessage;
  
  private TextView mMessageView;
  
  private boolean mShowTitle;
  
  private CharSequence mTitle;
  
  private TextView mTitleView;
  
  private View mView;
  
  private int mViewLayoutResId;
  
  private int mViewSpacingBottom;
  
  private int mViewSpacingLeft;
  
  private int mViewSpacingRight;
  
  private boolean mViewSpacingSpecified = false;
  
  private int mViewSpacingTop;
  
  private final Window mWindow;
  
  int n;
  
  int o;
  
  Handler p;
  
  public AlertController(Context paramContext, AppCompatDialog paramAppCompatDialog, Window paramWindow) {
    this.mContext = paramContext;
    this.a = paramAppCompatDialog;
    this.mWindow = paramWindow;
    this.p = new ButtonHandler((DialogInterface)paramAppCompatDialog);
    TypedArray typedArray = paramContext.obtainStyledAttributes(null, R.styleable.AlertDialog, R.attr.alertDialogStyle, 0);
    this.mAlertDialogLayout = typedArray.getResourceId(R.styleable.AlertDialog_android_layout, 0);
    this.mButtonPanelSideLayout = typedArray.getResourceId(R.styleable.AlertDialog_buttonPanelSideLayout, 0);
    this.l = typedArray.getResourceId(R.styleable.AlertDialog_listLayout, 0);
    this.m = typedArray.getResourceId(R.styleable.AlertDialog_multiChoiceItemLayout, 0);
    this.n = typedArray.getResourceId(R.styleable.AlertDialog_singleChoiceItemLayout, 0);
    this.o = typedArray.getResourceId(R.styleable.AlertDialog_listItemLayout, 0);
    this.mShowTitle = typedArray.getBoolean(R.styleable.AlertDialog_showTitle, true);
    this.mButtonIconDimen = typedArray.getDimensionPixelSize(R.styleable.AlertDialog_buttonIconDimen, 0);
    typedArray.recycle();
    paramAppCompatDialog.supportRequestWindowFeature(1);
  }
  
  static void a(View paramView1, View paramView2, View paramView3) {
    byte b = 4;
    if (paramView2 != null) {
      byte b1;
      if (paramView1.canScrollVertically(-1)) {
        b1 = 0;
      } else {
        b1 = 4;
      } 
      paramView2.setVisibility(b1);
    } 
    if (paramView3 != null) {
      if (paramView1.canScrollVertically(1))
        b = 0; 
      paramView3.setVisibility(b);
    } 
  }
  
  static boolean a(View paramView) {
    if (paramView.onCheckIsTextEditor())
      return true; 
    if (!(paramView instanceof ViewGroup))
      return false; 
    ViewGroup viewGroup = (ViewGroup)paramView;
    int i = viewGroup.getChildCount();
    while (i > 0) {
      if (a(viewGroup.getChildAt(--i)))
        return true; 
    } 
    return false;
  }
  
  private void centerButton(Button paramButton) {
    LinearLayout.LayoutParams layoutParams = (LinearLayout.LayoutParams)paramButton.getLayoutParams();
    layoutParams.gravity = 1;
    layoutParams.weight = 0.5F;
    paramButton.setLayoutParams((ViewGroup.LayoutParams)layoutParams);
  }
  
  @Nullable
  private ViewGroup resolvePanel(@Nullable View paramView1, @Nullable View paramView2) {
    if (paramView1 == null) {
      if (paramView2 instanceof ViewStub)
        paramView2 = ((ViewStub)paramView2).inflate(); 
      return (ViewGroup)paramView2;
    } 
    if (paramView2 != null) {
      ViewParent viewParent = paramView2.getParent();
      if (viewParent instanceof ViewGroup)
        ((ViewGroup)viewParent).removeView(paramView2); 
    } 
    if (paramView1 instanceof ViewStub)
      paramView1 = ((ViewStub)paramView1).inflate(); 
    return (ViewGroup)paramView1;
  }
  
  private int selectContentView() {
    return (this.mButtonPanelSideLayout == 0) ? this.mAlertDialogLayout : ((this.mButtonPanelLayoutHint == 1) ? this.mButtonPanelSideLayout : this.mAlertDialogLayout);
  }
  
  private void setScrollIndicators(ViewGroup paramViewGroup, View paramView, int paramInt1, int paramInt2) {
    View view1 = this.mWindow.findViewById(R.id.scrollIndicatorUp);
    View view2 = this.mWindow.findViewById(R.id.scrollIndicatorDown);
    if (Build.VERSION.SDK_INT >= 23) {
      ViewCompat.setScrollIndicators(paramView, paramInt1, paramInt2);
      if (view1 != null)
        paramViewGroup.removeView(view1); 
      if (view2 != null) {
        paramViewGroup.removeView(view2);
        return;
      } 
    } else {
      View view;
      if (view1 != null && (paramInt1 & 0x1) == 0) {
        paramViewGroup.removeView(view1);
        view1 = null;
      } 
      if (view2 != null && (paramInt1 & 0x2) == 0) {
        paramViewGroup.removeView(view2);
        view = null;
      } else {
        view = view2;
      } 
      if (view1 != null || view != null) {
        if (this.mMessage != null) {
          this.i.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener(this, view1, view) {
                public void onScrollChange(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
                  AlertController.a((View)param1NestedScrollView, this.a, this.b);
                }
              });
          this.i.post(new Runnable(this, view1, view) {
                public void run() {
                  AlertController.a((View)this.c.i, this.a, this.b);
                }
              });
          return;
        } 
        if (this.b != null) {
          this.b.setOnScrollListener(new AbsListView.OnScrollListener(this, view1, view) {
                public void onScroll(AbsListView param1AbsListView, int param1Int1, int param1Int2, int param1Int3) {
                  AlertController.a((View)param1AbsListView, this.a, this.b);
                }
                
                public void onScrollStateChanged(AbsListView param1AbsListView, int param1Int) {}
              });
          this.b.post(new Runnable(this, view1, view) {
                public void run() {
                  AlertController.a((View)this.c.b, this.a, this.b);
                }
              });
          return;
        } 
        if (view1 != null)
          paramViewGroup.removeView(view1); 
        if (view != null)
          paramViewGroup.removeView(view); 
      } 
    } 
  }
  
  private void setupButtons(ViewGroup paramViewGroup) {
    int i;
    this.c = (Button)paramViewGroup.findViewById(16908313);
    this.c.setOnClickListener(this.mButtonHandler);
    boolean bool = TextUtils.isEmpty(this.mButtonPositiveText);
    byte b = 1;
    if (bool && this.mButtonPositiveIcon == null) {
      this.c.setVisibility(8);
      i = 0;
    } else {
      this.c.setText(this.mButtonPositiveText);
      if (this.mButtonPositiveIcon != null) {
        this.mButtonPositiveIcon.setBounds(0, 0, this.mButtonIconDimen, this.mButtonIconDimen);
        this.c.setCompoundDrawables(this.mButtonPositiveIcon, null, null, null);
      } 
      this.c.setVisibility(0);
      i = 1;
    } 
    this.e = (Button)paramViewGroup.findViewById(16908314);
    this.e.setOnClickListener(this.mButtonHandler);
    if (TextUtils.isEmpty(this.mButtonNegativeText) && this.mButtonNegativeIcon == null) {
      this.e.setVisibility(8);
    } else {
      this.e.setText(this.mButtonNegativeText);
      if (this.mButtonNegativeIcon != null) {
        this.mButtonNegativeIcon.setBounds(0, 0, this.mButtonIconDimen, this.mButtonIconDimen);
        this.e.setCompoundDrawables(this.mButtonNegativeIcon, null, null, null);
      } 
      this.e.setVisibility(0);
      i |= 0x2;
    } 
    this.g = (Button)paramViewGroup.findViewById(16908315);
    this.g.setOnClickListener(this.mButtonHandler);
    if (TextUtils.isEmpty(this.mButtonNeutralText) && this.mButtonNeutralIcon == null) {
      this.g.setVisibility(8);
    } else {
      this.g.setText(this.mButtonNeutralText);
      if (this.mButtonPositiveIcon != null) {
        this.mButtonPositiveIcon.setBounds(0, 0, this.mButtonIconDimen, this.mButtonIconDimen);
        this.c.setCompoundDrawables(this.mButtonPositiveIcon, null, null, null);
      } 
      this.g.setVisibility(0);
      i |= 0x4;
    } 
    if (shouldCenterSingleButton(this.mContext))
      if (i == b) {
        centerButton(this.c);
      } else if (i == 2) {
        centerButton(this.e);
      } else if (i == 4) {
        centerButton(this.g);
      }  
    if (i == 0)
      b = 0; 
    if (b == 0)
      paramViewGroup.setVisibility(8); 
  }
  
  private void setupContent(ViewGroup paramViewGroup) {
    this.i = (NestedScrollView)this.mWindow.findViewById(R.id.scrollView);
    this.i.setFocusable(false);
    this.i.setNestedScrollingEnabled(false);
    this.mMessageView = (TextView)paramViewGroup.findViewById(16908299);
    if (this.mMessageView == null)
      return; 
    if (this.mMessage != null) {
      this.mMessageView.setText(this.mMessage);
      return;
    } 
    this.mMessageView.setVisibility(8);
    this.i.removeView((View)this.mMessageView);
    if (this.b != null) {
      ViewGroup viewGroup = (ViewGroup)this.i.getParent();
      int i = viewGroup.indexOfChild((View)this.i);
      viewGroup.removeViewAt(i);
      viewGroup.addView((View)this.b, i, new ViewGroup.LayoutParams(-1, -1));
      return;
    } 
    paramViewGroup.setVisibility(8);
  }
  
  private void setupCustomContent(ViewGroup paramViewGroup) {
    View view;
    if (this.mView != null) {
      view = this.mView;
    } else if (this.mViewLayoutResId != 0) {
      view = LayoutInflater.from(this.mContext).inflate(this.mViewLayoutResId, paramViewGroup, false);
    } else {
      view = null;
    } 
    boolean bool = false;
    if (view != null)
      bool = true; 
    if (!bool || !a(view))
      this.mWindow.setFlags(131072, 131072); 
    if (bool) {
      FrameLayout frameLayout = (FrameLayout)this.mWindow.findViewById(R.id.custom);
      frameLayout.addView(view, new ViewGroup.LayoutParams(-1, -1));
      if (this.mViewSpacingSpecified)
        frameLayout.setPadding(this.mViewSpacingLeft, this.mViewSpacingTop, this.mViewSpacingRight, this.mViewSpacingBottom); 
      if (this.b != null) {
        ((LinearLayoutCompat.LayoutParams)paramViewGroup.getLayoutParams()).weight = 0.0F;
        return;
      } 
    } else {
      paramViewGroup.setVisibility(8);
    } 
  }
  
  private void setupTitle(ViewGroup paramViewGroup) {
    if (this.mCustomTitleView != null) {
      ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-1, -2);
      paramViewGroup.addView(this.mCustomTitleView, 0, layoutParams);
      this.mWindow.findViewById(R.id.title_template).setVisibility(8);
      return;
    } 
    this.mIconView = (ImageView)this.mWindow.findViewById(16908294);
    if ((true ^ TextUtils.isEmpty(this.mTitle)) != 0 && this.mShowTitle) {
      this.mTitleView = (TextView)this.mWindow.findViewById(R.id.alertTitle);
      this.mTitleView.setText(this.mTitle);
      if (this.mIconId != 0) {
        this.mIconView.setImageResource(this.mIconId);
        return;
      } 
      if (this.mIcon != null) {
        this.mIconView.setImageDrawable(this.mIcon);
        return;
      } 
      this.mTitleView.setPadding(this.mIconView.getPaddingLeft(), this.mIconView.getPaddingTop(), this.mIconView.getPaddingRight(), this.mIconView.getPaddingBottom());
      this.mIconView.setVisibility(8);
      return;
    } 
    this.mWindow.findViewById(R.id.title_template).setVisibility(8);
    this.mIconView.setVisibility(8);
    paramViewGroup.setVisibility(8);
  }
  
  private void setupView() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mWindow : Landroid/view/Window;
    //   4: getstatic android/support/v7/appcompat/R$id.parentPanel : I
    //   7: invokevirtual findViewById : (I)Landroid/view/View;
    //   10: astore_1
    //   11: aload_1
    //   12: getstatic android/support/v7/appcompat/R$id.topPanel : I
    //   15: invokevirtual findViewById : (I)Landroid/view/View;
    //   18: astore_2
    //   19: aload_1
    //   20: getstatic android/support/v7/appcompat/R$id.contentPanel : I
    //   23: invokevirtual findViewById : (I)Landroid/view/View;
    //   26: astore_3
    //   27: aload_1
    //   28: getstatic android/support/v7/appcompat/R$id.buttonPanel : I
    //   31: invokevirtual findViewById : (I)Landroid/view/View;
    //   34: astore #4
    //   36: aload_1
    //   37: getstatic android/support/v7/appcompat/R$id.customPanel : I
    //   40: invokevirtual findViewById : (I)Landroid/view/View;
    //   43: checkcast android/view/ViewGroup
    //   46: astore #5
    //   48: aload_0
    //   49: aload #5
    //   51: invokespecial setupCustomContent : (Landroid/view/ViewGroup;)V
    //   54: aload #5
    //   56: getstatic android/support/v7/appcompat/R$id.topPanel : I
    //   59: invokevirtual findViewById : (I)Landroid/view/View;
    //   62: astore #6
    //   64: aload #5
    //   66: getstatic android/support/v7/appcompat/R$id.contentPanel : I
    //   69: invokevirtual findViewById : (I)Landroid/view/View;
    //   72: astore #7
    //   74: aload #5
    //   76: getstatic android/support/v7/appcompat/R$id.buttonPanel : I
    //   79: invokevirtual findViewById : (I)Landroid/view/View;
    //   82: astore #8
    //   84: aload_0
    //   85: aload #6
    //   87: aload_2
    //   88: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   91: astore #9
    //   93: aload_0
    //   94: aload #7
    //   96: aload_3
    //   97: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   100: astore #10
    //   102: aload_0
    //   103: aload #8
    //   105: aload #4
    //   107: invokespecial resolvePanel : (Landroid/view/View;Landroid/view/View;)Landroid/view/ViewGroup;
    //   110: astore #11
    //   112: aload_0
    //   113: aload #10
    //   115: invokespecial setupContent : (Landroid/view/ViewGroup;)V
    //   118: aload_0
    //   119: aload #11
    //   121: invokespecial setupButtons : (Landroid/view/ViewGroup;)V
    //   124: aload_0
    //   125: aload #9
    //   127: invokespecial setupTitle : (Landroid/view/ViewGroup;)V
    //   130: aload #5
    //   132: ifnull -> 151
    //   135: aload #5
    //   137: invokevirtual getVisibility : ()I
    //   140: bipush #8
    //   142: if_icmpeq -> 151
    //   145: iconst_1
    //   146: istore #12
    //   148: goto -> 154
    //   151: iconst_0
    //   152: istore #12
    //   154: aload #9
    //   156: ifnull -> 175
    //   159: aload #9
    //   161: invokevirtual getVisibility : ()I
    //   164: bipush #8
    //   166: if_icmpeq -> 175
    //   169: iconst_1
    //   170: istore #13
    //   172: goto -> 178
    //   175: iconst_0
    //   176: istore #13
    //   178: aload #11
    //   180: ifnull -> 199
    //   183: aload #11
    //   185: invokevirtual getVisibility : ()I
    //   188: bipush #8
    //   190: if_icmpeq -> 199
    //   193: iconst_1
    //   194: istore #14
    //   196: goto -> 202
    //   199: iconst_0
    //   200: istore #14
    //   202: iload #14
    //   204: ifne -> 233
    //   207: aload #10
    //   209: ifnull -> 233
    //   212: aload #10
    //   214: getstatic android/support/v7/appcompat/R$id.textSpacerNoButtons : I
    //   217: invokevirtual findViewById : (I)Landroid/view/View;
    //   220: astore #22
    //   222: aload #22
    //   224: ifnull -> 233
    //   227: aload #22
    //   229: iconst_0
    //   230: invokevirtual setVisibility : (I)V
    //   233: iload #13
    //   235: ifeq -> 298
    //   238: aload_0
    //   239: getfield i : Landroid/support/v4/widget/NestedScrollView;
    //   242: ifnull -> 253
    //   245: aload_0
    //   246: getfield i : Landroid/support/v4/widget/NestedScrollView;
    //   249: iconst_1
    //   250: invokevirtual setClipToPadding : (Z)V
    //   253: aload_0
    //   254: getfield mMessage : Ljava/lang/CharSequence;
    //   257: ifnonnull -> 274
    //   260: aload_0
    //   261: getfield b : Landroid/widget/ListView;
    //   264: astore #21
    //   266: aconst_null
    //   267: astore #20
    //   269: aload #21
    //   271: ifnull -> 284
    //   274: aload #9
    //   276: getstatic android/support/v7/appcompat/R$id.titleDividerNoCustom : I
    //   279: invokevirtual findViewById : (I)Landroid/view/View;
    //   282: astore #20
    //   284: aload #20
    //   286: ifnull -> 324
    //   289: aload #20
    //   291: iconst_0
    //   292: invokevirtual setVisibility : (I)V
    //   295: goto -> 324
    //   298: aload #10
    //   300: ifnull -> 324
    //   303: aload #10
    //   305: getstatic android/support/v7/appcompat/R$id.textSpacerNoTitle : I
    //   308: invokevirtual findViewById : (I)Landroid/view/View;
    //   311: astore #19
    //   313: aload #19
    //   315: ifnull -> 324
    //   318: aload #19
    //   320: iconst_0
    //   321: invokevirtual setVisibility : (I)V
    //   324: aload_0
    //   325: getfield b : Landroid/widget/ListView;
    //   328: instanceof android/support/v7/app/AlertController$RecycleListView
    //   331: ifeq -> 348
    //   334: aload_0
    //   335: getfield b : Landroid/widget/ListView;
    //   338: checkcast android/support/v7/app/AlertController$RecycleListView
    //   341: iload #13
    //   343: iload #14
    //   345: invokevirtual setHasDecor : (ZZ)V
    //   348: iload #12
    //   350: ifne -> 405
    //   353: aload_0
    //   354: getfield b : Landroid/widget/ListView;
    //   357: ifnull -> 369
    //   360: aload_0
    //   361: getfield b : Landroid/widget/ListView;
    //   364: astore #17
    //   366: goto -> 375
    //   369: aload_0
    //   370: getfield i : Landroid/support/v4/widget/NestedScrollView;
    //   373: astore #17
    //   375: aload #17
    //   377: ifnull -> 405
    //   380: iconst_0
    //   381: istore #18
    //   383: iload #14
    //   385: ifeq -> 391
    //   388: iconst_2
    //   389: istore #18
    //   391: aload_0
    //   392: aload #10
    //   394: aload #17
    //   396: iload #13
    //   398: iload #18
    //   400: ior
    //   401: iconst_3
    //   402: invokespecial setScrollIndicators : (Landroid/view/ViewGroup;Landroid/view/View;II)V
    //   405: aload_0
    //   406: getfield b : Landroid/widget/ListView;
    //   409: astore #15
    //   411: aload #15
    //   413: ifnull -> 459
    //   416: aload_0
    //   417: getfield j : Landroid/widget/ListAdapter;
    //   420: ifnull -> 459
    //   423: aload #15
    //   425: aload_0
    //   426: getfield j : Landroid/widget/ListAdapter;
    //   429: invokevirtual setAdapter : (Landroid/widget/ListAdapter;)V
    //   432: aload_0
    //   433: getfield k : I
    //   436: istore #16
    //   438: iload #16
    //   440: iconst_m1
    //   441: if_icmple -> 459
    //   444: aload #15
    //   446: iload #16
    //   448: iconst_1
    //   449: invokevirtual setItemChecked : (IZ)V
    //   452: aload #15
    //   454: iload #16
    //   456: invokevirtual setSelection : (I)V
    //   459: return
  }
  
  private static boolean shouldCenterSingleButton(Context paramContext) {
    TypedValue typedValue = new TypedValue();
    paramContext.getTheme().resolveAttribute(R.attr.alertDialogCenterButtons, typedValue, true);
    return (typedValue.data != 0);
  }
  
  public Button getButton(int paramInt) {
    switch (paramInt) {
      default:
        return null;
      case -1:
        return this.c;
      case -2:
        return this.e;
      case -3:
        break;
    } 
    return this.g;
  }
  
  public int getIconAttributeResId(int paramInt) {
    TypedValue typedValue = new TypedValue();
    this.mContext.getTheme().resolveAttribute(paramInt, typedValue, true);
    return typedValue.resourceId;
  }
  
  public ListView getListView() {
    return this.b;
  }
  
  public void installContent() {
    int i = selectContentView();
    this.a.setContentView(i);
    setupView();
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    return (this.i != null && this.i.executeKeyEvent(paramKeyEvent));
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    return (this.i != null && this.i.executeKeyEvent(paramKeyEvent));
  }
  
  public void setButton(int paramInt, CharSequence paramCharSequence, DialogInterface.OnClickListener paramOnClickListener, Message paramMessage, Drawable paramDrawable) {
    if (paramMessage == null && paramOnClickListener != null)
      paramMessage = this.p.obtainMessage(paramInt, paramOnClickListener); 
    switch (paramInt) {
      default:
        throw new IllegalArgumentException("Button does not exist");
      case -1:
        this.mButtonPositiveText = paramCharSequence;
        this.d = paramMessage;
        this.mButtonPositiveIcon = paramDrawable;
        return;
      case -2:
        this.mButtonNegativeText = paramCharSequence;
        this.f = paramMessage;
        this.mButtonNegativeIcon = paramDrawable;
        return;
      case -3:
        break;
    } 
    this.mButtonNeutralText = paramCharSequence;
    this.h = paramMessage;
    this.mButtonNeutralIcon = paramDrawable;
  }
  
  public void setButtonPanelLayoutHint(int paramInt) {
    this.mButtonPanelLayoutHint = paramInt;
  }
  
  public void setCustomTitle(View paramView) {
    this.mCustomTitleView = paramView;
  }
  
  public void setIcon(int paramInt) {
    this.mIcon = null;
    this.mIconId = paramInt;
    if (this.mIconView != null) {
      if (paramInt != 0) {
        this.mIconView.setVisibility(0);
        this.mIconView.setImageResource(this.mIconId);
        return;
      } 
      this.mIconView.setVisibility(8);
    } 
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.mIcon = paramDrawable;
    this.mIconId = 0;
    if (this.mIconView != null) {
      if (paramDrawable != null) {
        this.mIconView.setVisibility(0);
        this.mIconView.setImageDrawable(paramDrawable);
        return;
      } 
      this.mIconView.setVisibility(8);
    } 
  }
  
  public void setMessage(CharSequence paramCharSequence) {
    this.mMessage = paramCharSequence;
    if (this.mMessageView != null)
      this.mMessageView.setText(paramCharSequence); 
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mTitle = paramCharSequence;
    if (this.mTitleView != null)
      this.mTitleView.setText(paramCharSequence); 
  }
  
  public void setView(int paramInt) {
    this.mView = null;
    this.mViewLayoutResId = paramInt;
    this.mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView) {
    this.mView = paramView;
    this.mViewLayoutResId = 0;
    this.mViewSpacingSpecified = false;
  }
  
  public void setView(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mView = paramView;
    this.mViewLayoutResId = 0;
    this.mViewSpacingSpecified = true;
    this.mViewSpacingLeft = paramInt1;
    this.mViewSpacingTop = paramInt2;
    this.mViewSpacingRight = paramInt3;
    this.mViewSpacingBottom = paramInt4;
  }
  
  public static class AlertParams {
    public ListAdapter mAdapter;
    
    public boolean mCancelable;
    
    public int mCheckedItem = -1;
    
    public boolean[] mCheckedItems;
    
    public final Context mContext;
    
    public Cursor mCursor;
    
    public View mCustomTitleView;
    
    public boolean mForceInverseBackground;
    
    public Drawable mIcon;
    
    public int mIconAttrId = 0;
    
    public int mIconId = 0;
    
    public final LayoutInflater mInflater;
    
    public String mIsCheckedColumn;
    
    public boolean mIsMultiChoice;
    
    public boolean mIsSingleChoice;
    
    public CharSequence[] mItems;
    
    public String mLabelColumn;
    
    public CharSequence mMessage;
    
    public Drawable mNegativeButtonIcon;
    
    public DialogInterface.OnClickListener mNegativeButtonListener;
    
    public CharSequence mNegativeButtonText;
    
    public Drawable mNeutralButtonIcon;
    
    public DialogInterface.OnClickListener mNeutralButtonListener;
    
    public CharSequence mNeutralButtonText;
    
    public DialogInterface.OnCancelListener mOnCancelListener;
    
    public DialogInterface.OnMultiChoiceClickListener mOnCheckboxClickListener;
    
    public DialogInterface.OnClickListener mOnClickListener;
    
    public DialogInterface.OnDismissListener mOnDismissListener;
    
    public AdapterView.OnItemSelectedListener mOnItemSelectedListener;
    
    public DialogInterface.OnKeyListener mOnKeyListener;
    
    public OnPrepareListViewListener mOnPrepareListViewListener;
    
    public Drawable mPositiveButtonIcon;
    
    public DialogInterface.OnClickListener mPositiveButtonListener;
    
    public CharSequence mPositiveButtonText;
    
    public boolean mRecycleOnMeasure = true;
    
    public CharSequence mTitle;
    
    public View mView;
    
    public int mViewLayoutResId;
    
    public int mViewSpacingBottom;
    
    public int mViewSpacingLeft;
    
    public int mViewSpacingRight;
    
    public boolean mViewSpacingSpecified = false;
    
    public int mViewSpacingTop;
    
    public AlertParams(Context param1Context) {
      this.mContext = param1Context;
      this.mCancelable = true;
      this.mInflater = (LayoutInflater)param1Context.getSystemService("layout_inflater");
    }
    
    private void createListView(AlertController param1AlertController) {
      ArrayAdapter<CharSequence> arrayAdapter;
      AlertController.RecycleListView recycleListView = (AlertController.RecycleListView)this.mInflater.inflate(param1AlertController.l, null);
      if (this.mIsMultiChoice) {
        if (this.mCursor == null) {
          Context context = this.mContext;
          int i = param1AlertController.m;
          CharSequence[] arrayOfCharSequence = this.mItems;
          arrayAdapter = new ArrayAdapter<CharSequence>(this, context, i, 16908308, arrayOfCharSequence, recycleListView) {
              public View getView(int param2Int, View param2View, ViewGroup param2ViewGroup) {
                View view = super.getView(param2Int, param2View, param2ViewGroup);
                if (this.b.mCheckedItems != null && this.b.mCheckedItems[param2Int])
                  this.a.setItemChecked(param2Int, true); 
                return view;
              }
            };
        } else {
          Context context = this.mContext;
          Cursor cursor = this.mCursor;
          CursorAdapter cursorAdapter = new CursorAdapter(this, context, cursor, false, recycleListView, param1AlertController) {
              private final int mIsCheckedIndex;
              
              private final int mLabelIndex;
              
              public void bindView(View param2View, Context param2Context, Cursor param2Cursor) {
                ((CheckedTextView)param2View.findViewById(16908308)).setText(param2Cursor.getString(this.mLabelIndex));
                AlertController.RecycleListView recycleListView = this.a;
                int i = param2Cursor.getPosition();
                int j = param2Cursor.getInt(this.mIsCheckedIndex);
                byte b = 1;
                if (j != b)
                  b = 0; 
                recycleListView.setItemChecked(i, b);
              }
              
              public View newView(Context param2Context, Cursor param2Cursor, ViewGroup param2ViewGroup) {
                return this.c.mInflater.inflate(this.b.m, param2ViewGroup, false);
              }
            };
        } 
      } else {
        int i;
        if (this.mIsSingleChoice) {
          i = param1AlertController.n;
        } else {
          i = param1AlertController.o;
        } 
        int j = i;
        if (this.mCursor != null) {
          Context context = this.mContext;
          Cursor cursor = this.mCursor;
          String[] arrayOfString = new String[1];
          arrayOfString[0] = this.mLabelColumn;
          SimpleCursorAdapter simpleCursorAdapter2 = new SimpleCursorAdapter(context, j, cursor, arrayOfString, new int[] { 16908308 });
          SimpleCursorAdapter simpleCursorAdapter1 = simpleCursorAdapter2;
        } else if (this.mAdapter != null) {
          ListAdapter listAdapter = this.mAdapter;
        } else {
          arrayAdapter = new AlertController.CheckedItemAdapter(this.mContext, j, 16908308, this.mItems);
        } 
      } 
      if (this.mOnPrepareListViewListener != null)
        this.mOnPrepareListViewListener.onPrepareListView(recycleListView); 
      param1AlertController.j = (ListAdapter)arrayAdapter;
      param1AlertController.k = this.mCheckedItem;
      if (this.mOnClickListener != null) {
        recycleListView.setOnItemClickListener(new AdapterView.OnItemClickListener(this, param1AlertController) {
              public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
                this.b.mOnClickListener.onClick((DialogInterface)this.a.a, param2Int);
                if (!this.b.mIsSingleChoice)
                  this.a.a.dismiss(); 
              }
            });
      } else if (this.mOnCheckboxClickListener != null) {
        recycleListView.setOnItemClickListener(new AdapterView.OnItemClickListener(this, recycleListView, param1AlertController) {
              public void onItemClick(AdapterView<?> param2AdapterView, View param2View, int param2Int, long param2Long) {
                if (this.c.mCheckedItems != null)
                  this.c.mCheckedItems[param2Int] = this.a.isItemChecked(param2Int); 
                this.c.mOnCheckboxClickListener.onClick((DialogInterface)this.b.a, param2Int, this.a.isItemChecked(param2Int));
              }
            });
      } 
      if (this.mOnItemSelectedListener != null)
        recycleListView.setOnItemSelectedListener(this.mOnItemSelectedListener); 
      if (this.mIsSingleChoice) {
        recycleListView.setChoiceMode(1);
      } else if (this.mIsMultiChoice) {
        recycleListView.setChoiceMode(2);
      } 
      param1AlertController.b = recycleListView;
    }
    
    public void apply(AlertController param1AlertController) {
      if (this.mCustomTitleView != null) {
        param1AlertController.setCustomTitle(this.mCustomTitleView);
      } else {
        if (this.mTitle != null)
          param1AlertController.setTitle(this.mTitle); 
        if (this.mIcon != null)
          param1AlertController.setIcon(this.mIcon); 
        if (this.mIconId != 0)
          param1AlertController.setIcon(this.mIconId); 
        if (this.mIconAttrId != 0)
          param1AlertController.setIcon(param1AlertController.getIconAttributeResId(this.mIconAttrId)); 
      } 
      if (this.mMessage != null)
        param1AlertController.setMessage(this.mMessage); 
      if (this.mPositiveButtonText != null || this.mPositiveButtonIcon != null)
        param1AlertController.setButton(-1, this.mPositiveButtonText, this.mPositiveButtonListener, null, this.mPositiveButtonIcon); 
      if (this.mNegativeButtonText != null || this.mNegativeButtonIcon != null)
        param1AlertController.setButton(-2, this.mNegativeButtonText, this.mNegativeButtonListener, null, this.mNegativeButtonIcon); 
      if (this.mNeutralButtonText != null || this.mNeutralButtonIcon != null)
        param1AlertController.setButton(-3, this.mNeutralButtonText, this.mNeutralButtonListener, null, this.mNeutralButtonIcon); 
      if (this.mItems != null || this.mCursor != null || this.mAdapter != null)
        createListView(param1AlertController); 
      if (this.mView != null) {
        if (this.mViewSpacingSpecified) {
          param1AlertController.setView(this.mView, this.mViewSpacingLeft, this.mViewSpacingTop, this.mViewSpacingRight, this.mViewSpacingBottom);
          return;
        } 
        param1AlertController.setView(this.mView);
        return;
      } 
      if (this.mViewLayoutResId != 0)
        param1AlertController.setView(this.mViewLayoutResId); 
    }
    
    public static interface OnPrepareListViewListener {
      void onPrepareListView(ListView param2ListView);
    }
  }
  
  class null extends ArrayAdapter<CharSequence> {
    null(AlertController this$0, Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence, AlertController.RecycleListView param1RecycleListView) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      View view = super.getView(param1Int, param1View, param1ViewGroup);
      if (this.b.mCheckedItems != null && this.b.mCheckedItems[param1Int])
        this.a.setItemChecked(param1Int, true); 
      return view;
    }
  }
  
  class null extends CursorAdapter {
    private final int mIsCheckedIndex;
    
    private final int mLabelIndex;
    
    null(AlertController this$0, Context param1Context, Cursor param1Cursor, boolean param1Boolean, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {
      super(param1Context, param1Cursor, param1Boolean);
      Cursor cursor = getCursor();
      this.mLabelIndex = cursor.getColumnIndexOrThrow(this.c.mLabelColumn);
      this.mIsCheckedIndex = cursor.getColumnIndexOrThrow(this.c.mIsCheckedColumn);
    }
    
    public void bindView(View param1View, Context param1Context, Cursor param1Cursor) {
      ((CheckedTextView)param1View.findViewById(16908308)).setText(param1Cursor.getString(this.mLabelIndex));
      AlertController.RecycleListView recycleListView = this.a;
      int i = param1Cursor.getPosition();
      int j = param1Cursor.getInt(this.mIsCheckedIndex);
      byte b = 1;
      if (j != b)
        b = 0; 
      recycleListView.setItemChecked(i, b);
    }
    
    public View newView(Context param1Context, Cursor param1Cursor, ViewGroup param1ViewGroup) {
      return this.c.mInflater.inflate(this.b.m, param1ViewGroup, false);
    }
  }
  
  class null implements AdapterView.OnItemClickListener {
    null(AlertController this$0, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      this.b.mOnClickListener.onClick((DialogInterface)this.a.a, param1Int);
      if (!this.b.mIsSingleChoice)
        this.a.a.dismiss(); 
    }
  }
  
  class null implements AdapterView.OnItemClickListener {
    null(AlertController this$0, AlertController.RecycleListView param1RecycleListView, AlertController param1AlertController) {}
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      if (this.c.mCheckedItems != null)
        this.c.mCheckedItems[param1Int] = this.a.isItemChecked(param1Int); 
      this.c.mOnCheckboxClickListener.onClick((DialogInterface)this.b.a, param1Int, this.a.isItemChecked(param1Int));
    }
  }
  
  public static interface OnPrepareListViewListener {
    void onPrepareListView(ListView param1ListView);
  }
  
  private static final class ButtonHandler extends Handler {
    private static final int MSG_DISMISS_DIALOG = 1;
    
    private WeakReference<DialogInterface> mDialog;
    
    public ButtonHandler(DialogInterface param1DialogInterface) {
      this.mDialog = new WeakReference<DialogInterface>(param1DialogInterface);
    }
    
    public void handleMessage(Message param1Message) {
      int i = param1Message.what;
      if (i != 1) {
        switch (i) {
          default:
            return;
          case -3:
          case -2:
          case -1:
            break;
        } 
        ((DialogInterface.OnClickListener)param1Message.obj).onClick(this.mDialog.get(), param1Message.what);
        return;
      } 
      ((DialogInterface)param1Message.obj).dismiss();
    }
  }
  
  private static class CheckedItemAdapter extends ArrayAdapter<CharSequence> {
    public CheckedItemAdapter(Context param1Context, int param1Int1, int param1Int2, CharSequence[] param1ArrayOfCharSequence) {
      super(param1Context, param1Int1, param1Int2, (Object[])param1ArrayOfCharSequence);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public boolean hasStableIds() {
      return true;
    }
  }
  
  public static class RecycleListView extends ListView {
    private final int mPaddingBottomNoButtons;
    
    private final int mPaddingTopNoTitle;
    
    public RecycleListView(Context param1Context) {
      this(param1Context, (AttributeSet)null);
    }
    
    public RecycleListView(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.RecycleListView);
      this.mPaddingBottomNoButtons = typedArray.getDimensionPixelOffset(R.styleable.RecycleListView_paddingBottomNoButtons, -1);
      this.mPaddingTopNoTitle = typedArray.getDimensionPixelOffset(R.styleable.RecycleListView_paddingTopNoTitle, -1);
    }
    
    public void setHasDecor(boolean param1Boolean1, boolean param1Boolean2) {
      if (!param1Boolean2 || !param1Boolean1) {
        int j;
        int m;
        int i = getPaddingLeft();
        if (param1Boolean1) {
          j = getPaddingTop();
        } else {
          j = this.mPaddingTopNoTitle;
        } 
        int k = getPaddingRight();
        if (param1Boolean2) {
          m = getPaddingBottom();
        } else {
          m = this.mPaddingBottomNoButtons;
        } 
        setPadding(i, j, k, m);
      } 
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AlertController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */