package android.support.v7.app;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.v4.view.ViewCompat;
import android.support.v7.view.WindowCallbackWrapper;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.widget.DecorToolbar;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.ToolbarWidgetWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.SpinnerAdapter;
import java.util.ArrayList;

class ToolbarActionBar extends ActionBar {
  DecorToolbar a;
  
  boolean b;
  
  Window.Callback c;
  
  private boolean mLastMenuVisibility;
  
  private boolean mMenuCallbackSet;
  
  private final Toolbar.OnMenuItemClickListener mMenuClicker = new Toolbar.OnMenuItemClickListener(this) {
      public boolean onMenuItemClick(MenuItem param1MenuItem) {
        return this.a.c.onMenuItemSelected(0, param1MenuItem);
      }
    };
  
  private final Runnable mMenuInvalidator = new Runnable(this) {
      public void run() {
        this.a.b();
      }
    };
  
  private ArrayList<ActionBar.OnMenuVisibilityListener> mMenuVisibilityListeners = new ArrayList<ActionBar.OnMenuVisibilityListener>();
  
  ToolbarActionBar(Toolbar paramToolbar, CharSequence paramCharSequence, Window.Callback paramCallback) {
    this.a = (DecorToolbar)new ToolbarWidgetWrapper(paramToolbar, false);
    this.c = (Window.Callback)new ToolbarCallbackWrapper(this, paramCallback);
    this.a.setWindowCallback(this.c);
    paramToolbar.setOnMenuItemClickListener(this.mMenuClicker);
    this.a.setWindowTitle(paramCharSequence);
  }
  
  private Menu getMenu() {
    if (!this.mMenuCallbackSet) {
      this.a.setMenuCallbacks(new ActionMenuPresenterCallback(this), new MenuBuilderCallback(this));
      this.mMenuCallbackSet = true;
    } 
    return this.a.getMenu();
  }
  
  void a() {
    this.a.getViewGroup().removeCallbacks(this.mMenuInvalidator);
  }
  
  public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.add(paramOnMenuVisibilityListener);
  }
  
  public void addTab(ActionBar.Tab paramTab) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt, boolean paramBoolean) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void addTab(ActionBar.Tab paramTab, boolean paramBoolean) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  void b() {
    MenuBuilder menuBuilder;
    Menu menu = getMenu();
    if (menu instanceof MenuBuilder) {
      menuBuilder = (MenuBuilder)menu;
    } else {
      menuBuilder = null;
    } 
    if (menuBuilder != null)
      menuBuilder.stopDispatchingItemsChanged(); 
    try {
      menu.clear();
      if (!this.c.onCreatePanelMenu(0, menu) || !this.c.onPreparePanel(0, null, menu))
        menu.clear(); 
      return;
    } finally {
      if (menuBuilder != null)
        menuBuilder.startDispatchingItemsChanged(); 
    } 
  }
  
  public boolean closeOptionsMenu() {
    return this.a.hideOverflowMenu();
  }
  
  public boolean collapseActionView() {
    if (this.a.hasExpandedActionView()) {
      this.a.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void dispatchMenuVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean == this.mLastMenuVisibility)
      return; 
    this.mLastMenuVisibility = paramBoolean;
    int i = this.mMenuVisibilityListeners.size();
    for (byte b = 0; b < i; b++)
      ((ActionBar.OnMenuVisibilityListener)this.mMenuVisibilityListeners.get(b)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public View getCustomView() {
    return this.a.getCustomView();
  }
  
  public int getDisplayOptions() {
    return this.a.getDisplayOptions();
  }
  
  public float getElevation() {
    return ViewCompat.getElevation((View)this.a.getViewGroup());
  }
  
  public int getHeight() {
    return this.a.getHeight();
  }
  
  public int getNavigationItemCount() {
    return 0;
  }
  
  public int getNavigationMode() {
    return 0;
  }
  
  public int getSelectedNavigationIndex() {
    return -1;
  }
  
  public ActionBar.Tab getSelectedTab() {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public CharSequence getSubtitle() {
    return this.a.getSubtitle();
  }
  
  public ActionBar.Tab getTabAt(int paramInt) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public int getTabCount() {
    return 0;
  }
  
  public Context getThemedContext() {
    return this.a.getContext();
  }
  
  public CharSequence getTitle() {
    return this.a.getTitle();
  }
  
  public Window.Callback getWrappedWindowCallback() {
    return this.c;
  }
  
  public void hide() {
    this.a.setVisibility(8);
  }
  
  public boolean invalidateOptionsMenu() {
    this.a.getViewGroup().removeCallbacks(this.mMenuInvalidator);
    ViewCompat.postOnAnimation((View)this.a.getViewGroup(), this.mMenuInvalidator);
    return true;
  }
  
  public boolean isShowing() {
    return (this.a.getVisibility() == 0);
  }
  
  public boolean isTitleTruncated() {
    return super.isTitleTruncated();
  }
  
  public ActionBar.Tab newTab() {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
  }
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent) {
    Menu menu = getMenu();
    if (menu != null) {
      byte b;
      if (paramKeyEvent != null) {
        b = paramKeyEvent.getDeviceId();
      } else {
        b = -1;
      } 
      int i = KeyCharacterMap.load(b).getKeyboardType();
      byte b1 = 1;
      if (i == b1)
        b1 = 0; 
      menu.setQwertyMode(b1);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public boolean onMenuKeyEvent(KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1)
      openOptionsMenu(); 
    return true;
  }
  
  public boolean openOptionsMenu() {
    return this.a.showOverflowMenu();
  }
  
  public void removeAllTabs() {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.remove(paramOnMenuVisibilityListener);
  }
  
  public void removeTab(ActionBar.Tab paramTab) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void removeTabAt(int paramInt) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public boolean requestFocus() {
    ViewGroup viewGroup = this.a.getViewGroup();
    if (viewGroup != null && !viewGroup.hasFocus()) {
      viewGroup.requestFocus();
      return true;
    } 
    return false;
  }
  
  public void selectTab(ActionBar.Tab paramTab) {
    throw new UnsupportedOperationException("Tabs are not supported in toolbar action bars");
  }
  
  public void setBackgroundDrawable(@Nullable Drawable paramDrawable) {
    this.a.setBackgroundDrawable(paramDrawable);
  }
  
  public void setCustomView(int paramInt) {
    setCustomView(LayoutInflater.from(this.a.getContext()).inflate(paramInt, this.a.getViewGroup(), false));
  }
  
  public void setCustomView(View paramView) {
    setCustomView(paramView, new ActionBar.LayoutParams(-2, -2));
  }
  
  public void setCustomView(View paramView, ActionBar.LayoutParams paramLayoutParams) {
    if (paramView != null)
      paramView.setLayoutParams((ViewGroup.LayoutParams)paramLayoutParams); 
    this.a.setCustomView(paramView);
  }
  
  public void setDefaultDisplayHomeAsUpEnabled(boolean paramBoolean) {}
  
  public void setDisplayHomeAsUpEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 4);
  }
  
  @SuppressLint({"WrongConstant"})
  public void setDisplayOptions(int paramInt) {
    setDisplayOptions(paramInt, -1);
  }
  
  public void setDisplayOptions(int paramInt1, int paramInt2) {
    int i = this.a.getDisplayOptions();
    this.a.setDisplayOptions(paramInt1 & paramInt2 | i & (paramInt2 ^ 0xFFFFFFFF));
  }
  
  public void setDisplayShowCustomEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 16);
  }
  
  public void setDisplayShowHomeEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 2);
  }
  
  public void setDisplayShowTitleEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 8);
  }
  
  public void setDisplayUseLogoEnabled(boolean paramBoolean) {
    setDisplayOptions(paramBoolean, 1);
  }
  
  public void setElevation(float paramFloat) {
    ViewCompat.setElevation((View)this.a.getViewGroup(), paramFloat);
  }
  
  public void setHomeActionContentDescription(int paramInt) {
    this.a.setNavigationContentDescription(paramInt);
  }
  
  public void setHomeActionContentDescription(CharSequence paramCharSequence) {
    this.a.setNavigationContentDescription(paramCharSequence);
  }
  
  public void setHomeAsUpIndicator(int paramInt) {
    this.a.setNavigationIcon(paramInt);
  }
  
  public void setHomeAsUpIndicator(Drawable paramDrawable) {
    this.a.setNavigationIcon(paramDrawable);
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {}
  
  public void setIcon(int paramInt) {
    this.a.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.a.setIcon(paramDrawable);
  }
  
  public void setListNavigationCallbacks(SpinnerAdapter paramSpinnerAdapter, ActionBar.OnNavigationListener paramOnNavigationListener) {
    this.a.setDropdownParams(paramSpinnerAdapter, new NavItemSelectedListener(paramOnNavigationListener));
  }
  
  public void setLogo(int paramInt) {
    this.a.setLogo(paramInt);
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.a.setLogo(paramDrawable);
  }
  
  public void setNavigationMode(int paramInt) {
    if (paramInt != 2) {
      this.a.setNavigationMode(paramInt);
      return;
    } 
    throw new IllegalArgumentException("Tabs not supported in this configuration");
  }
  
  public void setSelectedNavigationItem(int paramInt) {
    if (this.a.getNavigationMode() == 1) {
      this.a.setDropdownSelectedPosition(paramInt);
      return;
    } 
    throw new IllegalStateException("setSelectedNavigationIndex not valid for current navigation mode");
  }
  
  public void setShowHideAnimationEnabled(boolean paramBoolean) {}
  
  public void setSplitBackgroundDrawable(Drawable paramDrawable) {}
  
  public void setStackedBackgroundDrawable(Drawable paramDrawable) {}
  
  public void setSubtitle(int paramInt) {
    CharSequence charSequence;
    DecorToolbar decorToolbar = this.a;
    if (paramInt != 0) {
      charSequence = this.a.getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    decorToolbar.setSubtitle(charSequence);
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.a.setSubtitle(paramCharSequence);
  }
  
  public void setTitle(int paramInt) {
    CharSequence charSequence;
    DecorToolbar decorToolbar = this.a;
    if (paramInt != 0) {
      charSequence = this.a.getContext().getText(paramInt);
    } else {
      charSequence = null;
    } 
    decorToolbar.setTitle(charSequence);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.a.setTitle(paramCharSequence);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    this.a.setWindowTitle(paramCharSequence);
  }
  
  public void show() {
    this.a.setVisibility(0);
  }
  
  private final class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    private boolean mClosingActionMenu;
    
    ActionMenuPresenterCallback(ToolbarActionBar this$0) {}
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (this.mClosingActionMenu)
        return; 
      this.mClosingActionMenu = true;
      this.a.a.dismissPopupMenus();
      if (this.a.c != null)
        this.a.c.onPanelClosed(108, (Menu)param1MenuBuilder); 
      this.mClosingActionMenu = false;
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      if (this.a.c != null) {
        this.a.c.onMenuOpened(108, (Menu)param1MenuBuilder);
        return true;
      } 
      return false;
    }
  }
  
  private final class MenuBuilderCallback implements MenuBuilder.Callback {
    MenuBuilderCallback(ToolbarActionBar this$0) {}
    
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return false;
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (this.a.c != null) {
        if (this.a.a.isOverflowMenuShowing()) {
          this.a.c.onPanelClosed(108, (Menu)param1MenuBuilder);
          return;
        } 
        if (this.a.c.onPreparePanel(0, null, (Menu)param1MenuBuilder))
          this.a.c.onMenuOpened(108, (Menu)param1MenuBuilder); 
      } 
    }
  }
  
  private class ToolbarCallbackWrapper extends WindowCallbackWrapper {
    public ToolbarCallbackWrapper(ToolbarActionBar this$0, Window.Callback param1Callback) {
      super(param1Callback);
    }
    
    public View onCreatePanelView(int param1Int) {
      return (param1Int == 0) ? new View(this.a.a.getContext()) : super.onCreatePanelView(param1Int);
    }
    
    public boolean onPreparePanel(int param1Int, View param1View, Menu param1Menu) {
      boolean bool = super.onPreparePanel(param1Int, param1View, param1Menu);
      if (bool && !this.a.b) {
        this.a.a.setMenuPrepared();
        this.a.b = true;
      } 
      return bool;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\ToolbarActionBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */