package android.support.v7.app;

import android.app.ActionBar;
import android.app.Activity;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import java.lang.reflect.Method;

@RequiresApi(11)
class ActionBarDrawerToggleHoneycomb {
  private static final String TAG = "ActionBarDrawerToggleHC";
  
  private static final int[] THEME_ATTRS = new int[] { 16843531 };
  
  public static Drawable getThemeUpIndicator(Activity paramActivity) {
    TypedArray typedArray = paramActivity.obtainStyledAttributes(THEME_ATTRS);
    Drawable drawable = typedArray.getDrawable(0);
    typedArray.recycle();
    return drawable;
  }
  
  public static SetIndicatorInfo setActionBarDescription(SetIndicatorInfo paramSetIndicatorInfo, Activity paramActivity, int paramInt) {
    if (paramSetIndicatorInfo == null)
      paramSetIndicatorInfo = new SetIndicatorInfo(paramActivity); 
    if (paramSetIndicatorInfo.setHomeAsUpIndicator != null)
      try {
        ActionBar actionBar = paramActivity.getActionBar();
        Method method = paramSetIndicatorInfo.setHomeActionContentDescription;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(paramInt);
        method.invoke(actionBar, arrayOfObject);
        if (Build.VERSION.SDK_INT <= 19) {
          actionBar.setSubtitle(actionBar.getSubtitle());
          return paramSetIndicatorInfo;
        } 
      } catch (Exception exception) {
        Log.w("ActionBarDrawerToggleHC", "Couldn't set content description via JB-MR2 API", exception);
      }  
    return paramSetIndicatorInfo;
  }
  
  public static SetIndicatorInfo setActionBarUpIndicator(SetIndicatorInfo paramSetIndicatorInfo, Activity paramActivity, Drawable paramDrawable, int paramInt) {
    SetIndicatorInfo setIndicatorInfo = new SetIndicatorInfo(paramActivity);
    if (setIndicatorInfo.setHomeAsUpIndicator != null)
      try {
        ActionBar actionBar = paramActivity.getActionBar();
        setIndicatorInfo.setHomeAsUpIndicator.invoke(actionBar, new Object[] { paramDrawable });
        Method method = setIndicatorInfo.setHomeActionContentDescription;
        Object[] arrayOfObject = new Object[1];
        arrayOfObject[0] = Integer.valueOf(paramInt);
        method.invoke(actionBar, arrayOfObject);
        return setIndicatorInfo;
      } catch (Exception exception) {
        Log.w("ActionBarDrawerToggleHC", "Couldn't set home-as-up indicator via JB-MR2 API", exception);
        return setIndicatorInfo;
      }  
    if (setIndicatorInfo.upIndicatorView != null) {
      setIndicatorInfo.upIndicatorView.setImageDrawable(paramDrawable);
      return setIndicatorInfo;
    } 
    Log.w("ActionBarDrawerToggleHC", "Couldn't set home-as-up indicator");
    return setIndicatorInfo;
  }
  
  static class SetIndicatorInfo {
    public Method setHomeActionContentDescription;
    
    public Method setHomeAsUpIndicator;
    
    public ImageView upIndicatorView;
    
    SetIndicatorInfo(Activity param1Activity) {
      try {
        this.setHomeAsUpIndicator = ActionBar.class.getDeclaredMethod("setHomeAsUpIndicator", new Class[] { Drawable.class });
        Class[] arrayOfClass = new Class[1];
        arrayOfClass[0] = int.class;
        this.setHomeActionContentDescription = ActionBar.class.getDeclaredMethod("setHomeActionContentDescription", arrayOfClass);
        return;
      } catch (NoSuchMethodException noSuchMethodException) {
        View view1 = param1Activity.findViewById(16908332);
        if (view1 == null)
          return; 
        ViewGroup viewGroup = (ViewGroup)view1.getParent();
        if (viewGroup.getChildCount() != 2)
          return; 
        View view2 = viewGroup.getChildAt(0);
        View view3 = viewGroup.getChildAt(1);
        if (view2.getId() != 16908332)
          view3 = view2; 
        if (view3 instanceof ImageView)
          this.upIndicatorView = (ImageView)view3; 
        return;
      } 
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\ActionBarDrawerToggleHoneycomb.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */