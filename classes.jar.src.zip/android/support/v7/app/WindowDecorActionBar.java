package android.support.v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.RestrictTo;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.ViewPropertyAnimatorUpdateListener;
import android.support.v7.appcompat.R;
import android.support.v7.content.res.AppCompatResources;
import android.support.v7.view.ActionBarPolicy;
import android.support.v7.view.ActionMode;
import android.support.v7.view.SupportMenuInflater;
import android.support.v7.view.ViewPropertyAnimatorCompatSet;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.view.menu.SubMenuBuilder;
import android.support.v7.widget.ActionBarContainer;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.ActionBarOverlayLayout;
import android.support.v7.widget.DecorToolbar;
import android.support.v7.widget.ScrollingTabContainerView;
import android.support.v7.widget.Toolbar;
import android.util.TypedValue;
import android.view.ContextThemeWrapper;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.widget.SpinnerAdapter;
import java.lang.ref.WeakReference;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class WindowDecorActionBar extends ActionBar implements ActionBarOverlayLayout.ActionBarVisibilityCallback {
  private static final long FADE_IN_DURATION_MS = 200L;
  
  private static final long FADE_OUT_DURATION_MS = 100L;
  
  private static final int INVALID_POSITION = -1;
  
  private static final String TAG = "WindowDecorActionBar";
  
  private static final Interpolator sHideInterpolator = (Interpolator)new AccelerateInterpolator();
  
  private static final Interpolator sShowInterpolator = (Interpolator)new DecelerateInterpolator();
  
  Context a;
  
  ActionBarOverlayLayout b;
  
  ActionBarContainer c;
  
  DecorToolbar d;
  
  ActionBarContextView e;
  
  View f;
  
  ScrollingTabContainerView g;
  
  ActionModeImpl h;
  
  ActionMode i;
  
  ActionMode.Callback j;
  
  boolean k = true;
  
  boolean l;
  
  boolean m;
  
  private Activity mActivity;
  
  private int mCurWindowVisibility = 0;
  
  private Dialog mDialog;
  
  private boolean mDisplayHomeAsUpSet;
  
  private boolean mHasEmbeddedTabs;
  
  private boolean mLastMenuVisibility;
  
  private ArrayList<ActionBar.OnMenuVisibilityListener> mMenuVisibilityListeners = new ArrayList<ActionBar.OnMenuVisibilityListener>();
  
  private boolean mNowShowing = true;
  
  private int mSavedTabPosition = -1;
  
  private TabImpl mSelectedTab;
  
  private boolean mShowHideAnimationEnabled;
  
  private boolean mShowingForMode;
  
  private ArrayList<TabImpl> mTabs = new ArrayList<TabImpl>();
  
  private Context mThemedContext;
  
  ViewPropertyAnimatorCompatSet n;
  
  boolean o;
  
  final ViewPropertyAnimatorListener p = (ViewPropertyAnimatorListener)new ViewPropertyAnimatorListenerAdapter(this) {
      public void onAnimationEnd(View param1View) {
        if (this.a.k && this.a.f != null) {
          this.a.f.setTranslationY(0.0F);
          this.a.c.setTranslationY(0.0F);
        } 
        this.a.c.setVisibility(8);
        this.a.c.setTransitioning(false);
        this.a.n = null;
        this.a.b();
        if (this.a.b != null)
          ViewCompat.requestApplyInsets((View)this.a.b); 
      }
    };
  
  final ViewPropertyAnimatorListener q = (ViewPropertyAnimatorListener)new ViewPropertyAnimatorListenerAdapter(this) {
      public void onAnimationEnd(View param1View) {
        this.a.n = null;
        this.a.c.requestLayout();
      }
    };
  
  final ViewPropertyAnimatorUpdateListener r = new ViewPropertyAnimatorUpdateListener(this) {
      public void onAnimationUpdate(View param1View) {
        ((View)this.a.c.getParent()).invalidate();
      }
    };
  
  public WindowDecorActionBar(Activity paramActivity, boolean paramBoolean) {
    this.mActivity = paramActivity;
    View view = paramActivity.getWindow().getDecorView();
    init(view);
    if (!paramBoolean)
      this.f = view.findViewById(16908290); 
  }
  
  public WindowDecorActionBar(Dialog paramDialog) {
    this.mDialog = paramDialog;
    init(paramDialog.getWindow().getDecorView());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public WindowDecorActionBar(View paramView) {
    if (s || paramView.isInEditMode()) {
      init(paramView);
      return;
    } 
    throw new AssertionError();
  }
  
  static boolean a(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    return paramBoolean3 ? true : (!(paramBoolean1 || paramBoolean2));
  }
  
  private void cleanupTabs() {
    if (this.mSelectedTab != null)
      selectTab(null); 
    this.mTabs.clear();
    if (this.g != null)
      this.g.removeAllTabs(); 
    this.mSavedTabPosition = -1;
  }
  
  private void configureTab(ActionBar.Tab paramTab, int paramInt) {
    TabImpl tabImpl = (TabImpl)paramTab;
    if (tabImpl.getCallback() != null) {
      tabImpl.setPosition(paramInt);
      this.mTabs.add(paramInt, tabImpl);
      int i = this.mTabs.size();
      while (++paramInt < i)
        ((TabImpl)this.mTabs.get(paramInt)).setPosition(paramInt); 
      return;
    } 
    throw new IllegalStateException("Action Bar Tab must have a Callback");
  }
  
  private void ensureTabsExist() {
    if (this.g != null)
      return; 
    ScrollingTabContainerView scrollingTabContainerView = new ScrollingTabContainerView(this.a);
    if (this.mHasEmbeddedTabs) {
      scrollingTabContainerView.setVisibility(0);
      this.d.setEmbeddedTabView(scrollingTabContainerView);
    } else {
      if (getNavigationMode() == 2) {
        scrollingTabContainerView.setVisibility(0);
        if (this.b != null)
          ViewCompat.requestApplyInsets((View)this.b); 
      } else {
        scrollingTabContainerView.setVisibility(8);
      } 
      this.c.setTabContainer(scrollingTabContainerView);
    } 
    this.g = scrollingTabContainerView;
  }
  
  private DecorToolbar getDecorToolbar(View paramView) {
    String str;
    if (paramView instanceof DecorToolbar)
      return (DecorToolbar)paramView; 
    if (paramView instanceof Toolbar)
      return ((Toolbar)paramView).getWrapper(); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't make a decor toolbar out of ");
    stringBuilder.append(paramView);
    if (stringBuilder.toString() != null) {
      str = paramView.getClass().getSimpleName();
    } else {
      str = "null";
    } 
    throw new IllegalStateException(str);
  }
  
  private void hideForActionMode() {
    if (this.mShowingForMode) {
      this.mShowingForMode = false;
      if (this.b != null)
        this.b.setShowingForActionMode(false); 
      updateVisibility(false);
    } 
  }
  
  private void init(View paramView) {
    this.b = (ActionBarOverlayLayout)paramView.findViewById(R.id.decor_content_parent);
    if (this.b != null)
      this.b.setActionBarVisibilityCallback(this); 
    this.d = getDecorToolbar(paramView.findViewById(R.id.action_bar));
    this.e = (ActionBarContextView)paramView.findViewById(R.id.action_context_bar);
    this.c = (ActionBarContainer)paramView.findViewById(R.id.action_bar_container);
    if (this.d != null && this.e != null && this.c != null) {
      boolean bool1;
      boolean bool2;
      this.a = this.d.getContext();
      if ((0x4 & this.d.getDisplayOptions()) != 0) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1)
        this.mDisplayHomeAsUpSet = true; 
      ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(this.a);
      if (actionBarPolicy.enableHomeButtonByDefault() || bool1) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      setHomeButtonEnabled(bool2);
      setHasEmbeddedTabs(actionBarPolicy.hasEmbeddedTabs());
      TypedArray typedArray = this.a.obtainStyledAttributes(null, R.styleable.ActionBar, R.attr.actionBarStyle, 0);
      if (typedArray.getBoolean(R.styleable.ActionBar_hideOnContentScroll, false))
        setHideOnContentScrollEnabled(true); 
      int i = typedArray.getDimensionPixelSize(R.styleable.ActionBar_elevation, 0);
      if (i != 0)
        setElevation(i); 
      typedArray.recycle();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used ");
    stringBuilder.append("with a compatible window decor layout");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private void setHasEmbeddedTabs(boolean paramBoolean) {
    boolean bool2;
    boolean bool3;
    this.mHasEmbeddedTabs = paramBoolean;
    if (!this.mHasEmbeddedTabs) {
      this.d.setEmbeddedTabView(null);
      this.c.setTabContainer(this.g);
    } else {
      this.c.setTabContainer(null);
      this.d.setEmbeddedTabView(this.g);
    } 
    int i = getNavigationMode();
    boolean bool1 = true;
    if (i == 2) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (this.g != null)
      if (bool2) {
        this.g.setVisibility(0);
        if (this.b != null)
          ViewCompat.requestApplyInsets((View)this.b); 
      } else {
        this.g.setVisibility(8);
      }  
    DecorToolbar decorToolbar = this.d;
    if (!this.mHasEmbeddedTabs && bool2) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    decorToolbar.setCollapsible(bool3);
    ActionBarOverlayLayout actionBarOverlayLayout = this.b;
    if (this.mHasEmbeddedTabs || !bool2)
      bool1 = false; 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(bool1);
  }
  
  private boolean shouldAnimateContextView() {
    return ViewCompat.isLaidOut((View)this.c);
  }
  
  private void showForActionMode() {
    if (!this.mShowingForMode) {
      this.mShowingForMode = true;
      if (this.b != null)
        this.b.setShowingForActionMode(true); 
      updateVisibility(false);
    } 
  }
  
  private void updateVisibility(boolean paramBoolean) {
    if (a(this.l, this.m, this.mShowingForMode)) {
      if (!this.mNowShowing) {
        this.mNowShowing = true;
        doShow(paramBoolean);
        return;
      } 
    } else if (this.mNowShowing) {
      this.mNowShowing = false;
      doHide(paramBoolean);
    } 
  }
  
  public void addOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.add(paramOnMenuVisibilityListener);
  }
  
  public void addTab(ActionBar.Tab paramTab) {
    addTab(paramTab, this.mTabs.isEmpty());
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt) {
    addTab(paramTab, paramInt, this.mTabs.isEmpty());
  }
  
  public void addTab(ActionBar.Tab paramTab, int paramInt, boolean paramBoolean) {
    ensureTabsExist();
    this.g.addTab(paramTab, paramInt, paramBoolean);
    configureTab(paramTab, paramInt);
    if (paramBoolean)
      selectTab(paramTab); 
  }
  
  public void addTab(ActionBar.Tab paramTab, boolean paramBoolean) {
    ensureTabsExist();
    this.g.addTab(paramTab, paramBoolean);
    configureTab(paramTab, this.mTabs.size());
    if (paramBoolean)
      selectTab(paramTab); 
  }
  
  public void animateToMode(boolean paramBoolean) {
    if (paramBoolean) {
      showForActionMode();
    } else {
      hideForActionMode();
    } 
    if (shouldAnimateContextView()) {
      ViewPropertyAnimatorCompat viewPropertyAnimatorCompat1;
      ViewPropertyAnimatorCompat viewPropertyAnimatorCompat2;
      if (paramBoolean) {
        viewPropertyAnimatorCompat2 = this.d.setupAnimatorToVisibility(4, 100L);
        viewPropertyAnimatorCompat1 = this.e.setupAnimatorToVisibility(0, 200L);
      } else {
        viewPropertyAnimatorCompat1 = this.d.setupAnimatorToVisibility(0, 200L);
        viewPropertyAnimatorCompat2 = this.e.setupAnimatorToVisibility(8, 100L);
      } 
      ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = new ViewPropertyAnimatorCompatSet();
      viewPropertyAnimatorCompatSet.playSequentially(viewPropertyAnimatorCompat2, viewPropertyAnimatorCompat1);
      viewPropertyAnimatorCompatSet.start();
      return;
    } 
    if (paramBoolean) {
      this.d.setVisibility(4);
      this.e.setVisibility(0);
      return;
    } 
    this.d.setVisibility(0);
    this.e.setVisibility(8);
  }
  
  void b() {
    if (this.j != null) {
      this.j.onDestroyActionMode(this.i);
      this.i = null;
      this.j = null;
    } 
  }
  
  public boolean collapseActionView() {
    if (this.d != null && this.d.hasExpandedActionView()) {
      this.d.collapseActionView();
      return true;
    } 
    return false;
  }
  
  public void dispatchMenuVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean == this.mLastMenuVisibility)
      return; 
    this.mLastMenuVisibility = paramBoolean;
    int i = this.mMenuVisibilityListeners.size();
    for (byte b = 0; b < i; b++)
      ((ActionBar.OnMenuVisibilityListener)this.mMenuVisibilityListeners.get(b)).onMenuVisibilityChanged(paramBoolean); 
  }
  
  public void doHide(boolean paramBoolean) {
    if (this.n != null)
      this.n.cancel(); 
    if (this.mCurWindowVisibility == 0 && (this.mShowHideAnimationEnabled || paramBoolean)) {
      this.c.setAlpha(1.0F);
      this.c.setTransitioning(true);
      ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = new ViewPropertyAnimatorCompatSet();
      float f = -this.c.getHeight();
      if (paramBoolean) {
        int[] arrayOfInt = { 0, 0 };
        this.c.getLocationInWindow(arrayOfInt);
        f -= arrayOfInt[1];
      } 
      ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = ViewCompat.animate((View)this.c).translationY(f);
      viewPropertyAnimatorCompat.setUpdateListener(this.r);
      viewPropertyAnimatorCompatSet.play(viewPropertyAnimatorCompat);
      if (this.k && this.f != null)
        viewPropertyAnimatorCompatSet.play(ViewCompat.animate(this.f).translationY(f)); 
      viewPropertyAnimatorCompatSet.setInterpolator(sHideInterpolator);
      viewPropertyAnimatorCompatSet.setDuration(250L);
      viewPropertyAnimatorCompatSet.setListener(this.p);
      this.n = viewPropertyAnimatorCompatSet;
      viewPropertyAnimatorCompatSet.start();
      return;
    } 
    this.p.onAnimationEnd(null);
  }
  
  public void doShow(boolean paramBoolean) {
    if (this.n != null)
      this.n.cancel(); 
    this.c.setVisibility(0);
    if (this.mCurWindowVisibility == 0 && (this.mShowHideAnimationEnabled || paramBoolean)) {
      this.c.setTranslationY(0.0F);
      float f = -this.c.getHeight();
      if (paramBoolean) {
        int[] arrayOfInt = { 0, 0 };
        this.c.getLocationInWindow(arrayOfInt);
        f -= arrayOfInt[1];
      } 
      this.c.setTranslationY(f);
      ViewPropertyAnimatorCompatSet viewPropertyAnimatorCompatSet = new ViewPropertyAnimatorCompatSet();
      ViewPropertyAnimatorCompat viewPropertyAnimatorCompat = ViewCompat.animate((View)this.c).translationY(0.0F);
      viewPropertyAnimatorCompat.setUpdateListener(this.r);
      viewPropertyAnimatorCompatSet.play(viewPropertyAnimatorCompat);
      if (this.k && this.f != null) {
        this.f.setTranslationY(f);
        viewPropertyAnimatorCompatSet.play(ViewCompat.animate(this.f).translationY(0.0F));
      } 
      viewPropertyAnimatorCompatSet.setInterpolator(sShowInterpolator);
      viewPropertyAnimatorCompatSet.setDuration(250L);
      viewPropertyAnimatorCompatSet.setListener(this.q);
      this.n = viewPropertyAnimatorCompatSet;
      viewPropertyAnimatorCompatSet.start();
    } else {
      this.c.setAlpha(1.0F);
      this.c.setTranslationY(0.0F);
      if (this.k && this.f != null)
        this.f.setTranslationY(0.0F); 
      this.q.onAnimationEnd(null);
    } 
    if (this.b != null)
      ViewCompat.requestApplyInsets((View)this.b); 
  }
  
  public void enableContentAnimations(boolean paramBoolean) {
    this.k = paramBoolean;
  }
  
  public View getCustomView() {
    return this.d.getCustomView();
  }
  
  public int getDisplayOptions() {
    return this.d.getDisplayOptions();
  }
  
  public float getElevation() {
    return ViewCompat.getElevation((View)this.c);
  }
  
  public int getHeight() {
    return this.c.getHeight();
  }
  
  public int getHideOffset() {
    return this.b.getActionBarHideOffset();
  }
  
  public int getNavigationItemCount() {
    switch (this.d.getNavigationMode()) {
      default:
        return 0;
      case 2:
        return this.mTabs.size();
      case 1:
        break;
    } 
    return this.d.getDropdownItemCount();
  }
  
  public int getNavigationMode() {
    return this.d.getNavigationMode();
  }
  
  public int getSelectedNavigationIndex() {
    int i = this.d.getNavigationMode();
    int j = -1;
    switch (i) {
      default:
        return j;
      case 2:
        if (this.mSelectedTab != null)
          j = this.mSelectedTab.getPosition(); 
        return j;
      case 1:
        break;
    } 
    return this.d.getDropdownSelectedPosition();
  }
  
  public ActionBar.Tab getSelectedTab() {
    return this.mSelectedTab;
  }
  
  public CharSequence getSubtitle() {
    return this.d.getSubtitle();
  }
  
  public ActionBar.Tab getTabAt(int paramInt) {
    return this.mTabs.get(paramInt);
  }
  
  public int getTabCount() {
    return this.mTabs.size();
  }
  
  public Context getThemedContext() {
    if (this.mThemedContext == null) {
      TypedValue typedValue = new TypedValue();
      this.a.getTheme().resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
      int i = typedValue.resourceId;
      if (i != 0) {
        this.mThemedContext = (Context)new ContextThemeWrapper(this.a, i);
      } else {
        this.mThemedContext = this.a;
      } 
    } 
    return this.mThemedContext;
  }
  
  public CharSequence getTitle() {
    return this.d.getTitle();
  }
  
  public boolean hasIcon() {
    return this.d.hasIcon();
  }
  
  public boolean hasLogo() {
    return this.d.hasLogo();
  }
  
  public void hide() {
    if (!this.l) {
      this.l = true;
      updateVisibility(false);
    } 
  }
  
  public void hideForSystem() {
    if (!this.m) {
      this.m = true;
      updateVisibility(true);
    } 
  }
  
  public boolean isHideOnContentScrollEnabled() {
    return this.b.isHideOnContentScrollEnabled();
  }
  
  public boolean isShowing() {
    int i = getHeight();
    return (this.mNowShowing && (i == 0 || getHideOffset() < i));
  }
  
  public boolean isTitleTruncated() {
    return (this.d != null && this.d.isTitleTruncated());
  }
  
  public ActionBar.Tab newTab() {
    return new TabImpl(this);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    setHasEmbeddedTabs(ActionBarPolicy.get(this.a).hasEmbeddedTabs());
  }
  
  public void onContentScrollStarted() {
    if (this.n != null) {
      this.n.cancel();
      this.n = null;
    } 
  }
  
  public void onContentScrollStopped() {}
  
  public boolean onKeyShortcut(int paramInt, KeyEvent paramKeyEvent) {
    if (this.h == null)
      return false; 
    Menu menu = this.h.getMenu();
    if (menu != null) {
      byte b;
      if (paramKeyEvent != null) {
        b = paramKeyEvent.getDeviceId();
      } else {
        b = -1;
      } 
      int i = KeyCharacterMap.load(b).getKeyboardType();
      byte b1 = 1;
      if (i == b1)
        b1 = 0; 
      menu.setQwertyMode(b1);
      return menu.performShortcut(paramInt, paramKeyEvent, 0);
    } 
    return false;
  }
  
  public void onWindowVisibilityChanged(int paramInt) {
    this.mCurWindowVisibility = paramInt;
  }
  
  public void removeAllTabs() {
    cleanupTabs();
  }
  
  public void removeOnMenuVisibilityListener(ActionBar.OnMenuVisibilityListener paramOnMenuVisibilityListener) {
    this.mMenuVisibilityListeners.remove(paramOnMenuVisibilityListener);
  }
  
  public void removeTab(ActionBar.Tab paramTab) {
    removeTabAt(paramTab.getPosition());
  }
  
  public void removeTabAt(int paramInt) {
    int i;
    if (this.g == null)
      return; 
    if (this.mSelectedTab != null) {
      i = this.mSelectedTab.getPosition();
    } else {
      i = this.mSavedTabPosition;
    } 
    this.g.removeTabAt(paramInt);
    TabImpl tabImpl = this.mTabs.remove(paramInt);
    if (tabImpl != null)
      tabImpl.setPosition(-1); 
    int j = this.mTabs.size();
    for (int k = paramInt; k < j; k++)
      ((TabImpl)this.mTabs.get(k)).setPosition(k); 
    if (i == paramInt) {
      TabImpl tabImpl1;
      if (this.mTabs.isEmpty()) {
        tabImpl1 = null;
      } else {
        tabImpl1 = this.mTabs.get(Math.max(0, paramInt - 1));
      } 
      selectTab(tabImpl1);
    } 
  }
  
  public boolean requestFocus() {
    ViewGroup viewGroup = this.d.getViewGroup();
    if (viewGroup != null && !viewGroup.hasFocus()) {
      viewGroup.requestFocus();
      return true;
    } 
    return false;
  }
  
  public void selectTab(ActionBar.Tab paramTab) {
    FragmentTransaction fragmentTransaction;
    int i = getNavigationMode();
    int j = -1;
    if (i != 2) {
      if (paramTab != null)
        j = paramTab.getPosition(); 
      this.mSavedTabPosition = j;
      return;
    } 
    if (this.mActivity instanceof FragmentActivity && !this.d.getViewGroup().isInEditMode()) {
      fragmentTransaction = ((FragmentActivity)this.mActivity).getSupportFragmentManager().beginTransaction().disallowAddToBackStack();
    } else {
      fragmentTransaction = null;
    } 
    if (this.mSelectedTab == paramTab) {
      if (this.mSelectedTab != null) {
        this.mSelectedTab.getCallback().onTabReselected(this.mSelectedTab, fragmentTransaction);
        this.g.animateToTab(paramTab.getPosition());
      } 
    } else {
      ScrollingTabContainerView scrollingTabContainerView = this.g;
      if (paramTab != null)
        j = paramTab.getPosition(); 
      scrollingTabContainerView.setTabSelected(j);
      if (this.mSelectedTab != null)
        this.mSelectedTab.getCallback().onTabUnselected(this.mSelectedTab, fragmentTransaction); 
      this.mSelectedTab = (TabImpl)paramTab;
      if (this.mSelectedTab != null)
        this.mSelectedTab.getCallback().onTabSelected(this.mSelectedTab, fragmentTransaction); 
    } 
    if (fragmentTransaction != null && !fragmentTransaction.isEmpty())
      fragmentTransaction.commit(); 
  }
  
  public void setBackgroundDrawable(Drawable paramDrawable) {
    this.c.setPrimaryBackground(paramDrawable);
  }
  
  public void setCustomView(int paramInt) {
    setCustomView(LayoutInflater.from(getThemedContext()).inflate(paramInt, this.d.getViewGroup(), false));
  }
  
  public void setCustomView(View paramView) {
    this.d.setCustomView(paramView);
  }
  
  public void setCustomView(View paramView, ActionBar.LayoutParams paramLayoutParams) {
    paramView.setLayoutParams((ViewGroup.LayoutParams)paramLayoutParams);
    this.d.setCustomView(paramView);
  }
  
  public void setDefaultDisplayHomeAsUpEnabled(boolean paramBoolean) {
    if (!this.mDisplayHomeAsUpSet)
      setDisplayHomeAsUpEnabled(paramBoolean); 
  }
  
  public void setDisplayHomeAsUpEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 4);
  }
  
  public void setDisplayOptions(int paramInt) {
    if ((paramInt & 0x4) != 0)
      this.mDisplayHomeAsUpSet = true; 
    this.d.setDisplayOptions(paramInt);
  }
  
  public void setDisplayOptions(int paramInt1, int paramInt2) {
    int i = this.d.getDisplayOptions();
    if ((paramInt2 & 0x4) != 0)
      this.mDisplayHomeAsUpSet = true; 
    this.d.setDisplayOptions(paramInt1 & paramInt2 | i & (paramInt2 ^ 0xFFFFFFFF));
  }
  
  public void setDisplayShowCustomEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 16);
  }
  
  public void setDisplayShowHomeEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 2);
  }
  
  public void setDisplayShowTitleEnabled(boolean paramBoolean) {
    boolean bool;
    if (paramBoolean) {
      bool = true;
    } else {
      bool = false;
    } 
    setDisplayOptions(bool, 8);
  }
  
  public void setDisplayUseLogoEnabled(boolean paramBoolean) {
    setDisplayOptions(paramBoolean, 1);
  }
  
  public void setElevation(float paramFloat) {
    ViewCompat.setElevation((View)this.c, paramFloat);
  }
  
  public void setHideOffset(int paramInt) {
    if (paramInt == 0 || this.b.isInOverlayMode()) {
      this.b.setActionBarHideOffset(paramInt);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to set a non-zero hide offset");
  }
  
  public void setHideOnContentScrollEnabled(boolean paramBoolean) {
    if (!paramBoolean || this.b.isInOverlayMode()) {
      this.o = paramBoolean;
      this.b.setHideOnContentScrollEnabled(paramBoolean);
      return;
    } 
    throw new IllegalStateException("Action bar must be in overlay mode (Window.FEATURE_OVERLAY_ACTION_BAR) to enable hide on content scroll");
  }
  
  public void setHomeActionContentDescription(int paramInt) {
    this.d.setNavigationContentDescription(paramInt);
  }
  
  public void setHomeActionContentDescription(CharSequence paramCharSequence) {
    this.d.setNavigationContentDescription(paramCharSequence);
  }
  
  public void setHomeAsUpIndicator(int paramInt) {
    this.d.setNavigationIcon(paramInt);
  }
  
  public void setHomeAsUpIndicator(Drawable paramDrawable) {
    this.d.setNavigationIcon(paramDrawable);
  }
  
  public void setHomeButtonEnabled(boolean paramBoolean) {
    this.d.setHomeButtonEnabled(paramBoolean);
  }
  
  public void setIcon(int paramInt) {
    this.d.setIcon(paramInt);
  }
  
  public void setIcon(Drawable paramDrawable) {
    this.d.setIcon(paramDrawable);
  }
  
  public void setListNavigationCallbacks(SpinnerAdapter paramSpinnerAdapter, ActionBar.OnNavigationListener paramOnNavigationListener) {
    this.d.setDropdownParams(paramSpinnerAdapter, new NavItemSelectedListener(paramOnNavigationListener));
  }
  
  public void setLogo(int paramInt) {
    this.d.setLogo(paramInt);
  }
  
  public void setLogo(Drawable paramDrawable) {
    this.d.setLogo(paramDrawable);
  }
  
  public void setNavigationMode(int paramInt) {
    boolean bool1;
    int i = this.d.getNavigationMode();
    if (i == 2) {
      this.mSavedTabPosition = getSelectedNavigationIndex();
      selectTab(null);
      this.g.setVisibility(8);
    } 
    if (i != paramInt && !this.mHasEmbeddedTabs && this.b != null)
      ViewCompat.requestApplyInsets((View)this.b); 
    this.d.setNavigationMode(paramInt);
    if (paramInt == 2) {
      ensureTabsExist();
      this.g.setVisibility(0);
      if (this.mSavedTabPosition != -1) {
        setSelectedNavigationItem(this.mSavedTabPosition);
        this.mSavedTabPosition = -1;
      } 
    } 
    DecorToolbar decorToolbar = this.d;
    if (paramInt == 2 && !this.mHasEmbeddedTabs) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    decorToolbar.setCollapsible(bool1);
    ActionBarOverlayLayout actionBarOverlayLayout = this.b;
    boolean bool2 = false;
    if (paramInt == 2) {
      boolean bool = this.mHasEmbeddedTabs;
      bool2 = false;
      if (!bool)
        bool2 = true; 
    } 
    actionBarOverlayLayout.setHasNonEmbeddedTabs(bool2);
  }
  
  public void setSelectedNavigationItem(int paramInt) {
    switch (this.d.getNavigationMode()) {
      default:
        throw new IllegalStateException("setSelectedNavigationIndex not valid for current navigation mode");
      case 2:
        selectTab(this.mTabs.get(paramInt));
        return;
      case 1:
        break;
    } 
    this.d.setDropdownSelectedPosition(paramInt);
  }
  
  public void setShowHideAnimationEnabled(boolean paramBoolean) {
    this.mShowHideAnimationEnabled = paramBoolean;
    if (!paramBoolean && this.n != null)
      this.n.cancel(); 
  }
  
  public void setSplitBackgroundDrawable(Drawable paramDrawable) {}
  
  public void setStackedBackgroundDrawable(Drawable paramDrawable) {
    this.c.setStackedBackground(paramDrawable);
  }
  
  public void setSubtitle(int paramInt) {
    setSubtitle(this.a.getString(paramInt));
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.d.setSubtitle(paramCharSequence);
  }
  
  public void setTitle(int paramInt) {
    setTitle(this.a.getString(paramInt));
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.d.setTitle(paramCharSequence);
  }
  
  public void setWindowTitle(CharSequence paramCharSequence) {
    this.d.setWindowTitle(paramCharSequence);
  }
  
  public void show() {
    if (this.l) {
      this.l = false;
      updateVisibility(false);
    } 
  }
  
  public void showForSystem() {
    if (this.m) {
      this.m = false;
      updateVisibility(true);
    } 
  }
  
  public ActionMode startActionMode(ActionMode.Callback paramCallback) {
    if (this.h != null)
      this.h.finish(); 
    this.b.setHideOnContentScrollEnabled(false);
    this.e.killMode();
    ActionModeImpl actionModeImpl = new ActionModeImpl(this, this.e.getContext(), paramCallback);
    if (actionModeImpl.dispatchOnCreate()) {
      this.h = actionModeImpl;
      actionModeImpl.invalidate();
      this.e.initForMode(actionModeImpl);
      animateToMode(true);
      this.e.sendAccessibilityEvent(32);
      return actionModeImpl;
    } 
    return null;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public class ActionModeImpl extends ActionMode implements MenuBuilder.Callback {
    private final Context mActionModeContext;
    
    private ActionMode.Callback mCallback;
    
    private WeakReference<View> mCustomView;
    
    private final MenuBuilder mMenu;
    
    public ActionModeImpl(WindowDecorActionBar this$0, Context param1Context, ActionMode.Callback param1Callback) {
      this.mActionModeContext = param1Context;
      this.mCallback = param1Callback;
      this.mMenu = (new MenuBuilder(param1Context)).setDefaultShowAsAction(1);
      this.mMenu.setCallback(this);
    }
    
    public boolean dispatchOnCreate() {
      this.mMenu.stopDispatchingItemsChanged();
      try {
        return this.mCallback.onCreateActionMode(this, (Menu)this.mMenu);
      } finally {
        this.mMenu.startDispatchingItemsChanged();
      } 
    }
    
    public void finish() {
      if (this.a.h != this)
        return; 
      if (!WindowDecorActionBar.a(this.a.l, this.a.m, false)) {
        this.a.i = this;
        this.a.j = this.mCallback;
      } else {
        this.mCallback.onDestroyActionMode(this);
      } 
      this.mCallback = null;
      this.a.animateToMode(false);
      this.a.e.closeMode();
      this.a.d.getViewGroup().sendAccessibilityEvent(32);
      this.a.b.setHideOnContentScrollEnabled(this.a.o);
      this.a.h = null;
    }
    
    public View getCustomView() {
      return (this.mCustomView != null) ? this.mCustomView.get() : null;
    }
    
    public Menu getMenu() {
      return (Menu)this.mMenu;
    }
    
    public MenuInflater getMenuInflater() {
      return (MenuInflater)new SupportMenuInflater(this.mActionModeContext);
    }
    
    public CharSequence getSubtitle() {
      return this.a.e.getSubtitle();
    }
    
    public CharSequence getTitle() {
      return this.a.e.getTitle();
    }
    
    public void invalidate() {
      if (this.a.h != this)
        return; 
      this.mMenu.stopDispatchingItemsChanged();
      try {
        this.mCallback.onPrepareActionMode(this, (Menu)this.mMenu);
        return;
      } finally {
        this.mMenu.startDispatchingItemsChanged();
      } 
    }
    
    public boolean isTitleOptional() {
      return this.a.e.isTitleOptional();
    }
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public void onCloseSubMenu(SubMenuBuilder param1SubMenuBuilder) {}
    
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return (this.mCallback != null) ? this.mCallback.onActionItemClicked(this, param1MenuItem) : false;
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (this.mCallback == null)
        return; 
      invalidate();
      this.a.e.showOverflowMenu();
    }
    
    public boolean onSubMenuSelected(SubMenuBuilder param1SubMenuBuilder) {
      if (this.mCallback == null)
        return false; 
      if (!param1SubMenuBuilder.hasVisibleItems())
        return true; 
      (new MenuPopupHelper(this.a.getThemedContext(), (MenuBuilder)param1SubMenuBuilder)).show();
      return true;
    }
    
    public void setCustomView(View param1View) {
      this.a.e.setCustomView(param1View);
      this.mCustomView = new WeakReference<View>(param1View);
    }
    
    public void setSubtitle(int param1Int) {
      setSubtitle(this.a.a.getResources().getString(param1Int));
    }
    
    public void setSubtitle(CharSequence param1CharSequence) {
      this.a.e.setSubtitle(param1CharSequence);
    }
    
    public void setTitle(int param1Int) {
      setTitle(this.a.a.getResources().getString(param1Int));
    }
    
    public void setTitle(CharSequence param1CharSequence) {
      this.a.e.setTitle(param1CharSequence);
    }
    
    public void setTitleOptionalHint(boolean param1Boolean) {
      super.setTitleOptionalHint(param1Boolean);
      this.a.e.setTitleOptional(param1Boolean);
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public class TabImpl extends ActionBar.Tab {
    private ActionBar.TabListener mCallback;
    
    private CharSequence mContentDesc;
    
    private View mCustomView;
    
    private Drawable mIcon;
    
    private int mPosition = -1;
    
    private Object mTag;
    
    private CharSequence mText;
    
    public TabImpl(WindowDecorActionBar this$0) {}
    
    public ActionBar.TabListener getCallback() {
      return this.mCallback;
    }
    
    public CharSequence getContentDescription() {
      return this.mContentDesc;
    }
    
    public View getCustomView() {
      return this.mCustomView;
    }
    
    public Drawable getIcon() {
      return this.mIcon;
    }
    
    public int getPosition() {
      return this.mPosition;
    }
    
    public Object getTag() {
      return this.mTag;
    }
    
    public CharSequence getText() {
      return this.mText;
    }
    
    public void select() {
      this.a.selectTab(this);
    }
    
    public ActionBar.Tab setContentDescription(int param1Int) {
      return setContentDescription(this.a.a.getResources().getText(param1Int));
    }
    
    public ActionBar.Tab setContentDescription(CharSequence param1CharSequence) {
      this.mContentDesc = param1CharSequence;
      if (this.mPosition >= 0)
        this.a.g.updateTab(this.mPosition); 
      return this;
    }
    
    public ActionBar.Tab setCustomView(int param1Int) {
      return setCustomView(LayoutInflater.from(this.a.getThemedContext()).inflate(param1Int, null));
    }
    
    public ActionBar.Tab setCustomView(View param1View) {
      this.mCustomView = param1View;
      if (this.mPosition >= 0)
        this.a.g.updateTab(this.mPosition); 
      return this;
    }
    
    public ActionBar.Tab setIcon(int param1Int) {
      return setIcon(AppCompatResources.getDrawable(this.a.a, param1Int));
    }
    
    public ActionBar.Tab setIcon(Drawable param1Drawable) {
      this.mIcon = param1Drawable;
      if (this.mPosition >= 0)
        this.a.g.updateTab(this.mPosition); 
      return this;
    }
    
    public void setPosition(int param1Int) {
      this.mPosition = param1Int;
    }
    
    public ActionBar.Tab setTabListener(ActionBar.TabListener param1TabListener) {
      this.mCallback = param1TabListener;
      return this;
    }
    
    public ActionBar.Tab setTag(Object param1Object) {
      this.mTag = param1Object;
      return this;
    }
    
    public ActionBar.Tab setText(int param1Int) {
      return setText(this.a.a.getResources().getText(param1Int));
    }
    
    public ActionBar.Tab setText(CharSequence param1CharSequence) {
      this.mText = param1CharSequence;
      if (this.mPosition >= 0)
        this.a.g.updateTab(this.mPosition); 
      return this;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\WindowDecorActionBar.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */