package android.support.v7.app;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.VisibleForTesting;
import android.support.v7.view.ActionMode;
import android.support.v7.view.SupportActionModeWrapper;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.ActionMode;
import android.view.View;
import android.view.Window;

@RequiresApi(14)
class AppCompatDelegateImplV14 extends AppCompatDelegateImplV9 {
  private static final String KEY_LOCAL_NIGHT_MODE = "appcompat:local_night_mode";
  
  private boolean mApplyDayNightCalled;
  
  private AutoNightModeManager mAutoNightModeManager;
  
  private boolean mHandleNativeActionModes = true;
  
  private int mLocalNightMode = -100;
  
  AppCompatDelegateImplV14(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback) {
    super(paramContext, paramWindow, paramAppCompatCallback);
  }
  
  private void ensureAutoNightModeManager() {
    if (this.mAutoNightModeManager == null)
      this.mAutoNightModeManager = new AutoNightModeManager(this, TwilightManager.a(this.a)); 
  }
  
  private int getNightMode() {
    return (this.mLocalNightMode != -100) ? this.mLocalNightMode : getDefaultNightMode();
  }
  
  private boolean shouldRecreateOnNightModeChange() {
    if (this.mApplyDayNightCalled && this.a instanceof Activity) {
      PackageManager packageManager = this.a.getPackageManager();
      try {
        int i = (packageManager.getActivityInfo(new ComponentName(this.a, this.a.getClass()), 0)).configChanges;
        int j = i & 0x200;
        boolean bool = false;
        if (j == 0)
          bool = true; 
        return bool;
      } catch (android.content.pm.PackageManager.NameNotFoundException nameNotFoundException) {
        Log.d("AppCompatDelegate", "Exception while getting ActivityInfo", (Throwable)nameNotFoundException);
        return true;
      } 
    } 
    return false;
  }
  
  private boolean updateForNightMode(int paramInt) {
    byte b;
    Resources resources = this.a.getResources();
    Configuration configuration = resources.getConfiguration();
    int i = 0x30 & configuration.uiMode;
    if (paramInt == 2) {
      b = 32;
    } else {
      b = 16;
    } 
    if (i != b) {
      if (shouldRecreateOnNightModeChange()) {
        ((Activity)this.a).recreate();
      } else {
        Configuration configuration1 = new Configuration(configuration);
        DisplayMetrics displayMetrics = resources.getDisplayMetrics();
        configuration1.uiMode = b | 0xFFFFFFCF & configuration1.uiMode;
        resources.updateConfiguration(configuration1, displayMetrics);
        if (Build.VERSION.SDK_INT < 26)
          ResourcesFlusher.a(resources); 
      } 
      return true;
    } 
    return false;
  }
  
  int a(int paramInt) {
    if (paramInt != -100) {
      if (paramInt != 0)
        return paramInt; 
      ensureAutoNightModeManager();
      return this.mAutoNightModeManager.getApplyableNightMode();
    } 
    return -1;
  }
  
  View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return null;
  }
  
  Window.Callback a(Window.Callback paramCallback) {
    return (Window.Callback)new AppCompatWindowCallbackV14(this, paramCallback);
  }
  
  public boolean applyDayNight() {
    boolean bool;
    int i = getNightMode();
    int j = a(i);
    if (j != -1) {
      bool = updateForNightMode(j);
    } else {
      bool = false;
    } 
    if (i == 0) {
      ensureAutoNightModeManager();
      this.mAutoNightModeManager.b();
    } 
    this.mApplyDayNightCalled = true;
    return bool;
  }
  
  @VisibleForTesting
  final AutoNightModeManager getAutoNightModeManager() {
    ensureAutoNightModeManager();
    return this.mAutoNightModeManager;
  }
  
  public boolean hasWindowFeature(int paramInt) {
    return (super.hasWindowFeature(paramInt) || this.b.hasFeature(paramInt));
  }
  
  public boolean isHandleNativeActionModesEnabled() {
    return this.mHandleNativeActionModes;
  }
  
  public void onCreate(Bundle paramBundle) {
    super.onCreate(paramBundle);
    if (paramBundle != null && this.mLocalNightMode == -100)
      this.mLocalNightMode = paramBundle.getInt("appcompat:local_night_mode", -100); 
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (this.mAutoNightModeManager != null)
      this.mAutoNightModeManager.c(); 
  }
  
  public void onSaveInstanceState(Bundle paramBundle) {
    super.onSaveInstanceState(paramBundle);
    if (this.mLocalNightMode != -100)
      paramBundle.putInt("appcompat:local_night_mode", this.mLocalNightMode); 
  }
  
  public void onStart() {
    super.onStart();
    applyDayNight();
  }
  
  public void onStop() {
    super.onStop();
    if (this.mAutoNightModeManager != null)
      this.mAutoNightModeManager.c(); 
  }
  
  public void setHandleNativeActionModesEnabled(boolean paramBoolean) {
    this.mHandleNativeActionModes = paramBoolean;
  }
  
  public void setLocalNightMode(int paramInt) {
    switch (paramInt) {
      default:
        Log.i("AppCompatDelegate", "setLocalNightMode() called with an unknown mode");
        return;
      case -1:
      case 0:
      case 1:
      case 2:
        break;
    } 
    if (this.mLocalNightMode != paramInt) {
      this.mLocalNightMode = paramInt;
      if (this.mApplyDayNightCalled)
        applyDayNight(); 
    } 
  }
  
  class AppCompatWindowCallbackV14 extends AppCompatDelegateImplBase.AppCompatWindowCallbackBase {
    AppCompatWindowCallbackV14(AppCompatDelegateImplV14 this$0, Window.Callback param1Callback) {
      super(this$0, param1Callback);
    }
    
    final ActionMode a(ActionMode.Callback param1Callback) {
      SupportActionModeWrapper.CallbackWrapper callbackWrapper = new SupportActionModeWrapper.CallbackWrapper(this.c.a, param1Callback);
      ActionMode actionMode = this.c.startSupportActionMode((ActionMode.Callback)callbackWrapper);
      return (actionMode != null) ? callbackWrapper.getActionModeWrapper(actionMode) : null;
    }
    
    public ActionMode onWindowStartingActionMode(ActionMode.Callback param1Callback) {
      return this.c.isHandleNativeActionModesEnabled() ? a(param1Callback) : super.onWindowStartingActionMode(param1Callback);
    }
  }
  
  @VisibleForTesting
  final class AutoNightModeManager {
    private BroadcastReceiver mAutoTimeChangeReceiver;
    
    private IntentFilter mAutoTimeChangeReceiverFilter;
    
    private boolean mIsNight;
    
    private TwilightManager mTwilightManager;
    
    AutoNightModeManager(AppCompatDelegateImplV14 this$0, @NonNull TwilightManager param1TwilightManager) {
      this.mTwilightManager = param1TwilightManager;
      this.mIsNight = param1TwilightManager.isNight();
    }
    
    final void a() {
      boolean bool = this.mTwilightManager.isNight();
      if (bool != this.mIsNight) {
        this.mIsNight = bool;
        this.a.applyDayNight();
      } 
    }
    
    final void b() {
      c();
      if (this.mAutoTimeChangeReceiver == null)
        this.mAutoTimeChangeReceiver = new BroadcastReceiver(this) {
            public void onReceive(Context param2Context, Intent param2Intent) {
              this.a.a();
            }
          }; 
      if (this.mAutoTimeChangeReceiverFilter == null) {
        this.mAutoTimeChangeReceiverFilter = new IntentFilter();
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIME_SET");
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIMEZONE_CHANGED");
        this.mAutoTimeChangeReceiverFilter.addAction("android.intent.action.TIME_TICK");
      } 
      this.a.a.registerReceiver(this.mAutoTimeChangeReceiver, this.mAutoTimeChangeReceiverFilter);
    }
    
    final void c() {
      if (this.mAutoTimeChangeReceiver != null) {
        this.a.a.unregisterReceiver(this.mAutoTimeChangeReceiver);
        this.mAutoTimeChangeReceiver = null;
      } 
    }
    
    final int getApplyableNightMode() {
      this.mIsNight = this.mTwilightManager.isNight();
      return this.mIsNight ? 2 : 1;
    }
  }
  
  class null extends BroadcastReceiver {
    null(AppCompatDelegateImplV14 this$0) {}
    
    public void onReceive(Context param1Context, Intent param1Intent) {
      this.a.a();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AppCompatDelegateImplV14.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */