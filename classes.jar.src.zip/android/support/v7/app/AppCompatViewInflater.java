package android.support.v7.app;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.view.ContextThemeWrapper;
import android.support.v7.widget.AppCompatAutoCompleteTextView;
import android.support.v7.widget.AppCompatButton;
import android.support.v7.widget.AppCompatCheckBox;
import android.support.v7.widget.AppCompatCheckedTextView;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.AppCompatImageButton;
import android.support.v7.widget.AppCompatImageView;
import android.support.v7.widget.AppCompatMultiAutoCompleteTextView;
import android.support.v7.widget.AppCompatRadioButton;
import android.support.v7.widget.AppCompatRatingBar;
import android.support.v7.widget.AppCompatSeekBar;
import android.support.v7.widget.AppCompatSpinner;
import android.support.v7.widget.AppCompatTextView;
import android.support.v7.widget.TintContextWrapper;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Map;

public class AppCompatViewInflater {
  private static final String LOG_TAG = "AppCompatViewInflater";
  
  private static final String[] sClassPrefixList;
  
  private static final Map<String, Constructor<? extends View>> sConstructorMap;
  
  private static final Class<?>[] sConstructorSignature = new Class[] { Context.class, AttributeSet.class };
  
  private static final int[] sOnClickAttrs = new int[] { 16843375 };
  
  private final Object[] mConstructorArgs = new Object[2];
  
  static {
    sClassPrefixList = new String[] { "android.widget.", "android.view.", "android.webkit." };
    sConstructorMap = (Map<String, Constructor<? extends View>>)new ArrayMap();
  }
  
  private void checkOnClickListener(View paramView, AttributeSet paramAttributeSet) {
    Context context = paramView.getContext();
    if (context instanceof ContextWrapper) {
      if (Build.VERSION.SDK_INT >= 15 && !ViewCompat.hasOnClickListeners(paramView))
        return; 
      TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, sOnClickAttrs);
      String str = typedArray.getString(0);
      if (str != null)
        paramView.setOnClickListener(new DeclaredOnClickListener(paramView, str)); 
      typedArray.recycle();
      return;
    } 
  }
  
  private View createViewByPrefix(Context paramContext, String paramString1, String paramString2) {
    Constructor<? extends View> constructor = sConstructorMap.get(paramString1);
    if (constructor == null)
      try {
        String str;
        ClassLoader classLoader = paramContext.getClassLoader();
        if (paramString2 != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(paramString2);
          stringBuilder.append(paramString1);
          str = stringBuilder.toString();
        } else {
          str = paramString1;
        } 
        constructor = classLoader.loadClass(str).<View>asSubclass(View.class).getConstructor(sConstructorSignature);
        sConstructorMap.put(paramString1, constructor);
        constructor.setAccessible(true);
        return constructor.newInstance(this.mConstructorArgs);
      } catch (Exception exception) {
        return null;
      }  
    constructor.setAccessible(true);
    return constructor.newInstance(this.mConstructorArgs);
  }
  
  private View createViewFromTag(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    if (paramString.equals("view"))
      paramString = paramAttributeSet.getAttributeValue(null, "class"); 
    try {
      this.mConstructorArgs[0] = paramContext;
      this.mConstructorArgs[1] = paramAttributeSet;
      if (-1 == paramString.indexOf('.')) {
        for (byte b = 0; b < sClassPrefixList.length; b++) {
          View view = createViewByPrefix(paramContext, paramString, sClassPrefixList[b]);
          if (view != null)
            return view; 
        } 
        return null;
      } 
      return createViewByPrefix(paramContext, paramString, null);
    } catch (Exception exception) {
      return null;
    } finally {
      this.mConstructorArgs[0] = null;
      this.mConstructorArgs[1] = null;
    } 
  }
  
  private static Context themifyContext(Context paramContext, AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2) {
    ContextThemeWrapper contextThemeWrapper;
    int i;
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.View, 0, 0);
    if (paramBoolean1) {
      i = typedArray.getResourceId(R.styleable.View_android_theme, 0);
    } else {
      i = 0;
    } 
    if (paramBoolean2 && !i) {
      i = typedArray.getResourceId(R.styleable.View_theme, 0);
      if (i != 0)
        Log.i("AppCompatViewInflater", "app:theme is now deprecated. Please move to using android:theme instead."); 
    } 
    typedArray.recycle();
    if (i != 0 && (!(paramContext instanceof ContextThemeWrapper) || ((ContextThemeWrapper)paramContext).getThemeResId() != i))
      contextThemeWrapper = new ContextThemeWrapper(paramContext, i); 
    return (Context)contextThemeWrapper;
  }
  
  private void verifyNotNull(View paramView, String paramString) {
    if (paramView != null)
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getName());
    stringBuilder.append(" asked to inflate view for <");
    stringBuilder.append(paramString);
    stringBuilder.append(">, but returned null");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  final View a(View paramView, String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
    Context context;
    View view2;
    AppCompatSeekBar appCompatSeekBar;
    AppCompatRatingBar appCompatRatingBar;
    AppCompatMultiAutoCompleteTextView appCompatMultiAutoCompleteTextView;
    AppCompatAutoCompleteTextView appCompatAutoCompleteTextView;
    AppCompatCheckedTextView appCompatCheckedTextView;
    AppCompatRadioButton appCompatRadioButton;
    AppCompatCheckBox appCompatCheckBox;
    AppCompatImageButton appCompatImageButton;
    AppCompatSpinner appCompatSpinner;
    AppCompatEditText appCompatEditText;
    AppCompatButton appCompatButton;
    AppCompatImageView appCompatImageView;
    AppCompatTextView appCompatTextView;
    View view1;
    if (paramBoolean1 && paramView != null) {
      context = paramView.getContext();
    } else {
      context = paramContext;
    } 
    if (paramBoolean2 || paramBoolean3)
      context = themifyContext(context, paramAttributeSet, paramBoolean2, paramBoolean3); 
    if (paramBoolean4)
      context = TintContextWrapper.wrap(context); 
    byte b = -1;
    switch (paramString.hashCode()) {
      case 2001146706:
        if (paramString.equals("Button"))
          b = 2; 
        break;
      case 1666676343:
        if (paramString.equals("EditText"))
          b = 3; 
        break;
      case 1601505219:
        if (paramString.equals("CheckBox"))
          b = 6; 
        break;
      case 1413872058:
        if (paramString.equals("AutoCompleteTextView"))
          b = 9; 
        break;
      case 1125864064:
        if (paramString.equals("ImageView"))
          b = 1; 
        break;
      case 776382189:
        if (paramString.equals("RadioButton"))
          b = 7; 
        break;
      case -339785223:
        if (paramString.equals("Spinner"))
          b = 4; 
        break;
      case -658531749:
        if (paramString.equals("SeekBar"))
          b = 12; 
        break;
      case -937446323:
        if (paramString.equals("ImageButton"))
          b = 5; 
        break;
      case -938935918:
        if (paramString.equals("TextView"))
          b = 0; 
        break;
      case -1346021293:
        if (paramString.equals("MultiAutoCompleteTextView"))
          b = 10; 
        break;
      case -1455429095:
        if (paramString.equals("CheckedTextView"))
          b = 8; 
        break;
      case -1946472170:
        if (paramString.equals("RatingBar"))
          b = 11; 
        break;
    } 
    switch (b) {
      default:
        view2 = createView(context, paramString, paramAttributeSet);
        break;
      case 12:
        appCompatSeekBar = createSeekBar(context, paramAttributeSet);
        verifyNotNull((View)appCompatSeekBar, paramString);
        break;
      case 11:
        appCompatRatingBar = createRatingBar(context, paramAttributeSet);
        verifyNotNull((View)appCompatRatingBar, paramString);
        break;
      case 10:
        appCompatMultiAutoCompleteTextView = createMultiAutoCompleteTextView(context, paramAttributeSet);
        verifyNotNull((View)appCompatMultiAutoCompleteTextView, paramString);
        break;
      case 9:
        appCompatAutoCompleteTextView = createAutoCompleteTextView(context, paramAttributeSet);
        verifyNotNull((View)appCompatAutoCompleteTextView, paramString);
        break;
      case 8:
        appCompatCheckedTextView = createCheckedTextView(context, paramAttributeSet);
        verifyNotNull((View)appCompatCheckedTextView, paramString);
        break;
      case 7:
        appCompatRadioButton = createRadioButton(context, paramAttributeSet);
        verifyNotNull((View)appCompatRadioButton, paramString);
        break;
      case 6:
        appCompatCheckBox = createCheckBox(context, paramAttributeSet);
        verifyNotNull((View)appCompatCheckBox, paramString);
        break;
      case 5:
        appCompatImageButton = createImageButton(context, paramAttributeSet);
        verifyNotNull((View)appCompatImageButton, paramString);
        break;
      case 4:
        appCompatSpinner = createSpinner(context, paramAttributeSet);
        verifyNotNull((View)appCompatSpinner, paramString);
        break;
      case 3:
        appCompatEditText = createEditText(context, paramAttributeSet);
        verifyNotNull((View)appCompatEditText, paramString);
        break;
      case 2:
        appCompatButton = createButton(context, paramAttributeSet);
        verifyNotNull((View)appCompatButton, paramString);
        break;
      case 1:
        appCompatImageView = createImageView(context, paramAttributeSet);
        verifyNotNull((View)appCompatImageView, paramString);
        break;
      case 0:
        appCompatTextView = createTextView(context, paramAttributeSet);
        verifyNotNull((View)appCompatTextView, paramString);
        break;
    } 
    if (appCompatTextView == null && paramContext != context)
      view1 = createViewFromTag(context, paramString, paramAttributeSet); 
    if (view1 != null)
      checkOnClickListener(view1, paramAttributeSet); 
    return view1;
  }
  
  @NonNull
  protected AppCompatAutoCompleteTextView createAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatButton createButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatButton(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatCheckBox createCheckBox(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckBox(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatCheckedTextView createCheckedTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatCheckedTextView(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatEditText createEditText(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatEditText(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatImageButton createImageButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageButton(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatImageView createImageView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatImageView(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatMultiAutoCompleteTextView createMultiAutoCompleteTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatMultiAutoCompleteTextView(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatRadioButton createRadioButton(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRadioButton(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatRatingBar createRatingBar(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatRatingBar(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatSeekBar createSeekBar(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSeekBar(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatSpinner createSpinner(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatSpinner(paramContext, paramAttributeSet);
  }
  
  @NonNull
  protected AppCompatTextView createTextView(Context paramContext, AttributeSet paramAttributeSet) {
    return new AppCompatTextView(paramContext, paramAttributeSet);
  }
  
  @Nullable
  protected View createView(Context paramContext, String paramString, AttributeSet paramAttributeSet) {
    return null;
  }
  
  private static class DeclaredOnClickListener implements View.OnClickListener {
    private final View mHostView;
    
    private final String mMethodName;
    
    private Context mResolvedContext;
    
    private Method mResolvedMethod;
    
    public DeclaredOnClickListener(@NonNull View param1View, @NonNull String param1String) {
      this.mHostView = param1View;
      this.mMethodName = param1String;
    }
    
    @NonNull
    private void resolveMethod(@Nullable Context param1Context, @NonNull String param1String) {
      String str;
      while (param1Context != null) {
        if (!param1Context.isRestricted()) {
          Method method = param1Context.getClass().getMethod(this.mMethodName, new Class[] { View.class });
          if (method != null) {
            this.mResolvedMethod = method;
            this.mResolvedContext = param1Context;
            return;
          } 
        } 
        if (param1Context instanceof ContextWrapper) {
          param1Context = ((ContextWrapper)param1Context).getBaseContext();
          continue;
        } 
        param1Context = null;
      } 
      int i = this.mHostView.getId();
      if (i == -1) {
        str = "";
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(" with id '");
        stringBuilder1.append(this.mHostView.getContext().getResources().getResourceEntryName(i));
        stringBuilder1.append("'");
        str = stringBuilder1.toString();
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find method ");
      stringBuilder.append(this.mMethodName);
      stringBuilder.append("(View) in a parent or ancestor Context for android:onClick ");
      stringBuilder.append("attribute defined on view ");
      stringBuilder.append(this.mHostView.getClass());
      stringBuilder.append(str);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void onClick(@NonNull View param1View) {
      if (this.mResolvedMethod == null)
        resolveMethod(this.mHostView.getContext(), this.mMethodName); 
      try {
        this.mResolvedMethod.invoke(this.mResolvedContext, new Object[] { param1View });
        return;
      } catch (IllegalAccessException illegalAccessException) {
        throw new IllegalStateException("Could not execute non-public method for android:onClick", illegalAccessException);
      } catch (InvocationTargetException invocationTargetException) {
        throw new IllegalStateException("Could not execute method for android:onClick", invocationTargetException);
      } 
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AppCompatViewInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */