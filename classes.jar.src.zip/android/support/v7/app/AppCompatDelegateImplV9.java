package android.support.v7.app;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Rect;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.app.NavUtils;
import android.support.v4.view.LayoutInflaterCompat;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v4.widget.PopupWindowCompat;
import android.support.v7.appcompat.R;
import android.support.v7.content.res.AppCompatResources;
import android.support.v7.view.ActionMode;
import android.support.v7.view.ContextThemeWrapper;
import android.support.v7.view.StandaloneActionMode;
import android.support.v7.view.menu.ListMenuPresenter;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuView;
import android.support.v7.widget.ActionBarContextView;
import android.support.v7.widget.AppCompatDrawableManager;
import android.support.v7.widget.ContentFrameLayout;
import android.support.v7.widget.DecorContentParent;
import android.support.v7.widget.FitWindowsViewGroup;
import android.support.v7.widget.Toolbar;
import android.support.v7.widget.VectorEnabledTintResources;
import android.support.v7.widget.ViewStubCompat;
import android.support.v7.widget.ViewUtils;
import android.text.TextUtils;
import android.util.AndroidRuntimeException;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyCharacterMap;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.PopupWindow;
import android.widget.TextView;
import org.xmlpull.v1.XmlPullParser;

@RequiresApi(14)
class AppCompatDelegateImplV9 extends AppCompatDelegateImplBase implements MenuBuilder.Callback, LayoutInflater.Factory2 {
  private static final boolean IS_PRE_LOLLIPOP;
  
  ActionMode m;
  
  private ActionMenuPresenterCallback mActionMenuPresenterCallback;
  
  private AppCompatViewInflater mAppCompatViewInflater;
  
  private boolean mClosingActionMenu;
  
  private DecorContentParent mDecorContentParent;
  
  private boolean mEnableDefaultActionBarUp;
  
  private boolean mFeatureIndeterminateProgress;
  
  private boolean mFeatureProgress;
  
  private final Runnable mInvalidatePanelMenuRunnable = new Runnable(this) {
      public void run() {
        if ((0x1 & this.a.s) != 0)
          this.a.c(0); 
        if ((0x1000 & this.a.s) != 0)
          this.a.c(108); 
        this.a.r = false;
        this.a.s = 0;
      }
    };
  
  private boolean mLongPressBackDown;
  
  private PanelMenuPresenterCallback mPanelMenuPresenterCallback;
  
  private PanelFeatureState[] mPanels;
  
  private PanelFeatureState mPreparedPanel;
  
  private View mStatusGuard;
  
  private ViewGroup mSubDecor;
  
  private boolean mSubDecorInstalled;
  
  private Rect mTempRect1;
  
  private Rect mTempRect2;
  
  private TextView mTitleView;
  
  ActionBarContextView n;
  
  PopupWindow o;
  
  Runnable p;
  
  ViewPropertyAnimatorCompat q = null;
  
  boolean r;
  
  int s;
  
  static {
    boolean bool;
    if (Build.VERSION.SDK_INT < 21) {
      bool = true;
    } else {
      bool = false;
    } 
    IS_PRE_LOLLIPOP = bool;
  }
  
  AppCompatDelegateImplV9(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback) {
    super(paramContext, paramWindow, paramAppCompatCallback);
  }
  
  private void applyFixedSizeWindow() {
    ContentFrameLayout contentFrameLayout = (ContentFrameLayout)this.mSubDecor.findViewById(16908290);
    View view = this.b.getDecorView();
    contentFrameLayout.setDecorPadding(view.getPaddingLeft(), view.getPaddingTop(), view.getPaddingRight(), view.getPaddingBottom());
    TypedArray typedArray = this.a.obtainStyledAttributes(R.styleable.AppCompatTheme);
    typedArray.getValue(R.styleable.AppCompatTheme_windowMinWidthMajor, contentFrameLayout.getMinWidthMajor());
    typedArray.getValue(R.styleable.AppCompatTheme_windowMinWidthMinor, contentFrameLayout.getMinWidthMinor());
    if (typedArray.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMajor))
      typedArray.getValue(R.styleable.AppCompatTheme_windowFixedWidthMajor, contentFrameLayout.getFixedWidthMajor()); 
    if (typedArray.hasValue(R.styleable.AppCompatTheme_windowFixedWidthMinor))
      typedArray.getValue(R.styleable.AppCompatTheme_windowFixedWidthMinor, contentFrameLayout.getFixedWidthMinor()); 
    if (typedArray.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMajor))
      typedArray.getValue(R.styleable.AppCompatTheme_windowFixedHeightMajor, contentFrameLayout.getFixedHeightMajor()); 
    if (typedArray.hasValue(R.styleable.AppCompatTheme_windowFixedHeightMinor))
      typedArray.getValue(R.styleable.AppCompatTheme_windowFixedHeightMinor, contentFrameLayout.getFixedHeightMinor()); 
    typedArray.recycle();
    contentFrameLayout.requestLayout();
  }
  
  private ViewGroup createSubDecor() {
    TypedArray typedArray = this.a.obtainStyledAttributes(R.styleable.AppCompatTheme);
    if (typedArray.hasValue(R.styleable.AppCompatTheme_windowActionBar)) {
      ViewGroup viewGroup;
      if (typedArray.getBoolean(R.styleable.AppCompatTheme_windowNoTitle, false)) {
        requestWindowFeature(1);
      } else if (typedArray.getBoolean(R.styleable.AppCompatTheme_windowActionBar, false)) {
        requestWindowFeature(108);
      } 
      if (typedArray.getBoolean(R.styleable.AppCompatTheme_windowActionBarOverlay, false))
        requestWindowFeature(109); 
      if (typedArray.getBoolean(R.styleable.AppCompatTheme_windowActionModeOverlay, false))
        requestWindowFeature(10); 
      this.k = typedArray.getBoolean(R.styleable.AppCompatTheme_android_windowIsFloating, false);
      typedArray.recycle();
      this.b.getDecorView();
      LayoutInflater layoutInflater = LayoutInflater.from(this.a);
      if (!this.l) {
        if (this.k) {
          viewGroup = (ViewGroup)layoutInflater.inflate(R.layout.abc_dialog_title_material, null);
          this.i = false;
          this.h = false;
        } else if (this.h) {
          Context context;
          TypedValue typedValue = new TypedValue();
          this.a.getTheme().resolveAttribute(R.attr.actionBarTheme, typedValue, true);
          if (typedValue.resourceId != 0) {
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(this.a, typedValue.resourceId);
          } else {
            context = this.a;
          } 
          viewGroup = (ViewGroup)LayoutInflater.from(context).inflate(R.layout.abc_screen_toolbar, null);
          this.mDecorContentParent = (DecorContentParent)viewGroup.findViewById(R.id.decor_content_parent);
          this.mDecorContentParent.setWindowCallback(getWindowCallback());
          if (this.i)
            this.mDecorContentParent.initFeature(109); 
          if (this.mFeatureProgress)
            this.mDecorContentParent.initFeature(2); 
          if (this.mFeatureIndeterminateProgress)
            this.mDecorContentParent.initFeature(5); 
        } else {
          viewGroup = null;
        } 
      } else {
        if (this.j) {
          viewGroup = (ViewGroup)layoutInflater.inflate(R.layout.abc_screen_simple_overlay_action_mode, null);
        } else {
          viewGroup = (ViewGroup)layoutInflater.inflate(R.layout.abc_screen_simple, null);
        } 
        if (Build.VERSION.SDK_INT >= 21) {
          ViewCompat.setOnApplyWindowInsetsListener((View)viewGroup, new OnApplyWindowInsetsListener(this) {
                public WindowInsetsCompat onApplyWindowInsets(View param1View, WindowInsetsCompat param1WindowInsetsCompat) {
                  int i = param1WindowInsetsCompat.getSystemWindowInsetTop();
                  int j = this.a.d(i);
                  if (i != j)
                    param1WindowInsetsCompat = param1WindowInsetsCompat.replaceSystemWindowInsets(param1WindowInsetsCompat.getSystemWindowInsetLeft(), j, param1WindowInsetsCompat.getSystemWindowInsetRight(), param1WindowInsetsCompat.getSystemWindowInsetBottom()); 
                  return ViewCompat.onApplyWindowInsets(param1View, param1WindowInsetsCompat);
                }
              });
        } else {
          ((FitWindowsViewGroup)viewGroup).setOnFitSystemWindowsListener(new FitWindowsViewGroup.OnFitSystemWindowsListener(this) {
                public void onFitSystemWindows(Rect param1Rect) {
                  param1Rect.top = this.a.d(param1Rect.top);
                }
              });
        } 
      } 
      if (viewGroup != null) {
        if (this.mDecorContentParent == null)
          this.mTitleView = (TextView)viewGroup.findViewById(R.id.title); 
        ViewUtils.makeOptionalFitsSystemWindows((View)viewGroup);
        ContentFrameLayout contentFrameLayout = (ContentFrameLayout)viewGroup.findViewById(R.id.action_bar_activity_content);
        ViewGroup viewGroup1 = (ViewGroup)this.b.findViewById(16908290);
        if (viewGroup1 != null) {
          while (viewGroup1.getChildCount() > 0) {
            View view = viewGroup1.getChildAt(0);
            viewGroup1.removeViewAt(0);
            contentFrameLayout.addView(view);
          } 
          viewGroup1.setId(-1);
          contentFrameLayout.setId(16908290);
          if (viewGroup1 instanceof FrameLayout)
            ((FrameLayout)viewGroup1).setForeground(null); 
        } 
        this.b.setContentView((View)viewGroup);
        contentFrameLayout.setAttachListener(new ContentFrameLayout.OnAttachListener(this) {
              public void onAttachedFromWindow() {}
              
              public void onDetachedFromWindow() {
                this.a.e();
              }
            });
        return viewGroup;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("AppCompat does not support the current theme features: { windowActionBar: ");
      stringBuilder.append(this.h);
      stringBuilder.append(", windowActionBarOverlay: ");
      stringBuilder.append(this.i);
      stringBuilder.append(", android:windowIsFloating: ");
      stringBuilder.append(this.k);
      stringBuilder.append(", windowActionModeOverlay: ");
      stringBuilder.append(this.j);
      stringBuilder.append(", windowNoTitle: ");
      stringBuilder.append(this.l);
      stringBuilder.append(" }");
      throw new IllegalArgumentException(stringBuilder.toString());
    } 
    typedArray.recycle();
    throw new IllegalStateException("You need to use a Theme.AppCompat theme (or descendant) with this activity.");
  }
  
  private void ensureSubDecor() {
    if (!this.mSubDecorInstalled) {
      this.mSubDecor = createSubDecor();
      CharSequence charSequence = getTitle();
      if (!TextUtils.isEmpty(charSequence))
        a(charSequence); 
      applyFixedSizeWindow();
      a(this.mSubDecor);
      this.mSubDecorInstalled = true;
      PanelFeatureState panelFeatureState = a(0, false);
      if (!isDestroyed() && (panelFeatureState == null || panelFeatureState.j == null))
        invalidatePanelMenu(108); 
    } 
  }
  
  private boolean initializePanelContent(PanelFeatureState paramPanelFeatureState) {
    if (paramPanelFeatureState.i != null) {
      paramPanelFeatureState.h = paramPanelFeatureState.i;
      return true;
    } 
    if (paramPanelFeatureState.j == null)
      return false; 
    if (this.mPanelMenuPresenterCallback == null)
      this.mPanelMenuPresenterCallback = new PanelMenuPresenterCallback(this); 
    paramPanelFeatureState.h = (View)paramPanelFeatureState.a(this.mPanelMenuPresenterCallback);
    return (paramPanelFeatureState.h != null);
  }
  
  private boolean initializePanelDecor(PanelFeatureState paramPanelFeatureState) {
    paramPanelFeatureState.setStyle(getActionBarThemedContext());
    paramPanelFeatureState.g = (ViewGroup)new ListMenuDecorView(this, paramPanelFeatureState.l);
    paramPanelFeatureState.c = 81;
    return true;
  }
  
  private boolean initializePanelMenu(PanelFeatureState paramPanelFeatureState) {
    ContextThemeWrapper contextThemeWrapper;
    Context context = this.a;
    if ((paramPanelFeatureState.a == 0 || paramPanelFeatureState.a == 108) && this.mDecorContentParent != null) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme1 = context.getTheme();
      theme1.resolveAttribute(R.attr.actionBarTheme, typedValue, true);
      Resources.Theme theme2 = null;
      if (typedValue.resourceId != 0) {
        theme2 = context.getResources().newTheme();
        theme2.setTo(theme1);
        theme2.applyStyle(typedValue.resourceId, true);
        theme2.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
      } else {
        theme1.resolveAttribute(R.attr.actionBarWidgetTheme, typedValue, true);
      } 
      if (typedValue.resourceId != 0) {
        if (theme2 == null) {
          theme2 = context.getResources().newTheme();
          theme2.setTo(theme1);
        } 
        theme2.applyStyle(typedValue.resourceId, true);
      } 
      if (theme2 != null) {
        ContextThemeWrapper contextThemeWrapper1 = new ContextThemeWrapper(context, 0);
        contextThemeWrapper1.getTheme().setTo(theme2);
        contextThemeWrapper = contextThemeWrapper1;
      } 
    } 
    MenuBuilder menuBuilder = new MenuBuilder((Context)contextThemeWrapper);
    menuBuilder.setCallback(this);
    paramPanelFeatureState.setMenu(menuBuilder);
    return true;
  }
  
  private void invalidatePanelMenu(int paramInt) {
    this.s |= 1 << paramInt;
    if (!this.r) {
      ViewCompat.postOnAnimation(this.b.getDecorView(), this.mInvalidatePanelMenuRunnable);
      this.r = true;
    } 
  }
  
  private boolean onKeyDownPanel(int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getRepeatCount() == 0) {
      PanelFeatureState panelFeatureState = a(paramInt, true);
      if (!panelFeatureState.o)
        return preparePanel(panelFeatureState, paramKeyEvent); 
    } 
    return false;
  }
  
  private boolean onKeyUpPanel(int paramInt, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_0
    //   1: getfield m : Landroid/support/v7/view/ActionMode;
    //   4: ifnull -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_0
    //   10: iload_1
    //   11: iconst_1
    //   12: invokevirtual a : (IZ)Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;
    //   15: astore_3
    //   16: iload_1
    //   17: ifne -> 108
    //   20: aload_0
    //   21: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   24: ifnull -> 108
    //   27: aload_0
    //   28: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   31: invokeinterface canShowOverflowMenu : ()Z
    //   36: ifeq -> 108
    //   39: aload_0
    //   40: getfield a : Landroid/content/Context;
    //   43: invokestatic get : (Landroid/content/Context;)Landroid/view/ViewConfiguration;
    //   46: invokevirtual hasPermanentMenuKey : ()Z
    //   49: ifne -> 108
    //   52: aload_0
    //   53: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   56: invokeinterface isOverflowMenuShowing : ()Z
    //   61: ifne -> 94
    //   64: aload_0
    //   65: invokevirtual isDestroyed : ()Z
    //   68: ifne -> 175
    //   71: aload_0
    //   72: aload_3
    //   73: aload_2
    //   74: invokespecial preparePanel : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   77: ifeq -> 175
    //   80: aload_0
    //   81: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   84: invokeinterface showOverflowMenu : ()Z
    //   89: istore #4
    //   91: goto -> 193
    //   94: aload_0
    //   95: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   98: invokeinterface hideOverflowMenu : ()Z
    //   103: istore #4
    //   105: goto -> 193
    //   108: aload_3
    //   109: getfield o : Z
    //   112: ifne -> 181
    //   115: aload_3
    //   116: getfield n : Z
    //   119: ifeq -> 125
    //   122: goto -> 181
    //   125: aload_3
    //   126: getfield m : Z
    //   129: ifeq -> 175
    //   132: aload_3
    //   133: getfield q : Z
    //   136: ifeq -> 155
    //   139: aload_3
    //   140: iconst_0
    //   141: putfield m : Z
    //   144: aload_0
    //   145: aload_3
    //   146: aload_2
    //   147: invokespecial preparePanel : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   150: istore #7
    //   152: goto -> 158
    //   155: iconst_1
    //   156: istore #7
    //   158: iload #7
    //   160: ifeq -> 175
    //   163: aload_0
    //   164: aload_3
    //   165: aload_2
    //   166: invokespecial openPanel : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Landroid/view/KeyEvent;)V
    //   169: iconst_1
    //   170: istore #4
    //   172: goto -> 193
    //   175: iconst_0
    //   176: istore #4
    //   178: goto -> 193
    //   181: aload_3
    //   182: getfield o : Z
    //   185: istore #4
    //   187: aload_0
    //   188: aload_3
    //   189: iconst_1
    //   190: invokevirtual a : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Z)V
    //   193: iload #4
    //   195: ifeq -> 237
    //   198: aload_0
    //   199: getfield a : Landroid/content/Context;
    //   202: ldc_w 'audio'
    //   205: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   208: checkcast android/media/AudioManager
    //   211: astore #5
    //   213: aload #5
    //   215: ifnull -> 227
    //   218: aload #5
    //   220: iconst_0
    //   221: invokevirtual playSoundEffect : (I)V
    //   224: iload #4
    //   226: ireturn
    //   227: ldc_w 'AppCompatDelegate'
    //   230: ldc_w 'Couldn't get audio manager'
    //   233: invokestatic w : (Ljava/lang/String;Ljava/lang/String;)I
    //   236: pop
    //   237: iload #4
    //   239: ireturn
  }
  
  private void openPanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent) {
    // Byte code:
    //   0: aload_1
    //   1: getfield o : Z
    //   4: ifne -> 420
    //   7: aload_0
    //   8: invokevirtual isDestroyed : ()Z
    //   11: ifeq -> 15
    //   14: return
    //   15: aload_1
    //   16: getfield a : I
    //   19: ifne -> 57
    //   22: bipush #15
    //   24: aload_0
    //   25: getfield a : Landroid/content/Context;
    //   28: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   31: invokevirtual getConfiguration : ()Landroid/content/res/Configuration;
    //   34: getfield screenLayout : I
    //   37: iand
    //   38: iconst_4
    //   39: if_icmpne -> 48
    //   42: iconst_1
    //   43: istore #12
    //   45: goto -> 51
    //   48: iconst_0
    //   49: istore #12
    //   51: iload #12
    //   53: ifeq -> 57
    //   56: return
    //   57: aload_0
    //   58: invokevirtual getWindowCallback : ()Landroid/view/Window$Callback;
    //   61: astore_3
    //   62: aload_3
    //   63: ifnull -> 90
    //   66: aload_3
    //   67: aload_1
    //   68: getfield a : I
    //   71: aload_1
    //   72: getfield j : Landroid/support/v7/view/menu/MenuBuilder;
    //   75: invokeinterface onMenuOpened : (ILandroid/view/Menu;)Z
    //   80: ifne -> 90
    //   83: aload_0
    //   84: aload_1
    //   85: iconst_1
    //   86: invokevirtual a : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Z)V
    //   89: return
    //   90: aload_0
    //   91: getfield a : Landroid/content/Context;
    //   94: ldc_w 'window'
    //   97: invokevirtual getSystemService : (Ljava/lang/String;)Ljava/lang/Object;
    //   100: checkcast android/view/WindowManager
    //   103: astore #4
    //   105: aload #4
    //   107: ifnonnull -> 111
    //   110: return
    //   111: aload_0
    //   112: aload_1
    //   113: aload_2
    //   114: invokespecial preparePanel : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   117: ifne -> 121
    //   120: return
    //   121: aload_1
    //   122: getfield g : Landroid/view/ViewGroup;
    //   125: ifnull -> 174
    //   128: aload_1
    //   129: getfield p : Z
    //   132: ifeq -> 138
    //   135: goto -> 174
    //   138: aload_1
    //   139: getfield i : Landroid/view/View;
    //   142: ifnull -> 344
    //   145: aload_1
    //   146: getfield i : Landroid/view/View;
    //   149: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   152: astore #11
    //   154: aload #11
    //   156: ifnull -> 344
    //   159: aload #11
    //   161: getfield width : I
    //   164: iconst_m1
    //   165: if_icmpne -> 344
    //   168: iconst_m1
    //   169: istore #8
    //   171: goto -> 348
    //   174: aload_1
    //   175: getfield g : Landroid/view/ViewGroup;
    //   178: ifnonnull -> 197
    //   181: aload_0
    //   182: aload_1
    //   183: invokespecial initializePanelDecor : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;)Z
    //   186: ifeq -> 196
    //   189: aload_1
    //   190: getfield g : Landroid/view/ViewGroup;
    //   193: ifnonnull -> 221
    //   196: return
    //   197: aload_1
    //   198: getfield p : Z
    //   201: ifeq -> 221
    //   204: aload_1
    //   205: getfield g : Landroid/view/ViewGroup;
    //   208: invokevirtual getChildCount : ()I
    //   211: ifle -> 221
    //   214: aload_1
    //   215: getfield g : Landroid/view/ViewGroup;
    //   218: invokevirtual removeAllViews : ()V
    //   221: aload_0
    //   222: aload_1
    //   223: invokespecial initializePanelContent : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;)Z
    //   226: ifeq -> 419
    //   229: aload_1
    //   230: invokevirtual hasPanelItems : ()Z
    //   233: ifne -> 237
    //   236: return
    //   237: aload_1
    //   238: getfield h : Landroid/view/View;
    //   241: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   244: astore #5
    //   246: aload #5
    //   248: ifnonnull -> 264
    //   251: new android/view/ViewGroup$LayoutParams
    //   254: dup
    //   255: bipush #-2
    //   257: bipush #-2
    //   259: invokespecial <init> : (II)V
    //   262: astore #5
    //   264: aload_1
    //   265: getfield b : I
    //   268: istore #6
    //   270: aload_1
    //   271: getfield g : Landroid/view/ViewGroup;
    //   274: iload #6
    //   276: invokevirtual setBackgroundResource : (I)V
    //   279: aload_1
    //   280: getfield h : Landroid/view/View;
    //   283: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   286: astore #7
    //   288: aload #7
    //   290: ifnull -> 313
    //   293: aload #7
    //   295: instanceof android/view/ViewGroup
    //   298: ifeq -> 313
    //   301: aload #7
    //   303: checkcast android/view/ViewGroup
    //   306: aload_1
    //   307: getfield h : Landroid/view/View;
    //   310: invokevirtual removeView : (Landroid/view/View;)V
    //   313: aload_1
    //   314: getfield g : Landroid/view/ViewGroup;
    //   317: aload_1
    //   318: getfield h : Landroid/view/View;
    //   321: aload #5
    //   323: invokevirtual addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   326: aload_1
    //   327: getfield h : Landroid/view/View;
    //   330: invokevirtual hasFocus : ()Z
    //   333: ifne -> 344
    //   336: aload_1
    //   337: getfield h : Landroid/view/View;
    //   340: invokevirtual requestFocus : ()Z
    //   343: pop
    //   344: bipush #-2
    //   346: istore #8
    //   348: aload_1
    //   349: iconst_0
    //   350: putfield n : Z
    //   353: new android/view/WindowManager$LayoutParams
    //   356: dup
    //   357: iload #8
    //   359: bipush #-2
    //   361: aload_1
    //   362: getfield d : I
    //   365: aload_1
    //   366: getfield e : I
    //   369: sipush #1002
    //   372: ldc_w 8519680
    //   375: bipush #-3
    //   377: invokespecial <init> : (IIIIIII)V
    //   380: astore #9
    //   382: aload #9
    //   384: aload_1
    //   385: getfield c : I
    //   388: putfield gravity : I
    //   391: aload #9
    //   393: aload_1
    //   394: getfield f : I
    //   397: putfield windowAnimations : I
    //   400: aload #4
    //   402: aload_1
    //   403: getfield g : Landroid/view/ViewGroup;
    //   406: aload #9
    //   408: invokeinterface addView : (Landroid/view/View;Landroid/view/ViewGroup$LayoutParams;)V
    //   413: aload_1
    //   414: iconst_1
    //   415: putfield o : Z
    //   418: return
    //   419: return
    //   420: return
  }
  
  private boolean performPanelShortcut(PanelFeatureState paramPanelFeatureState, int paramInt1, KeyEvent paramKeyEvent, int paramInt2) {
    // Byte code:
    //   0: aload_3
    //   1: invokevirtual isSystem : ()Z
    //   4: ifeq -> 9
    //   7: iconst_0
    //   8: ireturn
    //   9: aload_1
    //   10: getfield m : Z
    //   13: ifne -> 32
    //   16: aload_0
    //   17: aload_1
    //   18: aload_3
    //   19: invokespecial preparePanel : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Landroid/view/KeyEvent;)Z
    //   22: istore #7
    //   24: iconst_0
    //   25: istore #6
    //   27: iload #7
    //   29: ifeq -> 59
    //   32: aload_1
    //   33: getfield j : Landroid/support/v7/view/menu/MenuBuilder;
    //   36: astore #5
    //   38: iconst_0
    //   39: istore #6
    //   41: aload #5
    //   43: ifnull -> 59
    //   46: aload_1
    //   47: getfield j : Landroid/support/v7/view/menu/MenuBuilder;
    //   50: iload_2
    //   51: aload_3
    //   52: iload #4
    //   54: invokevirtual performShortcut : (ILandroid/view/KeyEvent;I)Z
    //   57: istore #6
    //   59: iload #6
    //   61: ifeq -> 84
    //   64: iload #4
    //   66: iconst_1
    //   67: iand
    //   68: ifne -> 84
    //   71: aload_0
    //   72: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   75: ifnonnull -> 84
    //   78: aload_0
    //   79: aload_1
    //   80: iconst_1
    //   81: invokevirtual a : (Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;Z)V
    //   84: iload #6
    //   86: ireturn
  }
  
  private boolean preparePanel(PanelFeatureState paramPanelFeatureState, KeyEvent paramKeyEvent) {
    boolean bool;
    if (isDestroyed())
      return false; 
    if (paramPanelFeatureState.m)
      return true; 
    if (this.mPreparedPanel != null && this.mPreparedPanel != paramPanelFeatureState)
      a(this.mPreparedPanel, false); 
    Window.Callback callback = getWindowCallback();
    if (callback != null)
      paramPanelFeatureState.i = callback.onCreatePanelView(paramPanelFeatureState.a); 
    if (paramPanelFeatureState.a == 0 || paramPanelFeatureState.a == 108) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool && this.mDecorContentParent != null)
      this.mDecorContentParent.setMenuPrepared(); 
    if (paramPanelFeatureState.i == null && (!bool || !(a() instanceof ToolbarActionBar))) {
      byte b;
      boolean bool1;
      if (paramPanelFeatureState.j == null || paramPanelFeatureState.q) {
        if (paramPanelFeatureState.j == null && (!initializePanelMenu(paramPanelFeatureState) || paramPanelFeatureState.j == null))
          return false; 
        if (bool && this.mDecorContentParent != null) {
          if (this.mActionMenuPresenterCallback == null)
            this.mActionMenuPresenterCallback = new ActionMenuPresenterCallback(this); 
          this.mDecorContentParent.setMenu((Menu)paramPanelFeatureState.j, this.mActionMenuPresenterCallback);
        } 
        paramPanelFeatureState.j.stopDispatchingItemsChanged();
        if (!callback.onCreatePanelMenu(paramPanelFeatureState.a, (Menu)paramPanelFeatureState.j)) {
          paramPanelFeatureState.setMenu(null);
          if (bool && this.mDecorContentParent != null)
            this.mDecorContentParent.setMenu(null, this.mActionMenuPresenterCallback); 
          return false;
        } 
        paramPanelFeatureState.q = false;
      } 
      paramPanelFeatureState.j.stopDispatchingItemsChanged();
      if (paramPanelFeatureState.r != null) {
        paramPanelFeatureState.j.restoreActionViewStates(paramPanelFeatureState.r);
        paramPanelFeatureState.r = null;
      } 
      if (!callback.onPreparePanel(0, paramPanelFeatureState.i, (Menu)paramPanelFeatureState.j)) {
        if (bool && this.mDecorContentParent != null)
          this.mDecorContentParent.setMenu(null, this.mActionMenuPresenterCallback); 
        paramPanelFeatureState.j.startDispatchingItemsChanged();
        return false;
      } 
      if (paramKeyEvent != null) {
        b = paramKeyEvent.getDeviceId();
      } else {
        b = -1;
      } 
      if (KeyCharacterMap.load(b).getKeyboardType() != 1) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      paramPanelFeatureState.qwertyMode = bool1;
      paramPanelFeatureState.j.setQwertyMode(paramPanelFeatureState.qwertyMode);
      paramPanelFeatureState.j.startDispatchingItemsChanged();
    } 
    paramPanelFeatureState.m = true;
    paramPanelFeatureState.n = false;
    this.mPreparedPanel = paramPanelFeatureState;
    return true;
  }
  
  private void reopenMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (this.mDecorContentParent != null && this.mDecorContentParent.canShowOverflowMenu() && (!ViewConfiguration.get(this.a).hasPermanentMenuKey() || this.mDecorContentParent.isOverflowMenuShowPending())) {
      Window.Callback callback = getWindowCallback();
      if (!this.mDecorContentParent.isOverflowMenuShowing() || !paramBoolean) {
        if (callback != null && !isDestroyed()) {
          if (this.r && (0x1 & this.s) != 0) {
            this.b.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable);
            this.mInvalidatePanelMenuRunnable.run();
          } 
          PanelFeatureState panelFeatureState1 = a(0, true);
          if (panelFeatureState1.j != null && !panelFeatureState1.q && callback.onPreparePanel(0, panelFeatureState1.i, (Menu)panelFeatureState1.j)) {
            callback.onMenuOpened(108, (Menu)panelFeatureState1.j);
            this.mDecorContentParent.showOverflowMenu();
          } 
        } 
        return;
      } 
      this.mDecorContentParent.hideOverflowMenu();
      if (!isDestroyed()) {
        callback.onPanelClosed(108, (Menu)(a(0, true)).j);
        return;
      } 
      return;
    } 
    PanelFeatureState panelFeatureState = a(0, true);
    panelFeatureState.p = true;
    a(panelFeatureState, false);
    openPanel(panelFeatureState, (KeyEvent)null);
  }
  
  private int sanitizeWindowFeatureId(int paramInt) {
    if (paramInt == 8) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR id when requesting this feature.");
      return 108;
    } 
    if (paramInt == 9) {
      Log.i("AppCompatDelegate", "You should now use the AppCompatDelegate.FEATURE_SUPPORT_ACTION_BAR_OVERLAY id when requesting this feature.");
      return 109;
    } 
    return paramInt;
  }
  
  private boolean shouldInheritContext(ViewParent paramViewParent) {
    if (paramViewParent == null)
      return false; 
    View view = this.b.getDecorView();
    while (true) {
      if (paramViewParent == null)
        return true; 
      if (paramViewParent != view && paramViewParent instanceof View) {
        if (ViewCompat.isAttachedToWindow((View)paramViewParent))
          return false; 
        paramViewParent = paramViewParent.getParent();
        continue;
      } 
      break;
    } 
    return false;
  }
  
  private void throwFeatureRequestIfSubDecorInstalled() {
    if (!this.mSubDecorInstalled)
      return; 
    throw new AndroidRuntimeException("Window feature must be requested before adding content");
  }
  
  protected PanelFeatureState a(int paramInt, boolean paramBoolean) {
    PanelFeatureState[] arrayOfPanelFeatureState = this.mPanels;
    if (arrayOfPanelFeatureState == null || arrayOfPanelFeatureState.length <= paramInt) {
      PanelFeatureState[] arrayOfPanelFeatureState1 = new PanelFeatureState[paramInt + 1];
      if (arrayOfPanelFeatureState != null)
        System.arraycopy(arrayOfPanelFeatureState, 0, arrayOfPanelFeatureState1, 0, arrayOfPanelFeatureState.length); 
      this.mPanels = arrayOfPanelFeatureState1;
      arrayOfPanelFeatureState = arrayOfPanelFeatureState1;
    } 
    PanelFeatureState panelFeatureState = arrayOfPanelFeatureState[paramInt];
    if (panelFeatureState == null) {
      panelFeatureState = new PanelFeatureState(paramInt);
      arrayOfPanelFeatureState[paramInt] = panelFeatureState;
    } 
    return panelFeatureState;
  }
  
  PanelFeatureState a(Menu paramMenu) {
    byte b2;
    PanelFeatureState[] arrayOfPanelFeatureState = this.mPanels;
    byte b1 = 0;
    if (arrayOfPanelFeatureState != null) {
      b2 = arrayOfPanelFeatureState.length;
      b1 = 0;
    } else {
      b2 = 0;
    } 
    while (b1 < b2) {
      PanelFeatureState panelFeatureState = arrayOfPanelFeatureState[b1];
      if (panelFeatureState != null && panelFeatureState.j == paramMenu)
        return panelFeatureState; 
      b1++;
    } 
    return null;
  }
  
  ActionMode a(@NonNull ActionMode.Callback paramCallback) {
    ActionMode actionMode;
    c();
    if (this.m != null)
      this.m.finish(); 
    if (!(paramCallback instanceof ActionModeCallbackWrapperV9))
      paramCallback = new ActionModeCallbackWrapperV9(this, paramCallback); 
    if (this.e != null && !isDestroyed()) {
      actionMode = this.e.onWindowStartingSupportActionMode(paramCallback);
    } else {
      actionMode = null;
    } 
    if (actionMode != null) {
      this.m = actionMode;
    } else {
      ActionBarContextView actionBarContextView = this.n;
      boolean bool = true;
      if (actionBarContextView == null)
        if (this.k) {
          Context context;
          TypedValue typedValue = new TypedValue();
          Resources.Theme theme = this.a.getTheme();
          theme.resolveAttribute(R.attr.actionBarTheme, typedValue, bool);
          if (typedValue.resourceId != 0) {
            Resources.Theme theme1 = this.a.getResources().newTheme();
            theme1.setTo(theme);
            theme1.applyStyle(typedValue.resourceId, bool);
            ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(this.a, 0);
            contextThemeWrapper.getTheme().setTo(theme1);
          } else {
            context = this.a;
          } 
          this.n = new ActionBarContextView(context);
          this.o = new PopupWindow(context, null, R.attr.actionModePopupWindowStyle);
          PopupWindowCompat.setWindowLayoutType(this.o, 2);
          this.o.setContentView((View)this.n);
          this.o.setWidth(-1);
          context.getTheme().resolveAttribute(R.attr.actionBarSize, typedValue, bool);
          int i = TypedValue.complexToDimensionPixelSize(typedValue.data, context.getResources().getDisplayMetrics());
          this.n.setContentHeight(i);
          this.o.setHeight(-2);
          this.p = new Runnable(this) {
              public void run() {
                this.a.o.showAtLocation((View)this.a.n, 55, 0, 0);
                this.a.c();
                if (this.a.b()) {
                  this.a.n.setAlpha(0.0F);
                  this.a.q = ViewCompat.animate((View)this.a.n).alpha(1.0F);
                  this.a.q.setListener((ViewPropertyAnimatorListener)new ViewPropertyAnimatorListenerAdapter(this) {
                        public void onAnimationEnd(View param2View) {
                          this.a.a.n.setAlpha(1.0F);
                          this.a.a.q.setListener(null);
                          this.a.a.q = null;
                        }
                        
                        public void onAnimationStart(View param2View) {
                          this.a.a.n.setVisibility(0);
                        }
                      });
                  return;
                } 
                this.a.n.setAlpha(1.0F);
                this.a.n.setVisibility(0);
              }
            };
        } else {
          ViewStubCompat viewStubCompat = (ViewStubCompat)this.mSubDecor.findViewById(R.id.action_mode_bar_stub);
          if (viewStubCompat != null) {
            viewStubCompat.setLayoutInflater(LayoutInflater.from(getActionBarThemedContext()));
            this.n = (ActionBarContextView)viewStubCompat.inflate();
          } 
        }  
      if (this.n != null) {
        c();
        this.n.killMode();
        Context context = this.n.getContext();
        ActionBarContextView actionBarContextView1 = this.n;
        if (this.o != null)
          bool = false; 
        StandaloneActionMode standaloneActionMode = new StandaloneActionMode(context, actionBarContextView1, paramCallback, bool);
        if (paramCallback.onCreateActionMode((ActionMode)standaloneActionMode, standaloneActionMode.getMenu())) {
          standaloneActionMode.invalidate();
          this.n.initForMode((ActionMode)standaloneActionMode);
          this.m = (ActionMode)standaloneActionMode;
          if (b()) {
            this.n.setAlpha(0.0F);
            this.q = ViewCompat.animate((View)this.n).alpha(1.0F);
            this.q.setListener((ViewPropertyAnimatorListener)new ViewPropertyAnimatorListenerAdapter(this) {
                  public void onAnimationEnd(View param1View) {
                    this.a.n.setAlpha(1.0F);
                    this.a.q.setListener(null);
                    this.a.q = null;
                  }
                  
                  public void onAnimationStart(View param1View) {
                    this.a.n.setVisibility(0);
                    this.a.n.sendAccessibilityEvent(32);
                    if (this.a.n.getParent() instanceof View)
                      ViewCompat.requestApplyInsets((View)this.a.n.getParent()); 
                  }
                });
          } else {
            this.n.setAlpha(1.0F);
            this.n.setVisibility(0);
            this.n.sendAccessibilityEvent(32);
            if (this.n.getParent() instanceof View)
              ViewCompat.requestApplyInsets((View)this.n.getParent()); 
          } 
          if (this.o != null)
            this.b.getDecorView().post(this.p); 
        } else {
          this.m = null;
        } 
      } 
    } 
    if (this.m != null && this.e != null)
      this.e.onSupportActionModeStarted(this.m); 
    return this.m;
  }
  
  View a(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (this.c instanceof LayoutInflater.Factory) {
      View view = ((LayoutInflater.Factory)this.c).onCreateView(paramString, paramContext, paramAttributeSet);
      if (view != null)
        return view; 
    } 
    return null;
  }
  
  void a(int paramInt, PanelFeatureState paramPanelFeatureState, Menu paramMenu) {
    MenuBuilder menuBuilder;
    if (paramMenu == null) {
      if (paramPanelFeatureState == null && paramInt >= 0 && paramInt < this.mPanels.length)
        paramPanelFeatureState = this.mPanels[paramInt]; 
      if (paramPanelFeatureState != null)
        menuBuilder = paramPanelFeatureState.j; 
    } 
    if (paramPanelFeatureState != null && !paramPanelFeatureState.o)
      return; 
    if (!isDestroyed())
      this.c.onPanelClosed(paramInt, (Menu)menuBuilder); 
  }
  
  void a(int paramInt, Menu paramMenu) {
    if (paramInt == 108) {
      ActionBar actionBar = getSupportActionBar();
      if (actionBar != null) {
        actionBar.dispatchMenuVisibilityChanged(false);
        return;
      } 
    } else if (paramInt == 0) {
      PanelFeatureState panelFeatureState = a(paramInt, true);
      if (panelFeatureState.o)
        a(panelFeatureState, false); 
    } 
  }
  
  void a(PanelFeatureState paramPanelFeatureState, boolean paramBoolean) {
    if (paramBoolean && paramPanelFeatureState.a == 0 && this.mDecorContentParent != null && this.mDecorContentParent.isOverflowMenuShowing()) {
      a(paramPanelFeatureState.j);
      return;
    } 
    WindowManager windowManager = (WindowManager)this.a.getSystemService("window");
    if (windowManager != null && paramPanelFeatureState.o && paramPanelFeatureState.g != null) {
      windowManager.removeView((View)paramPanelFeatureState.g);
      if (paramBoolean)
        a(paramPanelFeatureState.a, paramPanelFeatureState, (Menu)null); 
    } 
    paramPanelFeatureState.m = false;
    paramPanelFeatureState.n = false;
    paramPanelFeatureState.o = false;
    paramPanelFeatureState.h = null;
    paramPanelFeatureState.p = true;
    if (this.mPreparedPanel == paramPanelFeatureState)
      this.mPreparedPanel = null; 
  }
  
  void a(MenuBuilder paramMenuBuilder) {
    if (this.mClosingActionMenu)
      return; 
    this.mClosingActionMenu = true;
    this.mDecorContentParent.dismissPopups();
    Window.Callback callback = getWindowCallback();
    if (callback != null && !isDestroyed())
      callback.onPanelClosed(108, (Menu)paramMenuBuilder); 
    this.mClosingActionMenu = false;
  }
  
  void a(ViewGroup paramViewGroup) {}
  
  void a(CharSequence paramCharSequence) {
    if (this.mDecorContentParent != null) {
      this.mDecorContentParent.setWindowTitle(paramCharSequence);
      return;
    } 
    if (a() != null) {
      a().setWindowTitle(paramCharSequence);
      return;
    } 
    if (this.mTitleView != null)
      this.mTitleView.setText(paramCharSequence); 
  }
  
  boolean a(int paramInt, KeyEvent paramKeyEvent) {
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null && actionBar.onKeyShortcut(paramInt, paramKeyEvent))
      return true; 
    if (this.mPreparedPanel != null && performPanelShortcut(this.mPreparedPanel, paramKeyEvent.getKeyCode(), paramKeyEvent, 1)) {
      if (this.mPreparedPanel != null)
        this.mPreparedPanel.n = true; 
      return true;
    } 
    if (this.mPreparedPanel == null) {
      PanelFeatureState panelFeatureState = a(0, true);
      preparePanel(panelFeatureState, paramKeyEvent);
      boolean bool = performPanelShortcut(panelFeatureState, paramKeyEvent.getKeyCode(), paramKeyEvent, 1);
      panelFeatureState.m = false;
      if (bool)
        return true; 
    } 
    return false;
  }
  
  boolean a(KeyEvent paramKeyEvent) {
    int i = paramKeyEvent.getKeyCode();
    boolean bool = true;
    if (i == 82 && this.c.dispatchKeyEvent(paramKeyEvent))
      return bool; 
    int j = paramKeyEvent.getKeyCode();
    if (paramKeyEvent.getAction() != 0)
      bool = false; 
    return bool ? c(j, paramKeyEvent) : b(j, paramKeyEvent);
  }
  
  public void addContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    ensureSubDecor();
    ((ViewGroup)this.mSubDecor.findViewById(16908290)).addView(paramView, paramLayoutParams);
    this.c.onContentChanged();
  }
  
  void b(int paramInt) {
    a(a(paramInt, true), true);
  }
  
  final boolean b() {
    return (this.mSubDecorInstalled && this.mSubDecor != null && ViewCompat.isLaidOut((View)this.mSubDecor));
  }
  
  boolean b(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      onKeyUpPanel(0, paramKeyEvent);
      return true;
    } 
    boolean bool = this.mLongPressBackDown;
    this.mLongPressBackDown = false;
    PanelFeatureState panelFeatureState = a(0, false);
    if (panelFeatureState != null && panelFeatureState.o) {
      if (!bool)
        a(panelFeatureState, true); 
      return true;
    } 
    return d();
  }
  
  boolean b(int paramInt, Menu paramMenu) {
    if (paramInt == 108) {
      ActionBar actionBar = getSupportActionBar();
      if (actionBar != null)
        actionBar.dispatchMenuVisibilityChanged(true); 
      return true;
    } 
    return false;
  }
  
  void c() {
    if (this.q != null)
      this.q.cancel(); 
  }
  
  void c(int paramInt) {
    PanelFeatureState panelFeatureState = a(paramInt, true);
    if (panelFeatureState.j != null) {
      Bundle bundle = new Bundle();
      panelFeatureState.j.saveActionViewStates(bundle);
      if (bundle.size() > 0)
        panelFeatureState.r = bundle; 
      panelFeatureState.j.stopDispatchingItemsChanged();
      panelFeatureState.j.clear();
    } 
    panelFeatureState.q = true;
    panelFeatureState.p = true;
    if ((paramInt == 108 || paramInt == 0) && this.mDecorContentParent != null) {
      PanelFeatureState panelFeatureState1 = a(0, false);
      if (panelFeatureState1 != null) {
        panelFeatureState1.m = false;
        preparePanel(panelFeatureState1, (KeyEvent)null);
      } 
    } 
  }
  
  boolean c(int paramInt, KeyEvent paramKeyEvent) {
    boolean bool = true;
    if (paramInt != 4) {
      if (paramInt != 82)
        return false; 
      onKeyDownPanel(0, paramKeyEvent);
      return bool;
    } 
    if ((0x80 & paramKeyEvent.getFlags()) == 0)
      bool = false; 
    this.mLongPressBackDown = bool;
    return false;
  }
  
  public View createView(View paramView, String paramString, @NonNull Context paramContext, @NonNull AttributeSet paramAttributeSet) {
    boolean bool;
    if (this.mAppCompatViewInflater == null) {
      String str = this.a.obtainStyledAttributes(R.styleable.AppCompatTheme).getString(R.styleable.AppCompatTheme_viewInflaterClass);
      if (str == null || AppCompatViewInflater.class.getName().equals(str)) {
        this.mAppCompatViewInflater = new AppCompatViewInflater();
      } else {
        try {
          this.mAppCompatViewInflater = Class.forName(str).getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
        } catch (Throwable throwable) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Failed to instantiate custom view inflater ");
          stringBuilder.append(str);
          stringBuilder.append(". Falling back to default.");
          Log.i("AppCompatDelegate", stringBuilder.toString(), throwable);
          this.mAppCompatViewInflater = new AppCompatViewInflater();
        } 
      } 
    } 
    if (IS_PRE_LOLLIPOP) {
      boolean bool1;
      if (paramAttributeSet instanceof XmlPullParser) {
        int i = ((XmlPullParser)paramAttributeSet).getDepth();
        bool1 = false;
        if (i > 1)
          bool1 = true; 
      } else {
        bool1 = shouldInheritContext((ViewParent)paramView);
      } 
      bool = bool1;
    } else {
      bool = false;
    } 
    return this.mAppCompatViewInflater.a(paramView, paramString, paramContext, paramAttributeSet, bool, IS_PRE_LOLLIPOP, true, VectorEnabledTintResources.shouldBeUsed());
  }
  
  int d(int paramInt) {
    boolean bool;
    if (this.n != null && this.n.getLayoutParams() instanceof ViewGroup.MarginLayoutParams) {
      boolean bool2;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.n.getLayoutParams();
      boolean bool1 = this.n.isShown();
      bool = true;
      if (bool1) {
        boolean bool3;
        if (this.mTempRect1 == null) {
          this.mTempRect1 = new Rect();
          this.mTempRect2 = new Rect();
        } 
        Rect rect1 = this.mTempRect1;
        Rect rect2 = this.mTempRect2;
        rect1.set(0, paramInt, 0, 0);
        ViewUtils.computeFitSystemWindows((View)this.mSubDecor, rect1, rect2);
        if (rect2.top == 0) {
          bool3 = paramInt;
        } else {
          bool3 = false;
        } 
        if (marginLayoutParams.topMargin != bool3) {
          marginLayoutParams.topMargin = paramInt;
          if (this.mStatusGuard == null) {
            this.mStatusGuard = new View(this.a);
            this.mStatusGuard.setBackgroundColor(this.a.getResources().getColor(R.color.abc_input_method_navigation_guard));
            this.mSubDecor.addView(this.mStatusGuard, -1, new ViewGroup.LayoutParams(-1, paramInt));
          } else {
            ViewGroup.LayoutParams layoutParams = this.mStatusGuard.getLayoutParams();
            if (layoutParams.height != paramInt) {
              layoutParams.height = paramInt;
              this.mStatusGuard.setLayoutParams(layoutParams);
            } 
          } 
          bool2 = true;
        } else {
          bool2 = false;
        } 
        if (this.mStatusGuard == null)
          bool = false; 
        if (!this.j && bool)
          paramInt = 0; 
      } else {
        if (marginLayoutParams.topMargin != 0) {
          marginLayoutParams.topMargin = 0;
          bool2 = true;
        } else {
          bool2 = false;
        } 
        bool = false;
      } 
      if (bool2)
        this.n.setLayoutParams((ViewGroup.LayoutParams)marginLayoutParams); 
    } else {
      bool = false;
    } 
    if (this.mStatusGuard != null) {
      byte b;
      View view = this.mStatusGuard;
      if (bool) {
        b = 0;
      } else {
        b = 8;
      } 
      view.setVisibility(b);
    } 
    return paramInt;
  }
  
  boolean d() {
    if (this.m != null) {
      this.m.finish();
      return true;
    } 
    ActionBar actionBar = getSupportActionBar();
    return (actionBar != null && actionBar.collapseActionView());
  }
  
  void e() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   4: ifnull -> 16
    //   7: aload_0
    //   8: getfield mDecorContentParent : Landroid/support/v7/widget/DecorContentParent;
    //   11: invokeinterface dismissPopups : ()V
    //   16: aload_0
    //   17: getfield o : Landroid/widget/PopupWindow;
    //   20: ifnull -> 64
    //   23: aload_0
    //   24: getfield b : Landroid/view/Window;
    //   27: invokevirtual getDecorView : ()Landroid/view/View;
    //   30: aload_0
    //   31: getfield p : Ljava/lang/Runnable;
    //   34: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)Z
    //   37: pop
    //   38: aload_0
    //   39: getfield o : Landroid/widget/PopupWindow;
    //   42: invokevirtual isShowing : ()Z
    //   45: ifeq -> 58
    //   48: aload_0
    //   49: getfield o : Landroid/widget/PopupWindow;
    //   52: invokevirtual dismiss : ()V
    //   55: goto -> 59
    //   58: pop
    //   59: aload_0
    //   60: aconst_null
    //   61: putfield o : Landroid/widget/PopupWindow;
    //   64: aload_0
    //   65: invokevirtual c : ()V
    //   68: aload_0
    //   69: iconst_0
    //   70: iconst_0
    //   71: invokevirtual a : (IZ)Landroid/support/v7/app/AppCompatDelegateImplV9$PanelFeatureState;
    //   74: astore_1
    //   75: aload_1
    //   76: ifnull -> 93
    //   79: aload_1
    //   80: getfield j : Landroid/support/v7/view/menu/MenuBuilder;
    //   83: ifnull -> 93
    //   86: aload_1
    //   87: getfield j : Landroid/support/v7/view/menu/MenuBuilder;
    //   90: invokevirtual close : ()V
    //   93: return
    // Exception table:
    //   from	to	target	type
    //   48	55	58	java/lang/IllegalArgumentException
  }
  
  @Nullable
  public <T extends View> T findViewById(@IdRes int paramInt) {
    ensureSubDecor();
    return (T)this.b.findViewById(paramInt);
  }
  
  ViewGroup getSubDecor() {
    return this.mSubDecor;
  }
  
  public boolean hasWindowFeature(int paramInt) {
    switch (sanitizeWindowFeatureId(paramInt)) {
      default:
        return false;
      case 109:
        return this.i;
      case 108:
        return this.h;
      case 10:
        return this.j;
      case 5:
        return this.mFeatureIndeterminateProgress;
      case 2:
        return this.mFeatureProgress;
      case 1:
        break;
    } 
    return this.l;
  }
  
  public void initWindowDecorActionBar() {
    ensureSubDecor();
    if (this.h) {
      if (this.f != null)
        return; 
      if (this.c instanceof Activity) {
        this.f = new WindowDecorActionBar((Activity)this.c, this.i);
      } else if (this.c instanceof Dialog) {
        this.f = new WindowDecorActionBar((Dialog)this.c);
      } 
      if (this.f != null)
        this.f.setDefaultDisplayHomeAsUpEnabled(this.mEnableDefaultActionBarUp); 
      return;
    } 
  }
  
  public void installViewFactory() {
    LayoutInflater layoutInflater = LayoutInflater.from(this.a);
    if (layoutInflater.getFactory() == null) {
      LayoutInflaterCompat.setFactory2(layoutInflater, this);
      return;
    } 
    if (!(layoutInflater.getFactory2() instanceof AppCompatDelegateImplV9))
      Log.i("AppCompatDelegate", "The Activity's LayoutInflater already has a Factory installed so we can not install AppCompat's"); 
  }
  
  public void invalidateOptionsMenu() {
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null && actionBar.invalidateOptionsMenu())
      return; 
    invalidatePanelMenu(0);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (this.h && this.mSubDecorInstalled) {
      ActionBar actionBar = getSupportActionBar();
      if (actionBar != null)
        actionBar.onConfigurationChanged(paramConfiguration); 
    } 
    AppCompatDrawableManager.get().onConfigurationChanged(this.a);
    applyDayNight();
  }
  
  public void onCreate(Bundle paramBundle) {
    if (this.c instanceof Activity && NavUtils.getParentActivityName((Activity)this.c) != null) {
      ActionBar actionBar = a();
      if (actionBar == null) {
        this.mEnableDefaultActionBarUp = true;
        return;
      } 
      actionBar.setDefaultDisplayHomeAsUpEnabled(true);
    } 
  }
  
  public final View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    View view = a(paramView, paramString, paramContext, paramAttributeSet);
    return (view != null) ? view : createView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView((View)null, paramString, paramContext, paramAttributeSet);
  }
  
  public void onDestroy() {
    if (this.r)
      this.b.getDecorView().removeCallbacks(this.mInvalidatePanelMenuRunnable); 
    super.onDestroy();
    if (this.f != null)
      this.f.a(); 
  }
  
  public boolean onMenuItemSelected(MenuBuilder paramMenuBuilder, MenuItem paramMenuItem) {
    Window.Callback callback = getWindowCallback();
    if (callback != null && !isDestroyed()) {
      PanelFeatureState panelFeatureState = a((Menu)paramMenuBuilder.getRootMenu());
      if (panelFeatureState != null)
        return callback.onMenuItemSelected(panelFeatureState.a, paramMenuItem); 
    } 
    return false;
  }
  
  public void onMenuModeChange(MenuBuilder paramMenuBuilder) {
    reopenMenu(paramMenuBuilder, true);
  }
  
  public void onPostCreate(Bundle paramBundle) {
    ensureSubDecor();
  }
  
  public void onPostResume() {
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null)
      actionBar.setShowHideAnimationEnabled(true); 
  }
  
  public void onStop() {
    ActionBar actionBar = getSupportActionBar();
    if (actionBar != null)
      actionBar.setShowHideAnimationEnabled(false); 
  }
  
  public boolean requestWindowFeature(int paramInt) {
    int i = sanitizeWindowFeatureId(paramInt);
    if (this.l && i == 108)
      return false; 
    if (this.h && i == 1)
      this.h = false; 
    switch (i) {
      default:
        return this.b.requestFeature(i);
      case 109:
        throwFeatureRequestIfSubDecorInstalled();
        this.i = true;
        return true;
      case 108:
        throwFeatureRequestIfSubDecorInstalled();
        this.h = true;
        return true;
      case 10:
        throwFeatureRequestIfSubDecorInstalled();
        this.j = true;
        return true;
      case 5:
        throwFeatureRequestIfSubDecorInstalled();
        this.mFeatureIndeterminateProgress = true;
        return true;
      case 2:
        throwFeatureRequestIfSubDecorInstalled();
        this.mFeatureProgress = true;
        return true;
      case 1:
        break;
    } 
    throwFeatureRequestIfSubDecorInstalled();
    this.l = true;
    return true;
  }
  
  public void setContentView(int paramInt) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    viewGroup.removeAllViews();
    LayoutInflater.from(this.a).inflate(paramInt, viewGroup);
    this.c.onContentChanged();
  }
  
  public void setContentView(View paramView) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView);
    this.c.onContentChanged();
  }
  
  public void setContentView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    ensureSubDecor();
    ViewGroup viewGroup = (ViewGroup)this.mSubDecor.findViewById(16908290);
    viewGroup.removeAllViews();
    viewGroup.addView(paramView, paramLayoutParams);
    this.c.onContentChanged();
  }
  
  public void setSupportActionBar(Toolbar paramToolbar) {
    if (!(this.c instanceof Activity))
      return; 
    ActionBar actionBar = getSupportActionBar();
    if (!(actionBar instanceof WindowDecorActionBar)) {
      this.g = null;
      if (actionBar != null)
        actionBar.a(); 
      if (paramToolbar != null) {
        ToolbarActionBar toolbarActionBar = new ToolbarActionBar(paramToolbar, ((Activity)this.c).getTitle(), this.d);
        this.f = toolbarActionBar;
        this.b.setCallback(toolbarActionBar.getWrappedWindowCallback());
      } else {
        this.f = null;
        this.b.setCallback(this.d);
      } 
      invalidateOptionsMenu();
      return;
    } 
    throw new IllegalStateException("This Activity already has an action bar supplied by the window decor. Do not request Window.FEATURE_SUPPORT_ACTION_BAR and set windowActionBar to false in your theme to use a Toolbar instead.");
  }
  
  public ActionMode startSupportActionMode(@NonNull ActionMode.Callback paramCallback) {
    if (paramCallback != null) {
      if (this.m != null)
        this.m.finish(); 
      ActionModeCallbackWrapperV9 actionModeCallbackWrapperV9 = new ActionModeCallbackWrapperV9(this, paramCallback);
      ActionBar actionBar = getSupportActionBar();
      if (actionBar != null) {
        this.m = actionBar.startActionMode(actionModeCallbackWrapperV9);
        if (this.m != null && this.e != null)
          this.e.onSupportActionModeStarted(this.m); 
      } 
      if (this.m == null)
        this.m = a(actionModeCallbackWrapperV9); 
      return this.m;
    } 
    throw new IllegalArgumentException("ActionMode callback can not be null.");
  }
  
  private final class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    ActionMenuPresenterCallback(AppCompatDelegateImplV9 this$0) {}
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      this.a.a(param1MenuBuilder);
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      Window.Callback callback = this.a.getWindowCallback();
      if (callback != null)
        callback.onMenuOpened(108, (Menu)param1MenuBuilder); 
      return true;
    }
  }
  
  class ActionModeCallbackWrapperV9 implements ActionMode.Callback {
    private ActionMode.Callback mWrapped;
    
    public ActionModeCallbackWrapperV9(AppCompatDelegateImplV9 this$0, ActionMode.Callback param1Callback) {
      this.mWrapped = param1Callback;
    }
    
    public boolean onActionItemClicked(ActionMode param1ActionMode, MenuItem param1MenuItem) {
      return this.mWrapped.onActionItemClicked(param1ActionMode, param1MenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.mWrapped.onCreateActionMode(param1ActionMode, param1Menu);
    }
    
    public void onDestroyActionMode(ActionMode param1ActionMode) {
      this.mWrapped.onDestroyActionMode(param1ActionMode);
      if (this.a.o != null)
        this.a.b.getDecorView().removeCallbacks(this.a.p); 
      if (this.a.n != null) {
        this.a.c();
        this.a.q = ViewCompat.animate((View)this.a.n).alpha(0.0F);
        this.a.q.setListener((ViewPropertyAnimatorListener)new ViewPropertyAnimatorListenerAdapter(this) {
              public void onAnimationEnd(View param2View) {
                this.a.a.n.setVisibility(8);
                if (this.a.a.o != null) {
                  this.a.a.o.dismiss();
                } else if (this.a.a.n.getParent() instanceof View) {
                  ViewCompat.requestApplyInsets((View)this.a.a.n.getParent());
                } 
                this.a.a.n.removeAllViews();
                this.a.a.q.setListener(null);
                this.a.a.q = null;
              }
            });
      } 
      if (this.a.e != null)
        this.a.e.onSupportActionModeFinished(this.a.m); 
      this.a.m = null;
    }
    
    public boolean onPrepareActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.mWrapped.onPrepareActionMode(param1ActionMode, param1Menu);
    }
  }
  
  class null extends ViewPropertyAnimatorListenerAdapter {
    null(AppCompatDelegateImplV9 this$0) {}
    
    public void onAnimationEnd(View param1View) {
      this.a.a.n.setVisibility(8);
      if (this.a.a.o != null) {
        this.a.a.o.dismiss();
      } else if (this.a.a.n.getParent() instanceof View) {
        ViewCompat.requestApplyInsets((View)this.a.a.n.getParent());
      } 
      this.a.a.n.removeAllViews();
      this.a.a.q.setListener(null);
      this.a.a.q = null;
    }
  }
  
  private class ListMenuDecorView extends ContentFrameLayout {
    public ListMenuDecorView(AppCompatDelegateImplV9 this$0, Context param1Context) {
      super(param1Context);
    }
    
    private boolean isOutOfBounds(int param1Int1, int param1Int2) {
      return (param1Int1 < -5 || param1Int2 < -5 || param1Int1 > 5 + getWidth() || param1Int2 > 5 + getHeight());
    }
    
    public boolean dispatchKeyEvent(KeyEvent param1KeyEvent) {
      return (this.a.a(param1KeyEvent) || super.dispatchKeyEvent(param1KeyEvent));
    }
    
    public boolean onInterceptTouchEvent(MotionEvent param1MotionEvent) {
      if (param1MotionEvent.getAction() == 0 && isOutOfBounds((int)param1MotionEvent.getX(), (int)param1MotionEvent.getY())) {
        this.a.b(0);
        return true;
      } 
      return super.onInterceptTouchEvent(param1MotionEvent);
    }
    
    public void setBackgroundResource(int param1Int) {
      setBackgroundDrawable(AppCompatResources.getDrawable(getContext(), param1Int));
    }
  }
  
  protected static final class PanelFeatureState {
    int a;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    ViewGroup g;
    
    View h;
    
    View i;
    
    MenuBuilder j;
    
    ListMenuPresenter k;
    
    Context l;
    
    boolean m;
    
    boolean n;
    
    boolean o;
    
    boolean p;
    
    boolean q;
    
    public boolean qwertyMode;
    
    Bundle r;
    
    PanelFeatureState(int param1Int) {
      this.a = param1Int;
      this.p = false;
    }
    
    MenuView a(MenuPresenter.Callback param1Callback) {
      if (this.j == null)
        return null; 
      if (this.k == null) {
        this.k = new ListMenuPresenter(this.l, R.layout.abc_list_menu_item_layout);
        this.k.setCallback(param1Callback);
        this.j.addMenuPresenter((MenuPresenter)this.k);
      } 
      return this.k.getMenuView(this.g);
    }
    
    public void clearMenuPresenters() {
      if (this.j != null)
        this.j.removeMenuPresenter((MenuPresenter)this.k); 
      this.k = null;
    }
    
    public boolean hasPanelItems() {
      if (this.h == null)
        return false; 
      if (this.i != null)
        return true; 
      int i = this.k.getAdapter().getCount();
      boolean bool = false;
      if (i > 0)
        bool = true; 
      return bool;
    }
    
    void setMenu(MenuBuilder param1MenuBuilder) {
      if (param1MenuBuilder == this.j)
        return; 
      if (this.j != null)
        this.j.removeMenuPresenter((MenuPresenter)this.k); 
      this.j = param1MenuBuilder;
      if (param1MenuBuilder != null && this.k != null)
        param1MenuBuilder.addMenuPresenter((MenuPresenter)this.k); 
    }
    
    void setStyle(Context param1Context) {
      TypedValue typedValue = new TypedValue();
      Resources.Theme theme = param1Context.getResources().newTheme();
      theme.setTo(param1Context.getTheme());
      theme.resolveAttribute(R.attr.actionBarPopupTheme, typedValue, true);
      if (typedValue.resourceId != 0)
        theme.applyStyle(typedValue.resourceId, true); 
      theme.resolveAttribute(R.attr.panelMenuListTheme, typedValue, true);
      if (typedValue.resourceId != 0) {
        theme.applyStyle(typedValue.resourceId, true);
      } else {
        theme.applyStyle(R.style.Theme_AppCompat_CompactMenu, true);
      } 
      ContextThemeWrapper contextThemeWrapper = new ContextThemeWrapper(param1Context, 0);
      contextThemeWrapper.getTheme().setTo(theme);
      this.l = (Context)contextThemeWrapper;
      TypedArray typedArray = contextThemeWrapper.obtainStyledAttributes(R.styleable.AppCompatTheme);
      this.b = typedArray.getResourceId(R.styleable.AppCompatTheme_panelBackground, 0);
      this.f = typedArray.getResourceId(R.styleable.AppCompatTheme_android_windowAnimationStyle, 0);
      typedArray.recycle();
    }
    
    private static class SavedState implements Parcelable {
      public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
          public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param3Parcel) {
            return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param3Parcel, null);
          }
          
          public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
            return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param3Parcel, param3ClassLoader);
          }
          
          public AppCompatDelegateImplV9.PanelFeatureState.SavedState[] newArray(int param3Int) {
            return new AppCompatDelegateImplV9.PanelFeatureState.SavedState[param3Int];
          }
        };
      
      int a;
      
      boolean b;
      
      Bundle c;
      
      static SavedState a(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        SavedState savedState = new SavedState();
        savedState.a = param2Parcel.readInt();
        int i = param2Parcel.readInt();
        byte b = 1;
        if (i != b)
          b = 0; 
        savedState.b = b;
        if (savedState.b)
          savedState.c = param2Parcel.readBundle(param2ClassLoader); 
        return savedState;
      }
      
      public int describeContents() {
        return 0;
      }
      
      public void writeToParcel(Parcel param2Parcel, int param2Int) {
        param2Parcel.writeInt(this.a);
        param2Parcel.writeInt(this.b);
        if (this.b)
          param2Parcel.writeBundle(this.c); 
      }
    }
    
    static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
      public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param2Parcel) {
        return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param2Parcel, null);
      }
      
      public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
        return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param2Parcel, param2ClassLoader);
      }
      
      public AppCompatDelegateImplV9.PanelFeatureState.SavedState[] newArray(int param2Int) {
        return new AppCompatDelegateImplV9.PanelFeatureState.SavedState[param2Int];
      }
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param3Parcel) {
          return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param3Parcel, null);
        }
        
        public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param3Parcel, ClassLoader param3ClassLoader) {
          return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param3Parcel, param3ClassLoader);
        }
        
        public AppCompatDelegateImplV9.PanelFeatureState.SavedState[] newArray(int param3Int) {
          return new AppCompatDelegateImplV9.PanelFeatureState.SavedState[param3Int];
        }
      };
    
    int a;
    
    boolean b;
    
    Bundle c;
    
    static SavedState a(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      SavedState savedState = new SavedState();
      savedState.a = param1Parcel.readInt();
      int i = param1Parcel.readInt();
      byte b = 1;
      if (i != b)
        b = 0; 
      savedState.b = b;
      if (savedState.b)
        savedState.c = param1Parcel.readBundle(param1ClassLoader); 
      return savedState;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.a);
      param1Parcel.writeInt(this.b);
      if (this.b)
        param1Parcel.writeBundle(this.c); 
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<PanelFeatureState.SavedState> {
    public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param1Parcel) {
      return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param1Parcel, null);
    }
    
    public AppCompatDelegateImplV9.PanelFeatureState.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return AppCompatDelegateImplV9.PanelFeatureState.SavedState.a(param1Parcel, param1ClassLoader);
    }
    
    public AppCompatDelegateImplV9.PanelFeatureState.SavedState[] newArray(int param1Int) {
      return new AppCompatDelegateImplV9.PanelFeatureState.SavedState[param1Int];
    }
  }
  
  private final class PanelMenuPresenterCallback implements MenuPresenter.Callback {
    PanelMenuPresenterCallback(AppCompatDelegateImplV9 this$0) {}
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      boolean bool;
      MenuBuilder menuBuilder = param1MenuBuilder.getRootMenu();
      if (menuBuilder != param1MenuBuilder) {
        bool = true;
      } else {
        bool = false;
      } 
      AppCompatDelegateImplV9 appCompatDelegateImplV9 = this.a;
      if (bool)
        param1MenuBuilder = menuBuilder; 
      AppCompatDelegateImplV9.PanelFeatureState panelFeatureState = appCompatDelegateImplV9.a((Menu)param1MenuBuilder);
      if (panelFeatureState != null) {
        if (bool) {
          this.a.a(panelFeatureState.a, panelFeatureState, (Menu)menuBuilder);
          this.a.a(panelFeatureState, true);
          return;
        } 
        this.a.a(panelFeatureState, param1Boolean);
      } 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      if (param1MenuBuilder == null && this.a.h) {
        Window.Callback callback = this.a.getWindowCallback();
        if (callback != null && !this.a.isDestroyed())
          callback.onMenuOpened(108, (Menu)param1MenuBuilder); 
      } 
      return true;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AppCompatDelegateImplV9.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */