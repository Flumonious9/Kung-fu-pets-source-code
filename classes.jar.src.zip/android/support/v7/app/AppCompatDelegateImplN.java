package android.support.v7.app;

import android.content.Context;
import android.support.annotation.RequiresApi;
import android.view.KeyboardShortcutGroup;
import android.view.Menu;
import android.view.Window;
import java.util.List;

@RequiresApi(24)
class AppCompatDelegateImplN extends AppCompatDelegateImplV23 {
  AppCompatDelegateImplN(Context paramContext, Window paramWindow, AppCompatCallback paramAppCompatCallback) {
    super(paramContext, paramWindow, paramAppCompatCallback);
  }
  
  Window.Callback a(Window.Callback paramCallback) {
    return (Window.Callback)new AppCompatWindowCallbackN(this, paramCallback);
  }
  
  class AppCompatWindowCallbackN extends AppCompatDelegateImplV23.AppCompatWindowCallbackV23 {
    AppCompatWindowCallbackN(AppCompatDelegateImplN this$0, Window.Callback param1Callback) {
      super(this$0, param1Callback);
    }
    
    public void onProvideKeyboardShortcuts(List<KeyboardShortcutGroup> param1List, Menu param1Menu, int param1Int) {
      AppCompatDelegateImplV9.PanelFeatureState panelFeatureState = this.b.a(0, true);
      if (panelFeatureState != null && panelFeatureState.j != null) {
        super.onProvideKeyboardShortcuts(param1List, (Menu)panelFeatureState.j, param1Int);
        return;
      } 
      super.onProvideKeyboardShortcuts(param1List, param1Menu, param1Int);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\app\AppCompatDelegateImplN.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */