package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.annotation.StyleRes;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuView;
import android.util.AttributeSet;
import android.view.ContextThemeWrapper;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewDebug.ExportedProperty;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;

public class ActionMenuView extends LinearLayoutCompat implements MenuBuilder.ItemInvoker, MenuView {
  private static final String TAG = "ActionMenuView";
  
  MenuBuilder.Callback a;
  
  OnMenuItemClickListener b;
  
  private MenuPresenter.Callback mActionMenuPresenterCallback;
  
  private boolean mFormatItems;
  
  private int mFormatItemsWidth;
  
  private int mGeneratedItemPadding;
  
  private MenuBuilder mMenu;
  
  private int mMinCellSize;
  
  private Context mPopupContext;
  
  private int mPopupTheme;
  
  private ActionMenuPresenter mPresenter;
  
  private boolean mReserveOverflow;
  
  public ActionMenuView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionMenuView(Context paramContext, AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    setBaselineAligned(false);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mMinCellSize = (int)(56.0F * f);
    this.mGeneratedItemPadding = (int)(f * 4.0F);
    this.mPopupContext = paramContext;
    this.mPopupTheme = 0;
  }
  
  static int a(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ActionMenuItemView actionMenuItemView;
    boolean bool2;
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt3) - paramInt4, View.MeasureSpec.getMode(paramInt3));
    if (paramView instanceof ActionMenuItemView) {
      actionMenuItemView = (ActionMenuItemView)paramView;
    } else {
      actionMenuItemView = null;
    } 
    boolean bool1 = true;
    if (actionMenuItemView != null && actionMenuItemView.hasText()) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    int j = 2;
    if (paramInt2 > 0 && (!bool2 || paramInt2 >= j)) {
      paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt2 * paramInt1, -2147483648), i);
      int k = paramView.getMeasuredWidth();
      int m = k / paramInt1;
      if (k % paramInt1 != 0)
        m++; 
      if (!bool2 || m >= j)
        j = m; 
    } else {
      j = 0;
    } 
    if (layoutParams.isOverflowButton || !bool2)
      bool1 = false; 
    layoutParams.expandable = bool1;
    layoutParams.cellsUsed = j;
    paramView.measure(View.MeasureSpec.makeMeasureSpec(paramInt1 * j, 1073741824), i);
    return j;
  }
  
  private void onMeasureExactFormat(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: iload_2
    //   1: invokestatic getMode : (I)I
    //   4: istore_3
    //   5: iload_1
    //   6: invokestatic getSize : (I)I
    //   9: istore #4
    //   11: iload_2
    //   12: invokestatic getSize : (I)I
    //   15: istore #5
    //   17: aload_0
    //   18: invokevirtual getPaddingLeft : ()I
    //   21: aload_0
    //   22: invokevirtual getPaddingRight : ()I
    //   25: iadd
    //   26: istore #6
    //   28: aload_0
    //   29: invokevirtual getPaddingTop : ()I
    //   32: aload_0
    //   33: invokevirtual getPaddingBottom : ()I
    //   36: iadd
    //   37: istore #7
    //   39: iload_2
    //   40: iload #7
    //   42: bipush #-2
    //   44: invokestatic getChildMeasureSpec : (III)I
    //   47: istore #8
    //   49: iload #4
    //   51: iload #6
    //   53: isub
    //   54: istore #9
    //   56: iload #9
    //   58: aload_0
    //   59: getfield mMinCellSize : I
    //   62: idiv
    //   63: istore #10
    //   65: iload #9
    //   67: aload_0
    //   68: getfield mMinCellSize : I
    //   71: irem
    //   72: istore #11
    //   74: iload #10
    //   76: ifne -> 87
    //   79: aload_0
    //   80: iload #9
    //   82: iconst_0
    //   83: invokevirtual setMeasuredDimension : (II)V
    //   86: return
    //   87: aload_0
    //   88: getfield mMinCellSize : I
    //   91: iload #11
    //   93: iload #10
    //   95: idiv
    //   96: iadd
    //   97: istore #12
    //   99: aload_0
    //   100: invokevirtual getChildCount : ()I
    //   103: istore #13
    //   105: iload #10
    //   107: istore #14
    //   109: iconst_0
    //   110: istore #15
    //   112: iconst_0
    //   113: istore #16
    //   115: iconst_0
    //   116: istore #17
    //   118: iconst_0
    //   119: istore #18
    //   121: iconst_0
    //   122: istore #19
    //   124: iconst_0
    //   125: istore #20
    //   127: lconst_0
    //   128: lstore #21
    //   130: iload #15
    //   132: iload #13
    //   134: if_icmpge -> 444
    //   137: aload_0
    //   138: iload #15
    //   140: invokevirtual getChildAt : (I)Landroid/view/View;
    //   143: astore #67
    //   145: aload #67
    //   147: invokevirtual getVisibility : ()I
    //   150: istore #68
    //   152: iload #5
    //   154: istore #69
    //   156: iload #68
    //   158: bipush #8
    //   160: if_icmpne -> 170
    //   163: iload #9
    //   165: istore #72
    //   167: goto -> 430
    //   170: aload #67
    //   172: instanceof android/support/v7/view/menu/ActionMenuItemView
    //   175: istore #70
    //   177: iload #18
    //   179: iconst_1
    //   180: iadd
    //   181: istore #71
    //   183: iload #70
    //   185: ifeq -> 222
    //   188: aload_0
    //   189: getfield mGeneratedItemPadding : I
    //   192: istore #81
    //   194: iload #71
    //   196: istore #73
    //   198: aload_0
    //   199: getfield mGeneratedItemPadding : I
    //   202: istore #82
    //   204: iload #9
    //   206: istore #72
    //   208: aload #67
    //   210: iload #81
    //   212: iconst_0
    //   213: iload #82
    //   215: iconst_0
    //   216: invokevirtual setPadding : (IIII)V
    //   219: goto -> 230
    //   222: iload #9
    //   224: istore #72
    //   226: iload #71
    //   228: istore #73
    //   230: aload #67
    //   232: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   235: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   238: astore #74
    //   240: aload #74
    //   242: iconst_0
    //   243: putfield a : Z
    //   246: aload #74
    //   248: iconst_0
    //   249: putfield extraPixels : I
    //   252: aload #74
    //   254: iconst_0
    //   255: putfield cellsUsed : I
    //   258: aload #74
    //   260: iconst_0
    //   261: putfield expandable : Z
    //   264: aload #74
    //   266: iconst_0
    //   267: putfield leftMargin : I
    //   270: aload #74
    //   272: iconst_0
    //   273: putfield rightMargin : I
    //   276: iload #70
    //   278: ifeq -> 298
    //   281: aload #67
    //   283: checkcast android/support/v7/view/menu/ActionMenuItemView
    //   286: invokevirtual hasText : ()Z
    //   289: ifeq -> 298
    //   292: iconst_1
    //   293: istore #75
    //   295: goto -> 301
    //   298: iconst_0
    //   299: istore #75
    //   301: aload #74
    //   303: iload #75
    //   305: putfield preventEdgeOffset : Z
    //   308: aload #74
    //   310: getfield isOverflowButton : Z
    //   313: ifeq -> 322
    //   316: iconst_1
    //   317: istore #76
    //   319: goto -> 326
    //   322: iload #14
    //   324: istore #76
    //   326: aload #67
    //   328: iload #12
    //   330: iload #76
    //   332: iload #8
    //   334: iload #7
    //   336: invokestatic a : (Landroid/view/View;IIII)I
    //   339: istore #77
    //   341: iload #19
    //   343: iload #77
    //   345: invokestatic max : (II)I
    //   348: istore #78
    //   350: aload #74
    //   352: getfield expandable : Z
    //   355: ifeq -> 361
    //   358: iinc #20, 1
    //   361: aload #74
    //   363: getfield isOverflowButton : Z
    //   366: ifeq -> 372
    //   369: iconst_1
    //   370: istore #17
    //   372: iload #14
    //   374: iload #77
    //   376: isub
    //   377: istore #14
    //   379: iload #16
    //   381: aload #67
    //   383: invokevirtual getMeasuredHeight : ()I
    //   386: invokestatic max : (II)I
    //   389: istore #16
    //   391: iload #77
    //   393: iconst_1
    //   394: if_icmpne -> 418
    //   397: iconst_1
    //   398: iload #15
    //   400: ishl
    //   401: istore #80
    //   403: iload #78
    //   405: istore #79
    //   407: lload #21
    //   409: iload #80
    //   411: i2l
    //   412: lor
    //   413: lstore #21
    //   415: goto -> 422
    //   418: iload #78
    //   420: istore #79
    //   422: iload #73
    //   424: istore #18
    //   426: iload #79
    //   428: istore #19
    //   430: iinc #15, 1
    //   433: iload #69
    //   435: istore #5
    //   437: iload #72
    //   439: istore #9
    //   441: goto -> 130
    //   444: iload #9
    //   446: istore #23
    //   448: iload #5
    //   450: istore #24
    //   452: iload #17
    //   454: ifeq -> 469
    //   457: iload #18
    //   459: iconst_2
    //   460: if_icmpne -> 469
    //   463: iconst_1
    //   464: istore #25
    //   466: goto -> 472
    //   469: iconst_0
    //   470: istore #25
    //   472: iconst_0
    //   473: istore #26
    //   475: iload #20
    //   477: ifle -> 813
    //   480: iload #14
    //   482: ifle -> 813
    //   485: iconst_0
    //   486: istore #48
    //   488: iconst_0
    //   489: istore #49
    //   491: ldc 2147483647
    //   493: istore #50
    //   495: lconst_0
    //   496: lstore #51
    //   498: iload #48
    //   500: iload #13
    //   502: if_icmpge -> 599
    //   505: aload_0
    //   506: iload #48
    //   508: invokevirtual getChildAt : (I)Landroid/view/View;
    //   511: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   514: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   517: astore #64
    //   519: iload #26
    //   521: istore #65
    //   523: aload #64
    //   525: getfield expandable : Z
    //   528: ifne -> 534
    //   531: goto -> 589
    //   534: aload #64
    //   536: getfield cellsUsed : I
    //   539: iload #50
    //   541: if_icmpge -> 567
    //   544: aload #64
    //   546: getfield cellsUsed : I
    //   549: istore #66
    //   551: lconst_1
    //   552: iload #48
    //   554: lshl
    //   555: lstore #51
    //   557: iload #66
    //   559: istore #50
    //   561: iconst_1
    //   562: istore #49
    //   564: goto -> 589
    //   567: aload #64
    //   569: getfield cellsUsed : I
    //   572: iload #50
    //   574: if_icmpne -> 589
    //   577: lload #51
    //   579: lconst_1
    //   580: iload #48
    //   582: lshl
    //   583: lor
    //   584: lstore #51
    //   586: iinc #49, 1
    //   589: iinc #48, 1
    //   592: iload #65
    //   594: istore #26
    //   596: goto -> 498
    //   599: iload #26
    //   601: istore #27
    //   603: lload #21
    //   605: lload #51
    //   607: lor
    //   608: lstore #21
    //   610: iload #49
    //   612: iload #14
    //   614: if_icmple -> 632
    //   617: iload #8
    //   619: istore #28
    //   621: iload #13
    //   623: istore #29
    //   625: iload #16
    //   627: istore #30
    //   629: goto -> 820
    //   632: iload #50
    //   634: iconst_1
    //   635: iadd
    //   636: istore #53
    //   638: iconst_0
    //   639: istore #54
    //   641: iload #54
    //   643: iload #13
    //   645: if_icmpge -> 807
    //   648: aload_0
    //   649: iload #54
    //   651: invokevirtual getChildAt : (I)Landroid/view/View;
    //   654: astore #55
    //   656: aload #55
    //   658: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   661: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   664: astore #56
    //   666: iload #16
    //   668: istore #57
    //   670: iconst_1
    //   671: iload #54
    //   673: ishl
    //   674: istore #58
    //   676: iload #8
    //   678: istore #59
    //   680: iload #13
    //   682: istore #60
    //   684: iload #58
    //   686: i2l
    //   687: lstore #61
    //   689: lload #51
    //   691: lload #61
    //   693: land
    //   694: lconst_0
    //   695: lcmp
    //   696: ifne -> 719
    //   699: aload #56
    //   701: getfield cellsUsed : I
    //   704: iload #53
    //   706: if_icmpne -> 789
    //   709: lload #21
    //   711: lload #61
    //   713: lor
    //   714: lstore #21
    //   716: goto -> 789
    //   719: iload #25
    //   721: ifeq -> 763
    //   724: aload #56
    //   726: getfield preventEdgeOffset : Z
    //   729: ifeq -> 763
    //   732: iconst_1
    //   733: istore #63
    //   735: iload #14
    //   737: iload #63
    //   739: if_icmpne -> 766
    //   742: aload #55
    //   744: iload #12
    //   746: aload_0
    //   747: getfield mGeneratedItemPadding : I
    //   750: iadd
    //   751: iconst_0
    //   752: aload_0
    //   753: getfield mGeneratedItemPadding : I
    //   756: iconst_0
    //   757: invokevirtual setPadding : (IIII)V
    //   760: goto -> 766
    //   763: iconst_1
    //   764: istore #63
    //   766: aload #56
    //   768: iload #63
    //   770: aload #56
    //   772: getfield cellsUsed : I
    //   775: iadd
    //   776: putfield cellsUsed : I
    //   779: aload #56
    //   781: iload #63
    //   783: putfield a : Z
    //   786: iinc #14, -1
    //   789: iinc #54, 1
    //   792: iload #57
    //   794: istore #16
    //   796: iload #59
    //   798: istore #8
    //   800: iload #60
    //   802: istore #13
    //   804: goto -> 641
    //   807: iconst_1
    //   808: istore #26
    //   810: goto -> 475
    //   813: iload #26
    //   815: istore #27
    //   817: goto -> 617
    //   820: iload #17
    //   822: ifne -> 841
    //   825: iconst_1
    //   826: istore #31
    //   828: iload #18
    //   830: iload #31
    //   832: if_icmpne -> 844
    //   835: iconst_1
    //   836: istore #32
    //   838: goto -> 847
    //   841: iconst_1
    //   842: istore #31
    //   844: iconst_0
    //   845: istore #32
    //   847: iload #14
    //   849: ifle -> 1186
    //   852: lload #21
    //   854: lconst_0
    //   855: lcmp
    //   856: ifeq -> 1186
    //   859: iload #14
    //   861: iload #18
    //   863: iload #31
    //   865: isub
    //   866: if_icmplt -> 881
    //   869: iload #32
    //   871: ifne -> 881
    //   874: iload #19
    //   876: iload #31
    //   878: if_icmple -> 1186
    //   881: lload #21
    //   883: invokestatic bitCount : (J)I
    //   886: i2f
    //   887: fstore #41
    //   889: iload #32
    //   891: ifne -> 977
    //   894: lload #21
    //   896: lconst_1
    //   897: land
    //   898: lconst_0
    //   899: lcmp
    //   900: ifeq -> 930
    //   903: aload_0
    //   904: iconst_0
    //   905: invokevirtual getChildAt : (I)Landroid/view/View;
    //   908: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   911: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   914: getfield preventEdgeOffset : Z
    //   917: ifne -> 930
    //   920: fload #41
    //   922: ldc 0.5
    //   924: fsub
    //   925: fstore #41
    //   927: goto -> 930
    //   930: iload #29
    //   932: iconst_1
    //   933: isub
    //   934: istore #47
    //   936: lload #21
    //   938: iconst_1
    //   939: iload #47
    //   941: ishl
    //   942: i2l
    //   943: land
    //   944: lconst_0
    //   945: lcmp
    //   946: ifeq -> 977
    //   949: aload_0
    //   950: iload #47
    //   952: invokevirtual getChildAt : (I)Landroid/view/View;
    //   955: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   958: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   961: getfield preventEdgeOffset : Z
    //   964: ifne -> 977
    //   967: fload #41
    //   969: ldc 0.5
    //   971: fsub
    //   972: fstore #41
    //   974: goto -> 977
    //   977: fload #41
    //   979: fconst_0
    //   980: fcmpl
    //   981: ifle -> 999
    //   984: iload #14
    //   986: iload #12
    //   988: imul
    //   989: i2f
    //   990: fload #41
    //   992: fdiv
    //   993: f2i
    //   994: istore #42
    //   996: goto -> 1002
    //   999: iconst_0
    //   1000: istore #42
    //   1002: iload #27
    //   1004: istore #43
    //   1006: iload #29
    //   1008: istore #33
    //   1010: iconst_0
    //   1011: istore #44
    //   1013: iload #44
    //   1015: iload #33
    //   1017: if_icmpge -> 1179
    //   1020: lload #21
    //   1022: iconst_1
    //   1023: iload #44
    //   1025: ishl
    //   1026: i2l
    //   1027: land
    //   1028: lconst_0
    //   1029: lcmp
    //   1030: ifne -> 1036
    //   1033: goto -> 1173
    //   1036: aload_0
    //   1037: iload #44
    //   1039: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1042: astore #45
    //   1044: aload #45
    //   1046: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1049: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   1052: astore #46
    //   1054: aload #45
    //   1056: instanceof android/support/v7/view/menu/ActionMenuItemView
    //   1059: ifeq -> 1107
    //   1062: aload #46
    //   1064: iload #42
    //   1066: putfield extraPixels : I
    //   1069: aload #46
    //   1071: iconst_1
    //   1072: putfield a : Z
    //   1075: iload #44
    //   1077: ifne -> 1101
    //   1080: aload #46
    //   1082: getfield preventEdgeOffset : Z
    //   1085: ifne -> 1101
    //   1088: aload #46
    //   1090: iload #42
    //   1092: ineg
    //   1093: iconst_2
    //   1094: idiv
    //   1095: putfield leftMargin : I
    //   1098: goto -> 1101
    //   1101: iconst_1
    //   1102: istore #43
    //   1104: goto -> 1173
    //   1107: aload #46
    //   1109: getfield isOverflowButton : Z
    //   1112: ifeq -> 1141
    //   1115: aload #46
    //   1117: iload #42
    //   1119: putfield extraPixels : I
    //   1122: aload #46
    //   1124: iconst_1
    //   1125: putfield a : Z
    //   1128: aload #46
    //   1130: iload #42
    //   1132: ineg
    //   1133: iconst_2
    //   1134: idiv
    //   1135: putfield rightMargin : I
    //   1138: goto -> 1101
    //   1141: iload #44
    //   1143: ifeq -> 1155
    //   1146: aload #46
    //   1148: iload #42
    //   1150: iconst_2
    //   1151: idiv
    //   1152: putfield leftMargin : I
    //   1155: iload #44
    //   1157: iload #33
    //   1159: iconst_1
    //   1160: isub
    //   1161: if_icmpeq -> 1173
    //   1164: aload #46
    //   1166: iload #42
    //   1168: iconst_2
    //   1169: idiv
    //   1170: putfield rightMargin : I
    //   1173: iinc #44, 1
    //   1176: goto -> 1013
    //   1179: iload #43
    //   1181: istore #27
    //   1183: goto -> 1190
    //   1186: iload #29
    //   1188: istore #33
    //   1190: iconst_0
    //   1191: istore #34
    //   1193: iload #27
    //   1195: ifeq -> 1282
    //   1198: iload #34
    //   1200: iload #33
    //   1202: if_icmpge -> 1282
    //   1205: aload_0
    //   1206: iload #34
    //   1208: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1211: astore #37
    //   1213: aload #37
    //   1215: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   1218: checkcast android/support/v7/widget/ActionMenuView$LayoutParams
    //   1221: astore #38
    //   1223: aload #38
    //   1225: getfield a : Z
    //   1228: ifne -> 1238
    //   1231: iload #28
    //   1233: istore #40
    //   1235: goto -> 1272
    //   1238: iload #12
    //   1240: aload #38
    //   1242: getfield cellsUsed : I
    //   1245: imul
    //   1246: aload #38
    //   1248: getfield extraPixels : I
    //   1251: iadd
    //   1252: ldc 1073741824
    //   1254: invokestatic makeMeasureSpec : (II)I
    //   1257: istore #39
    //   1259: iload #28
    //   1261: istore #40
    //   1263: aload #37
    //   1265: iload #39
    //   1267: iload #40
    //   1269: invokevirtual measure : (II)V
    //   1272: iinc #34, 1
    //   1275: iload #40
    //   1277: istore #28
    //   1279: goto -> 1198
    //   1282: iload_3
    //   1283: ldc 1073741824
    //   1285: if_icmpeq -> 1299
    //   1288: iload #23
    //   1290: istore #36
    //   1292: iload #30
    //   1294: istore #35
    //   1296: goto -> 1307
    //   1299: iload #24
    //   1301: istore #35
    //   1303: iload #23
    //   1305: istore #36
    //   1307: aload_0
    //   1308: iload #36
    //   1310: iload #35
    //   1312: invokevirtual setMeasuredDimension : (II)V
    //   1315: return
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams != null && paramLayoutParams instanceof LayoutParams);
  }
  
  public void dismissPopupMenus() {
    if (this.mPresenter != null)
      this.mPresenter.dismissPopupMenus(); 
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    return false;
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    LayoutParams layoutParams = new LayoutParams(-2, -2);
    layoutParams.gravity = 16;
    return layoutParams;
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    if (paramLayoutParams != null) {
      LayoutParams layoutParams;
      if (paramLayoutParams instanceof LayoutParams) {
        layoutParams = new LayoutParams((LayoutParams)paramLayoutParams);
      } else {
        layoutParams = new LayoutParams(paramLayoutParams);
      } 
      if (layoutParams.gravity <= 0)
        layoutParams.gravity = 16; 
      return layoutParams;
    } 
    return generateDefaultLayoutParams();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public LayoutParams generateOverflowButtonLayoutParams() {
    LayoutParams layoutParams = generateDefaultLayoutParams();
    layoutParams.isOverflowButton = true;
    return layoutParams;
  }
  
  public Menu getMenu() {
    if (this.mMenu == null) {
      MenuPresenter.Callback callback;
      Context context = getContext();
      this.mMenu = new MenuBuilder(context);
      this.mMenu.setCallback(new MenuBuilderCallback(this));
      this.mPresenter = new ActionMenuPresenter(context);
      this.mPresenter.setReserveOverflow(true);
      ActionMenuPresenter actionMenuPresenter = this.mPresenter;
      if (this.mActionMenuPresenterCallback != null) {
        callback = this.mActionMenuPresenterCallback;
      } else {
        callback = new ActionMenuPresenterCallback();
      } 
      actionMenuPresenter.setCallback(callback);
      this.mMenu.addMenuPresenter((MenuPresenter)this.mPresenter, this.mPopupContext);
      this.mPresenter.setMenuView(this);
    } 
    return (Menu)this.mMenu;
  }
  
  @Nullable
  public Drawable getOverflowIcon() {
    getMenu();
    return this.mPresenter.getOverflowIcon();
  }
  
  public int getPopupTheme() {
    return this.mPopupTheme;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int getWindowAnimations() {
    return 0;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  protected boolean hasSupportDividerBeforeChildAt(int paramInt) {
    boolean bool;
    if (paramInt == 0)
      return false; 
    View view1 = getChildAt(paramInt - 1);
    View view2 = getChildAt(paramInt);
    int i = getChildCount();
    int j = 0;
    if (paramInt < i) {
      boolean bool1 = view1 instanceof ActionMenuChildView;
      j = 0;
      if (bool1)
        j = false | ((ActionMenuChildView)view1).needsDividerAfter(); 
    } 
    if (paramInt > 0 && view2 instanceof ActionMenuChildView)
      bool = j | ((ActionMenuChildView)view2).needsDividerBefore(); 
    return bool;
  }
  
  public boolean hideOverflowMenu() {
    return (this.mPresenter != null && this.mPresenter.hideOverflowMenu());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void initialize(MenuBuilder paramMenuBuilder) {
    this.mMenu = paramMenuBuilder;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean invokeItem(MenuItemImpl paramMenuItemImpl) {
    return this.mMenu.performItemAction((MenuItem)paramMenuItemImpl, 0);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean isOverflowMenuShowPending() {
    return (this.mPresenter != null && this.mPresenter.isOverflowMenuShowPending());
  }
  
  public boolean isOverflowMenuShowing() {
    return (this.mPresenter != null && this.mPresenter.isOverflowMenuShowing());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    super.onConfigurationChanged(paramConfiguration);
    if (this.mPresenter != null) {
      this.mPresenter.updateMenuView(false);
      if (this.mPresenter.isOverflowMenuShowing()) {
        this.mPresenter.hideOverflowMenu();
        this.mPresenter.showOverflowMenu();
      } 
    } 
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    dismissPopupMenus();
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    byte b3;
    boolean bool2;
    if (!this.mFormatItems) {
      super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
    int i = getChildCount();
    int j = (paramInt4 - paramInt2) / 2;
    int k = getDividerWidth();
    int m = paramInt3 - paramInt1;
    int n = m - getPaddingRight() - getPaddingLeft();
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    int i1 = n;
    byte b1 = 0;
    boolean bool1 = false;
    byte b2 = 0;
    while (b1 < i) {
      View view = getChildAt(b1);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isOverflowButton) {
          int i6;
          int i7;
          int i4 = view.getMeasuredWidth();
          if (hasSupportDividerBeforeChildAt(b1))
            i4 += k; 
          int i5 = view.getMeasuredHeight();
          if (bool) {
            i7 = getPaddingLeft() + layoutParams.leftMargin;
            i6 = i7 + i4;
          } else {
            i6 = getWidth() - getPaddingRight() - layoutParams.rightMargin;
            i7 = i6 - i4;
          } 
          int i8 = j - i5 / 2;
          view.layout(i7, i8, i6, i5 + i8);
          i1 -= i4;
          bool1 = true;
        } else {
          i1 -= view.getMeasuredWidth() + layoutParams.leftMargin + layoutParams.rightMargin;
          hasSupportDividerBeforeChildAt(b1);
          b2++;
        } 
      } 
      b1++;
    } 
    if (i == 1 && !bool1) {
      View view = getChildAt(0);
      int i4 = view.getMeasuredWidth();
      int i5 = view.getMeasuredHeight();
      int i6 = m / 2 - i4 / 2;
      int i7 = j - i5 / 2;
      view.layout(i6, i7, i4 + i6, i5 + i7);
      return;
    } 
    int i2 = b2 - (bool1 ^ true);
    if (i2 > 0) {
      bool2 = i1 / i2;
      b3 = 0;
    } else {
      b3 = 0;
      bool2 = false;
    } 
    int i3 = Math.max(0, bool2);
    if (bool) {
      int i4 = getWidth() - getPaddingRight();
      while (b3 < i) {
        View view = getChildAt(b3);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (view.getVisibility() != 8 && !layoutParams.isOverflowButton) {
          int i5 = i4 - layoutParams.rightMargin;
          int i6 = view.getMeasuredWidth();
          int i7 = view.getMeasuredHeight();
          int i8 = j - i7 / 2;
          view.layout(i5 - i6, i8, i5, i7 + i8);
          i4 = i5 - i3 + i6 + layoutParams.leftMargin;
        } 
        b3++;
      } 
    } else {
      int i4 = getPaddingLeft();
      while (b3 < i) {
        View view = getChildAt(b3);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (view.getVisibility() != 8 && !layoutParams.isOverflowButton) {
          int i5 = i4 + layoutParams.leftMargin;
          int i6 = view.getMeasuredWidth();
          int i7 = view.getMeasuredHeight();
          int i8 = j - i7 / 2;
          view.layout(i5, i8, i5 + i6, i7 + i8);
          i4 = i5 + i3 + i6 + layoutParams.rightMargin;
        } 
        b3++;
      } 
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    boolean bool = this.mFormatItems;
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.mFormatItems = bool1;
    if (bool != this.mFormatItems)
      this.mFormatItemsWidth = 0; 
    int i = View.MeasureSpec.getSize(paramInt1);
    if (this.mFormatItems && this.mMenu != null && i != this.mFormatItemsWidth) {
      this.mFormatItemsWidth = i;
      this.mMenu.onItemsChanged(true);
    } 
    int j = getChildCount();
    if (this.mFormatItems && j > 0) {
      onMeasureExactFormat(paramInt1, paramInt2);
      return;
    } 
    for (byte b = 0; b < j; b++) {
      LayoutParams layoutParams = (LayoutParams)getChildAt(b).getLayoutParams();
      layoutParams.rightMargin = 0;
      layoutParams.leftMargin = 0;
    } 
    super.onMeasure(paramInt1, paramInt2);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public MenuBuilder peekMenu() {
    return this.mMenu;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mPresenter.setExpandedActionViewsExclusive(paramBoolean);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setMenuCallbacks(MenuPresenter.Callback paramCallback, MenuBuilder.Callback paramCallback1) {
    this.mActionMenuPresenterCallback = paramCallback;
    this.a = paramCallback1;
  }
  
  public void setOnMenuItemClickListener(OnMenuItemClickListener paramOnMenuItemClickListener) {
    this.b = paramOnMenuItemClickListener;
  }
  
  public void setOverflowIcon(@Nullable Drawable paramDrawable) {
    getMenu();
    this.mPresenter.setOverflowIcon(paramDrawable);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setOverflowReserved(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
  }
  
  public void setPopupTheme(@StyleRes int paramInt) {
    if (this.mPopupTheme != paramInt) {
      this.mPopupTheme = paramInt;
      if (paramInt == 0) {
        this.mPopupContext = getContext();
        return;
      } 
      this.mPopupContext = (Context)new ContextThemeWrapper(getContext(), paramInt);
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setPresenter(ActionMenuPresenter paramActionMenuPresenter) {
    this.mPresenter = paramActionMenuPresenter;
    this.mPresenter.setMenuView(this);
  }
  
  public boolean showOverflowMenu() {
    return (this.mPresenter != null && this.mPresenter.showOverflowMenu());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static interface ActionMenuChildView {
    boolean needsDividerAfter();
    
    boolean needsDividerBefore();
  }
  
  private static class ActionMenuPresenterCallback implements MenuPresenter.Callback {
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {}
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      return false;
    }
  }
  
  public static class LayoutParams extends LinearLayoutCompat.LayoutParams {
    boolean a;
    
    @ExportedProperty
    public int cellsUsed;
    
    @ExportedProperty
    public boolean expandable;
    
    @ExportedProperty
    public int extraPixels;
    
    @ExportedProperty
    public boolean isOverflowButton;
    
    @ExportedProperty
    public boolean preventEdgeOffset;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
      this.isOverflowButton = false;
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super((ViewGroup.LayoutParams)param1LayoutParams);
      this.isOverflowButton = param1LayoutParams.isOverflowButton;
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
  }
  
  private class MenuBuilderCallback implements MenuBuilder.Callback {
    MenuBuilderCallback(ActionMenuView this$0) {}
    
    public boolean onMenuItemSelected(MenuBuilder param1MenuBuilder, MenuItem param1MenuItem) {
      return (this.a.b != null && this.a.b.onMenuItemClick(param1MenuItem));
    }
    
    public void onMenuModeChange(MenuBuilder param1MenuBuilder) {
      if (this.a.a != null)
        this.a.a.onMenuModeChange(param1MenuBuilder); 
    }
  }
  
  public static interface OnMenuItemClickListener {
    boolean onMenuItemClick(MenuItem param1MenuItem);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActionMenuView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */