package android.support.v7.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.widget.AutoSizeableTextView;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.widget.TextView;
import java.lang.ref.WeakReference;

@RequiresApi(9)
class AppCompatTextHelper {
  private static final int MONOSPACE = 3;
  
  private static final int SANS = 1;
  
  private static final int SERIF = 2;
  
  final TextView a;
  
  private boolean mAsyncFontPending;
  
  @NonNull
  private final AppCompatTextViewAutoSizeHelper mAutoSizeTextHelper;
  
  private TintInfo mDrawableBottomTint;
  
  private TintInfo mDrawableLeftTint;
  
  private TintInfo mDrawableRightTint;
  
  private TintInfo mDrawableTopTint;
  
  private Typeface mFontTypeface;
  
  private int mStyle = 0;
  
  AppCompatTextHelper(TextView paramTextView) {
    this.a = paramTextView;
    this.mAutoSizeTextHelper = new AppCompatTextViewAutoSizeHelper(this.a);
  }
  
  static AppCompatTextHelper a(TextView paramTextView) {
    return (Build.VERSION.SDK_INT >= 17) ? new AppCompatTextHelperV17(paramTextView) : new AppCompatTextHelper(paramTextView);
  }
  
  protected static TintInfo a(Context paramContext, AppCompatDrawableManager paramAppCompatDrawableManager, int paramInt) {
    ColorStateList colorStateList = paramAppCompatDrawableManager.a(paramContext, paramInt);
    if (colorStateList != null) {
      TintInfo tintInfo = new TintInfo();
      tintInfo.mHasTintList = true;
      tintInfo.mTintList = colorStateList;
      return tintInfo;
    } 
    return null;
  }
  
  private void onAsyncTypefaceReceived(WeakReference<TextView> paramWeakReference, Typeface paramTypeface) {
    if (this.mAsyncFontPending) {
      this.mFontTypeface = paramTypeface;
      TextView textView = paramWeakReference.get();
      if (textView != null)
        textView.setTypeface(paramTypeface, this.mStyle); 
    } 
  }
  
  private void setTextSizeInternal(int paramInt, float paramFloat) {
    this.mAutoSizeTextHelper.setTextSizeInternal(paramInt, paramFloat);
  }
  
  private void updateTypefaceAndStyle(Context paramContext, TintTypedArray paramTintTypedArray) {
    this.mStyle = paramTintTypedArray.getInt(R.styleable.TextAppearance_android_textStyle, this.mStyle);
    boolean bool = paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_fontFamily);
    boolean bool1 = true;
    if (bool || paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
      int i;
      this.mFontTypeface = null;
      if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_fontFamily)) {
        i = R.styleable.TextAppearance_fontFamily;
      } else {
        i = R.styleable.TextAppearance_android_fontFamily;
      } 
      if (!paramContext.isRestricted()) {
        ResourcesCompat.FontCallback fontCallback = new ResourcesCompat.FontCallback(this, new WeakReference<TextView>(this.a)) {
            public void onFontRetrievalFailed(int param1Int) {}
            
            public void onFontRetrieved(@NonNull Typeface param1Typeface) {
              AppCompatTextHelper.a(this.b, this.a, param1Typeface);
            }
          };
        this.mFontTypeface = paramTintTypedArray.getFont(i, this.mStyle, fontCallback);
        if (this.mFontTypeface != null)
          bool1 = false; 
        this.mAsyncFontPending = bool1;
      } 
      if (this.mFontTypeface == null) {
        String str = paramTintTypedArray.getString(i);
        if (str != null)
          this.mFontTypeface = Typeface.create(str, this.mStyle); 
      } 
      return;
    } 
    if (paramTintTypedArray.hasValue(R.styleable.TextAppearance_android_typeface)) {
      this.mAsyncFontPending = false;
      switch (paramTintTypedArray.getInt(R.styleable.TextAppearance_android_typeface, bool1)) {
        default:
          return;
        case 3:
          this.mFontTypeface = Typeface.MONOSPACE;
          return;
        case 2:
          this.mFontTypeface = Typeface.SERIF;
          return;
        case 1:
          break;
      } 
      this.mFontTypeface = Typeface.SANS_SERIF;
    } 
  }
  
  void a() {
    if (this.mDrawableLeftTint != null || this.mDrawableTopTint != null || this.mDrawableRightTint != null || this.mDrawableBottomTint != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawables();
      a(arrayOfDrawable[0], this.mDrawableLeftTint);
      a(arrayOfDrawable[1], this.mDrawableTopTint);
      a(arrayOfDrawable[2], this.mDrawableRightTint);
      a(arrayOfDrawable[3], this.mDrawableBottomTint);
    } 
  }
  
  void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mAutoSizeTextHelper.a(paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  void a(Context paramContext, int paramInt) {
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramInt, R.styleable.TextAppearance);
    if (tintTypedArray.hasValue(R.styleable.TextAppearance_textAllCaps))
      setAllCaps(tintTypedArray.getBoolean(R.styleable.TextAppearance_textAllCaps, false)); 
    if (Build.VERSION.SDK_INT < 23 && tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColor)) {
      ColorStateList colorStateList = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
      if (colorStateList != null)
        this.a.setTextColor(colorStateList); 
    } 
    updateTypefaceAndStyle(paramContext, tintTypedArray);
    tintTypedArray.recycle();
    if (this.mFontTypeface != null)
      this.a.setTypeface(this.mFontTypeface, this.mStyle); 
  }
  
  final void a(Drawable paramDrawable, TintInfo paramTintInfo) {
    if (paramDrawable != null && paramTintInfo != null)
      AppCompatDrawableManager.a(paramDrawable, paramTintInfo, this.a.getDrawableState()); 
  }
  
  @SuppressLint({"NewApi"})
  void a(AttributeSet paramAttributeSet, int paramInt) {
    ColorStateList colorStateList2;
    ColorStateList colorStateList3;
    boolean bool3;
    boolean bool4;
    Context context = this.a.getContext();
    AppCompatDrawableManager appCompatDrawableManager = AppCompatDrawableManager.get();
    TintTypedArray tintTypedArray1 = TintTypedArray.obtainStyledAttributes(context, paramAttributeSet, R.styleable.AppCompatTextHelper, paramInt, 0);
    int i = tintTypedArray1.getResourceId(R.styleable.AppCompatTextHelper_android_textAppearance, -1);
    if (tintTypedArray1.hasValue(R.styleable.AppCompatTextHelper_android_drawableLeft))
      this.mDrawableLeftTint = a(context, appCompatDrawableManager, tintTypedArray1.getResourceId(R.styleable.AppCompatTextHelper_android_drawableLeft, 0)); 
    if (tintTypedArray1.hasValue(R.styleable.AppCompatTextHelper_android_drawableTop))
      this.mDrawableTopTint = a(context, appCompatDrawableManager, tintTypedArray1.getResourceId(R.styleable.AppCompatTextHelper_android_drawableTop, 0)); 
    if (tintTypedArray1.hasValue(R.styleable.AppCompatTextHelper_android_drawableRight))
      this.mDrawableRightTint = a(context, appCompatDrawableManager, tintTypedArray1.getResourceId(R.styleable.AppCompatTextHelper_android_drawableRight, 0)); 
    if (tintTypedArray1.hasValue(R.styleable.AppCompatTextHelper_android_drawableBottom))
      this.mDrawableBottomTint = a(context, appCompatDrawableManager, tintTypedArray1.getResourceId(R.styleable.AppCompatTextHelper_android_drawableBottom, 0)); 
    tintTypedArray1.recycle();
    boolean bool1 = this.a.getTransformationMethod() instanceof android.text.method.PasswordTransformationMethod;
    boolean bool2 = true;
    ColorStateList colorStateList1 = null;
    if (i != -1) {
      TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(context, i, R.styleable.TextAppearance);
      if (!bool1 && tintTypedArray.hasValue(R.styleable.TextAppearance_textAllCaps)) {
        bool4 = tintTypedArray.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
        bool3 = true;
      } else {
        bool3 = false;
        bool4 = false;
      } 
      updateTypefaceAndStyle(context, tintTypedArray);
      if (Build.VERSION.SDK_INT < 23) {
        ColorStateList colorStateList4;
        if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColor)) {
          colorStateList4 = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColor);
        } else {
          colorStateList4 = null;
        } 
        if (tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColorHint)) {
          colorStateList3 = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColorHint);
        } else {
          colorStateList3 = null;
        } 
        boolean bool = tintTypedArray.hasValue(R.styleable.TextAppearance_android_textColorLink);
        ColorStateList colorStateList5 = null;
        if (bool)
          colorStateList5 = tintTypedArray.getColorStateList(R.styleable.TextAppearance_android_textColorLink); 
        ColorStateList colorStateList6 = colorStateList4;
        colorStateList2 = colorStateList5;
        colorStateList1 = colorStateList6;
      } else {
        colorStateList2 = null;
        colorStateList3 = null;
      } 
      tintTypedArray.recycle();
    } else {
      colorStateList2 = null;
      colorStateList3 = null;
      bool3 = false;
      bool4 = false;
    } 
    TintTypedArray tintTypedArray2 = TintTypedArray.obtainStyledAttributes(context, paramAttributeSet, R.styleable.TextAppearance, paramInt, 0);
    if (!bool1 && tintTypedArray2.hasValue(R.styleable.TextAppearance_textAllCaps)) {
      bool4 = tintTypedArray2.getBoolean(R.styleable.TextAppearance_textAllCaps, false);
    } else {
      bool2 = bool3;
    } 
    if (Build.VERSION.SDK_INT < 23) {
      if (tintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColor))
        colorStateList1 = tintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColor); 
      if (tintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorHint))
        colorStateList3 = tintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorHint); 
      if (tintTypedArray2.hasValue(R.styleable.TextAppearance_android_textColorLink))
        colorStateList2 = tintTypedArray2.getColorStateList(R.styleable.TextAppearance_android_textColorLink); 
    } 
    updateTypefaceAndStyle(context, tintTypedArray2);
    tintTypedArray2.recycle();
    if (colorStateList1 != null)
      this.a.setTextColor(colorStateList1); 
    if (colorStateList3 != null)
      this.a.setHintTextColor(colorStateList3); 
    if (colorStateList2 != null)
      this.a.setLinkTextColor(colorStateList2); 
    if (!bool1 && bool2)
      setAllCaps(bool4); 
    if (this.mFontTypeface != null)
      this.a.setTypeface(this.mFontTypeface, this.mStyle); 
    this.mAutoSizeTextHelper.a(paramAttributeSet, paramInt);
    if (AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE && this.mAutoSizeTextHelper.getAutoSizeTextType() != 0) {
      int[] arrayOfInt = this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
      if (arrayOfInt.length > 0) {
        if (this.a.getAutoSizeStepGranularity() != -1.0F) {
          this.a.setAutoSizeTextTypeUniformWithConfiguration(this.mAutoSizeTextHelper.getAutoSizeMinTextSize(), this.mAutoSizeTextHelper.getAutoSizeMaxTextSize(), this.mAutoSizeTextHelper.getAutoSizeStepGranularity(), 0);
          return;
        } 
        this.a.setAutoSizeTextTypeUniformWithPresetSizes(arrayOfInt, 0);
      } 
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  void a(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE)
      b(); 
  }
  
  void a(@NonNull int[] paramArrayOfint, int paramInt) {
    this.mAutoSizeTextHelper.a(paramArrayOfint, paramInt);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  void b() {
    this.mAutoSizeTextHelper.a();
  }
  
  int getAutoSizeMaxTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMaxTextSize();
  }
  
  int getAutoSizeMinTextSize() {
    return this.mAutoSizeTextHelper.getAutoSizeMinTextSize();
  }
  
  int getAutoSizeStepGranularity() {
    return this.mAutoSizeTextHelper.getAutoSizeStepGranularity();
  }
  
  int[] getAutoSizeTextAvailableSizes() {
    return this.mAutoSizeTextHelper.getAutoSizeTextAvailableSizes();
  }
  
  int getAutoSizeTextType() {
    return this.mAutoSizeTextHelper.getAutoSizeTextType();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  boolean isAutoSizeEnabled() {
    return this.mAutoSizeTextHelper.isAutoSizeEnabled();
  }
  
  void setAllCaps(boolean paramBoolean) {
    this.a.setAllCaps(paramBoolean);
  }
  
  void setAutoSizeTextTypeWithDefaults(int paramInt) {
    this.mAutoSizeTextHelper.setAutoSizeTextTypeWithDefaults(paramInt);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  void setTextSize(int paramInt, float paramFloat) {
    if (!AutoSizeableTextView.PLATFORM_SUPPORTS_AUTOSIZE && !isAutoSizeEnabled())
      setTextSizeInternal(paramInt, paramFloat); 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\AppCompatTextHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */