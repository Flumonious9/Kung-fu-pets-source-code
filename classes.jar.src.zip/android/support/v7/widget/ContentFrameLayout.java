package android.support.v7.widget;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.RestrictTo;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.TypedValue;
import android.view.View;
import android.widget.FrameLayout;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public class ContentFrameLayout extends FrameLayout {
  private OnAttachListener mAttachListener;
  
  private final Rect mDecorPadding = new Rect();
  
  private TypedValue mFixedHeightMajor;
  
  private TypedValue mFixedHeightMinor;
  
  private TypedValue mFixedWidthMajor;
  
  private TypedValue mFixedWidthMinor;
  
  private TypedValue mMinWidthMajor;
  
  private TypedValue mMinWidthMinor;
  
  public ContentFrameLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ContentFrameLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void dispatchFitSystemWindows(Rect paramRect) {
    fitSystemWindows(paramRect);
  }
  
  public TypedValue getFixedHeightMajor() {
    if (this.mFixedHeightMajor == null)
      this.mFixedHeightMajor = new TypedValue(); 
    return this.mFixedHeightMajor;
  }
  
  public TypedValue getFixedHeightMinor() {
    if (this.mFixedHeightMinor == null)
      this.mFixedHeightMinor = new TypedValue(); 
    return this.mFixedHeightMinor;
  }
  
  public TypedValue getFixedWidthMajor() {
    if (this.mFixedWidthMajor == null)
      this.mFixedWidthMajor = new TypedValue(); 
    return this.mFixedWidthMajor;
  }
  
  public TypedValue getFixedWidthMinor() {
    if (this.mFixedWidthMinor == null)
      this.mFixedWidthMinor = new TypedValue(); 
    return this.mFixedWidthMinor;
  }
  
  public TypedValue getMinWidthMajor() {
    if (this.mMinWidthMajor == null)
      this.mMinWidthMajor = new TypedValue(); 
    return this.mMinWidthMajor;
  }
  
  public TypedValue getMinWidthMinor() {
    if (this.mMinWidthMinor == null)
      this.mMinWidthMinor = new TypedValue(); 
    return this.mMinWidthMinor;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    if (this.mAttachListener != null)
      this.mAttachListener.onAttachedFromWindow(); 
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.mAttachListener != null)
      this.mAttachListener.onDetachedFromWindow(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContext : ()Landroid/content/Context;
    //   4: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   7: invokevirtual getDisplayMetrics : ()Landroid/util/DisplayMetrics;
    //   10: astore_3
    //   11: aload_3
    //   12: getfield widthPixels : I
    //   15: istore #4
    //   17: aload_3
    //   18: getfield heightPixels : I
    //   21: istore #5
    //   23: iconst_1
    //   24: istore #6
    //   26: iload #4
    //   28: iload #5
    //   30: if_icmpge -> 39
    //   33: iconst_1
    //   34: istore #7
    //   36: goto -> 42
    //   39: iconst_0
    //   40: istore #7
    //   42: iload_1
    //   43: invokestatic getMode : (I)I
    //   46: istore #8
    //   48: iload_2
    //   49: invokestatic getMode : (I)I
    //   52: istore #9
    //   54: iload #8
    //   56: ldc -2147483648
    //   58: if_icmpne -> 192
    //   61: iload #7
    //   63: ifeq -> 75
    //   66: aload_0
    //   67: getfield mFixedWidthMinor : Landroid/util/TypedValue;
    //   70: astore #18
    //   72: goto -> 81
    //   75: aload_0
    //   76: getfield mFixedWidthMajor : Landroid/util/TypedValue;
    //   79: astore #18
    //   81: aload #18
    //   83: ifnull -> 192
    //   86: aload #18
    //   88: getfield type : I
    //   91: ifeq -> 192
    //   94: aload #18
    //   96: getfield type : I
    //   99: iconst_5
    //   100: if_icmpne -> 115
    //   103: aload #18
    //   105: aload_3
    //   106: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   109: f2i
    //   110: istore #19
    //   112: goto -> 149
    //   115: aload #18
    //   117: getfield type : I
    //   120: bipush #6
    //   122: if_icmpne -> 146
    //   125: aload #18
    //   127: aload_3
    //   128: getfield widthPixels : I
    //   131: i2f
    //   132: aload_3
    //   133: getfield widthPixels : I
    //   136: i2f
    //   137: invokevirtual getFraction : (FF)F
    //   140: f2i
    //   141: istore #19
    //   143: goto -> 149
    //   146: iconst_0
    //   147: istore #19
    //   149: iload #19
    //   151: ifle -> 192
    //   154: iload #19
    //   156: aload_0
    //   157: getfield mDecorPadding : Landroid/graphics/Rect;
    //   160: getfield left : I
    //   163: aload_0
    //   164: getfield mDecorPadding : Landroid/graphics/Rect;
    //   167: getfield right : I
    //   170: iadd
    //   171: isub
    //   172: iload_1
    //   173: invokestatic getSize : (I)I
    //   176: invokestatic min : (II)I
    //   179: ldc 1073741824
    //   181: invokestatic makeMeasureSpec : (II)I
    //   184: istore #10
    //   186: iconst_1
    //   187: istore #11
    //   189: goto -> 198
    //   192: iload_1
    //   193: istore #10
    //   195: iconst_0
    //   196: istore #11
    //   198: iload #9
    //   200: ldc -2147483648
    //   202: if_icmpne -> 329
    //   205: iload #7
    //   207: ifeq -> 219
    //   210: aload_0
    //   211: getfield mFixedHeightMajor : Landroid/util/TypedValue;
    //   214: astore #16
    //   216: goto -> 225
    //   219: aload_0
    //   220: getfield mFixedHeightMinor : Landroid/util/TypedValue;
    //   223: astore #16
    //   225: aload #16
    //   227: ifnull -> 329
    //   230: aload #16
    //   232: getfield type : I
    //   235: ifeq -> 329
    //   238: aload #16
    //   240: getfield type : I
    //   243: iconst_5
    //   244: if_icmpne -> 259
    //   247: aload #16
    //   249: aload_3
    //   250: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   253: f2i
    //   254: istore #17
    //   256: goto -> 293
    //   259: aload #16
    //   261: getfield type : I
    //   264: bipush #6
    //   266: if_icmpne -> 290
    //   269: aload #16
    //   271: aload_3
    //   272: getfield heightPixels : I
    //   275: i2f
    //   276: aload_3
    //   277: getfield heightPixels : I
    //   280: i2f
    //   281: invokevirtual getFraction : (FF)F
    //   284: f2i
    //   285: istore #17
    //   287: goto -> 293
    //   290: iconst_0
    //   291: istore #17
    //   293: iload #17
    //   295: ifle -> 329
    //   298: iload #17
    //   300: aload_0
    //   301: getfield mDecorPadding : Landroid/graphics/Rect;
    //   304: getfield top : I
    //   307: aload_0
    //   308: getfield mDecorPadding : Landroid/graphics/Rect;
    //   311: getfield bottom : I
    //   314: iadd
    //   315: isub
    //   316: iload_2
    //   317: invokestatic getSize : (I)I
    //   320: invokestatic min : (II)I
    //   323: ldc 1073741824
    //   325: invokestatic makeMeasureSpec : (II)I
    //   328: istore_2
    //   329: aload_0
    //   330: iload #10
    //   332: iload_2
    //   333: invokespecial onMeasure : (II)V
    //   336: aload_0
    //   337: invokevirtual getMeasuredWidth : ()I
    //   340: istore #12
    //   342: iload #12
    //   344: ldc 1073741824
    //   346: invokestatic makeMeasureSpec : (II)I
    //   349: istore #13
    //   351: iload #11
    //   353: ifne -> 495
    //   356: iload #8
    //   358: ldc -2147483648
    //   360: if_icmpne -> 495
    //   363: iload #7
    //   365: ifeq -> 377
    //   368: aload_0
    //   369: getfield mMinWidthMinor : Landroid/util/TypedValue;
    //   372: astore #14
    //   374: goto -> 383
    //   377: aload_0
    //   378: getfield mMinWidthMajor : Landroid/util/TypedValue;
    //   381: astore #14
    //   383: aload #14
    //   385: ifnull -> 495
    //   388: aload #14
    //   390: getfield type : I
    //   393: ifeq -> 495
    //   396: aload #14
    //   398: getfield type : I
    //   401: iconst_5
    //   402: if_icmpne -> 417
    //   405: aload #14
    //   407: aload_3
    //   408: invokevirtual getDimension : (Landroid/util/DisplayMetrics;)F
    //   411: f2i
    //   412: istore #15
    //   414: goto -> 451
    //   417: aload #14
    //   419: getfield type : I
    //   422: bipush #6
    //   424: if_icmpne -> 448
    //   427: aload #14
    //   429: aload_3
    //   430: getfield widthPixels : I
    //   433: i2f
    //   434: aload_3
    //   435: getfield widthPixels : I
    //   438: i2f
    //   439: invokevirtual getFraction : (FF)F
    //   442: f2i
    //   443: istore #15
    //   445: goto -> 451
    //   448: iconst_0
    //   449: istore #15
    //   451: iload #15
    //   453: ifle -> 476
    //   456: iload #15
    //   458: aload_0
    //   459: getfield mDecorPadding : Landroid/graphics/Rect;
    //   462: getfield left : I
    //   465: aload_0
    //   466: getfield mDecorPadding : Landroid/graphics/Rect;
    //   469: getfield right : I
    //   472: iadd
    //   473: isub
    //   474: istore #15
    //   476: iload #12
    //   478: iload #15
    //   480: if_icmpge -> 495
    //   483: iload #15
    //   485: ldc 1073741824
    //   487: invokestatic makeMeasureSpec : (II)I
    //   490: istore #13
    //   492: goto -> 498
    //   495: iconst_0
    //   496: istore #6
    //   498: iload #6
    //   500: ifeq -> 510
    //   503: aload_0
    //   504: iload #13
    //   506: iload_2
    //   507: invokespecial onMeasure : (II)V
    //   510: return
  }
  
  public void setAttachListener(OnAttachListener paramOnAttachListener) {
    this.mAttachListener = paramOnAttachListener;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setDecorPadding(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mDecorPadding.set(paramInt1, paramInt2, paramInt3, paramInt4);
    if (ViewCompat.isLaidOut((View)this))
      requestLayout(); 
  }
  
  public static interface OnAttachListener {
    void onAttachedFromWindow();
    
    void onDetachedFromWindow();
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ContentFrameLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */