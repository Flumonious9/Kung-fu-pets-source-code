package android.support.v7.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.annotation.RestrictTo;
import android.support.v4.view.ActionProvider;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v7.appcompat.R;
import android.support.v7.view.menu.ShowableListMenu;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.view.accessibility.AccessibilityNodeInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListAdapter;
import android.widget.PopupWindow;
import android.widget.TextView;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ActivityChooserView extends ViewGroup implements ActivityChooserModel.ActivityChooserModelClient {
  private static final String LOG_TAG = "ActivityChooserView";
  
  final ActivityChooserViewAdapter a;
  
  final FrameLayout b;
  
  final FrameLayout c;
  
  ActionProvider d;
  
  final DataSetObserver e = new DataSetObserver(this) {
      public void onChanged() {
        super.onChanged();
        this.a.a.notifyDataSetChanged();
      }
      
      public void onInvalidated() {
        super.onInvalidated();
        this.a.a.notifyDataSetInvalidated();
      }
    };
  
  PopupWindow.OnDismissListener f;
  
  boolean g;
  
  int h = 4;
  
  private final LinearLayoutCompat mActivityChooserContent;
  
  private final Drawable mActivityChooserContentBackground;
  
  private final Callbacks mCallbacks;
  
  private int mDefaultActionButtonContentDescription;
  
  private final ImageView mDefaultActivityButtonImage;
  
  private final ImageView mExpandActivityOverflowButtonImage;
  
  private boolean mIsAttachedToWindow;
  
  private final int mListPopupMaxWidth;
  
  private ListPopupWindow mListPopupWindow;
  
  private final ViewTreeObserver.OnGlobalLayoutListener mOnGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener(this) {
      public void onGlobalLayout() {
        if (this.a.isShowingPopup()) {
          if (!this.a.isShown()) {
            this.a.getListPopupWindow().dismiss();
            return;
          } 
          this.a.getListPopupWindow().show();
          if (this.a.d != null)
            this.a.d.subUiVisibilityChanged(true); 
        } 
      }
    };
  
  public ActivityChooserView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActivityChooserView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public ActivityChooserView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.ActivityChooserView, paramInt, 0);
    this.h = typedArray.getInt(R.styleable.ActivityChooserView_initialActivityCount, 4);
    Drawable drawable = typedArray.getDrawable(R.styleable.ActivityChooserView_expandActivityOverflowButtonDrawable);
    typedArray.recycle();
    LayoutInflater.from(getContext()).inflate(R.layout.abc_activity_chooser_view, this, true);
    this.mCallbacks = new Callbacks(this);
    this.mActivityChooserContent = (LinearLayoutCompat)findViewById(R.id.activity_chooser_view_content);
    this.mActivityChooserContentBackground = this.mActivityChooserContent.getBackground();
    this.c = (FrameLayout)findViewById(R.id.default_activity_button);
    this.c.setOnClickListener(this.mCallbacks);
    this.c.setOnLongClickListener(this.mCallbacks);
    this.mDefaultActivityButtonImage = (ImageView)this.c.findViewById(R.id.image);
    FrameLayout frameLayout = (FrameLayout)findViewById(R.id.expand_activities_button);
    frameLayout.setOnClickListener(this.mCallbacks);
    frameLayout.setAccessibilityDelegate(new View.AccessibilityDelegate(this) {
          public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfo param1AccessibilityNodeInfo) {
            super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfo);
            AccessibilityNodeInfoCompat.wrap(param1AccessibilityNodeInfo).setCanOpenPopup(true);
          }
        });
    frameLayout.setOnTouchListener(new ForwardingListener(this, (View)frameLayout) {
          public ShowableListMenu getPopup() {
            return this.a.getListPopupWindow();
          }
          
          protected boolean onForwardingStarted() {
            this.a.showPopup();
            return true;
          }
          
          protected boolean onForwardingStopped() {
            this.a.dismissPopup();
            return true;
          }
        });
    this.b = frameLayout;
    this.mExpandActivityOverflowButtonImage = (ImageView)frameLayout.findViewById(R.id.image);
    this.mExpandActivityOverflowButtonImage.setImageDrawable(drawable);
    this.a = new ActivityChooserViewAdapter(this);
    this.a.registerDataSetObserver(new DataSetObserver(this) {
          public void onChanged() {
            super.onChanged();
            this.a.a();
          }
        });
    Resources resources = paramContext.getResources();
    this.mListPopupMaxWidth = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
  }
  
  void a() {
    if (this.a.getCount() > 0) {
      this.b.setEnabled(true);
    } else {
      this.b.setEnabled(false);
    } 
    int i = this.a.getActivityCount();
    int j = this.a.getHistorySize();
    if (i == 1 || (i > 1 && j > 0)) {
      this.c.setVisibility(0);
      ResolveInfo resolveInfo = this.a.getDefaultActivity();
      PackageManager packageManager = getContext().getPackageManager();
      this.mDefaultActivityButtonImage.setImageDrawable(resolveInfo.loadIcon(packageManager));
      if (this.mDefaultActionButtonContentDescription != 0) {
        CharSequence charSequence = resolveInfo.loadLabel(packageManager);
        String str = getContext().getString(this.mDefaultActionButtonContentDescription, new Object[] { charSequence });
        this.c.setContentDescription(str);
      } 
    } else {
      this.c.setVisibility(8);
    } 
    if (this.c.getVisibility() == 0) {
      this.mActivityChooserContent.setBackgroundDrawable(this.mActivityChooserContentBackground);
      return;
    } 
    this.mActivityChooserContent.setBackgroundDrawable(null);
  }
  
  void a(int paramInt) {
    if (this.a.getDataModel() != null) {
      byte b;
      getViewTreeObserver().addOnGlobalLayoutListener(this.mOnGlobalLayoutListener);
      if (this.c.getVisibility() == 0) {
        b = 1;
      } else {
        b = 0;
      } 
      int i = this.a.getActivityCount();
      if (paramInt != Integer.MAX_VALUE && i > paramInt + b) {
        this.a.setShowFooterView(true);
        this.a.setMaxActivityCount(paramInt - 1);
      } else {
        this.a.setShowFooterView(false);
        this.a.setMaxActivityCount(paramInt);
      } 
      ListPopupWindow listPopupWindow = getListPopupWindow();
      if (!listPopupWindow.isShowing()) {
        if (this.g || b == 0) {
          this.a.setShowDefaultActivity(true, b);
        } else {
          this.a.setShowDefaultActivity(false, false);
        } 
        listPopupWindow.setContentWidth(Math.min(this.a.measureContentWidth(), this.mListPopupMaxWidth));
        listPopupWindow.show();
        if (this.d != null)
          this.d.subUiVisibilityChanged(true); 
        listPopupWindow.getListView().setContentDescription(getContext().getString(R.string.abc_activitychooserview_choose_application));
        listPopupWindow.getListView().setSelector((Drawable)new ColorDrawable(0));
      } 
      return;
    } 
    throw new IllegalStateException("No data model. Did you call #setDataModel?");
  }
  
  public boolean dismissPopup() {
    if (isShowingPopup()) {
      getListPopupWindow().dismiss();
      ViewTreeObserver viewTreeObserver = getViewTreeObserver();
      if (viewTreeObserver.isAlive())
        viewTreeObserver.removeGlobalOnLayoutListener(this.mOnGlobalLayoutListener); 
    } 
    return true;
  }
  
  public ActivityChooserModel getDataModel() {
    return this.a.getDataModel();
  }
  
  ListPopupWindow getListPopupWindow() {
    if (this.mListPopupWindow == null) {
      this.mListPopupWindow = new ListPopupWindow(getContext());
      this.mListPopupWindow.setAdapter((ListAdapter)this.a);
      this.mListPopupWindow.setAnchorView((View)this);
      this.mListPopupWindow.setModal(true);
      this.mListPopupWindow.setOnItemClickListener(this.mCallbacks);
      this.mListPopupWindow.setOnDismissListener(this.mCallbacks);
    } 
    return this.mListPopupWindow;
  }
  
  public boolean isShowingPopup() {
    return getListPopupWindow().isShowing();
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    ActivityChooserModel activityChooserModel = this.a.getDataModel();
    if (activityChooserModel != null)
      activityChooserModel.registerObserver(this.e); 
    this.mIsAttachedToWindow = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    ActivityChooserModel activityChooserModel = this.a.getDataModel();
    if (activityChooserModel != null)
      activityChooserModel.unregisterObserver(this.e); 
    ViewTreeObserver viewTreeObserver = getViewTreeObserver();
    if (viewTreeObserver.isAlive())
      viewTreeObserver.removeGlobalOnLayoutListener(this.mOnGlobalLayoutListener); 
    if (isShowingPopup())
      dismissPopup(); 
    this.mIsAttachedToWindow = false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mActivityChooserContent.layout(0, 0, paramInt3 - paramInt1, paramInt4 - paramInt2);
    if (!isShowingPopup())
      dismissPopup(); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    LinearLayoutCompat linearLayoutCompat = this.mActivityChooserContent;
    if (this.c.getVisibility() != 0)
      paramInt2 = View.MeasureSpec.makeMeasureSpec(View.MeasureSpec.getSize(paramInt2), 1073741824); 
    measureChild((View)linearLayoutCompat, paramInt1, paramInt2);
    setMeasuredDimension(linearLayoutCompat.getMeasuredWidth(), linearLayoutCompat.getMeasuredHeight());
  }
  
  public void setActivityChooserModel(ActivityChooserModel paramActivityChooserModel) {
    this.a.setDataModel(paramActivityChooserModel);
    if (isShowingPopup()) {
      dismissPopup();
      showPopup();
    } 
  }
  
  public void setDefaultActionButtonContentDescription(int paramInt) {
    this.mDefaultActionButtonContentDescription = paramInt;
  }
  
  public void setExpandActivityOverflowButtonContentDescription(int paramInt) {
    String str = getContext().getString(paramInt);
    this.mExpandActivityOverflowButtonImage.setContentDescription(str);
  }
  
  public void setExpandActivityOverflowButtonDrawable(Drawable paramDrawable) {
    this.mExpandActivityOverflowButtonImage.setImageDrawable(paramDrawable);
  }
  
  public void setInitialActivityCount(int paramInt) {
    this.h = paramInt;
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.f = paramOnDismissListener;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setProvider(ActionProvider paramActionProvider) {
    this.d = paramActionProvider;
  }
  
  public boolean showPopup() {
    if (!isShowingPopup()) {
      if (!this.mIsAttachedToWindow)
        return false; 
      this.g = false;
      a(this.h);
      return true;
    } 
    return false;
  }
  
  private class ActivityChooserViewAdapter extends BaseAdapter {
    private static final int ITEM_VIEW_TYPE_ACTIVITY = 0;
    
    private static final int ITEM_VIEW_TYPE_COUNT = 3;
    
    private static final int ITEM_VIEW_TYPE_FOOTER = 1;
    
    public static final int MAX_ACTIVITY_COUNT_DEFAULT = 4;
    
    public static final int MAX_ACTIVITY_COUNT_UNLIMITED = 2147483647;
    
    private ActivityChooserModel mDataModel;
    
    private boolean mHighlightDefaultActivity;
    
    private int mMaxActivityCount = 4;
    
    private boolean mShowDefaultActivity;
    
    private boolean mShowFooterView;
    
    ActivityChooserViewAdapter(ActivityChooserView this$0) {}
    
    public int getActivityCount() {
      return this.mDataModel.getActivityCount();
    }
    
    public int getCount() {
      int i = this.mDataModel.getActivityCount();
      if (!this.mShowDefaultActivity && this.mDataModel.getDefaultActivity() != null)
        i--; 
      int j = Math.min(i, this.mMaxActivityCount);
      if (this.mShowFooterView)
        j++; 
      return j;
    }
    
    public ActivityChooserModel getDataModel() {
      return this.mDataModel;
    }
    
    public ResolveInfo getDefaultActivity() {
      return this.mDataModel.getDefaultActivity();
    }
    
    public int getHistorySize() {
      return this.mDataModel.getHistorySize();
    }
    
    public Object getItem(int param1Int) {
      switch (getItemViewType(param1Int)) {
        default:
          throw new IllegalArgumentException();
        case 1:
          return null;
        case 0:
          break;
      } 
      if (!this.mShowDefaultActivity && this.mDataModel.getDefaultActivity() != null)
        param1Int++; 
      return this.mDataModel.getActivity(param1Int);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public int getItemViewType(int param1Int) {
      return (this.mShowFooterView && param1Int == getCount() - 1) ? 1 : 0;
    }
    
    public boolean getShowDefaultActivity() {
      return this.mShowDefaultActivity;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      switch (getItemViewType(param1Int)) {
        default:
          throw new IllegalArgumentException();
        case 1:
          if (param1View == null || param1View.getId() != 1) {
            param1View = LayoutInflater.from(this.a.getContext()).inflate(R.layout.abc_activity_chooser_view_list_item, param1ViewGroup, false);
            param1View.setId(1);
            ((TextView)param1View.findViewById(R.id.title)).setText(this.a.getContext().getString(R.string.abc_activity_chooser_view_see_all));
          } 
          return param1View;
        case 0:
          break;
      } 
      if (param1View == null || param1View.getId() != R.id.list_item)
        param1View = LayoutInflater.from(this.a.getContext()).inflate(R.layout.abc_activity_chooser_view_list_item, param1ViewGroup, false); 
      PackageManager packageManager = this.a.getContext().getPackageManager();
      ImageView imageView = (ImageView)param1View.findViewById(R.id.icon);
      ResolveInfo resolveInfo = (ResolveInfo)getItem(param1Int);
      imageView.setImageDrawable(resolveInfo.loadIcon(packageManager));
      ((TextView)param1View.findViewById(R.id.title)).setText(resolveInfo.loadLabel(packageManager));
      if (this.mShowDefaultActivity && param1Int == 0 && this.mHighlightDefaultActivity) {
        param1View.setActivated(true);
        return param1View;
      } 
      param1View.setActivated(false);
      return param1View;
    }
    
    public int getViewTypeCount() {
      return 3;
    }
    
    public int measureContentWidth() {
      int i = this.mMaxActivityCount;
      this.mMaxActivityCount = Integer.MAX_VALUE;
      byte b = 0;
      int j = View.MeasureSpec.makeMeasureSpec(0, 0);
      int k = View.MeasureSpec.makeMeasureSpec(0, 0);
      int m = getCount();
      View view = null;
      int n = 0;
      while (b < m) {
        view = getView(b, view, (ViewGroup)null);
        view.measure(j, k);
        n = Math.max(n, view.getMeasuredWidth());
        b++;
      } 
      this.mMaxActivityCount = i;
      return n;
    }
    
    public void setDataModel(ActivityChooserModel param1ActivityChooserModel) {
      ActivityChooserModel activityChooserModel = this.a.a.getDataModel();
      if (activityChooserModel != null && this.a.isShown())
        activityChooserModel.unregisterObserver(this.a.e); 
      this.mDataModel = param1ActivityChooserModel;
      if (param1ActivityChooserModel != null && this.a.isShown())
        param1ActivityChooserModel.registerObserver(this.a.e); 
      notifyDataSetChanged();
    }
    
    public void setMaxActivityCount(int param1Int) {
      if (this.mMaxActivityCount != param1Int) {
        this.mMaxActivityCount = param1Int;
        notifyDataSetChanged();
      } 
    }
    
    public void setShowDefaultActivity(boolean param1Boolean1, boolean param1Boolean2) {
      if (this.mShowDefaultActivity != param1Boolean1 || this.mHighlightDefaultActivity != param1Boolean2) {
        this.mShowDefaultActivity = param1Boolean1;
        this.mHighlightDefaultActivity = param1Boolean2;
        notifyDataSetChanged();
      } 
    }
    
    public void setShowFooterView(boolean param1Boolean) {
      if (this.mShowFooterView != param1Boolean) {
        this.mShowFooterView = param1Boolean;
        notifyDataSetChanged();
      } 
    }
  }
  
  private class Callbacks implements View.OnClickListener, View.OnLongClickListener, AdapterView.OnItemClickListener, PopupWindow.OnDismissListener {
    Callbacks(ActivityChooserView this$0) {}
    
    private void notifyOnDismissListener() {
      if (this.a.f != null)
        this.a.f.onDismiss(); 
    }
    
    public void onClick(View param1View) {
      if (param1View == this.a.c) {
        this.a.dismissPopup();
        ResolveInfo resolveInfo = this.a.a.getDefaultActivity();
        int i = this.a.a.getDataModel().getActivityIndex(resolveInfo);
        Intent intent = this.a.a.getDataModel().chooseActivity(i);
        if (intent != null) {
          intent.addFlags(524288);
          this.a.getContext().startActivity(intent);
          return;
        } 
      } else {
        if (param1View == this.a.b) {
          this.a.g = false;
          this.a.a(this.a.h);
          return;
        } 
        throw new IllegalArgumentException();
      } 
    }
    
    public void onDismiss() {
      notifyOnDismissListener();
      if (this.a.d != null)
        this.a.d.subUiVisibilityChanged(false); 
    }
    
    public void onItemClick(AdapterView<?> param1AdapterView, View param1View, int param1Int, long param1Long) {
      switch (((ActivityChooserView.ActivityChooserViewAdapter)param1AdapterView.getAdapter()).getItemViewType(param1Int)) {
        default:
          throw new IllegalArgumentException();
        case 1:
          this.a.a(2147483647);
          return;
        case 0:
          break;
      } 
      this.a.dismissPopup();
      if (this.a.g) {
        if (param1Int > 0) {
          this.a.a.getDataModel().setDefaultActivity(param1Int);
          return;
        } 
      } else {
        if (!this.a.a.getShowDefaultActivity())
          param1Int++; 
        Intent intent = this.a.a.getDataModel().chooseActivity(param1Int);
        if (intent != null) {
          intent.addFlags(524288);
          this.a.getContext().startActivity(intent);
        } 
      } 
    }
    
    public boolean onLongClick(View param1View) {
      if (param1View == this.a.c) {
        if (this.a.a.getCount() > 0) {
          this.a.g = true;
          this.a.a(this.a.h);
        } 
        return true;
      } 
      throw new IllegalArgumentException();
    }
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static class InnerLayout extends LinearLayout {
    private static final int[] TINT_ATTRS = new int[] { 16842964 };
    
    public InnerLayout(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(param1Context, param1AttributeSet, TINT_ATTRS);
      setBackgroundDrawable(tintTypedArray.getDrawable(0));
      tintTypedArray.recycle();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActivityChooserView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */