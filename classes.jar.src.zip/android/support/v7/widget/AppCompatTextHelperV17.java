package android.support.v7.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.drawable.Drawable;
import android.support.annotation.RequiresApi;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.widget.TextView;

@RequiresApi(17)
class AppCompatTextHelperV17 extends AppCompatTextHelper {
  private TintInfo mDrawableEndTint;
  
  private TintInfo mDrawableStartTint;
  
  AppCompatTextHelperV17(TextView paramTextView) {
    super(paramTextView);
  }
  
  void a() {
    super.a();
    if (this.mDrawableStartTint != null || this.mDrawableEndTint != null) {
      Drawable[] arrayOfDrawable = this.a.getCompoundDrawablesRelative();
      a(arrayOfDrawable[0], this.mDrawableStartTint);
      a(arrayOfDrawable[2], this.mDrawableEndTint);
    } 
  }
  
  void a(AttributeSet paramAttributeSet, int paramInt) {
    super.a(paramAttributeSet, paramInt);
    Context context = this.a.getContext();
    AppCompatDrawableManager appCompatDrawableManager = AppCompatDrawableManager.get();
    TypedArray typedArray = context.obtainStyledAttributes(paramAttributeSet, R.styleable.AppCompatTextHelper, paramInt, 0);
    if (typedArray.hasValue(R.styleable.AppCompatTextHelper_android_drawableStart))
      this.mDrawableStartTint = a(context, appCompatDrawableManager, typedArray.getResourceId(R.styleable.AppCompatTextHelper_android_drawableStart, 0)); 
    if (typedArray.hasValue(R.styleable.AppCompatTextHelper_android_drawableEnd))
      this.mDrawableEndTint = a(context, appCompatDrawableManager, typedArray.getResourceId(R.styleable.AppCompatTextHelper_android_drawableEnd, 0)); 
    typedArray.recycle();
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\AppCompatTextHelperV17.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */