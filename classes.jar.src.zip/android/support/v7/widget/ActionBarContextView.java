package android.support.v7.widget;

import android.content.Context;
import android.support.annotation.RestrictTo;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v7.appcompat.R;
import android.support.v7.view.ActionMode;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuPresenter;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.widget.LinearLayout;
import android.widget.TextView;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ActionBarContextView extends AbsActionBarView {
  private static final String TAG = "ActionBarContextView";
  
  private View mClose;
  
  private int mCloseItemLayout;
  
  private View mCustomView;
  
  private CharSequence mSubtitle;
  
  private int mSubtitleStyleRes;
  
  private TextView mSubtitleView;
  
  private CharSequence mTitle;
  
  private LinearLayout mTitleLayout;
  
  private boolean mTitleOptional;
  
  private int mTitleStyleRes;
  
  private TextView mTitleView;
  
  public ActionBarContextView(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, R.attr.actionModeStyle);
  }
  
  public ActionBarContextView(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(paramContext, paramAttributeSet, R.styleable.ActionMode, paramInt, 0);
    ViewCompat.setBackground((View)this, tintTypedArray.getDrawable(R.styleable.ActionMode_background));
    this.mTitleStyleRes = tintTypedArray.getResourceId(R.styleable.ActionMode_titleTextStyle, 0);
    this.mSubtitleStyleRes = tintTypedArray.getResourceId(R.styleable.ActionMode_subtitleTextStyle, 0);
    this.mContentHeight = tintTypedArray.getLayoutDimension(R.styleable.ActionMode_height, 0);
    this.mCloseItemLayout = tintTypedArray.getResourceId(R.styleable.ActionMode_closeItemLayout, R.layout.abc_action_mode_close_item_material);
    tintTypedArray.recycle();
  }
  
  private void initTitle() {
    byte b2;
    if (this.mTitleLayout == null) {
      LayoutInflater.from(getContext()).inflate(R.layout.abc_action_bar_title_item, this);
      this.mTitleLayout = (LinearLayout)getChildAt(-1 + getChildCount());
      this.mTitleView = (TextView)this.mTitleLayout.findViewById(R.id.action_bar_title);
      this.mSubtitleView = (TextView)this.mTitleLayout.findViewById(R.id.action_bar_subtitle);
      if (this.mTitleStyleRes != 0)
        this.mTitleView.setTextAppearance(getContext(), this.mTitleStyleRes); 
      if (this.mSubtitleStyleRes != 0)
        this.mSubtitleView.setTextAppearance(getContext(), this.mSubtitleStyleRes); 
    } 
    this.mTitleView.setText(this.mTitle);
    this.mSubtitleView.setText(this.mSubtitle);
    int i = true ^ TextUtils.isEmpty(this.mTitle);
    int j = true ^ TextUtils.isEmpty(this.mSubtitle);
    TextView textView = this.mSubtitleView;
    byte b1 = 8;
    if (j != 0) {
      b2 = 0;
    } else {
      b2 = 8;
    } 
    textView.setVisibility(b2);
    LinearLayout linearLayout = this.mTitleLayout;
    if (i != 0 || j != 0)
      b1 = 0; 
    linearLayout.setVisibility(b1);
    if (this.mTitleLayout.getParent() == null)
      addView((View)this.mTitleLayout); 
  }
  
  public void closeMode() {
    if (this.mClose == null) {
      killMode();
      return;
    } 
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(-1, -2);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new ViewGroup.MarginLayoutParams(getContext(), paramAttributeSet);
  }
  
  public CharSequence getSubtitle() {
    return this.mSubtitle;
  }
  
  public CharSequence getTitle() {
    return this.mTitle;
  }
  
  public boolean hideOverflowMenu() {
    return (this.mActionMenuPresenter != null) ? this.mActionMenuPresenter.hideOverflowMenu() : false;
  }
  
  public void initForMode(ActionMode paramActionMode) {
    if (this.mClose == null) {
      this.mClose = LayoutInflater.from(getContext()).inflate(this.mCloseItemLayout, this, false);
      addView(this.mClose);
    } else if (this.mClose.getParent() == null) {
      addView(this.mClose);
    } 
    this.mClose.findViewById(R.id.action_mode_close_button).setOnClickListener(new View.OnClickListener(this, paramActionMode) {
          public void onClick(View param1View) {
            this.a.finish();
          }
        });
    MenuBuilder menuBuilder = (MenuBuilder)paramActionMode.getMenu();
    if (this.mActionMenuPresenter != null)
      this.mActionMenuPresenter.dismissPopupMenus(); 
    this.mActionMenuPresenter = new ActionMenuPresenter(getContext());
    this.mActionMenuPresenter.setReserveOverflow(true);
    ViewGroup.LayoutParams layoutParams = new ViewGroup.LayoutParams(-2, -1);
    menuBuilder.addMenuPresenter((MenuPresenter)this.mActionMenuPresenter, this.mPopupContext);
    this.mMenuView = (ActionMenuView)this.mActionMenuPresenter.getMenuView(this);
    ViewCompat.setBackground((View)this.mMenuView, null);
    addView((View)this.mMenuView, layoutParams);
  }
  
  public boolean isOverflowMenuShowing() {
    return (this.mActionMenuPresenter != null) ? this.mActionMenuPresenter.isOverflowMenuShowing() : false;
  }
  
  public boolean isTitleOptional() {
    return this.mTitleOptional;
  }
  
  public void killMode() {
    removeAllViews();
    this.mCustomView = null;
    this.mMenuView = null;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.mActionMenuPresenter != null) {
      this.mActionMenuPresenter.hideOverflowMenu();
      this.mActionMenuPresenter.hideSubMenus();
    } 
  }
  
  public void onInitializeAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 32) {
      paramAccessibilityEvent.setSource((View)this);
      paramAccessibilityEvent.setClassName(getClass().getName());
      paramAccessibilityEvent.setPackageName(getContext().getPackageName());
      paramAccessibilityEvent.setContentDescription(this.mTitle);
      return;
    } 
    super.onInitializeAccessibilityEvent(paramAccessibilityEvent);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i;
    int m;
    int i1;
    boolean bool = ViewUtils.isLayoutRtl((View)this);
    if (bool) {
      i = paramInt3 - paramInt1 - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    int j = getPaddingTop();
    int k = paramInt4 - paramInt2 - getPaddingTop() - getPaddingBottom();
    if (this.mClose != null && this.mClose.getVisibility() != 8) {
      int i2;
      int i3;
      ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams();
      if (bool) {
        i2 = marginLayoutParams.rightMargin;
      } else {
        i2 = marginLayoutParams.leftMargin;
      } 
      if (bool) {
        i3 = marginLayoutParams.leftMargin;
      } else {
        i3 = marginLayoutParams.rightMargin;
      } 
      int i4 = next(i, i2, bool);
      m = next(i4 + positionChild(this.mClose, i4, j, k, bool), i3, bool);
    } else {
      m = i;
    } 
    if (this.mTitleLayout != null && this.mCustomView == null && this.mTitleLayout.getVisibility() != 8)
      m += positionChild((View)this.mTitleLayout, m, j, k, bool); 
    int n = m;
    if (this.mCustomView != null)
      positionChild(this.mCustomView, n, j, k, bool); 
    if (bool) {
      i1 = getPaddingLeft();
    } else {
      i1 = paramInt3 - paramInt1 - getPaddingRight();
    } 
    if (this.mMenuView != null)
      positionChild((View)this.mMenuView, i1, j, k, bool ^ true); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = 1073741824;
    if (i == j) {
      if (View.MeasureSpec.getMode(paramInt2) != 0) {
        int m;
        int k = View.MeasureSpec.getSize(paramInt1);
        if (this.mContentHeight > 0) {
          m = this.mContentHeight;
        } else {
          m = View.MeasureSpec.getSize(paramInt2);
        } 
        int n = getPaddingTop() + getPaddingBottom();
        int i1 = k - getPaddingLeft() - getPaddingRight();
        int i2 = m - n;
        int i3 = View.MeasureSpec.makeMeasureSpec(i2, -2147483648);
        View view = this.mClose;
        byte b = 0;
        if (view != null) {
          int i4 = measureChildView(this.mClose, i1, i3, 0);
          ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)this.mClose.getLayoutParams();
          i1 = i4 - marginLayoutParams.leftMargin + marginLayoutParams.rightMargin;
        } 
        if (this.mMenuView != null && this.mMenuView.getParent() == this)
          i1 = measureChildView((View)this.mMenuView, i1, i3, 0); 
        if (this.mTitleLayout != null && this.mCustomView == null)
          if (this.mTitleOptional) {
            boolean bool;
            byte b1;
            int i4 = View.MeasureSpec.makeMeasureSpec(0, 0);
            this.mTitleLayout.measure(i4, i3);
            int i5 = this.mTitleLayout.getMeasuredWidth();
            if (i5 <= i1) {
              bool = true;
            } else {
              bool = false;
            } 
            if (bool)
              i1 -= i5; 
            LinearLayout linearLayout = this.mTitleLayout;
            if (bool) {
              b1 = 0;
            } else {
              b1 = 8;
            } 
            linearLayout.setVisibility(b1);
          } else {
            i1 = measureChildView((View)this.mTitleLayout, i1, i3, 0);
          }  
        if (this.mCustomView != null) {
          int i4;
          ViewGroup.LayoutParams layoutParams = this.mCustomView.getLayoutParams();
          if (layoutParams.width != -2) {
            i4 = 1073741824;
          } else {
            i4 = Integer.MIN_VALUE;
          } 
          if (layoutParams.width >= 0)
            i1 = Math.min(layoutParams.width, i1); 
          if (layoutParams.height == -2)
            j = Integer.MIN_VALUE; 
          if (layoutParams.height >= 0)
            i2 = Math.min(layoutParams.height, i2); 
          this.mCustomView.measure(View.MeasureSpec.makeMeasureSpec(i1, i4), View.MeasureSpec.makeMeasureSpec(i2, j));
        } 
        if (this.mContentHeight <= 0) {
          int i4 = getChildCount();
          int i5 = 0;
          while (b < i4) {
            int i6 = n + getChildAt(b).getMeasuredHeight();
            if (i6 > i5)
              i5 = i6; 
            b++;
          } 
          setMeasuredDimension(k, i5);
          return;
        } 
        setMeasuredDimension(k, m);
        return;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(getClass().getSimpleName());
      stringBuilder1.append(" can only be used ");
      stringBuilder1.append("with android:layout_height=\"wrap_content\"");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(getClass().getSimpleName());
    stringBuilder.append(" can only be used ");
    stringBuilder.append("with android:layout_width=\"match_parent\" (or fill_parent)");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void setContentHeight(int paramInt) {
    this.mContentHeight = paramInt;
  }
  
  public void setCustomView(View paramView) {
    if (this.mCustomView != null)
      removeView(this.mCustomView); 
    this.mCustomView = paramView;
    if (paramView != null && this.mTitleLayout != null) {
      removeView((View)this.mTitleLayout);
      this.mTitleLayout = null;
    } 
    if (paramView != null)
      addView(paramView); 
    requestLayout();
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.mSubtitle = paramCharSequence;
    initTitle();
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.mTitle = paramCharSequence;
    initTitle();
  }
  
  public void setTitleOptional(boolean paramBoolean) {
    if (paramBoolean != this.mTitleOptional)
      requestLayout(); 
    this.mTitleOptional = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return false;
  }
  
  public boolean showOverflowMenu() {
    return (this.mActionMenuPresenter != null) ? this.mActionMenuPresenter.showOverflowMenu() : false;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActionBarContextView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */