package android.support.v7.widget;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ResolveInfo;
import android.database.DataSetObservable;
import android.os.AsyncTask;
import android.text.TextUtils;
import android.util.Log;
import android.util.Xml;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Executor;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlSerializer;

class ActivityChooserModel extends DataSetObservable {
  private static final int DEFAULT_ACTIVITY_INFLATION = 5;
  
  private static final float DEFAULT_HISTORICAL_RECORD_WEIGHT = 1.0F;
  
  public static final String DEFAULT_HISTORY_FILE_NAME = "activity_choser_model_history.xml";
  
  public static final int DEFAULT_HISTORY_MAX_LENGTH = 50;
  
  private static final String HISTORY_FILE_EXTENSION = ".xml";
  
  private static final int INVALID_INDEX = -1;
  
  static final String a = "ActivityChooserModel";
  
  private static final Map<String, ActivityChooserModel> sDataModelRegistry;
  
  private static final Object sRegistryLock = new Object();
  
  final Context b;
  
  final String c;
  
  boolean d = true;
  
  private final List<ActivityResolveInfo> mActivities = new ArrayList<ActivityResolveInfo>();
  
  private OnChooseActivityListener mActivityChoserModelPolicy;
  
  private ActivitySorter mActivitySorter = new DefaultSorter();
  
  private final List<HistoricalRecord> mHistoricalRecords = new ArrayList<HistoricalRecord>();
  
  private boolean mHistoricalRecordsChanged = true;
  
  private int mHistoryMaxSize = 50;
  
  private final Object mInstanceLock = new Object();
  
  private Intent mIntent;
  
  private boolean mReadShareHistoryCalled = false;
  
  private boolean mReloadActivities = false;
  
  static {
    sDataModelRegistry = new HashMap<String, ActivityChooserModel>();
  }
  
  private ActivityChooserModel(Context paramContext, String paramString) {
    this.b = paramContext.getApplicationContext();
    if (!TextUtils.isEmpty(paramString) && !paramString.endsWith(".xml")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append(".xml");
      this.c = stringBuilder.toString();
      return;
    } 
    this.c = paramString;
  }
  
  private boolean addHistoricalRecord(HistoricalRecord paramHistoricalRecord) {
    boolean bool = this.mHistoricalRecords.add(paramHistoricalRecord);
    if (bool) {
      this.mHistoricalRecordsChanged = true;
      pruneExcessiveHistoricalRecordsIfNeeded();
      persistHistoricalDataIfNeeded();
      sortActivitiesIfNeeded();
      notifyChanged();
    } 
    return bool;
  }
  
  private void ensureConsistentState() {
    int i = loadActivitiesIfNeeded() | readHistoricalDataIfNeeded();
    pruneExcessiveHistoricalRecordsIfNeeded();
    if (i != 0) {
      sortActivitiesIfNeeded();
      notifyChanged();
    } 
  }
  
  public static ActivityChooserModel get(Context paramContext, String paramString) {
    synchronized (sRegistryLock) {
      ActivityChooserModel activityChooserModel = sDataModelRegistry.get(paramString);
      if (activityChooserModel == null) {
        activityChooserModel = new ActivityChooserModel(paramContext, paramString);
        sDataModelRegistry.put(paramString, activityChooserModel);
      } 
      return activityChooserModel;
    } 
  }
  
  private boolean loadActivitiesIfNeeded() {
    boolean bool = this.mReloadActivities;
    byte b = 0;
    if (bool && this.mIntent != null) {
      this.mReloadActivities = false;
      this.mActivities.clear();
      List<ResolveInfo> list = this.b.getPackageManager().queryIntentActivities(this.mIntent, 0);
      int i = list.size();
      while (b < i) {
        ResolveInfo resolveInfo = list.get(b);
        this.mActivities.add(new ActivityResolveInfo(resolveInfo));
        b++;
      } 
      return true;
    } 
    return false;
  }
  
  private void persistHistoricalDataIfNeeded() {
    if (this.mReadShareHistoryCalled) {
      if (!this.mHistoricalRecordsChanged)
        return; 
      this.mHistoricalRecordsChanged = false;
      if (!TextUtils.isEmpty(this.c)) {
        PersistHistoryAsyncTask persistHistoryAsyncTask = new PersistHistoryAsyncTask(this);
        Executor executor = AsyncTask.THREAD_POOL_EXECUTOR;
        Object[] arrayOfObject = new Object[2];
        arrayOfObject[0] = new ArrayList<HistoricalRecord>(this.mHistoricalRecords);
        arrayOfObject[1] = this.c;
        persistHistoryAsyncTask.executeOnExecutor(executor, arrayOfObject);
      } 
      return;
    } 
    throw new IllegalStateException("No preceding call to #readHistoricalData");
  }
  
  private void pruneExcessiveHistoricalRecordsIfNeeded() {
    int i = this.mHistoricalRecords.size() - this.mHistoryMaxSize;
    if (i <= 0)
      return; 
    this.mHistoricalRecordsChanged = true;
    for (byte b = 0; b < i; b++)
      (HistoricalRecord)this.mHistoricalRecords.remove(0); 
  }
  
  private boolean readHistoricalDataIfNeeded() {
    if (this.d && this.mHistoricalRecordsChanged && !TextUtils.isEmpty(this.c)) {
      this.d = false;
      this.mReadShareHistoryCalled = true;
      readHistoricalDataImpl();
      return true;
    } 
    return false;
  }
  
  private void readHistoricalDataImpl() {
    try {
      FileInputStream fileInputStream = this.b.openFileInput(this.c);
      try {
        XmlPullParser xmlPullParser = Xml.newPullParser();
        xmlPullParser.setInput(fileInputStream, "UTF-8");
        int i;
        for (i = 0; i != 1 && i != 2; i = xmlPullParser.next());
        if ("historical-records".equals(xmlPullParser.getName())) {
          List<HistoricalRecord> list = this.mHistoricalRecords;
          list.clear();
          while (true) {
            int j = xmlPullParser.next();
            if (j == 1) {
              if (fileInputStream != null) {
                fileInputStream.close();
                return;
              } 
              break;
            } 
            if (j == 3 || j == 4)
              continue; 
            if ("historical-record".equals(xmlPullParser.getName())) {
              list.add(new HistoricalRecord(xmlPullParser.getAttributeValue(null, "activity"), Long.parseLong(xmlPullParser.getAttributeValue(null, "time")), Float.parseFloat(xmlPullParser.getAttributeValue(null, "weight"))));
              continue;
            } 
            throw new XmlPullParserException("Share records file not well-formed.");
          } 
        } else {
          throw new XmlPullParserException("Share records file does not start with historical-records tag.");
        } 
      } catch (XmlPullParserException xmlPullParserException) {
        String str = a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error reading historical recrod file: ");
        stringBuilder.append(this.c);
        Log.e(str, stringBuilder.toString(), (Throwable)xmlPullParserException);
        if (fileInputStream != null) {
          fileInputStream.close();
          return;
        } 
      } catch (IOException iOException) {
        String str = a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error reading historical recrod file: ");
        stringBuilder.append(this.c);
        Log.e(str, stringBuilder.toString(), iOException);
        if (fileInputStream != null) {
          fileInputStream.close();
          return;
        } 
      } finally {
        Exception exception;
      } 
      return;
    } catch (FileNotFoundException fileNotFoundException) {
      return;
    } 
  }
  
  private boolean sortActivitiesIfNeeded() {
    if (this.mActivitySorter != null && this.mIntent != null && !this.mActivities.isEmpty() && !this.mHistoricalRecords.isEmpty()) {
      this.mActivitySorter.sort(this.mIntent, this.mActivities, Collections.unmodifiableList(this.mHistoricalRecords));
      return true;
    } 
    return false;
  }
  
  public Intent chooseActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      if (this.mIntent == null)
        return null; 
      ensureConsistentState();
      ActivityResolveInfo activityResolveInfo = this.mActivities.get(paramInt);
      ComponentName componentName = new ComponentName(activityResolveInfo.resolveInfo.activityInfo.packageName, activityResolveInfo.resolveInfo.activityInfo.name);
      Intent intent = new Intent(this.mIntent);
      intent.setComponent(componentName);
      if (this.mActivityChoserModelPolicy != null) {
        Intent intent1 = new Intent(intent);
        if (this.mActivityChoserModelPolicy.onChooseActivity(this, intent1))
          return null; 
      } 
      addHistoricalRecord(new HistoricalRecord(componentName, System.currentTimeMillis(), 1.0F));
      return intent;
    } 
  }
  
  public ResolveInfo getActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return ((ActivityResolveInfo)this.mActivities.get(paramInt)).resolveInfo;
    } 
  }
  
  public int getActivityCount() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return this.mActivities.size();
    } 
  }
  
  public int getActivityIndex(ResolveInfo paramResolveInfo) {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      List<ActivityResolveInfo> list = this.mActivities;
      int i = list.size();
      for (byte b = 0;; b++) {
        if (b < i) {
          if (((ActivityResolveInfo)list.get(b)).resolveInfo == paramResolveInfo)
            return b; 
        } else {
          return -1;
        } 
      } 
    } 
  }
  
  public ResolveInfo getDefaultActivity() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      if (!this.mActivities.isEmpty())
        return ((ActivityResolveInfo)this.mActivities.get(0)).resolveInfo; 
      return null;
    } 
  }
  
  public int getHistoryMaxSize() {
    synchronized (this.mInstanceLock) {
      return this.mHistoryMaxSize;
    } 
  }
  
  public int getHistorySize() {
    synchronized (this.mInstanceLock) {
      ensureConsistentState();
      return this.mHistoricalRecords.size();
    } 
  }
  
  public Intent getIntent() {
    synchronized (this.mInstanceLock) {
      return this.mIntent;
    } 
  }
  
  public void setActivitySorter(ActivitySorter paramActivitySorter) {
    synchronized (this.mInstanceLock) {
      if (this.mActivitySorter == paramActivitySorter)
        return; 
      this.mActivitySorter = paramActivitySorter;
      if (sortActivitiesIfNeeded())
        notifyChanged(); 
      return;
    } 
  }
  
  public void setDefaultActivity(int paramInt) {
    synchronized (this.mInstanceLock) {
      float f;
      ensureConsistentState();
      ActivityResolveInfo activityResolveInfo1 = this.mActivities.get(paramInt);
      ActivityResolveInfo activityResolveInfo2 = this.mActivities.get(0);
      if (activityResolveInfo2 != null) {
        f = 5.0F + activityResolveInfo2.weight - activityResolveInfo1.weight;
      } else {
        f = 1.0F;
      } 
      addHistoricalRecord(new HistoricalRecord(new ComponentName(activityResolveInfo1.resolveInfo.activityInfo.packageName, activityResolveInfo1.resolveInfo.activityInfo.name), System.currentTimeMillis(), f));
      return;
    } 
  }
  
  public void setHistoryMaxSize(int paramInt) {
    synchronized (this.mInstanceLock) {
      if (this.mHistoryMaxSize == paramInt)
        return; 
      this.mHistoryMaxSize = paramInt;
      pruneExcessiveHistoricalRecordsIfNeeded();
      if (sortActivitiesIfNeeded())
        notifyChanged(); 
      return;
    } 
  }
  
  public void setIntent(Intent paramIntent) {
    synchronized (this.mInstanceLock) {
      if (this.mIntent == paramIntent)
        return; 
      this.mIntent = paramIntent;
      this.mReloadActivities = true;
      ensureConsistentState();
      return;
    } 
  }
  
  public void setOnChooseActivityListener(OnChooseActivityListener paramOnChooseActivityListener) {
    synchronized (this.mInstanceLock) {
      this.mActivityChoserModelPolicy = paramOnChooseActivityListener;
      return;
    } 
  }
  
  public static interface ActivityChooserModelClient {
    void setActivityChooserModel(ActivityChooserModel param1ActivityChooserModel);
  }
  
  public static final class ActivityResolveInfo implements Comparable<ActivityResolveInfo> {
    public final ResolveInfo resolveInfo;
    
    public float weight;
    
    public ActivityResolveInfo(ResolveInfo param1ResolveInfo) {
      this.resolveInfo = param1ResolveInfo;
    }
    
    public int compareTo(ActivityResolveInfo param1ActivityResolveInfo) {
      return Float.floatToIntBits(param1ActivityResolveInfo.weight) - Float.floatToIntBits(this.weight);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (getClass() != param1Object.getClass())
        return false; 
      ActivityResolveInfo activityResolveInfo = (ActivityResolveInfo)param1Object;
      return !(Float.floatToIntBits(this.weight) != Float.floatToIntBits(activityResolveInfo.weight));
    }
    
    public int hashCode() {
      return 31 + Float.floatToIntBits(this.weight);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append("resolveInfo:");
      stringBuilder.append(this.resolveInfo.toString());
      stringBuilder.append("; weight:");
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static interface ActivitySorter {
    void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1);
  }
  
  private static final class DefaultSorter implements ActivitySorter {
    private static final float WEIGHT_DECAY_COEFFICIENT = 0.95F;
    
    private final Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> mPackageNameToActivityMap = new HashMap<ComponentName, ActivityChooserModel.ActivityResolveInfo>();
    
    public void sort(Intent param1Intent, List<ActivityChooserModel.ActivityResolveInfo> param1List, List<ActivityChooserModel.HistoricalRecord> param1List1) {
      Map<ComponentName, ActivityChooserModel.ActivityResolveInfo> map = this.mPackageNameToActivityMap;
      map.clear();
      int i = param1List.size();
      for (byte b = 0; b < i; b++) {
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = param1List.get(b);
        activityResolveInfo.weight = 0.0F;
        map.put(new ComponentName(activityResolveInfo.resolveInfo.activityInfo.packageName, activityResolveInfo.resolveInfo.activityInfo.name), activityResolveInfo);
      } 
      int j = -1 + param1List1.size();
      float f = 1.0F;
      while (j >= 0) {
        ActivityChooserModel.HistoricalRecord historicalRecord = param1List1.get(j);
        ActivityChooserModel.ActivityResolveInfo activityResolveInfo = map.get(historicalRecord.activity);
        if (activityResolveInfo != null) {
          activityResolveInfo.weight += f * historicalRecord.weight;
          f *= 0.95F;
        } 
        j--;
      } 
      Collections.sort(param1List);
    }
  }
  
  public static final class HistoricalRecord {
    public final ComponentName activity;
    
    public final long time;
    
    public final float weight;
    
    public HistoricalRecord(ComponentName param1ComponentName, long param1Long, float param1Float) {
      this.activity = param1ComponentName;
      this.time = param1Long;
      this.weight = param1Float;
    }
    
    public HistoricalRecord(String param1String, long param1Long, float param1Float) {
      this(ComponentName.unflattenFromString(param1String), param1Long, param1Float);
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (param1Object == null)
        return false; 
      if (getClass() != param1Object.getClass())
        return false; 
      HistoricalRecord historicalRecord = (HistoricalRecord)param1Object;
      if (this.activity == null) {
        if (historicalRecord.activity != null)
          return false; 
      } else if (!this.activity.equals(historicalRecord.activity)) {
        return false;
      } 
      return (this.time != historicalRecord.time) ? false : (!(Float.floatToIntBits(this.weight) != Float.floatToIntBits(historicalRecord.weight)));
    }
    
    public int hashCode() {
      int i;
      if (this.activity == null) {
        i = 0;
      } else {
        i = this.activity.hashCode();
      } 
      return 31 * (31 * (i + 31) + (int)(this.time ^ this.time >>> 32L)) + Float.floatToIntBits(this.weight);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("[");
      stringBuilder.append("; activity:");
      stringBuilder.append(this.activity);
      stringBuilder.append("; time:");
      stringBuilder.append(this.time);
      stringBuilder.append("; weight:");
      stringBuilder.append(new BigDecimal(this.weight));
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  public static interface OnChooseActivityListener {
    boolean onChooseActivity(ActivityChooserModel param1ActivityChooserModel, Intent param1Intent);
  }
  
  private final class PersistHistoryAsyncTask extends AsyncTask<Object, Void, Void> {
    PersistHistoryAsyncTask(ActivityChooserModel this$0) {}
    
    public Void doInBackground(Object... param1VarArgs) {
      List<ActivityChooserModel.HistoricalRecord> list = (List)param1VarArgs[0];
      String str = (String)param1VarArgs[1];
      try {
        FileOutputStream fileOutputStream = this.a.b.openFileOutput(str, 0);
        XmlSerializer xmlSerializer = Xml.newSerializer();
        try {
          xmlSerializer.setOutput(fileOutputStream, null);
          xmlSerializer.startDocument("UTF-8", Boolean.valueOf(true));
          xmlSerializer.startTag(null, "historical-records");
          int i = list.size();
          for (byte b = 0; b < i; b++) {
            ActivityChooserModel.HistoricalRecord historicalRecord = list.remove(0);
            xmlSerializer.startTag(null, "historical-record");
            xmlSerializer.attribute(null, "activity", historicalRecord.activity.flattenToString());
            xmlSerializer.attribute(null, "time", String.valueOf(historicalRecord.time));
            xmlSerializer.attribute(null, "weight", String.valueOf(historicalRecord.weight));
            xmlSerializer.endTag(null, "historical-record");
          } 
          xmlSerializer.endTag(null, "historical-records");
          xmlSerializer.endDocument();
          this.a.d = true;
          if (fileOutputStream != null) {
            fileOutputStream.close();
            return null;
          } 
        } catch (IllegalArgumentException illegalArgumentException) {
          String str1 = ActivityChooserModel.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Error writing historical record file: ");
          stringBuilder.append(this.a.c);
          Log.e(str1, stringBuilder.toString(), illegalArgumentException);
          this.a.d = true;
          if (fileOutputStream != null) {
            fileOutputStream.close();
            return null;
          } 
        } catch (IllegalStateException illegalStateException) {
          String str1 = ActivityChooserModel.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Error writing historical record file: ");
          stringBuilder.append(this.a.c);
          Log.e(str1, stringBuilder.toString(), illegalStateException);
          this.a.d = true;
          if (fileOutputStream != null) {
            fileOutputStream.close();
            return null;
          } 
        } catch (IOException iOException) {
          String str1 = ActivityChooserModel.a;
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Error writing historical record file: ");
          stringBuilder.append(this.a.c);
          Log.e(str1, stringBuilder.toString(), iOException);
          this.a.d = true;
          if (fileOutputStream != null) {
            fileOutputStream.close();
            return null;
          } 
        } finally {
          Exception exception;
        } 
        return null;
      } catch (FileNotFoundException fileNotFoundException) {
        String str1 = ActivityChooserModel.a;
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error writing historical record file: ");
        stringBuilder.append(str);
        Log.e(str1, stringBuilder.toString(), fileNotFoundException);
        return null;
      } 
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActivityChooserModel.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */