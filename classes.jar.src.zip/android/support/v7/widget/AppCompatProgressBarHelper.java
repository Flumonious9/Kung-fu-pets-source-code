package android.support.v7.widget;

import android.graphics.Bitmap;
import android.graphics.BitmapShader;
import android.graphics.Shader;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.ClipDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.RoundRectShape;
import android.graphics.drawable.shapes.Shape;
import android.support.v4.graphics.drawable.WrappedDrawable;
import android.util.AttributeSet;
import android.widget.ProgressBar;

class AppCompatProgressBarHelper {
  private static final int[] TINT_ATTRS = new int[] { 16843067, 16843068 };
  
  private Bitmap mSampleTile;
  
  private final ProgressBar mView;
  
  AppCompatProgressBarHelper(ProgressBar paramProgressBar) {
    this.mView = paramProgressBar;
  }
  
  private Shape getDrawableShape() {
    return (Shape)new RoundRectShape(new float[] { 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F, 5.0F }, null, null);
  }
  
  private Drawable tileify(Drawable paramDrawable, boolean paramBoolean) {
    if (paramDrawable instanceof WrappedDrawable) {
      WrappedDrawable wrappedDrawable = (WrappedDrawable)paramDrawable;
      Drawable drawable = wrappedDrawable.getWrappedDrawable();
      if (drawable != null) {
        wrappedDrawable.setWrappedDrawable(tileify(drawable, paramBoolean));
        return paramDrawable;
      } 
    } else {
      if (paramDrawable instanceof LayerDrawable) {
        LayerDrawable layerDrawable1 = (LayerDrawable)paramDrawable;
        int i = layerDrawable1.getNumberOfLayers();
        Drawable[] arrayOfDrawable = new Drawable[i];
        byte b1 = 0;
        for (byte b2 = 0; b2 < i; b2++) {
          boolean bool;
          int j = layerDrawable1.getId(b2);
          Drawable drawable = layerDrawable1.getDrawable(b2);
          if (j == 16908301 || j == 16908303) {
            bool = true;
          } else {
            bool = false;
          } 
          arrayOfDrawable[b2] = tileify(drawable, bool);
        } 
        LayerDrawable layerDrawable2 = new LayerDrawable(arrayOfDrawable);
        while (b1 < i) {
          layerDrawable2.setId(b1, layerDrawable1.getId(b1));
          b1++;
        } 
        return (Drawable)layerDrawable2;
      } 
      if (paramDrawable instanceof BitmapDrawable) {
        BitmapDrawable bitmapDrawable = (BitmapDrawable)paramDrawable;
        Bitmap bitmap = bitmapDrawable.getBitmap();
        if (this.mSampleTile == null)
          this.mSampleTile = bitmap; 
        ShapeDrawable shapeDrawable = new ShapeDrawable(getDrawableShape());
        BitmapShader bitmapShader = new BitmapShader(bitmap, Shader.TileMode.REPEAT, Shader.TileMode.CLAMP);
        shapeDrawable.getPaint().setShader((Shader)bitmapShader);
        shapeDrawable.getPaint().setColorFilter(bitmapDrawable.getPaint().getColorFilter());
        return (Drawable)(paramBoolean ? new ClipDrawable((Drawable)shapeDrawable, 3, 1) : shapeDrawable);
      } 
    } 
    return paramDrawable;
  }
  
  private Drawable tileifyIndeterminate(Drawable paramDrawable) {
    AnimationDrawable animationDrawable;
    if (paramDrawable instanceof AnimationDrawable) {
      AnimationDrawable animationDrawable1 = (AnimationDrawable)paramDrawable;
      int i = animationDrawable1.getNumberOfFrames();
      AnimationDrawable animationDrawable2 = new AnimationDrawable();
      animationDrawable2.setOneShot(animationDrawable1.isOneShot());
      for (byte b = 0; b < i; b++) {
        Drawable drawable = tileify(animationDrawable1.getFrame(b), true);
        drawable.setLevel(10000);
        animationDrawable2.addFrame(drawable, animationDrawable1.getDuration(b));
      } 
      animationDrawable2.setLevel(10000);
      animationDrawable = animationDrawable2;
    } 
    return (Drawable)animationDrawable;
  }
  
  void a(AttributeSet paramAttributeSet, int paramInt) {
    TintTypedArray tintTypedArray = TintTypedArray.obtainStyledAttributes(this.mView.getContext(), paramAttributeSet, TINT_ATTRS, paramInt, 0);
    Drawable drawable1 = tintTypedArray.getDrawableIfKnown(0);
    if (drawable1 != null)
      this.mView.setIndeterminateDrawable(tileifyIndeterminate(drawable1)); 
    Drawable drawable2 = tintTypedArray.getDrawableIfKnown(1);
    if (drawable2 != null)
      this.mView.setProgressDrawable(tileify(drawable2, false)); 
    tintTypedArray.recycle();
  }
  
  Bitmap getSampleTime() {
    return this.mSampleTile;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\AppCompatProgressBarHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */