package android.support.v7.widget;

import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.graphics.drawable.Drawable;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.ActionProvider;
import android.support.v7.appcompat.R;
import android.support.v7.view.ActionBarPolicy;
import android.support.v7.view.menu.ActionMenuItemView;
import android.support.v7.view.menu.BaseMenuPresenter;
import android.support.v7.view.menu.MenuBuilder;
import android.support.v7.view.menu.MenuItemImpl;
import android.support.v7.view.menu.MenuPopupHelper;
import android.support.v7.view.menu.MenuPresenter;
import android.support.v7.view.menu.MenuView;
import android.support.v7.view.menu.ShowableListMenu;
import android.support.v7.view.menu.SubMenuBuilder;
import android.util.AttributeSet;
import android.util.SparseBooleanArray;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

class ActionMenuPresenter extends BaseMenuPresenter implements ActionProvider.SubUiVisibilityListener {
  private static final String TAG = "ActionMenuPresenter";
  
  OverflowMenuButton a;
  
  OverflowPopup b;
  
  ActionButtonSubmenu c;
  
  OpenOverflowRunnable d;
  
  final PopupPresenterCallback e = new PopupPresenterCallback(this);
  
  int f;
  
  private final SparseBooleanArray mActionButtonGroups = new SparseBooleanArray();
  
  private int mActionItemWidthLimit;
  
  private boolean mExpandedActionViewsExclusive;
  
  private int mMaxItems;
  
  private boolean mMaxItemsSet;
  
  private int mMinCellSize;
  
  private Drawable mPendingOverflowIcon;
  
  private boolean mPendingOverflowIconSet;
  
  private ActionMenuPopupCallback mPopupCallback;
  
  private boolean mReserveOverflow;
  
  private boolean mReserveOverflowSet;
  
  private View mScrapActionButtonView;
  
  private boolean mStrictWidthLimit;
  
  private int mWidthLimit;
  
  private boolean mWidthLimitSet;
  
  public ActionMenuPresenter(Context paramContext) {
    super(paramContext, R.layout.abc_action_menu_layout, R.layout.abc_action_menu_item_layout);
  }
  
  private View findViewForItem(MenuItem paramMenuItem) {
    ViewGroup viewGroup = (ViewGroup)this.mMenuView;
    if (viewGroup == null)
      return null; 
    int i = viewGroup.getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = viewGroup.getChildAt(b);
      if (view instanceof MenuView.ItemView && ((MenuView.ItemView)view).getItemData() == paramMenuItem)
        return view; 
    } 
    return null;
  }
  
  public void bindItemView(MenuItemImpl paramMenuItemImpl, MenuView.ItemView paramItemView) {
    paramItemView.initialize(paramMenuItemImpl, 0);
    ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
    ActionMenuItemView actionMenuItemView = (ActionMenuItemView)paramItemView;
    actionMenuItemView.setItemInvoker(actionMenuView);
    if (this.mPopupCallback == null)
      this.mPopupCallback = new ActionMenuPopupCallback(this); 
    actionMenuItemView.setPopupCallback(this.mPopupCallback);
  }
  
  public boolean dismissPopupMenus() {
    return hideOverflowMenu() | hideSubMenus();
  }
  
  public boolean filterLeftoverView(ViewGroup paramViewGroup, int paramInt) {
    return (paramViewGroup.getChildAt(paramInt) == this.a) ? false : super.filterLeftoverView(paramViewGroup, paramInt);
  }
  
  public boolean flagActionItems() {
    ArrayList<MenuItemImpl> arrayList;
    byte b1;
    int i1;
    boolean bool2;
    ActionMenuPresenter actionMenuPresenter = this;
    if (actionMenuPresenter.mMenu != null) {
      arrayList = actionMenuPresenter.mMenu.getVisibleItems();
      b1 = arrayList.size();
    } else {
      arrayList = null;
      b1 = 0;
    } 
    int i = actionMenuPresenter.mMaxItems;
    int j = actionMenuPresenter.mActionItemWidthLimit;
    int k = View.MeasureSpec.makeMeasureSpec(0, 0);
    ViewGroup viewGroup = (ViewGroup)actionMenuPresenter.mMenuView;
    int m = i;
    byte b2 = 0;
    byte b3 = 0;
    boolean bool1 = false;
    byte b4 = 0;
    while (b2 < b1) {
      MenuItemImpl menuItemImpl = arrayList.get(b2);
      if (menuItemImpl.requiresActionButton()) {
        b3++;
      } else if (menuItemImpl.requestsActionButton()) {
        b4++;
      } else {
        bool1 = true;
      } 
      if (actionMenuPresenter.mExpandedActionViewsExclusive && menuItemImpl.isActionViewExpanded())
        m = 0; 
      b2++;
    } 
    if (actionMenuPresenter.mReserveOverflow && (bool1 || b4 + b3 > m))
      m--; 
    int n = m - b3;
    SparseBooleanArray sparseBooleanArray = actionMenuPresenter.mActionButtonGroups;
    sparseBooleanArray.clear();
    if (actionMenuPresenter.mStrictWidthLimit) {
      i1 = j / actionMenuPresenter.mMinCellSize;
      int i4 = j % actionMenuPresenter.mMinCellSize;
      bool2 = actionMenuPresenter.mMinCellSize + i4 / i1;
    } else {
      i1 = 0;
      bool2 = false;
    } 
    int i2 = j;
    byte b5 = 0;
    int i3 = 0;
    while (b5 < b1) {
      byte b;
      MenuItemImpl menuItemImpl = arrayList.get(b5);
      if (menuItemImpl.requiresActionButton()) {
        boolean bool;
        View view = actionMenuPresenter.getItemView(menuItemImpl, actionMenuPresenter.mScrapActionButtonView, viewGroup);
        if (actionMenuPresenter.mScrapActionButtonView == null)
          actionMenuPresenter.mScrapActionButtonView = view; 
        if (actionMenuPresenter.mStrictWidthLimit) {
          i1 -= ActionMenuView.a(view, bool2, i1, k, 0);
        } else {
          view.measure(k, k);
        } 
        int i4 = view.getMeasuredWidth();
        i2 -= i4;
        if (i3)
          i4 = i3; 
        int i5 = menuItemImpl.getGroupId();
        if (i5 != 0) {
          bool = true;
          sparseBooleanArray.put(i5, bool);
        } else {
          bool = true;
        } 
        menuItemImpl.setIsActionButton(bool);
        b = b1;
        i3 = i4;
      } else if (menuItemImpl.requestsActionButton()) {
        int i5;
        int i4 = menuItemImpl.getGroupId();
        boolean bool = sparseBooleanArray.get(i4);
        if ((n > 0 || bool) && i2 > 0 && (!actionMenuPresenter.mStrictWidthLimit || i1 > 0)) {
          i5 = 1;
        } else {
          i5 = 0;
        } 
        if (i5) {
          int i6 = i5;
          View view = actionMenuPresenter.getItemView(menuItemImpl, actionMenuPresenter.mScrapActionButtonView, viewGroup);
          b = b1;
          if (actionMenuPresenter.mScrapActionButtonView == null)
            actionMenuPresenter.mScrapActionButtonView = view; 
          if (actionMenuPresenter.mStrictWidthLimit) {
            int i8 = ActionMenuView.a(view, bool2, i1, k, 0);
            i1 -= i8;
            if (i8 == 0)
              i6 = 0; 
          } else {
            view.measure(k, k);
          } 
          int i7 = view.getMeasuredWidth();
          i2 -= i7;
          if (i3 == 0)
            i3 = i7; 
          if (actionMenuPresenter.mStrictWidthLimit) {
            byte b6;
            if (i2 >= 0) {
              b6 = 1;
            } else {
              b6 = 0;
            } 
            i5 = i6 & b6;
          } else {
            byte b6;
            if (i2 + i3 > 0) {
              b6 = 1;
            } else {
              b6 = 0;
            } 
            i5 = i6 & b6;
          } 
        } else {
          b = b1;
        } 
        if (i5 != 0 && i4 != 0) {
          sparseBooleanArray.put(i4, true);
        } else if (bool) {
          sparseBooleanArray.put(i4, false);
          for (byte b6 = 0; b6 < b5; b6++) {
            MenuItemImpl menuItemImpl1 = arrayList.get(b6);
            if (menuItemImpl1.getGroupId() == i4) {
              if (menuItemImpl1.isActionButton())
                n++; 
              menuItemImpl1.setIsActionButton(false);
            } 
          } 
        } 
        if (i5 != 0)
          n--; 
        menuItemImpl.setIsActionButton(i5);
      } else {
        b = b1;
        menuItemImpl.setIsActionButton(false);
      } 
      b5++;
      b1 = b;
      actionMenuPresenter = this;
    } 
    return true;
  }
  
  public View getItemView(MenuItemImpl paramMenuItemImpl, View paramView, ViewGroup paramViewGroup) {
    boolean bool;
    View view = paramMenuItemImpl.getActionView();
    if (view == null || paramMenuItemImpl.hasCollapsibleActionView())
      view = super.getItemView(paramMenuItemImpl, paramView, paramViewGroup); 
    if (paramMenuItemImpl.isActionViewExpanded()) {
      bool = true;
    } else {
      bool = false;
    } 
    view.setVisibility(bool);
    ActionMenuView actionMenuView = (ActionMenuView)paramViewGroup;
    ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
    if (!actionMenuView.checkLayoutParams(layoutParams))
      view.setLayoutParams((ViewGroup.LayoutParams)actionMenuView.generateLayoutParams(layoutParams)); 
    return view;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    MenuView menuView1 = this.mMenuView;
    MenuView menuView2 = super.getMenuView(paramViewGroup);
    if (menuView1 != menuView2)
      ((ActionMenuView)menuView2).setPresenter(this); 
    return menuView2;
  }
  
  public Drawable getOverflowIcon() {
    return (this.a != null) ? this.a.getDrawable() : (this.mPendingOverflowIconSet ? this.mPendingOverflowIcon : null);
  }
  
  public boolean hideOverflowMenu() {
    if (this.d != null && this.mMenuView != null) {
      ((View)this.mMenuView).removeCallbacks(this.d);
      this.d = null;
      return true;
    } 
    OverflowPopup overflowPopup = this.b;
    if (overflowPopup != null) {
      overflowPopup.dismiss();
      return true;
    } 
    return false;
  }
  
  public boolean hideSubMenus() {
    if (this.c != null) {
      this.c.dismiss();
      return true;
    } 
    return false;
  }
  
  public void initForMenu(@NonNull Context paramContext, @Nullable MenuBuilder paramMenuBuilder) {
    super.initForMenu(paramContext, paramMenuBuilder);
    Resources resources = paramContext.getResources();
    ActionBarPolicy actionBarPolicy = ActionBarPolicy.get(paramContext);
    if (!this.mReserveOverflowSet)
      this.mReserveOverflow = actionBarPolicy.showsOverflowMenuButton(); 
    if (!this.mWidthLimitSet)
      this.mWidthLimit = actionBarPolicy.getEmbeddedMenuWidthLimit(); 
    if (!this.mMaxItemsSet)
      this.mMaxItems = actionBarPolicy.getMaxActionButtons(); 
    int i = this.mWidthLimit;
    if (this.mReserveOverflow) {
      if (this.a == null) {
        this.a = new OverflowMenuButton(this, this.mSystemContext);
        if (this.mPendingOverflowIconSet) {
          this.a.setImageDrawable(this.mPendingOverflowIcon);
          this.mPendingOverflowIcon = null;
          this.mPendingOverflowIconSet = false;
        } 
        int j = View.MeasureSpec.makeMeasureSpec(0, 0);
        this.a.measure(j, j);
      } 
      i -= this.a.getMeasuredWidth();
    } else {
      this.a = null;
    } 
    this.mActionItemWidthLimit = i;
    this.mMinCellSize = (int)(56.0F * (resources.getDisplayMetrics()).density);
    this.mScrapActionButtonView = null;
  }
  
  public boolean isOverflowMenuShowPending() {
    return (this.d != null || isOverflowMenuShowing());
  }
  
  public boolean isOverflowMenuShowing() {
    return (this.b != null && this.b.isShowing());
  }
  
  public boolean isOverflowReserved() {
    return this.mReserveOverflow;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    dismissPopupMenus();
    super.onCloseMenu(paramMenuBuilder, paramBoolean);
  }
  
  public void onConfigurationChanged(Configuration paramConfiguration) {
    if (!this.mMaxItemsSet)
      this.mMaxItems = ActionBarPolicy.get(this.mContext).getMaxActionButtons(); 
    if (this.mMenu != null)
      this.mMenu.onItemsChanged(true); 
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState))
      return; 
    SavedState savedState = (SavedState)paramParcelable;
    if (savedState.openSubMenuId > 0) {
      MenuItem menuItem = this.mMenu.findItem(savedState.openSubMenuId);
      if (menuItem != null)
        onSubMenuSelected((SubMenuBuilder)menuItem.getSubMenu()); 
    } 
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState();
    savedState.openSubMenuId = this.f;
    return savedState;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    boolean bool;
    if (!paramSubMenuBuilder.hasVisibleItems())
      return false; 
    SubMenuBuilder subMenuBuilder;
    for (subMenuBuilder = paramSubMenuBuilder; subMenuBuilder.getParentMenu() != this.mMenu; subMenuBuilder = (SubMenuBuilder)subMenuBuilder.getParentMenu());
    View view = findViewForItem(subMenuBuilder.getItem());
    if (view == null)
      return false; 
    this.f = paramSubMenuBuilder.getItem().getItemId();
    int i = paramSubMenuBuilder.size();
    byte b = 0;
    while (true) {
      bool = false;
      if (b < i) {
        MenuItem menuItem = paramSubMenuBuilder.getItem(b);
        if (menuItem.isVisible() && menuItem.getIcon() != null) {
          bool = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    this.c = new ActionButtonSubmenu(this, this.mContext, paramSubMenuBuilder, view);
    this.c.setForceShowIcon(bool);
    this.c.show();
    super.onSubMenuSelected(paramSubMenuBuilder);
    return true;
  }
  
  public void onSubUiVisibilityChanged(boolean paramBoolean) {
    if (paramBoolean) {
      super.onSubMenuSelected(null);
      return;
    } 
    if (this.mMenu != null)
      this.mMenu.close(false); 
  }
  
  public void setExpandedActionViewsExclusive(boolean paramBoolean) {
    this.mExpandedActionViewsExclusive = paramBoolean;
  }
  
  public void setItemLimit(int paramInt) {
    this.mMaxItems = paramInt;
    this.mMaxItemsSet = true;
  }
  
  public void setMenuView(ActionMenuView paramActionMenuView) {
    this.mMenuView = paramActionMenuView;
    paramActionMenuView.initialize(this.mMenu);
  }
  
  public void setOverflowIcon(Drawable paramDrawable) {
    if (this.a != null) {
      this.a.setImageDrawable(paramDrawable);
      return;
    } 
    this.mPendingOverflowIconSet = true;
    this.mPendingOverflowIcon = paramDrawable;
  }
  
  public void setReserveOverflow(boolean paramBoolean) {
    this.mReserveOverflow = paramBoolean;
    this.mReserveOverflowSet = true;
  }
  
  public void setWidthLimit(int paramInt, boolean paramBoolean) {
    this.mWidthLimit = paramInt;
    this.mStrictWidthLimit = paramBoolean;
    this.mWidthLimitSet = true;
  }
  
  public boolean shouldIncludeItem(int paramInt, MenuItemImpl paramMenuItemImpl) {
    return paramMenuItemImpl.isActionButton();
  }
  
  public boolean showOverflowMenu() {
    if (this.mReserveOverflow && !isOverflowMenuShowing() && this.mMenu != null && this.mMenuView != null && this.d == null && !this.mMenu.getNonActionItems().isEmpty()) {
      OverflowPopup overflowPopup = new OverflowPopup(this, this.mContext, this.mMenu, (View)this.a, true);
      this.d = new OpenOverflowRunnable(this, overflowPopup);
      ((View)this.mMenuView).post(this.d);
      super.onSubMenuSelected(null);
      return true;
    } 
    return false;
  }
  
  public void updateMenuView(boolean paramBoolean) {
    ArrayList<MenuItemImpl> arrayList;
    super.updateMenuView(paramBoolean);
    ((View)this.mMenuView).requestLayout();
    if (this.mMenu != null) {
      ArrayList<MenuItemImpl> arrayList1 = this.mMenu.getActionItems();
      int j = arrayList1.size();
      for (byte b = 0; b < j; b++) {
        ActionProvider actionProvider = ((MenuItemImpl)arrayList1.get(b)).getSupportActionProvider();
        if (actionProvider != null)
          actionProvider.setSubUiVisibilityListener(this); 
      } 
    } 
    if (this.mMenu != null) {
      arrayList = this.mMenu.getNonActionItems();
    } else {
      arrayList = null;
    } 
    boolean bool = this.mReserveOverflow;
    int i = 0;
    if (bool) {
      i = 0;
      if (arrayList != null) {
        int j = arrayList.size();
        if (j == 1) {
          i = true ^ ((MenuItemImpl)arrayList.get(0)).isActionViewExpanded();
        } else {
          i = 0;
          if (j > 0)
            i = 1; 
        } 
      } 
    } 
    if (i != 0) {
      if (this.a == null)
        this.a = new OverflowMenuButton(this, this.mSystemContext); 
      ViewGroup viewGroup = (ViewGroup)this.a.getParent();
      if (viewGroup != this.mMenuView) {
        if (viewGroup != null)
          viewGroup.removeView((View)this.a); 
        ActionMenuView actionMenuView = (ActionMenuView)this.mMenuView;
        actionMenuView.addView((View)this.a, (ViewGroup.LayoutParams)actionMenuView.generateOverflowButtonLayoutParams());
      } 
    } else if (this.a != null && this.a.getParent() == this.mMenuView) {
      ((ViewGroup)this.mMenuView).removeView((View)this.a);
    } 
    ((ActionMenuView)this.mMenuView).setOverflowReserved(this.mReserveOverflow);
  }
  
  private class ActionButtonSubmenu extends MenuPopupHelper {
    public ActionButtonSubmenu(ActionMenuPresenter this$0, Context param1Context, SubMenuBuilder param1SubMenuBuilder, View param1View) {
      super(param1Context, (MenuBuilder)param1SubMenuBuilder, param1View, false, R.attr.actionOverflowMenuStyle);
      if (!((MenuItemImpl)param1SubMenuBuilder.getItem()).isActionButton()) {
        ActionMenuPresenter.OverflowMenuButton overflowMenuButton;
        if (this$0.a == null) {
          View view = (View)ActionMenuPresenter.c(this$0);
        } else {
          overflowMenuButton = this$0.a;
        } 
        setAnchorView((View)overflowMenuButton);
      } 
      setPresenterCallback(this$0.e);
    }
    
    protected void onDismiss() {
      this.a.c = null;
      this.a.f = 0;
      super.onDismiss();
    }
  }
  
  private class ActionMenuPopupCallback extends ActionMenuItemView.PopupCallback {
    ActionMenuPopupCallback(ActionMenuPresenter this$0) {}
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((this.a.c != null) ? this.a.c.getPopup() : null);
    }
  }
  
  private class OpenOverflowRunnable implements Runnable {
    private ActionMenuPresenter.OverflowPopup mPopup;
    
    public OpenOverflowRunnable(ActionMenuPresenter this$0, ActionMenuPresenter.OverflowPopup param1OverflowPopup) {
      this.mPopup = param1OverflowPopup;
    }
    
    public void run() {
      if (ActionMenuPresenter.d(this.a) != null)
        ActionMenuPresenter.e(this.a).changeMenuMode(); 
      View view = (View)ActionMenuPresenter.f(this.a);
      if (view != null && view.getWindowToken() != null && this.mPopup.tryShow())
        this.a.b = this.mPopup; 
      this.a.d = null;
    }
  }
  
  private class OverflowMenuButton extends AppCompatImageView implements ActionMenuView.ActionMenuChildView {
    private final float[] mTempPts = new float[2];
    
    public OverflowMenuButton(ActionMenuPresenter this$0, Context param1Context) {
      super(param1Context, (AttributeSet)null, R.attr.actionOverflowButtonStyle);
      setClickable(true);
      setFocusable(true);
      setVisibility(0);
      setEnabled(true);
      TooltipCompat.setTooltipText((View)this, getContentDescription());
      setOnTouchListener(new ForwardingListener(this, (View)this, this$0) {
            public ShowableListMenu getPopup() {
              return (ShowableListMenu)((this.b.a.b == null) ? null : this.b.a.b.getPopup());
            }
            
            public boolean onForwardingStarted() {
              this.b.a.showOverflowMenu();
              return true;
            }
            
            public boolean onForwardingStopped() {
              if (this.b.a.d != null)
                return false; 
              this.b.a.hideOverflowMenu();
              return true;
            }
          });
    }
    
    public boolean needsDividerAfter() {
      return false;
    }
    
    public boolean needsDividerBefore() {
      return false;
    }
    
    public boolean performClick() {
      if (super.performClick())
        return true; 
      playSoundEffect(0);
      this.a.showOverflowMenu();
      return true;
    }
    
    protected boolean setFrame(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      boolean bool = super.setFrame(param1Int1, param1Int2, param1Int3, param1Int4);
      Drawable drawable1 = getDrawable();
      Drawable drawable2 = getBackground();
      if (drawable1 != null && drawable2 != null) {
        int i = getWidth();
        int j = getHeight();
        int k = Math.max(i, j) / 2;
        int m = getPaddingLeft() - getPaddingRight();
        int n = getPaddingTop() - getPaddingBottom();
        int i1 = (i + m) / 2;
        int i2 = (j + n) / 2;
        DrawableCompat.setHotspotBounds(drawable2, i1 - k, i2 - k, i1 + k, i2 + k);
      } 
      return bool;
    }
  }
  
  class null extends ForwardingListener {
    null(ActionMenuPresenter this$0, View param1View, ActionMenuPresenter param1ActionMenuPresenter) {
      super(param1View);
    }
    
    public ShowableListMenu getPopup() {
      return (ShowableListMenu)((this.b.a.b == null) ? null : this.b.a.b.getPopup());
    }
    
    public boolean onForwardingStarted() {
      this.b.a.showOverflowMenu();
      return true;
    }
    
    public boolean onForwardingStopped() {
      if (this.b.a.d != null)
        return false; 
      this.b.a.hideOverflowMenu();
      return true;
    }
  }
  
  private class OverflowPopup extends MenuPopupHelper {
    public OverflowPopup(ActionMenuPresenter this$0, Context param1Context, MenuBuilder param1MenuBuilder, View param1View, boolean param1Boolean) {
      super(param1Context, param1MenuBuilder, param1View, param1Boolean, R.attr.actionOverflowMenuStyle);
      setGravity(8388613);
      setPresenterCallback(this$0.e);
    }
    
    protected void onDismiss() {
      if (ActionMenuPresenter.a(this.a) != null)
        ActionMenuPresenter.b(this.a).close(); 
      this.a.b = null;
      super.onDismiss();
    }
  }
  
  private class PopupPresenterCallback implements MenuPresenter.Callback {
    PopupPresenterCallback(ActionMenuPresenter this$0) {}
    
    public void onCloseMenu(MenuBuilder param1MenuBuilder, boolean param1Boolean) {
      if (param1MenuBuilder instanceof SubMenuBuilder)
        param1MenuBuilder.getRootMenu().close(false); 
      MenuPresenter.Callback callback = this.a.getCallback();
      if (callback != null)
        callback.onCloseMenu(param1MenuBuilder, param1Boolean); 
    }
    
    public boolean onOpenSubMenu(MenuBuilder param1MenuBuilder) {
      if (param1MenuBuilder == null)
        return false; 
      this.a.f = ((SubMenuBuilder)param1MenuBuilder).getItem().getItemId();
      MenuPresenter.Callback callback = this.a.getCallback();
      boolean bool = false;
      if (callback != null)
        bool = callback.onOpenSubMenu(param1MenuBuilder); 
      return bool;
    }
  }
  
  private static class SavedState implements Parcelable {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public ActionMenuPresenter.SavedState createFromParcel(Parcel param2Parcel) {
          return new ActionMenuPresenter.SavedState(param2Parcel);
        }
        
        public ActionMenuPresenter.SavedState[] newArray(int param2Int) {
          return new ActionMenuPresenter.SavedState[param2Int];
        }
      };
    
    public int openSubMenuId;
    
    SavedState() {}
    
    SavedState(Parcel param1Parcel) {
      this.openSubMenuId = param1Parcel.readInt();
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.openSubMenuId);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public ActionMenuPresenter.SavedState createFromParcel(Parcel param1Parcel) {
      return new ActionMenuPresenter.SavedState(param1Parcel);
    }
    
    public ActionMenuPresenter.SavedState[] newArray(int param1Int) {
      return new ActionMenuPresenter.SavedState[param1Int];
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActionMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */