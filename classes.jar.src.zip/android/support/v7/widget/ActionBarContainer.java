package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.annotation.RestrictTo;
import android.support.v7.appcompat.R;
import android.util.AttributeSet;
import android.view.ActionMode;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ActionBarContainer extends FrameLayout {
  Drawable a;
  
  Drawable b;
  
  Drawable c;
  
  boolean d;
  
  boolean e;
  
  private View mActionBarView;
  
  private View mContextView;
  
  private int mHeight;
  
  private boolean mIsTransitioning;
  
  private View mTabContainer;
  
  public ActionBarContainer(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public ActionBarContainer(Context paramContext, AttributeSet paramAttributeSet) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: aload_2
    //   3: invokespecial <init> : (Landroid/content/Context;Landroid/util/AttributeSet;)V
    //   6: getstatic android/os/Build$VERSION.SDK_INT : I
    //   9: bipush #21
    //   11: if_icmplt -> 26
    //   14: new android/support/v7/widget/ActionBarBackgroundDrawableV21
    //   17: dup
    //   18: aload_0
    //   19: invokespecial <init> : (Landroid/support/v7/widget/ActionBarContainer;)V
    //   22: astore_3
    //   23: goto -> 35
    //   26: new android/support/v7/widget/ActionBarBackgroundDrawable
    //   29: dup
    //   30: aload_0
    //   31: invokespecial <init> : (Landroid/support/v7/widget/ActionBarContainer;)V
    //   34: astore_3
    //   35: aload_0
    //   36: aload_3
    //   37: invokestatic setBackground : (Landroid/view/View;Landroid/graphics/drawable/Drawable;)V
    //   40: aload_1
    //   41: aload_2
    //   42: getstatic android/support/v7/appcompat/R$styleable.ActionBar : [I
    //   45: invokevirtual obtainStyledAttributes : (Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   48: astore #4
    //   50: aload_0
    //   51: aload #4
    //   53: getstatic android/support/v7/appcompat/R$styleable.ActionBar_background : I
    //   56: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   59: putfield a : Landroid/graphics/drawable/Drawable;
    //   62: aload_0
    //   63: aload #4
    //   65: getstatic android/support/v7/appcompat/R$styleable.ActionBar_backgroundStacked : I
    //   68: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   71: putfield b : Landroid/graphics/drawable/Drawable;
    //   74: aload_0
    //   75: aload #4
    //   77: getstatic android/support/v7/appcompat/R$styleable.ActionBar_height : I
    //   80: iconst_m1
    //   81: invokevirtual getDimensionPixelSize : (II)I
    //   84: putfield mHeight : I
    //   87: aload_0
    //   88: invokevirtual getId : ()I
    //   91: getstatic android/support/v7/appcompat/R$id.split_action_bar : I
    //   94: if_icmpne -> 114
    //   97: aload_0
    //   98: iconst_1
    //   99: putfield d : Z
    //   102: aload_0
    //   103: aload #4
    //   105: getstatic android/support/v7/appcompat/R$styleable.ActionBar_backgroundSplit : I
    //   108: invokevirtual getDrawable : (I)Landroid/graphics/drawable/Drawable;
    //   111: putfield c : Landroid/graphics/drawable/Drawable;
    //   114: aload #4
    //   116: invokevirtual recycle : ()V
    //   119: aload_0
    //   120: getfield d : Z
    //   123: ifeq -> 146
    //   126: aload_0
    //   127: getfield c : Landroid/graphics/drawable/Drawable;
    //   130: astore #8
    //   132: iconst_0
    //   133: istore #6
    //   135: aload #8
    //   137: ifnonnull -> 177
    //   140: iconst_1
    //   141: istore #6
    //   143: goto -> 177
    //   146: aload_0
    //   147: getfield a : Landroid/graphics/drawable/Drawable;
    //   150: astore #5
    //   152: iconst_0
    //   153: istore #6
    //   155: aload #5
    //   157: ifnonnull -> 177
    //   160: aload_0
    //   161: getfield b : Landroid/graphics/drawable/Drawable;
    //   164: astore #7
    //   166: iconst_0
    //   167: istore #6
    //   169: aload #7
    //   171: ifnonnull -> 177
    //   174: goto -> 140
    //   177: aload_0
    //   178: iload #6
    //   180: invokevirtual setWillNotDraw : (Z)V
    //   183: return
  }
  
  private int getMeasuredHeightWithMargins(View paramView) {
    FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)paramView.getLayoutParams();
    return paramView.getMeasuredHeight() + layoutParams.topMargin + layoutParams.bottomMargin;
  }
  
  private boolean isCollapsed(View paramView) {
    return (paramView == null || paramView.getVisibility() == 8 || paramView.getMeasuredHeight() == 0);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    if (this.a != null && this.a.isStateful())
      this.a.setState(getDrawableState()); 
    if (this.b != null && this.b.isStateful())
      this.b.setState(getDrawableState()); 
    if (this.c != null && this.c.isStateful())
      this.c.setState(getDrawableState()); 
  }
  
  public View getTabContainer() {
    return this.mTabContainer;
  }
  
  public void jumpDrawablesToCurrentState() {
    super.jumpDrawablesToCurrentState();
    if (this.a != null)
      this.a.jumpToCurrentState(); 
    if (this.b != null)
      this.b.jumpToCurrentState(); 
    if (this.c != null)
      this.c.jumpToCurrentState(); 
  }
  
  public void onFinishInflate() {
    super.onFinishInflate();
    this.mActionBarView = findViewById(R.id.action_bar);
    this.mContextView = findViewById(R.id.action_context_bar);
  }
  
  public boolean onHoverEvent(MotionEvent paramMotionEvent) {
    super.onHoverEvent(paramMotionEvent);
    return true;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    return (this.mIsTransitioning || super.onInterceptTouchEvent(paramMotionEvent));
  }
  
  public void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    boolean bool2;
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    View view = this.mTabContainer;
    boolean bool1 = true;
    if (view != null && view.getVisibility() != 8) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (view != null && view.getVisibility() != 8) {
      int i = getMeasuredHeight();
      FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
      view.layout(paramInt1, i - view.getMeasuredHeight() - layoutParams.bottomMargin, paramInt3, i - layoutParams.bottomMargin);
    } 
    if (this.d) {
      if (this.c != null) {
        this.c.setBounds(0, 0, getMeasuredWidth(), getMeasuredHeight());
      } else {
        bool1 = false;
      } 
    } else {
      Drawable drawable = this.a;
      boolean bool = false;
      if (drawable != null) {
        if (this.mActionBarView.getVisibility() == 0) {
          this.a.setBounds(this.mActionBarView.getLeft(), this.mActionBarView.getTop(), this.mActionBarView.getRight(), this.mActionBarView.getBottom());
        } else if (this.mContextView != null && this.mContextView.getVisibility() == 0) {
          this.a.setBounds(this.mContextView.getLeft(), this.mContextView.getTop(), this.mContextView.getRight(), this.mContextView.getBottom());
        } else {
          this.a.setBounds(0, 0, 0, 0);
        } 
        bool = true;
      } 
      this.e = bool2;
      if (bool2 && this.b != null) {
        this.b.setBounds(view.getLeft(), view.getTop(), view.getRight(), view.getBottom());
      } else {
        bool1 = bool;
      } 
    } 
    if (bool1)
      invalidate(); 
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    if (this.mActionBarView == null && View.MeasureSpec.getMode(paramInt2) == Integer.MIN_VALUE && this.mHeight >= 0)
      paramInt2 = View.MeasureSpec.makeMeasureSpec(Math.min(this.mHeight, View.MeasureSpec.getSize(paramInt2)), -2147483648); 
    super.onMeasure(paramInt1, paramInt2);
    if (this.mActionBarView == null)
      return; 
    int i = View.MeasureSpec.getMode(paramInt2);
    if (this.mTabContainer != null && this.mTabContainer.getVisibility() != 8 && i != 1073741824) {
      byte b;
      int j;
      if (!isCollapsed(this.mActionBarView)) {
        b = getMeasuredHeightWithMargins(this.mActionBarView);
      } else if (!isCollapsed(this.mContextView)) {
        b = getMeasuredHeightWithMargins(this.mContextView);
      } else {
        b = 0;
      } 
      if (i == Integer.MIN_VALUE) {
        j = View.MeasureSpec.getSize(paramInt2);
      } else {
        j = Integer.MAX_VALUE;
      } 
      setMeasuredDimension(getMeasuredWidth(), Math.min(b + getMeasuredHeightWithMargins(this.mTabContainer), j));
    } 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    super.onTouchEvent(paramMotionEvent);
    return true;
  }
  
  public void setPrimaryBackground(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Landroid/graphics/drawable/Drawable;
    //   4: ifnull -> 23
    //   7: aload_0
    //   8: getfield a : Landroid/graphics/drawable/Drawable;
    //   11: aconst_null
    //   12: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   15: aload_0
    //   16: aload_0
    //   17: getfield a : Landroid/graphics/drawable/Drawable;
    //   20: invokevirtual unscheduleDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   23: aload_0
    //   24: aload_1
    //   25: putfield a : Landroid/graphics/drawable/Drawable;
    //   28: aload_1
    //   29: ifnull -> 79
    //   32: aload_1
    //   33: aload_0
    //   34: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   37: aload_0
    //   38: getfield mActionBarView : Landroid/view/View;
    //   41: ifnull -> 79
    //   44: aload_0
    //   45: getfield a : Landroid/graphics/drawable/Drawable;
    //   48: aload_0
    //   49: getfield mActionBarView : Landroid/view/View;
    //   52: invokevirtual getLeft : ()I
    //   55: aload_0
    //   56: getfield mActionBarView : Landroid/view/View;
    //   59: invokevirtual getTop : ()I
    //   62: aload_0
    //   63: getfield mActionBarView : Landroid/view/View;
    //   66: invokevirtual getRight : ()I
    //   69: aload_0
    //   70: getfield mActionBarView : Landroid/view/View;
    //   73: invokevirtual getBottom : ()I
    //   76: invokevirtual setBounds : (IIII)V
    //   79: aload_0
    //   80: getfield d : Z
    //   83: ifeq -> 104
    //   86: aload_0
    //   87: getfield c : Landroid/graphics/drawable/Drawable;
    //   90: astore #5
    //   92: iconst_0
    //   93: istore_3
    //   94: aload #5
    //   96: ifnonnull -> 131
    //   99: iconst_1
    //   100: istore_3
    //   101: goto -> 131
    //   104: aload_0
    //   105: getfield a : Landroid/graphics/drawable/Drawable;
    //   108: astore_2
    //   109: iconst_0
    //   110: istore_3
    //   111: aload_2
    //   112: ifnonnull -> 131
    //   115: aload_0
    //   116: getfield b : Landroid/graphics/drawable/Drawable;
    //   119: astore #4
    //   121: iconst_0
    //   122: istore_3
    //   123: aload #4
    //   125: ifnonnull -> 131
    //   128: goto -> 99
    //   131: aload_0
    //   132: iload_3
    //   133: invokevirtual setWillNotDraw : (Z)V
    //   136: aload_0
    //   137: invokevirtual invalidate : ()V
    //   140: return
  }
  
  public void setSplitBackground(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : Landroid/graphics/drawable/Drawable;
    //   4: ifnull -> 23
    //   7: aload_0
    //   8: getfield c : Landroid/graphics/drawable/Drawable;
    //   11: aconst_null
    //   12: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   15: aload_0
    //   16: aload_0
    //   17: getfield c : Landroid/graphics/drawable/Drawable;
    //   20: invokevirtual unscheduleDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   23: aload_0
    //   24: aload_1
    //   25: putfield c : Landroid/graphics/drawable/Drawable;
    //   28: aload_1
    //   29: ifnull -> 68
    //   32: aload_1
    //   33: aload_0
    //   34: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   37: aload_0
    //   38: getfield d : Z
    //   41: ifeq -> 68
    //   44: aload_0
    //   45: getfield c : Landroid/graphics/drawable/Drawable;
    //   48: ifnull -> 68
    //   51: aload_0
    //   52: getfield c : Landroid/graphics/drawable/Drawable;
    //   55: iconst_0
    //   56: iconst_0
    //   57: aload_0
    //   58: invokevirtual getMeasuredWidth : ()I
    //   61: aload_0
    //   62: invokevirtual getMeasuredHeight : ()I
    //   65: invokevirtual setBounds : (IIII)V
    //   68: aload_0
    //   69: getfield d : Z
    //   72: ifeq -> 93
    //   75: aload_0
    //   76: getfield c : Landroid/graphics/drawable/Drawable;
    //   79: astore #5
    //   81: iconst_0
    //   82: istore_3
    //   83: aload #5
    //   85: ifnonnull -> 120
    //   88: iconst_1
    //   89: istore_3
    //   90: goto -> 120
    //   93: aload_0
    //   94: getfield a : Landroid/graphics/drawable/Drawable;
    //   97: astore_2
    //   98: iconst_0
    //   99: istore_3
    //   100: aload_2
    //   101: ifnonnull -> 120
    //   104: aload_0
    //   105: getfield b : Landroid/graphics/drawable/Drawable;
    //   108: astore #4
    //   110: iconst_0
    //   111: istore_3
    //   112: aload #4
    //   114: ifnonnull -> 120
    //   117: goto -> 88
    //   120: aload_0
    //   121: iload_3
    //   122: invokevirtual setWillNotDraw : (Z)V
    //   125: aload_0
    //   126: invokevirtual invalidate : ()V
    //   129: return
  }
  
  public void setStackedBackground(Drawable paramDrawable) {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Landroid/graphics/drawable/Drawable;
    //   4: ifnull -> 23
    //   7: aload_0
    //   8: getfield b : Landroid/graphics/drawable/Drawable;
    //   11: aconst_null
    //   12: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   15: aload_0
    //   16: aload_0
    //   17: getfield b : Landroid/graphics/drawable/Drawable;
    //   20: invokevirtual unscheduleDrawable : (Landroid/graphics/drawable/Drawable;)V
    //   23: aload_0
    //   24: aload_1
    //   25: putfield b : Landroid/graphics/drawable/Drawable;
    //   28: aload_1
    //   29: ifnull -> 86
    //   32: aload_1
    //   33: aload_0
    //   34: invokevirtual setCallback : (Landroid/graphics/drawable/Drawable$Callback;)V
    //   37: aload_0
    //   38: getfield e : Z
    //   41: ifeq -> 86
    //   44: aload_0
    //   45: getfield b : Landroid/graphics/drawable/Drawable;
    //   48: ifnull -> 86
    //   51: aload_0
    //   52: getfield b : Landroid/graphics/drawable/Drawable;
    //   55: aload_0
    //   56: getfield mTabContainer : Landroid/view/View;
    //   59: invokevirtual getLeft : ()I
    //   62: aload_0
    //   63: getfield mTabContainer : Landroid/view/View;
    //   66: invokevirtual getTop : ()I
    //   69: aload_0
    //   70: getfield mTabContainer : Landroid/view/View;
    //   73: invokevirtual getRight : ()I
    //   76: aload_0
    //   77: getfield mTabContainer : Landroid/view/View;
    //   80: invokevirtual getBottom : ()I
    //   83: invokevirtual setBounds : (IIII)V
    //   86: aload_0
    //   87: getfield d : Z
    //   90: ifeq -> 111
    //   93: aload_0
    //   94: getfield c : Landroid/graphics/drawable/Drawable;
    //   97: astore #5
    //   99: iconst_0
    //   100: istore_3
    //   101: aload #5
    //   103: ifnonnull -> 138
    //   106: iconst_1
    //   107: istore_3
    //   108: goto -> 138
    //   111: aload_0
    //   112: getfield a : Landroid/graphics/drawable/Drawable;
    //   115: astore_2
    //   116: iconst_0
    //   117: istore_3
    //   118: aload_2
    //   119: ifnonnull -> 138
    //   122: aload_0
    //   123: getfield b : Landroid/graphics/drawable/Drawable;
    //   126: astore #4
    //   128: iconst_0
    //   129: istore_3
    //   130: aload #4
    //   132: ifnonnull -> 138
    //   135: goto -> 106
    //   138: aload_0
    //   139: iload_3
    //   140: invokevirtual setWillNotDraw : (Z)V
    //   143: aload_0
    //   144: invokevirtual invalidate : ()V
    //   147: return
  }
  
  public void setTabContainer(ScrollingTabContainerView paramScrollingTabContainerView) {
    if (this.mTabContainer != null)
      removeView(this.mTabContainer); 
    this.mTabContainer = (View)paramScrollingTabContainerView;
    if (paramScrollingTabContainerView != null) {
      addView((View)paramScrollingTabContainerView);
      ViewGroup.LayoutParams layoutParams = paramScrollingTabContainerView.getLayoutParams();
      layoutParams.width = -1;
      layoutParams.height = -2;
      paramScrollingTabContainerView.setAllowCollapse(false);
    } 
  }
  
  public void setTransitioning(boolean paramBoolean) {
    int i;
    this.mIsTransitioning = paramBoolean;
    if (paramBoolean) {
      i = 393216;
    } else {
      i = 262144;
    } 
    setDescendantFocusability(i);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.a != null)
      this.a.setVisible(bool, false); 
    if (this.b != null)
      this.b.setVisible(bool, false); 
    if (this.c != null)
      this.c.setVisible(bool, false); 
  }
  
  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback) {
    return null;
  }
  
  public ActionMode startActionModeForChild(View paramView, ActionMode.Callback paramCallback, int paramInt) {
    return (paramInt != 0) ? super.startActionModeForChild(paramView, paramCallback, paramInt) : null;
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return ((paramDrawable == this.a && !this.d) || (paramDrawable == this.b && this.e) || (paramDrawable == this.c && this.d) || super.verifyDrawable(paramDrawable));
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\widget\ActionBarContainer.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */