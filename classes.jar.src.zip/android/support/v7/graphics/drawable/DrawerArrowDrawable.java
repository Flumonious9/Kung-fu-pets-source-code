package android.support.v7.graphics.drawable;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.FloatRange;
import android.support.annotation.RestrictTo;
import android.support.v7.appcompat.R;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class DrawerArrowDrawable extends Drawable {
  public static final int ARROW_DIRECTION_END = 3;
  
  public static final int ARROW_DIRECTION_LEFT = 0;
  
  public static final int ARROW_DIRECTION_RIGHT = 1;
  
  public static final int ARROW_DIRECTION_START = 2;
  
  private static final float ARROW_HEAD_ANGLE = (float)Math.toRadians(45.0D);
  
  private float mArrowHeadLength;
  
  private float mArrowShaftLength;
  
  private float mBarGap;
  
  private float mBarLength;
  
  private int mDirection = 2;
  
  private float mMaxCutForBarSize;
  
  private final Paint mPaint = new Paint();
  
  private final Path mPath = new Path();
  
  private float mProgress;
  
  private final int mSize;
  
  private boolean mSpin;
  
  private boolean mVerticalMirror = false;
  
  public DrawerArrowDrawable(Context paramContext) {
    this.mPaint.setStyle(Paint.Style.STROKE);
    this.mPaint.setStrokeJoin(Paint.Join.MITER);
    this.mPaint.setStrokeCap(Paint.Cap.BUTT);
    this.mPaint.setAntiAlias(true);
    TypedArray typedArray = paramContext.getTheme().obtainStyledAttributes(null, R.styleable.DrawerArrowToggle, R.attr.drawerArrowStyle, R.style.Base_Widget_AppCompat_DrawerArrowToggle);
    setColor(typedArray.getColor(R.styleable.DrawerArrowToggle_color, 0));
    setBarThickness(typedArray.getDimension(R.styleable.DrawerArrowToggle_thickness, 0.0F));
    setSpinEnabled(typedArray.getBoolean(R.styleable.DrawerArrowToggle_spinBars, true));
    setGapSize(Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_gapBetweenBars, 0.0F)));
    this.mSize = typedArray.getDimensionPixelSize(R.styleable.DrawerArrowToggle_drawableSize, 0);
    this.mBarLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_barLength, 0.0F));
    this.mArrowHeadLength = Math.round(typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowHeadLength, 0.0F));
    this.mArrowShaftLength = typedArray.getDimension(R.styleable.DrawerArrowToggle_arrowShaftLength, 0.0F);
    typedArray.recycle();
  }
  
  private static float lerp(float paramFloat1, float paramFloat2, float paramFloat3) {
    return paramFloat1 + paramFloat3 * (paramFloat2 - paramFloat1);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getBounds : ()Landroid/graphics/Rect;
    //   4: astore_2
    //   5: aload_0
    //   6: getfield mDirection : I
    //   9: istore_3
    //   10: iconst_1
    //   11: istore #4
    //   13: iload_3
    //   14: iconst_3
    //   15: if_icmpeq -> 66
    //   18: iconst_0
    //   19: istore #5
    //   21: iload_3
    //   22: tableswitch default -> 44, 0 -> 83, 1 -> 60
    //   44: aload_0
    //   45: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   48: istore #34
    //   50: iconst_0
    //   51: istore #5
    //   53: iload #34
    //   55: iload #4
    //   57: if_icmpne -> 83
    //   60: iconst_1
    //   61: istore #5
    //   63: goto -> 83
    //   66: aload_0
    //   67: invokestatic getLayoutDirection : (Landroid/graphics/drawable/Drawable;)I
    //   70: istore #35
    //   72: iconst_0
    //   73: istore #5
    //   75: iload #35
    //   77: ifne -> 83
    //   80: goto -> 60
    //   83: fconst_2
    //   84: aload_0
    //   85: getfield mArrowHeadLength : F
    //   88: aload_0
    //   89: getfield mArrowHeadLength : F
    //   92: fmul
    //   93: fmul
    //   94: f2d
    //   95: invokestatic sqrt : (D)D
    //   98: d2f
    //   99: fstore #6
    //   101: aload_0
    //   102: getfield mBarLength : F
    //   105: fload #6
    //   107: aload_0
    //   108: getfield mProgress : F
    //   111: invokestatic lerp : (FFF)F
    //   114: fstore #7
    //   116: aload_0
    //   117: getfield mBarLength : F
    //   120: aload_0
    //   121: getfield mArrowShaftLength : F
    //   124: aload_0
    //   125: getfield mProgress : F
    //   128: invokestatic lerp : (FFF)F
    //   131: fstore #8
    //   133: fconst_0
    //   134: aload_0
    //   135: getfield mMaxCutForBarSize : F
    //   138: aload_0
    //   139: getfield mProgress : F
    //   142: invokestatic lerp : (FFF)F
    //   145: invokestatic round : (F)I
    //   148: i2f
    //   149: fstore #9
    //   151: fconst_0
    //   152: getstatic android/support/v7/graphics/drawable/DrawerArrowDrawable.ARROW_HEAD_ANGLE : F
    //   155: aload_0
    //   156: getfield mProgress : F
    //   159: invokestatic lerp : (FFF)F
    //   162: fstore #10
    //   164: iload #5
    //   166: ifeq -> 175
    //   169: fconst_0
    //   170: fstore #11
    //   172: goto -> 179
    //   175: ldc -180.0
    //   177: fstore #11
    //   179: iload #5
    //   181: ifeq -> 191
    //   184: ldc 180.0
    //   186: fstore #12
    //   188: goto -> 194
    //   191: fconst_0
    //   192: fstore #12
    //   194: fload #11
    //   196: fload #12
    //   198: aload_0
    //   199: getfield mProgress : F
    //   202: invokestatic lerp : (FFF)F
    //   205: fstore #13
    //   207: fload #7
    //   209: f2d
    //   210: dstore #14
    //   212: fload #10
    //   214: f2d
    //   215: dstore #16
    //   217: dload #16
    //   219: invokestatic cos : (D)D
    //   222: dstore #18
    //   224: dload #14
    //   226: invokestatic isNaN : (D)Z
    //   229: pop
    //   230: dload #18
    //   232: dload #14
    //   234: dmul
    //   235: dstore #21
    //   237: iload #5
    //   239: istore #23
    //   241: dload #21
    //   243: invokestatic round : (D)J
    //   246: l2f
    //   247: fstore #24
    //   249: dload #16
    //   251: invokestatic sin : (D)D
    //   254: dstore #25
    //   256: dload #14
    //   258: invokestatic isNaN : (D)Z
    //   261: pop
    //   262: dload #14
    //   264: dload #25
    //   266: dmul
    //   267: invokestatic round : (D)J
    //   270: l2f
    //   271: fstore #28
    //   273: aload_0
    //   274: getfield mPath : Landroid/graphics/Path;
    //   277: invokevirtual rewind : ()V
    //   280: aload_0
    //   281: getfield mBarGap : F
    //   284: aload_0
    //   285: getfield mPaint : Landroid/graphics/Paint;
    //   288: invokevirtual getStrokeWidth : ()F
    //   291: fadd
    //   292: aload_0
    //   293: getfield mMaxCutForBarSize : F
    //   296: fneg
    //   297: aload_0
    //   298: getfield mProgress : F
    //   301: invokestatic lerp : (FFF)F
    //   304: fstore #29
    //   306: fload #8
    //   308: fneg
    //   309: fconst_2
    //   310: fdiv
    //   311: fstore #30
    //   313: aload_0
    //   314: getfield mPath : Landroid/graphics/Path;
    //   317: fload #30
    //   319: fload #9
    //   321: fadd
    //   322: fconst_0
    //   323: invokevirtual moveTo : (FF)V
    //   326: aload_0
    //   327: getfield mPath : Landroid/graphics/Path;
    //   330: fload #8
    //   332: fload #9
    //   334: fconst_2
    //   335: fmul
    //   336: fsub
    //   337: fconst_0
    //   338: invokevirtual rLineTo : (FF)V
    //   341: aload_0
    //   342: getfield mPath : Landroid/graphics/Path;
    //   345: fload #30
    //   347: fload #29
    //   349: invokevirtual moveTo : (FF)V
    //   352: aload_0
    //   353: getfield mPath : Landroid/graphics/Path;
    //   356: fload #24
    //   358: fload #28
    //   360: invokevirtual rLineTo : (FF)V
    //   363: aload_0
    //   364: getfield mPath : Landroid/graphics/Path;
    //   367: fload #30
    //   369: fload #29
    //   371: fneg
    //   372: invokevirtual moveTo : (FF)V
    //   375: aload_0
    //   376: getfield mPath : Landroid/graphics/Path;
    //   379: fload #24
    //   381: fload #28
    //   383: fneg
    //   384: invokevirtual rLineTo : (FF)V
    //   387: aload_0
    //   388: getfield mPath : Landroid/graphics/Path;
    //   391: invokevirtual close : ()V
    //   394: aload_1
    //   395: invokevirtual save : ()I
    //   398: pop
    //   399: aload_0
    //   400: getfield mPaint : Landroid/graphics/Paint;
    //   403: invokevirtual getStrokeWidth : ()F
    //   406: fstore #32
    //   408: iconst_2
    //   409: aload_2
    //   410: invokevirtual height : ()I
    //   413: i2f
    //   414: ldc_w 3.0
    //   417: fload #32
    //   419: fmul
    //   420: fsub
    //   421: fconst_2
    //   422: aload_0
    //   423: getfield mBarGap : F
    //   426: fmul
    //   427: fsub
    //   428: f2i
    //   429: iconst_4
    //   430: idiv
    //   431: imul
    //   432: i2f
    //   433: fload #32
    //   435: ldc_w 1.5
    //   438: fmul
    //   439: aload_0
    //   440: getfield mBarGap : F
    //   443: fadd
    //   444: fadd
    //   445: fstore #33
    //   447: aload_1
    //   448: aload_2
    //   449: invokevirtual centerX : ()I
    //   452: i2f
    //   453: fload #33
    //   455: invokevirtual translate : (FF)V
    //   458: aload_0
    //   459: getfield mSpin : Z
    //   462: ifeq -> 491
    //   465: iload #23
    //   467: aload_0
    //   468: getfield mVerticalMirror : Z
    //   471: ixor
    //   472: ifeq -> 478
    //   475: iconst_m1
    //   476: istore #4
    //   478: aload_1
    //   479: fload #13
    //   481: iload #4
    //   483: i2f
    //   484: fmul
    //   485: invokevirtual rotate : (F)V
    //   488: goto -> 502
    //   491: iload #23
    //   493: ifeq -> 502
    //   496: aload_1
    //   497: ldc 180.0
    //   499: invokevirtual rotate : (F)V
    //   502: aload_1
    //   503: aload_0
    //   504: getfield mPath : Landroid/graphics/Path;
    //   507: aload_0
    //   508: getfield mPaint : Landroid/graphics/Paint;
    //   511: invokevirtual drawPath : (Landroid/graphics/Path;Landroid/graphics/Paint;)V
    //   514: aload_1
    //   515: invokevirtual restore : ()V
    //   518: return
  }
  
  public float getArrowHeadLength() {
    return this.mArrowHeadLength;
  }
  
  public float getArrowShaftLength() {
    return this.mArrowShaftLength;
  }
  
  public float getBarLength() {
    return this.mBarLength;
  }
  
  public float getBarThickness() {
    return this.mPaint.getStrokeWidth();
  }
  
  @ColorInt
  public int getColor() {
    return this.mPaint.getColor();
  }
  
  public int getDirection() {
    return this.mDirection;
  }
  
  public float getGapSize() {
    return this.mBarGap;
  }
  
  public int getIntrinsicHeight() {
    return this.mSize;
  }
  
  public int getIntrinsicWidth() {
    return this.mSize;
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public final Paint getPaint() {
    return this.mPaint;
  }
  
  @FloatRange(from = 0.0D, to = 1.0D)
  public float getProgress() {
    return this.mProgress;
  }
  
  public boolean isSpinEnabled() {
    return this.mSpin;
  }
  
  public void setAlpha(int paramInt) {
    if (paramInt != this.mPaint.getAlpha()) {
      this.mPaint.setAlpha(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setArrowHeadLength(float paramFloat) {
    if (this.mArrowHeadLength != paramFloat) {
      this.mArrowHeadLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setArrowShaftLength(float paramFloat) {
    if (this.mArrowShaftLength != paramFloat) {
      this.mArrowShaftLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarLength(float paramFloat) {
    if (this.mBarLength != paramFloat) {
      this.mBarLength = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setBarThickness(float paramFloat) {
    if (this.mPaint.getStrokeWidth() != paramFloat) {
      this.mPaint.setStrokeWidth(paramFloat);
      double d1 = (paramFloat / 2.0F);
      double d2 = Math.cos(ARROW_HEAD_ANGLE);
      Double.isNaN(d1);
      this.mMaxCutForBarSize = (float)(d1 * d2);
      invalidateSelf();
    } 
  }
  
  public void setColor(@ColorInt int paramInt) {
    if (paramInt != this.mPaint.getColor()) {
      this.mPaint.setColor(paramInt);
      invalidateSelf();
    } 
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.mPaint.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  public void setDirection(int paramInt) {
    if (paramInt != this.mDirection) {
      this.mDirection = paramInt;
      invalidateSelf();
    } 
  }
  
  public void setGapSize(float paramFloat) {
    if (paramFloat != this.mBarGap) {
      this.mBarGap = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setProgress(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    if (this.mProgress != paramFloat) {
      this.mProgress = paramFloat;
      invalidateSelf();
    } 
  }
  
  public void setSpinEnabled(boolean paramBoolean) {
    if (this.mSpin != paramBoolean) {
      this.mSpin = paramBoolean;
      invalidateSelf();
    } 
  }
  
  public void setVerticalMirror(boolean paramBoolean) {
    if (this.mVerticalMirror != paramBoolean) {
      this.mVerticalMirror = paramBoolean;
      invalidateSelf();
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ArrowDirection {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\graphics\drawable\DrawerArrowDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */