package android.support.v7.view.menu;

import android.content.Context;
import android.graphics.Rect;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.HeaderViewListAdapter;
import android.widget.ListAdapter;
import android.widget.PopupWindow;

abstract class MenuPopup implements MenuPresenter, ShowableListMenu, AdapterView.OnItemClickListener {
  private Rect mEpicenterBounds;
  
  protected static int a(ListAdapter paramListAdapter, ViewGroup paramViewGroup, Context paramContext, int paramInt) {
    byte b = 0;
    int i = View.MeasureSpec.makeMeasureSpec(0, 0);
    int j = View.MeasureSpec.makeMeasureSpec(0, 0);
    int k = paramListAdapter.getCount();
    ViewGroup viewGroup = paramViewGroup;
    View view = null;
    int m = 0;
    int n = 0;
    while (b < k) {
      FrameLayout frameLayout;
      int i1 = paramListAdapter.getItemViewType(b);
      if (i1 != m) {
        view = null;
        m = i1;
      } 
      if (viewGroup == null)
        frameLayout = new FrameLayout(paramContext); 
      view = paramListAdapter.getView(b, view, (ViewGroup)frameLayout);
      view.measure(i, j);
      int i2 = view.getMeasuredWidth();
      if (i2 >= paramInt)
        return paramInt; 
      if (i2 > n)
        n = i2; 
      b++;
    } 
    return n;
  }
  
  protected static MenuAdapter a(ListAdapter paramListAdapter) {
    return (paramListAdapter instanceof HeaderViewListAdapter) ? (MenuAdapter)((HeaderViewListAdapter)paramListAdapter).getWrappedAdapter() : (MenuAdapter)paramListAdapter;
  }
  
  protected static boolean a(MenuBuilder paramMenuBuilder) {
    int i = paramMenuBuilder.size();
    for (byte b = 0; b < i; b++) {
      MenuItem menuItem = paramMenuBuilder.getItem(b);
      if (menuItem.isVisible() && menuItem.getIcon() != null)
        return true; 
    } 
    return false;
  }
  
  protected boolean a() {
    return true;
  }
  
  public abstract void addMenu(MenuBuilder paramMenuBuilder);
  
  public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl) {
    return false;
  }
  
  public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl) {
    return false;
  }
  
  public Rect getEpicenterBounds() {
    return this.mEpicenterBounds;
  }
  
  public int getId() {
    return 0;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    throw new UnsupportedOperationException("MenuPopups manage their own views");
  }
  
  public void initForMenu(@NonNull Context paramContext, @Nullable MenuBuilder paramMenuBuilder) {}
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    byte b;
    ListAdapter listAdapter = (ListAdapter)paramAdapterView.getAdapter();
    MenuBuilder menuBuilder = (a(listAdapter)).b;
    MenuItem menuItem = (MenuItem)listAdapter.getItem(paramInt);
    if (a()) {
      b = 0;
    } else {
      b = 4;
    } 
    menuBuilder.performItemAction(menuItem, this, b);
  }
  
  public abstract void setAnchorView(View paramView);
  
  public void setEpicenterBounds(Rect paramRect) {
    this.mEpicenterBounds = paramRect;
  }
  
  public abstract void setForceShowIcon(boolean paramBoolean);
  
  public abstract void setGravity(int paramInt);
  
  public abstract void setHorizontalOffset(int paramInt);
  
  public abstract void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener);
  
  public abstract void setShowTitle(boolean paramBoolean);
  
  public abstract void setVerticalOffset(int paramInt);
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\menu\MenuPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */