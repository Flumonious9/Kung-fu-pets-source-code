package android.support.v7.view.menu;

import android.content.Context;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.RestrictTo;
import android.support.v7.appcompat.R;
import android.util.SparseArray;
import android.view.ContextThemeWrapper;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListAdapter;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ListMenuPresenter implements MenuPresenter, AdapterView.OnItemClickListener {
  private static final String TAG = "ListMenuPresenter";
  
  public static final String VIEWS_TAG = "android:menu:list";
  
  Context a;
  
  LayoutInflater b;
  
  MenuBuilder c;
  
  ExpandedMenuView d;
  
  int e;
  
  int f;
  
  int g;
  
  MenuAdapter h;
  
  private MenuPresenter.Callback mCallback;
  
  private int mId;
  
  public ListMenuPresenter(int paramInt1, int paramInt2) {
    this.g = paramInt1;
    this.f = paramInt2;
  }
  
  public ListMenuPresenter(Context paramContext, int paramInt) {
    this(paramInt, 0);
    this.a = paramContext;
    this.b = LayoutInflater.from(this.a);
  }
  
  public boolean collapseItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl) {
    return false;
  }
  
  public boolean expandItemActionView(MenuBuilder paramMenuBuilder, MenuItemImpl paramMenuItemImpl) {
    return false;
  }
  
  public boolean flagActionItems() {
    return false;
  }
  
  public ListAdapter getAdapter() {
    if (this.h == null)
      this.h = new MenuAdapter(this); 
    return (ListAdapter)this.h;
  }
  
  public int getId() {
    return this.mId;
  }
  
  int getItemIndexOffset() {
    return this.e;
  }
  
  public MenuView getMenuView(ViewGroup paramViewGroup) {
    if (this.d == null) {
      this.d = (ExpandedMenuView)this.b.inflate(R.layout.abc_expanded_menu_layout, paramViewGroup, false);
      if (this.h == null)
        this.h = new MenuAdapter(this); 
      this.d.setAdapter((ListAdapter)this.h);
      this.d.setOnItemClickListener(this);
    } 
    return this.d;
  }
  
  public void initForMenu(Context paramContext, MenuBuilder paramMenuBuilder) {
    if (this.f != 0) {
      this.a = (Context)new ContextThemeWrapper(paramContext, this.f);
      this.b = LayoutInflater.from(this.a);
    } else if (this.a != null) {
      this.a = paramContext;
      if (this.b == null)
        this.b = LayoutInflater.from(this.a); 
    } 
    this.c = paramMenuBuilder;
    if (this.h != null)
      this.h.notifyDataSetChanged(); 
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (this.mCallback != null)
      this.mCallback.onCloseMenu(paramMenuBuilder, paramBoolean); 
  }
  
  public void onItemClick(AdapterView<?> paramAdapterView, View paramView, int paramInt, long paramLong) {
    this.c.performItemAction((MenuItem)this.h.getItem(paramInt), this, 0);
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    restoreHierarchyState((Bundle)paramParcelable);
  }
  
  public Parcelable onSaveInstanceState() {
    if (this.d == null)
      return null; 
    Bundle bundle = new Bundle();
    saveHierarchyState(bundle);
    return (Parcelable)bundle;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    if (!paramSubMenuBuilder.hasVisibleItems())
      return false; 
    (new MenuDialogHelper(paramSubMenuBuilder)).show(null);
    if (this.mCallback != null)
      this.mCallback.onOpenSubMenu(paramSubMenuBuilder); 
    return true;
  }
  
  public void restoreHierarchyState(Bundle paramBundle) {
    SparseArray sparseArray = paramBundle.getSparseParcelableArray("android:menu:list");
    if (sparseArray != null)
      this.d.restoreHierarchyState(sparseArray); 
  }
  
  public void saveHierarchyState(Bundle paramBundle) {
    SparseArray sparseArray = new SparseArray();
    if (this.d != null)
      this.d.saveHierarchyState(sparseArray); 
    paramBundle.putSparseParcelableArray("android:menu:list", sparseArray);
  }
  
  public void setCallback(MenuPresenter.Callback paramCallback) {
    this.mCallback = paramCallback;
  }
  
  public void setId(int paramInt) {
    this.mId = paramInt;
  }
  
  public void setItemIndexOffset(int paramInt) {
    this.e = paramInt;
    if (this.d != null)
      updateMenuView(false); 
  }
  
  public void updateMenuView(boolean paramBoolean) {
    if (this.h != null)
      this.h.notifyDataSetChanged(); 
  }
  
  private class MenuAdapter extends BaseAdapter {
    private int mExpandedIndex = -1;
    
    public MenuAdapter(ListMenuPresenter this$0) {
      a();
    }
    
    void a() {
      MenuItemImpl menuItemImpl = this.a.c.getExpandedItem();
      if (menuItemImpl != null) {
        ArrayList<MenuItemImpl> arrayList = this.a.c.getNonActionItems();
        int i = arrayList.size();
        for (byte b = 0; b < i; b++) {
          if ((MenuItemImpl)arrayList.get(b) == menuItemImpl) {
            this.mExpandedIndex = b;
            return;
          } 
        } 
      } 
      this.mExpandedIndex = -1;
    }
    
    public int getCount() {
      int i = this.a.c.getNonActionItems().size() - this.a.e;
      return (this.mExpandedIndex < 0) ? i : (i - 1);
    }
    
    public MenuItemImpl getItem(int param1Int) {
      ArrayList<MenuItemImpl> arrayList = this.a.c.getNonActionItems();
      int i = param1Int + this.a.e;
      if (this.mExpandedIndex >= 0 && i >= this.mExpandedIndex)
        i++; 
      return arrayList.get(i);
    }
    
    public long getItemId(int param1Int) {
      return param1Int;
    }
    
    public View getView(int param1Int, View param1View, ViewGroup param1ViewGroup) {
      if (param1View == null)
        param1View = this.a.b.inflate(this.a.g, param1ViewGroup, false); 
      ((MenuView.ItemView)param1View).initialize(getItem(param1Int), 0);
      return param1View;
    }
    
    public void notifyDataSetChanged() {
      a();
      super.notifyDataSetChanged();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\menu\ListMenuPresenter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */