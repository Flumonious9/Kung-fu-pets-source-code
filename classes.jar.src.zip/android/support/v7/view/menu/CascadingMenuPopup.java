package android.support.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Rect;
import android.os.Build;
import android.os.Handler;
import android.os.Parcelable;
import android.support.annotation.AttrRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.StyleRes;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v7.appcompat.R;
import android.support.v7.widget.MenuItemHoverListener;
import android.support.v7.widget.MenuPopupWindow;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

final class CascadingMenuPopup extends MenuPopup implements MenuPresenter, View.OnKeyListener, PopupWindow.OnDismissListener {
  final Handler a;
  
  final List<CascadingMenuInfo> b = new ArrayList<CascadingMenuInfo>();
  
  View c;
  
  boolean d;
  
  private View mAnchorView;
  
  private final View.OnAttachStateChangeListener mAttachStateChangeListener = new View.OnAttachStateChangeListener(this) {
      public void onViewAttachedToWindow(View param1View) {}
      
      public void onViewDetachedFromWindow(View param1View) {
        if (CascadingMenuPopup.a(this.a) != null) {
          if (!CascadingMenuPopup.a(this.a).isAlive())
            CascadingMenuPopup.a(this.a, param1View.getViewTreeObserver()); 
          CascadingMenuPopup.a(this.a).removeGlobalOnLayoutListener(CascadingMenuPopup.b(this.a));
        } 
        param1View.removeOnAttachStateChangeListener(this);
      }
    };
  
  private final Context mContext;
  
  private int mDropDownGravity = 0;
  
  private boolean mForceShowIcon;
  
  private final ViewTreeObserver.OnGlobalLayoutListener mGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener(this) {
      public void onGlobalLayout() {
        if (this.a.isShowing() && this.a.b.size() > 0 && !((CascadingMenuPopup.CascadingMenuInfo)this.a.b.get(0)).window.isModal()) {
          View view = this.a.c;
          if (view == null || !view.isShown()) {
            this.a.dismiss();
            return;
          } 
          Iterator<CascadingMenuPopup.CascadingMenuInfo> iterator = this.a.b.iterator();
          while (iterator.hasNext())
            ((CascadingMenuPopup.CascadingMenuInfo)iterator.next()).window.show(); 
        } 
      }
    };
  
  private boolean mHasXOffset;
  
  private boolean mHasYOffset;
  
  private int mLastPosition;
  
  private final MenuItemHoverListener mMenuItemHoverListener = new MenuItemHoverListener(this) {
      public void onItemHoverEnter(@NonNull MenuBuilder param1MenuBuilder, @NonNull MenuItem param1MenuItem) {
        // Byte code:
        //   0: aload_0
        //   1: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   4: getfield a : Landroid/os/Handler;
        //   7: aconst_null
        //   8: invokevirtual removeCallbacksAndMessages : (Ljava/lang/Object;)V
        //   11: aload_0
        //   12: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   15: getfield b : Ljava/util/List;
        //   18: invokeinterface size : ()I
        //   23: istore_3
        //   24: iconst_0
        //   25: istore #4
        //   27: iload #4
        //   29: iload_3
        //   30: if_icmpge -> 66
        //   33: aload_1
        //   34: aload_0
        //   35: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   38: getfield b : Ljava/util/List;
        //   41: iload #4
        //   43: invokeinterface get : (I)Ljava/lang/Object;
        //   48: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
        //   51: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
        //   54: if_acmpne -> 60
        //   57: goto -> 69
        //   60: iinc #4, 1
        //   63: goto -> 27
        //   66: iconst_m1
        //   67: istore #4
        //   69: iload #4
        //   71: iconst_m1
        //   72: if_icmpne -> 76
        //   75: return
        //   76: iload #4
        //   78: iconst_1
        //   79: iadd
        //   80: istore #5
        //   82: aload_0
        //   83: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   86: getfield b : Ljava/util/List;
        //   89: invokeinterface size : ()I
        //   94: istore #6
        //   96: aconst_null
        //   97: astore #7
        //   99: iload #5
        //   101: iload #6
        //   103: if_icmpge -> 125
        //   106: aload_0
        //   107: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   110: getfield b : Ljava/util/List;
        //   113: iload #5
        //   115: invokeinterface get : (I)Ljava/lang/Object;
        //   120: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
        //   123: astore #7
        //   125: new android/support/v7/view/menu/CascadingMenuPopup$3$1
        //   128: dup
        //   129: aload_0
        //   130: aload #7
        //   132: aload_2
        //   133: aload_1
        //   134: invokespecial <init> : (Landroid/support/v7/view/menu/CascadingMenuPopup$3;Landroid/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo;Landroid/view/MenuItem;Landroid/support/v7/view/menu/MenuBuilder;)V
        //   137: astore #8
        //   139: ldc2_w 200
        //   142: invokestatic uptimeMillis : ()J
        //   145: ladd
        //   146: lstore #9
        //   148: aload_0
        //   149: getfield a : Landroid/support/v7/view/menu/CascadingMenuPopup;
        //   152: getfield a : Landroid/os/Handler;
        //   155: aload #8
        //   157: aload_1
        //   158: lload #9
        //   160: invokevirtual postAtTime : (Ljava/lang/Runnable;Ljava/lang/Object;J)Z
        //   163: pop
        //   164: return
      }
      
      public void onItemHoverExit(@NonNull MenuBuilder param1MenuBuilder, @NonNull MenuItem param1MenuItem) {
        this.a.a.removeCallbacksAndMessages(param1MenuBuilder);
      }
    };
  
  private final int mMenuMaxWidth;
  
  private PopupWindow.OnDismissListener mOnDismissListener;
  
  private final boolean mOverflowOnly;
  
  private final List<MenuBuilder> mPendingMenus = new ArrayList<MenuBuilder>();
  
  private final int mPopupStyleAttr;
  
  private final int mPopupStyleRes;
  
  private MenuPresenter.Callback mPresenterCallback;
  
  private int mRawDropDownGravity = 0;
  
  private boolean mShowTitle;
  
  private ViewTreeObserver mTreeObserver;
  
  private int mXOffset;
  
  private int mYOffset;
  
  public CascadingMenuPopup(@NonNull Context paramContext, @NonNull View paramView, @AttrRes int paramInt1, @StyleRes int paramInt2, boolean paramBoolean) {
    this.mContext = paramContext;
    this.mAnchorView = paramView;
    this.mPopupStyleAttr = paramInt1;
    this.mPopupStyleRes = paramInt2;
    this.mOverflowOnly = paramBoolean;
    this.mForceShowIcon = false;
    this.mLastPosition = getInitialMenuPosition();
    Resources resources = paramContext.getResources();
    this.mMenuMaxWidth = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    this.a = new Handler();
  }
  
  private MenuPopupWindow createPopupWindow() {
    MenuPopupWindow menuPopupWindow = new MenuPopupWindow(this.mContext, null, this.mPopupStyleAttr, this.mPopupStyleRes);
    menuPopupWindow.setHoverListener(this.mMenuItemHoverListener);
    menuPopupWindow.setOnItemClickListener(this);
    menuPopupWindow.setOnDismissListener(this);
    menuPopupWindow.setAnchorView(this.mAnchorView);
    menuPopupWindow.setDropDownGravity(this.mDropDownGravity);
    menuPopupWindow.setModal(true);
    menuPopupWindow.setInputMethodMode(2);
    return menuPopupWindow;
  }
  
  private int findIndexOfAddedMenu(@NonNull MenuBuilder paramMenuBuilder) {
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      if (paramMenuBuilder == ((CascadingMenuInfo)this.b.get(b)).menu)
        return b; 
    } 
    return -1;
  }
  
  private MenuItem findMenuItemForSubmenu(@NonNull MenuBuilder paramMenuBuilder1, @NonNull MenuBuilder paramMenuBuilder2) {
    int i = paramMenuBuilder1.size();
    for (byte b = 0; b < i; b++) {
      MenuItem menuItem = paramMenuBuilder1.getItem(b);
      if (menuItem.hasSubMenu() && paramMenuBuilder2 == menuItem.getSubMenu())
        return menuItem; 
    } 
    return null;
  }
  
  @Nullable
  private View findParentViewForSubmenu(@NonNull CascadingMenuInfo paramCascadingMenuInfo, @NonNull MenuBuilder paramMenuBuilder) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
    //   5: aload_2
    //   6: invokespecial findMenuItemForSubmenu : (Landroid/support/v7/view/menu/MenuBuilder;Landroid/support/v7/view/menu/MenuBuilder;)Landroid/view/MenuItem;
    //   9: astore_3
    //   10: aload_3
    //   11: ifnonnull -> 16
    //   14: aconst_null
    //   15: areturn
    //   16: aload_1
    //   17: invokevirtual getListView : ()Landroid/widget/ListView;
    //   20: astore #4
    //   22: aload #4
    //   24: invokevirtual getAdapter : ()Landroid/widget/ListAdapter;
    //   27: astore #5
    //   29: aload #5
    //   31: instanceof android/widget/HeaderViewListAdapter
    //   34: istore #6
    //   36: iconst_0
    //   37: istore #7
    //   39: iload #6
    //   41: ifeq -> 71
    //   44: aload #5
    //   46: checkcast android/widget/HeaderViewListAdapter
    //   49: astore #12
    //   51: aload #12
    //   53: invokevirtual getHeadersCount : ()I
    //   56: istore #9
    //   58: aload #12
    //   60: invokevirtual getWrappedAdapter : ()Landroid/widget/ListAdapter;
    //   63: checkcast android/support/v7/view/menu/MenuAdapter
    //   66: astore #8
    //   68: goto -> 81
    //   71: aload #5
    //   73: checkcast android/support/v7/view/menu/MenuAdapter
    //   76: astore #8
    //   78: iconst_0
    //   79: istore #9
    //   81: aload #8
    //   83: invokevirtual getCount : ()I
    //   86: istore #10
    //   88: iload #7
    //   90: iload #10
    //   92: if_icmpge -> 115
    //   95: aload_3
    //   96: aload #8
    //   98: iload #7
    //   100: invokevirtual getItem : (I)Landroid/support/v7/view/menu/MenuItemImpl;
    //   103: if_acmpne -> 109
    //   106: goto -> 118
    //   109: iinc #7, 1
    //   112: goto -> 88
    //   115: iconst_m1
    //   116: istore #7
    //   118: iload #7
    //   120: iconst_m1
    //   121: if_icmpne -> 126
    //   124: aconst_null
    //   125: areturn
    //   126: iload #7
    //   128: iload #9
    //   130: iadd
    //   131: aload #4
    //   133: invokevirtual getFirstVisiblePosition : ()I
    //   136: isub
    //   137: istore #11
    //   139: iload #11
    //   141: iflt -> 164
    //   144: iload #11
    //   146: aload #4
    //   148: invokevirtual getChildCount : ()I
    //   151: if_icmplt -> 156
    //   154: aconst_null
    //   155: areturn
    //   156: aload #4
    //   158: iload #11
    //   160: invokevirtual getChildAt : (I)Landroid/view/View;
    //   163: areturn
    //   164: aconst_null
    //   165: areturn
  }
  
  private int getInitialMenuPosition() {
    int i = ViewCompat.getLayoutDirection(this.mAnchorView);
    byte b = 1;
    if (i == b)
      b = 0; 
    return b;
  }
  
  private int getNextMenuPosition(int paramInt) {
    ListView listView = ((CascadingMenuInfo)this.b.get(this.b.size() - 1)).getListView();
    int[] arrayOfInt = new int[2];
    listView.getLocationOnScreen(arrayOfInt);
    Rect rect = new Rect();
    this.c.getWindowVisibleDisplayFrame(rect);
    return (this.mLastPosition == 1) ? ((paramInt + arrayOfInt[0] + listView.getWidth() > rect.right) ? 0 : 1) : ((arrayOfInt[0] - paramInt < 0) ? 1 : 0);
  }
  
  private void showMenu(@NonNull MenuBuilder paramMenuBuilder) {
    Object object;
    View view;
    LayoutInflater layoutInflater = LayoutInflater.from(this.mContext);
    MenuAdapter menuAdapter = new MenuAdapter(paramMenuBuilder, layoutInflater, this.mOverflowOnly);
    if (!isShowing() && this.mForceShowIcon) {
      menuAdapter.setForceShowIcon(true);
    } else if (isShowing()) {
      menuAdapter.setForceShowIcon(MenuPopup.a(paramMenuBuilder));
    } 
    int i = a((ListAdapter)menuAdapter, null, this.mContext, this.mMenuMaxWidth);
    MenuPopupWindow menuPopupWindow = createPopupWindow();
    menuPopupWindow.setAdapter((ListAdapter)menuAdapter);
    menuPopupWindow.setContentWidth(i);
    menuPopupWindow.setDropDownGravity(this.mDropDownGravity);
    if (this.b.size() > 0) {
      object = this.b.get(this.b.size() - 1);
      view = findParentViewForSubmenu((CascadingMenuInfo)object, paramMenuBuilder);
    } else {
      object = null;
      view = null;
    } 
    if (view != null) {
      boolean bool;
      int k;
      int m;
      int n;
      menuPopupWindow.setTouchModal(false);
      menuPopupWindow.setEnterTransition(null);
      int j = getNextMenuPosition(i);
      if (j == 1) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mLastPosition = j;
      if (Build.VERSION.SDK_INT >= 26) {
        menuPopupWindow.setAnchorView(view);
        m = 0;
        k = 0;
      } else {
        int[] arrayOfInt1 = new int[2];
        this.mAnchorView.getLocationOnScreen(arrayOfInt1);
        int[] arrayOfInt2 = new int[2];
        view.getLocationOnScreen(arrayOfInt2);
        if ((0x7 & this.mDropDownGravity) == 5) {
          arrayOfInt1[0] = arrayOfInt1[0] + this.mAnchorView.getWidth();
          arrayOfInt2[0] = arrayOfInt2[0] + view.getWidth();
        } 
        k = arrayOfInt2[0] - arrayOfInt1[0];
        m = arrayOfInt2[1] - arrayOfInt1[1];
      } 
      if ((0x5 & this.mDropDownGravity) == 5) {
        if (bool) {
          n = k + i;
        } else {
          n = k - view.getWidth();
        } 
      } else if (bool) {
        n = k + view.getWidth();
      } else {
        n = k - i;
      } 
      menuPopupWindow.setHorizontalOffset(n);
      menuPopupWindow.setOverlapAnchor(true);
      menuPopupWindow.setVerticalOffset(m);
    } else {
      if (this.mHasXOffset)
        menuPopupWindow.setHorizontalOffset(this.mXOffset); 
      if (this.mHasYOffset)
        menuPopupWindow.setVerticalOffset(this.mYOffset); 
      menuPopupWindow.setEpicenterBounds(getEpicenterBounds());
    } 
    CascadingMenuInfo cascadingMenuInfo = new CascadingMenuInfo(menuPopupWindow, paramMenuBuilder, this.mLastPosition);
    this.b.add(cascadingMenuInfo);
    menuPopupWindow.show();
    ListView listView = menuPopupWindow.getListView();
    listView.setOnKeyListener(this);
    if (object == null && this.mShowTitle && paramMenuBuilder.getHeaderTitle() != null) {
      FrameLayout frameLayout = (FrameLayout)layoutInflater.inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)listView, false);
      TextView textView = (TextView)frameLayout.findViewById(16908310);
      frameLayout.setEnabled(false);
      textView.setText(paramMenuBuilder.getHeaderTitle());
      listView.addHeaderView((View)frameLayout, null, false);
      menuPopupWindow.show();
    } 
  }
  
  protected boolean a() {
    return false;
  }
  
  public void addMenu(MenuBuilder paramMenuBuilder) {
    paramMenuBuilder.addMenuPresenter(this, this.mContext);
    if (isShowing()) {
      showMenu(paramMenuBuilder);
      return;
    } 
    this.mPendingMenus.add(paramMenuBuilder);
  }
  
  public void dismiss() {
    int i = this.b.size();
    if (i > 0) {
      CascadingMenuInfo[] arrayOfCascadingMenuInfo = this.b.<CascadingMenuInfo>toArray(new CascadingMenuInfo[i]);
      for (int j = i - 1; j >= 0; j--) {
        CascadingMenuInfo cascadingMenuInfo = arrayOfCascadingMenuInfo[j];
        if (cascadingMenuInfo.window.isShowing())
          cascadingMenuInfo.window.dismiss(); 
      } 
    } 
  }
  
  public boolean flagActionItems() {
    return false;
  }
  
  public ListView getListView() {
    return this.b.isEmpty() ? null : ((CascadingMenuInfo)this.b.get(-1 + this.b.size())).getListView();
  }
  
  public boolean isShowing() {
    int i = this.b.size();
    boolean bool = false;
    if (i > 0) {
      boolean bool1 = ((CascadingMenuInfo)this.b.get(0)).window.isShowing();
      bool = false;
      if (bool1)
        bool = true; 
    } 
    return bool;
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    int i = findIndexOfAddedMenu(paramMenuBuilder);
    if (i < 0)
      return; 
    int j = i + 1;
    if (j < this.b.size())
      ((CascadingMenuInfo)this.b.get(j)).menu.close(false); 
    CascadingMenuInfo cascadingMenuInfo = this.b.remove(i);
    cascadingMenuInfo.menu.removeMenuPresenter(this);
    if (this.d) {
      cascadingMenuInfo.window.setExitTransition(null);
      cascadingMenuInfo.window.setAnimationStyle(0);
    } 
    cascadingMenuInfo.window.dismiss();
    int k = this.b.size();
    if (k > 0) {
      this.mLastPosition = ((CascadingMenuInfo)this.b.get(k - 1)).position;
    } else {
      this.mLastPosition = getInitialMenuPosition();
    } 
    if (k == 0) {
      dismiss();
      if (this.mPresenterCallback != null)
        this.mPresenterCallback.onCloseMenu(paramMenuBuilder, true); 
      if (this.mTreeObserver != null) {
        if (this.mTreeObserver.isAlive())
          this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener); 
        this.mTreeObserver = null;
      } 
      this.c.removeOnAttachStateChangeListener(this.mAttachStateChangeListener);
      this.mOnDismissListener.onDismiss();
      return;
    } 
    if (paramBoolean)
      ((CascadingMenuInfo)this.b.get(0)).menu.close(false); 
  }
  
  public void onDismiss() {
    // Byte code:
    //   0: aload_0
    //   1: getfield b : Ljava/util/List;
    //   4: invokeinterface size : ()I
    //   9: istore_1
    //   10: iconst_0
    //   11: istore_2
    //   12: iload_2
    //   13: iload_1
    //   14: if_icmpge -> 50
    //   17: aload_0
    //   18: getfield b : Ljava/util/List;
    //   21: iload_2
    //   22: invokeinterface get : (I)Ljava/lang/Object;
    //   27: checkcast android/support/v7/view/menu/CascadingMenuPopup$CascadingMenuInfo
    //   30: astore_3
    //   31: aload_3
    //   32: getfield window : Landroid/support/v7/widget/MenuPopupWindow;
    //   35: invokevirtual isShowing : ()Z
    //   38: ifne -> 44
    //   41: goto -> 52
    //   44: iinc #2, 1
    //   47: goto -> 12
    //   50: aconst_null
    //   51: astore_3
    //   52: aload_3
    //   53: ifnull -> 64
    //   56: aload_3
    //   57: getfield menu : Landroid/support/v7/view/menu/MenuBuilder;
    //   60: iconst_0
    //   61: invokevirtual close : (Z)V
    //   64: return
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {}
  
  public Parcelable onSaveInstanceState() {
    return null;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    for (CascadingMenuInfo cascadingMenuInfo : this.b) {
      if (paramSubMenuBuilder == cascadingMenuInfo.menu) {
        cascadingMenuInfo.getListView().requestFocus();
        return true;
      } 
    } 
    if (paramSubMenuBuilder.hasVisibleItems()) {
      addMenu(paramSubMenuBuilder);
      if (this.mPresenterCallback != null)
        this.mPresenterCallback.onOpenSubMenu(paramSubMenuBuilder); 
      return true;
    } 
    return false;
  }
  
  public void setAnchorView(@NonNull View paramView) {
    if (this.mAnchorView != paramView) {
      this.mAnchorView = paramView;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(this.mRawDropDownGravity, ViewCompat.getLayoutDirection(this.mAnchorView));
    } 
  }
  
  public void setCallback(MenuPresenter.Callback paramCallback) {
    this.mPresenterCallback = paramCallback;
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.mForceShowIcon = paramBoolean;
  }
  
  public void setGravity(int paramInt) {
    if (this.mRawDropDownGravity != paramInt) {
      this.mRawDropDownGravity = paramInt;
      this.mDropDownGravity = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection(this.mAnchorView));
    } 
  }
  
  public void setHorizontalOffset(int paramInt) {
    this.mHasXOffset = true;
    this.mXOffset = paramInt;
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.mOnDismissListener = paramOnDismissListener;
  }
  
  public void setShowTitle(boolean paramBoolean) {
    this.mShowTitle = paramBoolean;
  }
  
  public void setVerticalOffset(int paramInt) {
    this.mHasYOffset = true;
    this.mYOffset = paramInt;
  }
  
  public void show() {
    if (isShowing())
      return; 
    Iterator<MenuBuilder> iterator = this.mPendingMenus.iterator();
    while (iterator.hasNext())
      showMenu(iterator.next()); 
    this.mPendingMenus.clear();
    this.c = this.mAnchorView;
    if (this.c != null) {
      boolean bool;
      if (this.mTreeObserver == null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mTreeObserver = this.c.getViewTreeObserver();
      if (bool)
        this.mTreeObserver.addOnGlobalLayoutListener(this.mGlobalLayoutListener); 
      this.c.addOnAttachStateChangeListener(this.mAttachStateChangeListener);
    } 
  }
  
  public void updateMenuView(boolean paramBoolean) {
    Iterator<CascadingMenuInfo> iterator = this.b.iterator();
    while (iterator.hasNext())
      a(((CascadingMenuInfo)iterator.next()).getListView().getAdapter()).notifyDataSetChanged(); 
  }
  
  private static class CascadingMenuInfo {
    public final MenuBuilder menu;
    
    public final int position;
    
    public final MenuPopupWindow window;
    
    public CascadingMenuInfo(@NonNull MenuPopupWindow param1MenuPopupWindow, @NonNull MenuBuilder param1MenuBuilder, int param1Int) {
      this.window = param1MenuPopupWindow;
      this.menu = param1MenuBuilder;
      this.position = param1Int;
    }
    
    public ListView getListView() {
      return this.window.getListView();
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  public static @interface HorizPosition {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\menu\CascadingMenuPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */