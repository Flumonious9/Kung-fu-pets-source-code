package android.support.v7.view.menu;

import android.support.annotation.RestrictTo;
import android.support.v7.appcompat.R;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class MenuAdapter extends BaseAdapter {
  static final int a = R.layout.abc_popup_menu_item_layout;
  
  MenuBuilder b;
  
  private int mExpandedIndex = -1;
  
  private boolean mForceShowIcon;
  
  private final LayoutInflater mInflater;
  
  private final boolean mOverflowOnly;
  
  public MenuAdapter(MenuBuilder paramMenuBuilder, LayoutInflater paramLayoutInflater, boolean paramBoolean) {
    this.mOverflowOnly = paramBoolean;
    this.mInflater = paramLayoutInflater;
    this.b = paramMenuBuilder;
    a();
  }
  
  void a() {
    MenuItemImpl menuItemImpl = this.b.getExpandedItem();
    if (menuItemImpl != null) {
      ArrayList<MenuItemImpl> arrayList = this.b.getNonActionItems();
      int i = arrayList.size();
      for (byte b = 0; b < i; b++) {
        if ((MenuItemImpl)arrayList.get(b) == menuItemImpl) {
          this.mExpandedIndex = b;
          return;
        } 
      } 
    } 
    this.mExpandedIndex = -1;
  }
  
  public MenuBuilder getAdapterMenu() {
    return this.b;
  }
  
  public int getCount() {
    ArrayList<MenuItemImpl> arrayList;
    if (this.mOverflowOnly) {
      arrayList = this.b.getNonActionItems();
    } else {
      arrayList = this.b.getVisibleItems();
    } 
    return (this.mExpandedIndex < 0) ? arrayList.size() : (-1 + arrayList.size());
  }
  
  public boolean getForceShowIcon() {
    return this.mForceShowIcon;
  }
  
  public MenuItemImpl getItem(int paramInt) {
    ArrayList<MenuItemImpl> arrayList;
    if (this.mOverflowOnly) {
      arrayList = this.b.getNonActionItems();
    } else {
      arrayList = this.b.getVisibleItems();
    } 
    if (this.mExpandedIndex >= 0 && paramInt >= this.mExpandedIndex)
      paramInt++; 
    return arrayList.get(paramInt);
  }
  
  public long getItemId(int paramInt) {
    return paramInt;
  }
  
  public View getView(int paramInt, View paramView, ViewGroup paramViewGroup) {
    if (paramView == null)
      paramView = this.mInflater.inflate(a, paramViewGroup, false); 
    MenuView.ItemView itemView = (MenuView.ItemView)paramView;
    if (this.mForceShowIcon)
      ((ListMenuItemView)paramView).setForceShowIcon(true); 
    itemView.initialize(getItem(paramInt), 0);
    return paramView;
  }
  
  public void notifyDataSetChanged() {
    a();
    super.notifyDataSetChanged();
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.mForceShowIcon = paramBoolean;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\menu\MenuAdapter.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */