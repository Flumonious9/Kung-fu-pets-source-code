package android.support.v7.view.menu;

import android.content.Context;
import android.content.res.Resources;
import android.os.Parcelable;
import android.support.v7.appcompat.R;
import android.support.v7.widget.MenuPopupWindow;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.AdapterView;
import android.widget.FrameLayout;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

final class StandardMenuPopup extends MenuPopup implements MenuPresenter, View.OnKeyListener, AdapterView.OnItemClickListener, PopupWindow.OnDismissListener {
  final MenuPopupWindow a;
  
  View b;
  
  private final MenuAdapter mAdapter;
  
  private View mAnchorView;
  
  private final View.OnAttachStateChangeListener mAttachStateChangeListener = new View.OnAttachStateChangeListener(this) {
      public void onViewAttachedToWindow(View param1View) {}
      
      public void onViewDetachedFromWindow(View param1View) {
        if (StandardMenuPopup.a(this.a) != null) {
          if (!StandardMenuPopup.a(this.a).isAlive())
            StandardMenuPopup.a(this.a, param1View.getViewTreeObserver()); 
          StandardMenuPopup.a(this.a).removeGlobalOnLayoutListener(StandardMenuPopup.b(this.a));
        } 
        param1View.removeOnAttachStateChangeListener(this);
      }
    };
  
  private int mContentWidth;
  
  private final Context mContext;
  
  private int mDropDownGravity = 0;
  
  private final ViewTreeObserver.OnGlobalLayoutListener mGlobalLayoutListener = new ViewTreeObserver.OnGlobalLayoutListener(this) {
      public void onGlobalLayout() {
        if (this.a.isShowing() && !this.a.a.isModal()) {
          View view = this.a.b;
          if (view == null || !view.isShown()) {
            this.a.dismiss();
            return;
          } 
          this.a.a.show();
          return;
        } 
      }
    };
  
  private boolean mHasContentWidth;
  
  private final MenuBuilder mMenu;
  
  private PopupWindow.OnDismissListener mOnDismissListener;
  
  private final boolean mOverflowOnly;
  
  private final int mPopupMaxWidth;
  
  private final int mPopupStyleAttr;
  
  private final int mPopupStyleRes;
  
  private MenuPresenter.Callback mPresenterCallback;
  
  private boolean mShowTitle;
  
  private ViewTreeObserver mTreeObserver;
  
  private boolean mWasDismissed;
  
  public StandardMenuPopup(Context paramContext, MenuBuilder paramMenuBuilder, View paramView, int paramInt1, int paramInt2, boolean paramBoolean) {
    this.mContext = paramContext;
    this.mMenu = paramMenuBuilder;
    this.mOverflowOnly = paramBoolean;
    this.mAdapter = new MenuAdapter(paramMenuBuilder, LayoutInflater.from(paramContext), this.mOverflowOnly);
    this.mPopupStyleAttr = paramInt1;
    this.mPopupStyleRes = paramInt2;
    Resources resources = paramContext.getResources();
    this.mPopupMaxWidth = Math.max((resources.getDisplayMetrics()).widthPixels / 2, resources.getDimensionPixelSize(R.dimen.abc_config_prefDialogWidth));
    this.mAnchorView = paramView;
    this.a = new MenuPopupWindow(this.mContext, null, this.mPopupStyleAttr, this.mPopupStyleRes);
    paramMenuBuilder.addMenuPresenter(this, paramContext);
  }
  
  private boolean tryShow() {
    if (isShowing())
      return true; 
    if (!this.mWasDismissed) {
      boolean bool;
      if (this.mAnchorView == null)
        return false; 
      this.b = this.mAnchorView;
      this.a.setOnDismissListener(this);
      this.a.setOnItemClickListener(this);
      this.a.setModal(true);
      View view = this.b;
      if (this.mTreeObserver == null) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mTreeObserver = view.getViewTreeObserver();
      if (bool)
        this.mTreeObserver.addOnGlobalLayoutListener(this.mGlobalLayoutListener); 
      view.addOnAttachStateChangeListener(this.mAttachStateChangeListener);
      this.a.setAnchorView(view);
      this.a.setDropDownGravity(this.mDropDownGravity);
      if (!this.mHasContentWidth) {
        this.mContentWidth = a((ListAdapter)this.mAdapter, null, this.mContext, this.mPopupMaxWidth);
        this.mHasContentWidth = true;
      } 
      this.a.setContentWidth(this.mContentWidth);
      this.a.setInputMethodMode(2);
      this.a.setEpicenterBounds(getEpicenterBounds());
      this.a.show();
      ListView listView = this.a.getListView();
      listView.setOnKeyListener(this);
      if (this.mShowTitle && this.mMenu.getHeaderTitle() != null) {
        FrameLayout frameLayout = (FrameLayout)LayoutInflater.from(this.mContext).inflate(R.layout.abc_popup_menu_header_item_layout, (ViewGroup)listView, false);
        TextView textView = (TextView)frameLayout.findViewById(16908310);
        if (textView != null)
          textView.setText(this.mMenu.getHeaderTitle()); 
        frameLayout.setEnabled(false);
        listView.addHeaderView((View)frameLayout, null, false);
      } 
      this.a.setAdapter((ListAdapter)this.mAdapter);
      this.a.show();
      return true;
    } 
    return false;
  }
  
  public void addMenu(MenuBuilder paramMenuBuilder) {}
  
  public void dismiss() {
    if (isShowing())
      this.a.dismiss(); 
  }
  
  public boolean flagActionItems() {
    return false;
  }
  
  public ListView getListView() {
    return this.a.getListView();
  }
  
  public boolean isShowing() {
    return (!this.mWasDismissed && this.a.isShowing());
  }
  
  public void onCloseMenu(MenuBuilder paramMenuBuilder, boolean paramBoolean) {
    if (paramMenuBuilder != this.mMenu)
      return; 
    dismiss();
    if (this.mPresenterCallback != null)
      this.mPresenterCallback.onCloseMenu(paramMenuBuilder, paramBoolean); 
  }
  
  public void onDismiss() {
    this.mWasDismissed = true;
    this.mMenu.close();
    if (this.mTreeObserver != null) {
      if (!this.mTreeObserver.isAlive())
        this.mTreeObserver = this.b.getViewTreeObserver(); 
      this.mTreeObserver.removeGlobalOnLayoutListener(this.mGlobalLayoutListener);
      this.mTreeObserver = null;
    } 
    this.b.removeOnAttachStateChangeListener(this.mAttachStateChangeListener);
    if (this.mOnDismissListener != null)
      this.mOnDismissListener.onDismiss(); 
  }
  
  public boolean onKey(View paramView, int paramInt, KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 1 && paramInt == 82) {
      dismiss();
      return true;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {}
  
  public Parcelable onSaveInstanceState() {
    return null;
  }
  
  public boolean onSubMenuSelected(SubMenuBuilder paramSubMenuBuilder) {
    if (paramSubMenuBuilder.hasVisibleItems()) {
      MenuPopupHelper menuPopupHelper = new MenuPopupHelper(this.mContext, paramSubMenuBuilder, this.b, this.mOverflowOnly, this.mPopupStyleAttr, this.mPopupStyleRes);
      menuPopupHelper.setPresenterCallback(this.mPresenterCallback);
      menuPopupHelper.setForceShowIcon(MenuPopup.a(paramSubMenuBuilder));
      menuPopupHelper.setGravity(this.mDropDownGravity);
      menuPopupHelper.setOnDismissListener(this.mOnDismissListener);
      this.mOnDismissListener = null;
      this.mMenu.close(false);
      if (menuPopupHelper.tryShow(this.a.getHorizontalOffset(), this.a.getVerticalOffset())) {
        if (this.mPresenterCallback != null)
          this.mPresenterCallback.onOpenSubMenu(paramSubMenuBuilder); 
        return true;
      } 
    } 
    return false;
  }
  
  public void setAnchorView(View paramView) {
    this.mAnchorView = paramView;
  }
  
  public void setCallback(MenuPresenter.Callback paramCallback) {
    this.mPresenterCallback = paramCallback;
  }
  
  public void setForceShowIcon(boolean paramBoolean) {
    this.mAdapter.setForceShowIcon(paramBoolean);
  }
  
  public void setGravity(int paramInt) {
    this.mDropDownGravity = paramInt;
  }
  
  public void setHorizontalOffset(int paramInt) {
    this.a.setHorizontalOffset(paramInt);
  }
  
  public void setOnDismissListener(PopupWindow.OnDismissListener paramOnDismissListener) {
    this.mOnDismissListener = paramOnDismissListener;
  }
  
  public void setShowTitle(boolean paramBoolean) {
    this.mShowTitle = paramBoolean;
  }
  
  public void setVerticalOffset(int paramInt) {
    this.a.setVerticalOffset(paramInt);
  }
  
  public void show() {
    if (tryShow())
      return; 
    throw new IllegalStateException("StandardMenuPopup cannot be used without an anchor");
  }
  
  public void updateMenuView(boolean paramBoolean) {
    this.mHasContentWidth = false;
    if (this.mAdapter != null)
      this.mAdapter.notifyDataSetChanged(); 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\menu\StandardMenuPopup.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */