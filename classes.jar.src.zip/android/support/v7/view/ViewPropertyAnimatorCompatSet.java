package android.support.v7.view;

import android.support.annotation.RestrictTo;
import android.support.v4.view.ViewPropertyAnimatorCompat;
import android.support.v4.view.ViewPropertyAnimatorListener;
import android.support.v4.view.ViewPropertyAnimatorListenerAdapter;
import android.view.View;
import android.view.animation.Interpolator;
import java.util.ArrayList;
import java.util.Iterator;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ViewPropertyAnimatorCompatSet {
  final ArrayList<ViewPropertyAnimatorCompat> a = new ArrayList<ViewPropertyAnimatorCompat>();
  
  ViewPropertyAnimatorListener b;
  
  private long mDuration = -1L;
  
  private Interpolator mInterpolator;
  
  private boolean mIsStarted;
  
  private final ViewPropertyAnimatorListenerAdapter mProxyListener = new ViewPropertyAnimatorListenerAdapter(this) {
      private int mProxyEndCount = 0;
      
      private boolean mProxyStarted = false;
      
      void a() {
        this.mProxyEndCount = 0;
        this.mProxyStarted = false;
        this.a.a();
      }
      
      public void onAnimationEnd(View param1View) {
        int i = 1 + this.mProxyEndCount;
        this.mProxyEndCount = i;
        if (i == this.a.a.size()) {
          if (this.a.b != null)
            this.a.b.onAnimationEnd(null); 
          a();
        } 
      }
      
      public void onAnimationStart(View param1View) {
        if (this.mProxyStarted)
          return; 
        this.mProxyStarted = true;
        if (this.a.b != null)
          this.a.b.onAnimationStart(null); 
      }
    };
  
  void a() {
    this.mIsStarted = false;
  }
  
  public void cancel() {
    if (!this.mIsStarted)
      return; 
    Iterator<ViewPropertyAnimatorCompat> iterator = this.a.iterator();
    while (iterator.hasNext())
      ((ViewPropertyAnimatorCompat)iterator.next()).cancel(); 
    this.mIsStarted = false;
  }
  
  public ViewPropertyAnimatorCompatSet play(ViewPropertyAnimatorCompat paramViewPropertyAnimatorCompat) {
    if (!this.mIsStarted)
      this.a.add(paramViewPropertyAnimatorCompat); 
    return this;
  }
  
  public ViewPropertyAnimatorCompatSet playSequentially(ViewPropertyAnimatorCompat paramViewPropertyAnimatorCompat1, ViewPropertyAnimatorCompat paramViewPropertyAnimatorCompat2) {
    this.a.add(paramViewPropertyAnimatorCompat1);
    paramViewPropertyAnimatorCompat2.setStartDelay(paramViewPropertyAnimatorCompat1.getDuration());
    this.a.add(paramViewPropertyAnimatorCompat2);
    return this;
  }
  
  public ViewPropertyAnimatorCompatSet setDuration(long paramLong) {
    if (!this.mIsStarted)
      this.mDuration = paramLong; 
    return this;
  }
  
  public ViewPropertyAnimatorCompatSet setInterpolator(Interpolator paramInterpolator) {
    if (!this.mIsStarted)
      this.mInterpolator = paramInterpolator; 
    return this;
  }
  
  public ViewPropertyAnimatorCompatSet setListener(ViewPropertyAnimatorListener paramViewPropertyAnimatorListener) {
    if (!this.mIsStarted)
      this.b = paramViewPropertyAnimatorListener; 
    return this;
  }
  
  public void start() {
    if (this.mIsStarted)
      return; 
    for (ViewPropertyAnimatorCompat viewPropertyAnimatorCompat : this.a) {
      if (this.mDuration >= 0L)
        viewPropertyAnimatorCompat.setDuration(this.mDuration); 
      if (this.mInterpolator != null)
        viewPropertyAnimatorCompat.setInterpolator(this.mInterpolator); 
      if (this.b != null)
        viewPropertyAnimatorCompat.setListener((ViewPropertyAnimatorListener)this.mProxyListener); 
      viewPropertyAnimatorCompat.start();
    } 
    this.mIsStarted = true;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\ViewPropertyAnimatorCompatSet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */