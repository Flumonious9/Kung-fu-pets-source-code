package android.support.v7.view;

import android.content.Context;
import android.support.annotation.RestrictTo;
import android.support.v4.internal.view.SupportMenu;
import android.support.v4.internal.view.SupportMenuItem;
import android.support.v4.util.SimpleArrayMap;
import android.support.v7.view.menu.MenuWrapperFactory;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class SupportActionModeWrapper extends ActionMode {
  final Context a;
  
  final ActionMode b;
  
  public SupportActionModeWrapper(Context paramContext, ActionMode paramActionMode) {
    this.a = paramContext;
    this.b = paramActionMode;
  }
  
  public void finish() {
    this.b.finish();
  }
  
  public View getCustomView() {
    return this.b.getCustomView();
  }
  
  public Menu getMenu() {
    return MenuWrapperFactory.wrapSupportMenu(this.a, (SupportMenu)this.b.getMenu());
  }
  
  public MenuInflater getMenuInflater() {
    return this.b.getMenuInflater();
  }
  
  public CharSequence getSubtitle() {
    return this.b.getSubtitle();
  }
  
  public Object getTag() {
    return this.b.getTag();
  }
  
  public CharSequence getTitle() {
    return this.b.getTitle();
  }
  
  public boolean getTitleOptionalHint() {
    return this.b.getTitleOptionalHint();
  }
  
  public void invalidate() {
    this.b.invalidate();
  }
  
  public boolean isTitleOptional() {
    return this.b.isTitleOptional();
  }
  
  public void setCustomView(View paramView) {
    this.b.setCustomView(paramView);
  }
  
  public void setSubtitle(int paramInt) {
    this.b.setSubtitle(paramInt);
  }
  
  public void setSubtitle(CharSequence paramCharSequence) {
    this.b.setSubtitle(paramCharSequence);
  }
  
  public void setTag(Object paramObject) {
    this.b.setTag(paramObject);
  }
  
  public void setTitle(int paramInt) {
    this.b.setTitle(paramInt);
  }
  
  public void setTitle(CharSequence paramCharSequence) {
    this.b.setTitle(paramCharSequence);
  }
  
  public void setTitleOptionalHint(boolean paramBoolean) {
    this.b.setTitleOptionalHint(paramBoolean);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static class CallbackWrapper implements ActionMode.Callback {
    final ActionMode.Callback a;
    
    final Context b;
    
    final ArrayList<SupportActionModeWrapper> c;
    
    final SimpleArrayMap<Menu, Menu> d;
    
    public CallbackWrapper(Context param1Context, ActionMode.Callback param1Callback) {
      this.b = param1Context;
      this.a = param1Callback;
      this.c = new ArrayList<SupportActionModeWrapper>();
      this.d = new SimpleArrayMap();
    }
    
    private Menu getMenuWrapper(Menu param1Menu) {
      Menu menu = (Menu)this.d.get(param1Menu);
      if (menu == null) {
        menu = MenuWrapperFactory.wrapSupportMenu(this.b, (SupportMenu)param1Menu);
        this.d.put(param1Menu, menu);
      } 
      return menu;
    }
    
    public ActionMode getActionModeWrapper(ActionMode param1ActionMode) {
      int i = this.c.size();
      for (byte b = 0; b < i; b++) {
        SupportActionModeWrapper supportActionModeWrapper1 = this.c.get(b);
        if (supportActionModeWrapper1 != null && supportActionModeWrapper1.b == param1ActionMode)
          return supportActionModeWrapper1; 
      } 
      SupportActionModeWrapper supportActionModeWrapper = new SupportActionModeWrapper(this.b, param1ActionMode);
      this.c.add(supportActionModeWrapper);
      return supportActionModeWrapper;
    }
    
    public boolean onActionItemClicked(ActionMode param1ActionMode, MenuItem param1MenuItem) {
      return this.a.onActionItemClicked(getActionModeWrapper(param1ActionMode), MenuWrapperFactory.wrapSupportMenuItem(this.b, (SupportMenuItem)param1MenuItem));
    }
    
    public boolean onCreateActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.a.onCreateActionMode(getActionModeWrapper(param1ActionMode), getMenuWrapper(param1Menu));
    }
    
    public void onDestroyActionMode(ActionMode param1ActionMode) {
      this.a.onDestroyActionMode(getActionModeWrapper(param1ActionMode));
    }
    
    public boolean onPrepareActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.a.onPrepareActionMode(getActionModeWrapper(param1ActionMode), getMenuWrapper(param1Menu));
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v7\view\SupportActionModeWrapper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */