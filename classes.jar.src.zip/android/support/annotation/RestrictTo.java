package android.support.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.ANNOTATION_TYPE, ElementType.TYPE, ElementType.METHOD, ElementType.CONSTRUCTOR, ElementType.FIELD, ElementType.PACKAGE})
public @interface RestrictTo {
  Scope[] value();
  
  public enum Scope {
    GROUP_ID, LIBRARY, LIBRARY_GROUP, SUBCLASSES, TESTS;
    
    static {
      SUBCLASSES = new Scope("SUBCLASSES", 4);
      Scope[] arrayOfScope = new Scope[5];
      arrayOfScope[0] = LIBRARY;
      arrayOfScope[1] = LIBRARY_GROUP;
      arrayOfScope[2] = GROUP_ID;
      arrayOfScope[3] = TESTS;
      arrayOfScope[4] = SUBCLASSES;
      $VALUES = arrayOfScope;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\annotation\RestrictTo.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */