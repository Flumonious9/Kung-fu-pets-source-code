package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.TypeEvaluator;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.AnimatedVectorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.util.ArrayMap;
import android.util.AttributeSet;
import android.util.Log;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

public class AnimatedVectorDrawableCompat extends VectorDrawableCommon implements Animatable2Compat {
  private static final String ANIMATED_VECTOR = "animated-vector";
  
  private static final boolean DBG_ANIMATION_VECTOR_DRAWABLE = false;
  
  private static final String LOGTAG = "AnimatedVDCompat";
  
  private static final String TARGET = "target";
  
  AnimatedVectorDrawableDelegateState a;
  
  final Drawable.Callback b = new Drawable.Callback(this) {
      public void invalidateDrawable(Drawable param1Drawable) {
        this.a.invalidateSelf();
      }
      
      public void scheduleDrawable(Drawable param1Drawable, Runnable param1Runnable, long param1Long) {
        this.a.scheduleSelf(param1Runnable, param1Long);
      }
      
      public void unscheduleDrawable(Drawable param1Drawable, Runnable param1Runnable) {
        this.a.unscheduleSelf(param1Runnable);
      }
    };
  
  private AnimatedVectorDrawableCompatState mAnimatedVectorState;
  
  private ArrayList<Animatable2Compat.AnimationCallback> mAnimationCallbacks = null;
  
  private Animator.AnimatorListener mAnimatorListener = null;
  
  private ArgbEvaluator mArgbEvaluator = null;
  
  private Context mContext;
  
  AnimatedVectorDrawableCompat() {
    this((Context)null, (AnimatedVectorDrawableCompatState)null, (Resources)null);
  }
  
  private AnimatedVectorDrawableCompat(@Nullable Context paramContext) {
    this(paramContext, (AnimatedVectorDrawableCompatState)null, (Resources)null);
  }
  
  private AnimatedVectorDrawableCompat(@Nullable Context paramContext, @Nullable AnimatedVectorDrawableCompatState paramAnimatedVectorDrawableCompatState, @Nullable Resources paramResources) {
    this.mContext = paramContext;
    if (paramAnimatedVectorDrawableCompatState != null) {
      this.mAnimatedVectorState = paramAnimatedVectorDrawableCompatState;
      return;
    } 
    this.mAnimatedVectorState = new AnimatedVectorDrawableCompatState(paramContext, paramAnimatedVectorDrawableCompatState, this.b, paramResources);
  }
  
  public static void clearAnimationCallbacks(Drawable paramDrawable) {
    if (paramDrawable != null) {
      if (!(paramDrawable instanceof android.graphics.drawable.Animatable))
        return; 
      if (Build.VERSION.SDK_INT >= 24) {
        ((AnimatedVectorDrawable)paramDrawable).clearAnimationCallbacks();
        return;
      } 
      ((AnimatedVectorDrawableCompat)paramDrawable).clearAnimationCallbacks();
      return;
    } 
  }
  
  @Nullable
  public static AnimatedVectorDrawableCompat create(@NonNull Context paramContext, @DrawableRes int paramInt) {
    if (Build.VERSION.SDK_INT >= 24) {
      AnimatedVectorDrawableCompat animatedVectorDrawableCompat = new AnimatedVectorDrawableCompat(paramContext);
      animatedVectorDrawableCompat.c = ResourcesCompat.getDrawable(paramContext.getResources(), paramInt, paramContext.getTheme());
      animatedVectorDrawableCompat.c.setCallback(animatedVectorDrawableCompat.b);
      animatedVectorDrawableCompat.a = new AnimatedVectorDrawableDelegateState(animatedVectorDrawableCompat.c.getConstantState());
      return animatedVectorDrawableCompat;
    } 
    Resources resources = paramContext.getResources();
    try {
      int i;
      XmlResourceParser xmlResourceParser = resources.getXml(paramInt);
      AttributeSet attributeSet = Xml.asAttributeSet((XmlPullParser)xmlResourceParser);
      while (true) {
        i = xmlResourceParser.next();
        if (i != 2 && i != 1)
          continue; 
        break;
      } 
      if (i == 2)
        return createFromXmlInner(paramContext, paramContext.getResources(), (XmlPullParser)xmlResourceParser, attributeSet, paramContext.getTheme()); 
      throw new XmlPullParserException("No start tag found");
    } catch (XmlPullParserException xmlPullParserException) {
      Log.e("AnimatedVDCompat", "parser error", (Throwable)xmlPullParserException);
    } catch (IOException iOException) {
      Log.e("AnimatedVDCompat", "parser error", iOException);
    } 
    return null;
  }
  
  public static AnimatedVectorDrawableCompat createFromXmlInner(Context paramContext, Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    AnimatedVectorDrawableCompat animatedVectorDrawableCompat = new AnimatedVectorDrawableCompat(paramContext);
    animatedVectorDrawableCompat.inflate(paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
    return animatedVectorDrawableCompat;
  }
  
  public static void registerAnimationCallback(Drawable paramDrawable, Animatable2Compat.AnimationCallback paramAnimationCallback) {
    if (paramDrawable != null) {
      if (paramAnimationCallback == null)
        return; 
      if (!(paramDrawable instanceof android.graphics.drawable.Animatable))
        return; 
      if (Build.VERSION.SDK_INT >= 24) {
        registerPlatformCallback((AnimatedVectorDrawable)paramDrawable, paramAnimationCallback);
        return;
      } 
      ((AnimatedVectorDrawableCompat)paramDrawable).registerAnimationCallback(paramAnimationCallback);
      return;
    } 
  }
  
  @RequiresApi(23)
  private static void registerPlatformCallback(@NonNull AnimatedVectorDrawable paramAnimatedVectorDrawable, @NonNull Animatable2Compat.AnimationCallback paramAnimationCallback) {
    paramAnimatedVectorDrawable.registerAnimationCallback(paramAnimationCallback.getPlatformCallback());
  }
  
  private void removeAnimatorSetListener() {
    if (this.mAnimatorListener != null) {
      this.mAnimatedVectorState.c.removeListener(this.mAnimatorListener);
      this.mAnimatorListener = null;
    } 
  }
  
  private void setupAnimatorsForTarget(String paramString, Animator paramAnimator) {
    paramAnimator.setTarget(this.mAnimatedVectorState.b.a(paramString));
    if (Build.VERSION.SDK_INT < 21)
      setupColorAnimator(paramAnimator); 
    if (AnimatedVectorDrawableCompatState.a(this.mAnimatedVectorState) == null) {
      AnimatedVectorDrawableCompatState.a(this.mAnimatedVectorState, new ArrayList());
      this.mAnimatedVectorState.d = new ArrayMap();
    } 
    AnimatedVectorDrawableCompatState.a(this.mAnimatedVectorState).add(paramAnimator);
    this.mAnimatedVectorState.d.put(paramAnimator, paramString);
  }
  
  private void setupColorAnimator(Animator paramAnimator) {
    if (paramAnimator instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)paramAnimator).getChildAnimations();
      if (arrayList != null)
        for (byte b = 0; b < arrayList.size(); b++)
          setupColorAnimator(arrayList.get(b));  
    } 
    if (paramAnimator instanceof ObjectAnimator) {
      ObjectAnimator objectAnimator = (ObjectAnimator)paramAnimator;
      String str = objectAnimator.getPropertyName();
      if ("fillColor".equals(str) || "strokeColor".equals(str)) {
        if (this.mArgbEvaluator == null)
          this.mArgbEvaluator = new ArgbEvaluator(); 
        objectAnimator.setEvaluator((TypeEvaluator)this.mArgbEvaluator);
      } 
    } 
  }
  
  public static boolean unregisterAnimationCallback(Drawable paramDrawable, Animatable2Compat.AnimationCallback paramAnimationCallback) {
    return (paramDrawable != null) ? ((paramAnimationCallback == null) ? false : (!(paramDrawable instanceof android.graphics.drawable.Animatable) ? false : ((Build.VERSION.SDK_INT >= 24) ? unregisterPlatformCallback((AnimatedVectorDrawable)paramDrawable, paramAnimationCallback) : ((AnimatedVectorDrawableCompat)paramDrawable).unregisterAnimationCallback(paramAnimationCallback)))) : false;
  }
  
  @RequiresApi(23)
  private static boolean unregisterPlatformCallback(AnimatedVectorDrawable paramAnimatedVectorDrawable, Animatable2Compat.AnimationCallback paramAnimationCallback) {
    return paramAnimatedVectorDrawable.unregisterAnimationCallback(paramAnimationCallback.getPlatformCallback());
  }
  
  public void applyTheme(Resources.Theme paramTheme) {
    if (this.c != null) {
      DrawableCompat.applyTheme(this.c, paramTheme);
      return;
    } 
  }
  
  public boolean canApplyTheme() {
    return (this.c != null) ? DrawableCompat.canApplyTheme(this.c) : false;
  }
  
  public void clearAnimationCallbacks() {
    if (this.c != null) {
      ((AnimatedVectorDrawable)this.c).clearAnimationCallbacks();
      return;
    } 
    removeAnimatorSetListener();
    if (this.mAnimationCallbacks == null)
      return; 
    this.mAnimationCallbacks.clear();
  }
  
  public void draw(Canvas paramCanvas) {
    if (this.c != null) {
      this.c.draw(paramCanvas);
      return;
    } 
    this.mAnimatedVectorState.b.draw(paramCanvas);
    if (this.mAnimatedVectorState.c.isStarted())
      invalidateSelf(); 
  }
  
  public int getAlpha() {
    return (this.c != null) ? DrawableCompat.getAlpha(this.c) : this.mAnimatedVectorState.b.getAlpha();
  }
  
  public int getChangingConfigurations() {
    return (this.c != null) ? this.c.getChangingConfigurations() : (super.getChangingConfigurations() | this.mAnimatedVectorState.a);
  }
  
  public Drawable.ConstantState getConstantState() {
    return (this.c != null && Build.VERSION.SDK_INT >= 24) ? new AnimatedVectorDrawableDelegateState(this.c.getConstantState()) : null;
  }
  
  public int getIntrinsicHeight() {
    return (this.c != null) ? this.c.getIntrinsicHeight() : this.mAnimatedVectorState.b.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return (this.c != null) ? this.c.getIntrinsicWidth() : this.mAnimatedVectorState.b.getIntrinsicWidth();
  }
  
  public int getOpacity() {
    return (this.c != null) ? this.c.getOpacity() : this.mAnimatedVectorState.b.getOpacity();
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) {
    inflate(paramResources, paramXmlPullParser, paramAttributeSet, (Resources.Theme)null);
  }
  
  public void inflate(Resources paramResources, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, Resources.Theme paramTheme) {
    if (this.c != null) {
      DrawableCompat.inflate(this.c, paramResources, paramXmlPullParser, paramAttributeSet, paramTheme);
      return;
    } 
    int i = paramXmlPullParser.getEventType();
    int j = 1 + paramXmlPullParser.getDepth();
    while (i != 1 && (paramXmlPullParser.getDepth() >= j || i != 3)) {
      if (i == 2) {
        String str = paramXmlPullParser.getName();
        if ("animated-vector".equals(str)) {
          TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.e);
          int k = typedArray.getResourceId(0, 0);
          if (k != 0) {
            VectorDrawableCompat vectorDrawableCompat = VectorDrawableCompat.create(paramResources, k, paramTheme);
            vectorDrawableCompat.setAllowCaching(false);
            vectorDrawableCompat.setCallback(this.b);
            if (this.mAnimatedVectorState.b != null)
              this.mAnimatedVectorState.b.setCallback(null); 
            this.mAnimatedVectorState.b = vectorDrawableCompat;
          } 
          typedArray.recycle();
        } else if ("target".equals(str)) {
          TypedArray typedArray = paramResources.obtainAttributes(paramAttributeSet, AndroidResources.f);
          String str1 = typedArray.getString(0);
          int k = typedArray.getResourceId(1, 0);
          if (k != 0)
            if (this.mContext != null) {
              setupAnimatorsForTarget(str1, AnimatorInflaterCompat.loadAnimator(this.mContext, k));
            } else {
              typedArray.recycle();
              throw new IllegalStateException("Context can't be null when inflating animators");
            }  
          typedArray.recycle();
        } 
      } 
      i = paramXmlPullParser.next();
    } 
    this.mAnimatedVectorState.setupAnimatorSet();
  }
  
  public boolean isAutoMirrored() {
    return (this.c != null) ? DrawableCompat.isAutoMirrored(this.c) : this.mAnimatedVectorState.b.isAutoMirrored();
  }
  
  public boolean isRunning() {
    return (this.c != null) ? ((AnimatedVectorDrawable)this.c).isRunning() : this.mAnimatedVectorState.c.isRunning();
  }
  
  public boolean isStateful() {
    return (this.c != null) ? this.c.isStateful() : this.mAnimatedVectorState.b.isStateful();
  }
  
  public Drawable mutate() {
    if (this.c != null)
      this.c.mutate(); 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    if (this.c != null) {
      this.c.setBounds(paramRect);
      return;
    } 
    this.mAnimatedVectorState.b.setBounds(paramRect);
  }
  
  protected boolean onLevelChange(int paramInt) {
    return (this.c != null) ? this.c.setLevel(paramInt) : this.mAnimatedVectorState.b.setLevel(paramInt);
  }
  
  protected boolean onStateChange(int[] paramArrayOfint) {
    return (this.c != null) ? this.c.setState(paramArrayOfint) : this.mAnimatedVectorState.b.setState(paramArrayOfint);
  }
  
  public void registerAnimationCallback(@NonNull Animatable2Compat.AnimationCallback paramAnimationCallback) {
    if (this.c != null) {
      registerPlatformCallback((AnimatedVectorDrawable)this.c, paramAnimationCallback);
      return;
    } 
    if (paramAnimationCallback == null)
      return; 
    if (this.mAnimationCallbacks == null)
      this.mAnimationCallbacks = new ArrayList<Animatable2Compat.AnimationCallback>(); 
    if (this.mAnimationCallbacks.contains(paramAnimationCallback))
      return; 
    this.mAnimationCallbacks.add(paramAnimationCallback);
    if (this.mAnimatorListener == null)
      this.mAnimatorListener = (Animator.AnimatorListener)new AnimatorListenerAdapter(this) {
          public void onAnimationEnd(Animator param1Animator) {
            ArrayList<Animatable2Compat.AnimationCallback> arrayList = new ArrayList(AnimatedVectorDrawableCompat.a(this.a));
            int i = arrayList.size();
            for (byte b = 0; b < i; b++)
              ((Animatable2Compat.AnimationCallback)arrayList.get(b)).onAnimationEnd(this.a); 
          }
          
          public void onAnimationStart(Animator param1Animator) {
            ArrayList<Animatable2Compat.AnimationCallback> arrayList = new ArrayList(AnimatedVectorDrawableCompat.a(this.a));
            int i = arrayList.size();
            for (byte b = 0; b < i; b++)
              ((Animatable2Compat.AnimationCallback)arrayList.get(b)).onAnimationStart(this.a); 
          }
        }; 
    this.mAnimatedVectorState.c.addListener(this.mAnimatorListener);
  }
  
  public void setAlpha(int paramInt) {
    if (this.c != null) {
      this.c.setAlpha(paramInt);
      return;
    } 
    this.mAnimatedVectorState.b.setAlpha(paramInt);
  }
  
  public void setAutoMirrored(boolean paramBoolean) {
    if (this.c != null) {
      DrawableCompat.setAutoMirrored(this.c, paramBoolean);
      return;
    } 
    this.mAnimatedVectorState.b.setAutoMirrored(paramBoolean);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    if (this.c != null) {
      this.c.setColorFilter(paramColorFilter);
      return;
    } 
    this.mAnimatedVectorState.b.setColorFilter(paramColorFilter);
  }
  
  public void setTint(int paramInt) {
    if (this.c != null) {
      DrawableCompat.setTint(this.c, paramInt);
      return;
    } 
    this.mAnimatedVectorState.b.setTint(paramInt);
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    if (this.c != null) {
      DrawableCompat.setTintList(this.c, paramColorStateList);
      return;
    } 
    this.mAnimatedVectorState.b.setTintList(paramColorStateList);
  }
  
  public void setTintMode(PorterDuff.Mode paramMode) {
    if (this.c != null) {
      DrawableCompat.setTintMode(this.c, paramMode);
      return;
    } 
    this.mAnimatedVectorState.b.setTintMode(paramMode);
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.c != null)
      return this.c.setVisible(paramBoolean1, paramBoolean2); 
    this.mAnimatedVectorState.b.setVisible(paramBoolean1, paramBoolean2);
    return super.setVisible(paramBoolean1, paramBoolean2);
  }
  
  public void start() {
    if (this.c != null) {
      ((AnimatedVectorDrawable)this.c).start();
      return;
    } 
    if (this.mAnimatedVectorState.c.isStarted())
      return; 
    this.mAnimatedVectorState.c.start();
    invalidateSelf();
  }
  
  public void stop() {
    if (this.c != null) {
      ((AnimatedVectorDrawable)this.c).stop();
      return;
    } 
    this.mAnimatedVectorState.c.end();
  }
  
  public boolean unregisterAnimationCallback(@NonNull Animatable2Compat.AnimationCallback paramAnimationCallback) {
    if (this.c != null)
      unregisterPlatformCallback((AnimatedVectorDrawable)this.c, paramAnimationCallback); 
    if (this.mAnimationCallbacks == null || paramAnimationCallback == null)
      return false; 
    boolean bool = this.mAnimationCallbacks.remove(paramAnimationCallback);
    if (this.mAnimationCallbacks.size() == 0)
      removeAnimatorSetListener(); 
    return bool;
  }
  
  private static class AnimatedVectorDrawableCompatState extends Drawable.ConstantState {
    int a;
    
    VectorDrawableCompat b;
    
    AnimatorSet c;
    
    ArrayMap<Animator, String> d;
    
    private ArrayList<Animator> mAnimators;
    
    public AnimatedVectorDrawableCompatState(Context param1Context, AnimatedVectorDrawableCompatState param1AnimatedVectorDrawableCompatState, Drawable.Callback param1Callback, Resources param1Resources) {
      if (param1AnimatedVectorDrawableCompatState != null) {
        this.a = param1AnimatedVectorDrawableCompatState.a;
        VectorDrawableCompat vectorDrawableCompat = param1AnimatedVectorDrawableCompatState.b;
        byte b = 0;
        if (vectorDrawableCompat != null) {
          Drawable.ConstantState constantState = param1AnimatedVectorDrawableCompatState.b.getConstantState();
          if (param1Resources != null) {
            this.b = (VectorDrawableCompat)constantState.newDrawable(param1Resources);
          } else {
            this.b = (VectorDrawableCompat)constantState.newDrawable();
          } 
          this.b = (VectorDrawableCompat)this.b.mutate();
          this.b.setCallback(param1Callback);
          this.b.setBounds(param1AnimatedVectorDrawableCompatState.b.getBounds());
          this.b.setAllowCaching(false);
        } 
        if (param1AnimatedVectorDrawableCompatState.mAnimators != null) {
          int i = param1AnimatedVectorDrawableCompatState.mAnimators.size();
          this.mAnimators = new ArrayList<Animator>(i);
          this.d = new ArrayMap(i);
          while (b < i) {
            Animator animator1 = param1AnimatedVectorDrawableCompatState.mAnimators.get(b);
            Animator animator2 = animator1.clone();
            String str = (String)param1AnimatedVectorDrawableCompatState.d.get(animator1);
            animator2.setTarget(this.b.a(str));
            this.mAnimators.add(animator2);
            this.d.put(animator2, str);
            b++;
          } 
          setupAnimatorSet();
        } 
      } 
    }
    
    public int getChangingConfigurations() {
      return this.a;
    }
    
    public Drawable newDrawable() {
      throw new IllegalStateException("No constant state support for SDK < 24.");
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      throw new IllegalStateException("No constant state support for SDK < 24.");
    }
    
    public void setupAnimatorSet() {
      if (this.c == null)
        this.c = new AnimatorSet(); 
      this.c.playTogether(this.mAnimators);
    }
  }
  
  @RequiresApi(24)
  private static class AnimatedVectorDrawableDelegateState extends Drawable.ConstantState {
    private final Drawable.ConstantState mDelegateState;
    
    public AnimatedVectorDrawableDelegateState(Drawable.ConstantState param1ConstantState) {
      this.mDelegateState = param1ConstantState;
    }
    
    public boolean canApplyTheme() {
      return this.mDelegateState.canApplyTheme();
    }
    
    public int getChangingConfigurations() {
      return this.mDelegateState.getChangingConfigurations();
    }
    
    public Drawable newDrawable() {
      AnimatedVectorDrawableCompat animatedVectorDrawableCompat = new AnimatedVectorDrawableCompat();
      animatedVectorDrawableCompat.c = this.mDelegateState.newDrawable();
      animatedVectorDrawableCompat.c.setCallback(animatedVectorDrawableCompat.b);
      return animatedVectorDrawableCompat;
    }
    
    public Drawable newDrawable(Resources param1Resources) {
      AnimatedVectorDrawableCompat animatedVectorDrawableCompat = new AnimatedVectorDrawableCompat();
      animatedVectorDrawableCompat.c = this.mDelegateState.newDrawable(param1Resources);
      animatedVectorDrawableCompat.c.setCallback(animatedVectorDrawableCompat.b);
      return animatedVectorDrawableCompat;
    }
    
    public Drawable newDrawable(Resources param1Resources, Resources.Theme param1Theme) {
      AnimatedVectorDrawableCompat animatedVectorDrawableCompat = new AnimatedVectorDrawableCompat();
      animatedVectorDrawableCompat.c = this.mDelegateState.newDrawable(param1Resources, param1Theme);
      animatedVectorDrawableCompat.c.setCallback(animatedVectorDrawableCompat.b);
      return animatedVectorDrawableCompat;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\graphics\drawable\AnimatedVectorDrawableCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */