package android.support.graphics.drawable;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.XmlResourceParser;
import android.os.Build;
import android.support.annotation.RestrictTo;
import android.support.v4.view.animation.FastOutLinearInInterpolator;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.support.v4.view.animation.LinearOutSlowInInterpolator;
import android.util.AttributeSet;
import android.util.Xml;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AnimationUtils;
import android.view.animation.AnticipateInterpolator;
import android.view.animation.AnticipateOvershootInterpolator;
import android.view.animation.BounceInterpolator;
import android.view.animation.CycleInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.OvershootInterpolator;
import java.io.IOException;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class AnimationUtilsCompat {
  private static Interpolator createInterpolatorFromXml(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser) {
    PathInterpolatorCompat pathInterpolatorCompat;
    int i = paramXmlPullParser.getDepth();
    LinearInterpolator linearInterpolator = null;
    while (true) {
      int j = paramXmlPullParser.next();
      if ((j != 3 || paramXmlPullParser.getDepth() > i) && j != 1) {
        PathInterpolatorCompat pathInterpolatorCompat1;
        if (j != 2)
          continue; 
        AttributeSet attributeSet = Xml.asAttributeSet(paramXmlPullParser);
        String str = paramXmlPullParser.getName();
        if (str.equals("linearInterpolator")) {
          linearInterpolator = new LinearInterpolator();
          continue;
        } 
        if (str.equals("accelerateInterpolator")) {
          AccelerateInterpolator accelerateInterpolator = new AccelerateInterpolator(paramContext, attributeSet);
        } else if (str.equals("decelerateInterpolator")) {
          DecelerateInterpolator decelerateInterpolator = new DecelerateInterpolator(paramContext, attributeSet);
        } else {
          if (str.equals("accelerateDecelerateInterpolator")) {
            AccelerateDecelerateInterpolator accelerateDecelerateInterpolator = new AccelerateDecelerateInterpolator();
            continue;
          } 
          if (str.equals("cycleInterpolator")) {
            CycleInterpolator cycleInterpolator = new CycleInterpolator(paramContext, attributeSet);
          } else if (str.equals("anticipateInterpolator")) {
            AnticipateInterpolator anticipateInterpolator = new AnticipateInterpolator(paramContext, attributeSet);
          } else if (str.equals("overshootInterpolator")) {
            OvershootInterpolator overshootInterpolator = new OvershootInterpolator(paramContext, attributeSet);
          } else if (str.equals("anticipateOvershootInterpolator")) {
            AnticipateOvershootInterpolator anticipateOvershootInterpolator = new AnticipateOvershootInterpolator(paramContext, attributeSet);
          } else {
            if (str.equals("bounceInterpolator")) {
              BounceInterpolator bounceInterpolator = new BounceInterpolator();
              continue;
            } 
            if (str.equals("pathInterpolator")) {
              pathInterpolatorCompat1 = new PathInterpolatorCompat(paramContext, attributeSet, paramXmlPullParser);
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Unknown interpolator name: ");
              stringBuilder.append(paramXmlPullParser.getName());
              throw new RuntimeException(stringBuilder.toString());
            } 
          } 
        } 
        pathInterpolatorCompat = pathInterpolatorCompat1;
        continue;
      } 
      break;
    } 
    return pathInterpolatorCompat;
  }
  
  public static Interpolator loadInterpolator(Context paramContext, int paramInt) {
    if (Build.VERSION.SDK_INT >= 21)
      return AnimationUtils.loadInterpolator(paramContext, paramInt); 
    XmlResourceParser xmlResourceParser = null;
    if (paramInt == 17563663) {
      try {
        return (Interpolator)new FastOutLinearInInterpolator();
      } catch (XmlPullParserException null) {
      
      } catch (IOException iOException) {
        xmlResourceParser = null;
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Can't load animation resource ID #0x");
        stringBuilder1.append(Integer.toHexString(paramInt));
        Resources.NotFoundException notFoundException1 = new Resources.NotFoundException(stringBuilder1.toString());
        notFoundException1.initCause(iOException);
        throw notFoundException1;
      } finally {
        if (xmlResourceParser != null)
          xmlResourceParser.close(); 
      } 
    } else {
      xmlResourceParser = null;
      if (paramInt == 17563661)
        return (Interpolator)new FastOutSlowInInterpolator(); 
      xmlResourceParser = null;
      if (paramInt == 17563662)
        return (Interpolator)new LinearOutSlowInInterpolator(); 
      XmlResourceParser xmlResourceParser1 = paramContext.getResources().getAnimation(paramInt);
      try {
        return createInterpolatorFromXml(paramContext, paramContext.getResources(), paramContext.getTheme(), (XmlPullParser)xmlResourceParser1);
      } catch (XmlPullParserException xmlPullParserException) {
      
      } catch (IOException iOException) {
      
      } finally {
        Exception exception = null;
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't load animation resource ID #0x");
    stringBuilder.append(Integer.toHexString(paramInt));
    Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
    notFoundException.initCause((Throwable)xmlPullParserException);
    throw notFoundException;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\graphics\drawable\AnimationUtilsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */