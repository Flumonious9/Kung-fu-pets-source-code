package android.support.graphics.drawable;

import android.graphics.drawable.Animatable;
import android.graphics.drawable.Animatable2;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;

public interface Animatable2Compat extends Animatable {
  void clearAnimationCallbacks();
  
  void registerAnimationCallback(@NonNull AnimationCallback paramAnimationCallback);
  
  boolean unregisterAnimationCallback(@NonNull AnimationCallback paramAnimationCallback);
  
  public static abstract class AnimationCallback {
    Animatable2.AnimationCallback a;
    
    @RequiresApi(23)
    Animatable2.AnimationCallback getPlatformCallback() {
      if (this.a == null)
        this.a = new Animatable2.AnimationCallback(this) {
            public void onAnimationEnd(Drawable param2Drawable) {
              this.a.onAnimationEnd(param2Drawable);
            }
            
            public void onAnimationStart(Drawable param2Drawable) {
              this.a.onAnimationStart(param2Drawable);
            }
          }; 
      return this.a;
    }
    
    public void onAnimationEnd(Drawable param1Drawable) {}
    
    public void onAnimationStart(Drawable param1Drawable) {}
  }
  
  class null extends Animatable2.AnimationCallback {
    null(Animatable2Compat this$0) {}
    
    public void onAnimationEnd(Drawable param1Drawable) {
      this.a.onAnimationEnd(param1Drawable);
    }
    
    public void onAnimationStart(Drawable param1Drawable) {
      this.a.onAnimationStart(param1Drawable);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\graphics\drawable\Animatable2Compat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */