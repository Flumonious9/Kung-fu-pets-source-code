package android.support.graphics.drawable;

import android.content.res.Resources;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.graphics.drawable.TintAwareDrawable;

abstract class VectorDrawableCommon extends Drawable implements TintAwareDrawable {
  Drawable c;
  
  public void applyTheme(Resources.Theme paramTheme) {
    if (this.c != null) {
      DrawableCompat.applyTheme(this.c, paramTheme);
      return;
    } 
  }
  
  public void clearColorFilter() {
    if (this.c != null) {
      this.c.clearColorFilter();
      return;
    } 
    super.clearColorFilter();
  }
  
  public ColorFilter getColorFilter() {
    return (this.c != null) ? DrawableCompat.getColorFilter(this.c) : null;
  }
  
  public Drawable getCurrent() {
    return (this.c != null) ? this.c.getCurrent() : super.getCurrent();
  }
  
  public int getMinimumHeight() {
    return (this.c != null) ? this.c.getMinimumHeight() : super.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return (this.c != null) ? this.c.getMinimumWidth() : super.getMinimumWidth();
  }
  
  public boolean getPadding(Rect paramRect) {
    return (this.c != null) ? this.c.getPadding(paramRect) : super.getPadding(paramRect);
  }
  
  public int[] getState() {
    return (this.c != null) ? this.c.getState() : super.getState();
  }
  
  public Region getTransparentRegion() {
    return (this.c != null) ? this.c.getTransparentRegion() : super.getTransparentRegion();
  }
  
  public void jumpToCurrentState() {
    if (this.c != null) {
      DrawableCompat.jumpToCurrentState(this.c);
      return;
    } 
  }
  
  protected void onBoundsChange(Rect paramRect) {
    if (this.c != null) {
      this.c.setBounds(paramRect);
      return;
    } 
    super.onBoundsChange(paramRect);
  }
  
  protected boolean onLevelChange(int paramInt) {
    return (this.c != null) ? this.c.setLevel(paramInt) : super.onLevelChange(paramInt);
  }
  
  public void setChangingConfigurations(int paramInt) {
    if (this.c != null) {
      this.c.setChangingConfigurations(paramInt);
      return;
    } 
    super.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(int paramInt, PorterDuff.Mode paramMode) {
    if (this.c != null) {
      this.c.setColorFilter(paramInt, paramMode);
      return;
    } 
    super.setColorFilter(paramInt, paramMode);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    if (this.c != null) {
      this.c.setFilterBitmap(paramBoolean);
      return;
    } 
  }
  
  public void setHotspot(float paramFloat1, float paramFloat2) {
    if (this.c != null)
      DrawableCompat.setHotspot(this.c, paramFloat1, paramFloat2); 
  }
  
  public void setHotspotBounds(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.c != null) {
      DrawableCompat.setHotspotBounds(this.c, paramInt1, paramInt2, paramInt3, paramInt4);
      return;
    } 
  }
  
  public boolean setState(int[] paramArrayOfint) {
    return (this.c != null) ? this.c.setState(paramArrayOfint) : super.setState(paramArrayOfint);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\graphics\drawable\VectorDrawableCommon.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */