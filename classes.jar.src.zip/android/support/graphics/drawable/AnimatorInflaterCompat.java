package android.support.graphics.drawable;

import android.animation.Animator;
import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.animation.Keyframe;
import android.animation.ObjectAnimator;
import android.animation.PropertyValuesHolder;
import android.animation.TimeInterpolator;
import android.animation.TypeEvaluator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.content.res.XmlResourceParser;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.os.Build;
import android.support.annotation.AnimatorRes;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.TypedArrayUtils;
import android.support.v4.graphics.PathParser;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.util.Xml;
import java.io.IOException;
import java.util.ArrayList;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class AnimatorInflaterCompat {
  private static final boolean DBG_ANIMATOR_INFLATER = false;
  
  private static final int MAX_NUM_POINTS = 100;
  
  private static final String TAG = "AnimatorInflater";
  
  private static final int TOGETHER = 0;
  
  private static final int VALUE_TYPE_COLOR = 3;
  
  private static final int VALUE_TYPE_FLOAT = 0;
  
  private static final int VALUE_TYPE_INT = 1;
  
  private static final int VALUE_TYPE_PATH = 2;
  
  private static final int VALUE_TYPE_UNDEFINED = 4;
  
  private static Animator createAnimatorFromXml(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, float paramFloat) {
    return createAnimatorFromXml(paramContext, paramResources, paramTheme, paramXmlPullParser, Xml.asAttributeSet(paramXmlPullParser), null, 0, paramFloat);
  }
  
  private static Animator createAnimatorFromXml(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet, AnimatorSet paramAnimatorSet, int paramInt, float paramFloat) {
    // Byte code:
    //   0: aload_3
    //   1: invokeinterface getDepth : ()I
    //   6: istore #8
    //   8: aconst_null
    //   9: astore #9
    //   11: aconst_null
    //   12: astore #10
    //   14: aload_3
    //   15: invokeinterface next : ()I
    //   20: istore #11
    //   22: iconst_0
    //   23: istore #12
    //   25: iload #11
    //   27: iconst_3
    //   28: if_icmpne -> 42
    //   31: aload_3
    //   32: invokeinterface getDepth : ()I
    //   37: iload #8
    //   39: if_icmple -> 329
    //   42: iload #11
    //   44: iconst_1
    //   45: if_icmpeq -> 329
    //   48: iload #11
    //   50: iconst_2
    //   51: if_icmpeq -> 57
    //   54: goto -> 14
    //   57: aload_3
    //   58: invokeinterface getName : ()Ljava/lang/String;
    //   63: astore #17
    //   65: aload #17
    //   67: ldc 'objectAnimator'
    //   69: invokevirtual equals : (Ljava/lang/Object;)Z
    //   72: ifeq -> 94
    //   75: aload_0
    //   76: aload_1
    //   77: aload_2
    //   78: aload #4
    //   80: fload #7
    //   82: aload_3
    //   83: invokestatic loadObjectAnimator : (Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;FLorg/xmlpull/v1/XmlPullParser;)Landroid/animation/ObjectAnimator;
    //   86: astore #9
    //   88: iconst_0
    //   89: istore #22
    //   91: goto -> 252
    //   94: aload #17
    //   96: ldc 'animator'
    //   98: invokevirtual equals : (Ljava/lang/Object;)Z
    //   101: ifeq -> 121
    //   104: aload_0
    //   105: aload_1
    //   106: aload_2
    //   107: aload #4
    //   109: aconst_null
    //   110: fload #7
    //   112: aload_3
    //   113: invokestatic loadAnimator : (Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;Landroid/animation/ValueAnimator;FLorg/xmlpull/v1/XmlPullParser;)Landroid/animation/ValueAnimator;
    //   116: astore #9
    //   118: goto -> 88
    //   121: aload #17
    //   123: ldc 'set'
    //   125: invokevirtual equals : (Ljava/lang/Object;)Z
    //   128: ifeq -> 198
    //   131: new android/animation/AnimatorSet
    //   134: dup
    //   135: invokespecial <init> : ()V
    //   138: astore #18
    //   140: aload_1
    //   141: aload_2
    //   142: aload #4
    //   144: getstatic android/support/graphics/drawable/AndroidResources.STYLEABLE_ANIMATOR_SET : [I
    //   147: invokestatic obtainAttributes : (Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Landroid/util/AttributeSet;[I)Landroid/content/res/TypedArray;
    //   150: astore #19
    //   152: aload #19
    //   154: aload_3
    //   155: ldc 'ordering'
    //   157: iconst_0
    //   158: iconst_0
    //   159: invokestatic getNamedInt : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;II)I
    //   162: istore #20
    //   164: aload_0
    //   165: aload_1
    //   166: aload_2
    //   167: aload_3
    //   168: aload #4
    //   170: aload #18
    //   172: checkcast android/animation/AnimatorSet
    //   175: iload #20
    //   177: fload #7
    //   179: invokestatic createAnimatorFromXml : (Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;Landroid/animation/AnimatorSet;IF)Landroid/animation/Animator;
    //   182: pop
    //   183: aload #19
    //   185: invokevirtual recycle : ()V
    //   188: aload #18
    //   190: astore #9
    //   192: iconst_0
    //   193: istore #22
    //   195: goto -> 252
    //   198: aload #17
    //   200: ldc 'propertyValuesHolder'
    //   202: invokevirtual equals : (Ljava/lang/Object;)Z
    //   205: ifeq -> 287
    //   208: aload_0
    //   209: aload_1
    //   210: aload_2
    //   211: aload_3
    //   212: aload_3
    //   213: invokestatic asAttributeSet : (Lorg/xmlpull/v1/XmlPullParser;)Landroid/util/AttributeSet;
    //   216: invokestatic loadValues : (Landroid/content/Context;Landroid/content/res/Resources;Landroid/content/res/Resources$Theme;Lorg/xmlpull/v1/XmlPullParser;Landroid/util/AttributeSet;)[Landroid/animation/PropertyValuesHolder;
    //   219: astore #27
    //   221: aload #27
    //   223: ifnull -> 249
    //   226: aload #9
    //   228: ifnull -> 249
    //   231: aload #9
    //   233: instanceof android/animation/ValueAnimator
    //   236: ifeq -> 249
    //   239: aload #9
    //   241: checkcast android/animation/ValueAnimator
    //   244: aload #27
    //   246: invokevirtual setValues : ([Landroid/animation/PropertyValuesHolder;)V
    //   249: iconst_1
    //   250: istore #22
    //   252: aload #5
    //   254: ifnull -> 14
    //   257: iload #22
    //   259: ifne -> 14
    //   262: aload #10
    //   264: ifnonnull -> 276
    //   267: new java/util/ArrayList
    //   270: dup
    //   271: invokespecial <init> : ()V
    //   274: astore #10
    //   276: aload #10
    //   278: aload #9
    //   280: invokevirtual add : (Ljava/lang/Object;)Z
    //   283: pop
    //   284: goto -> 14
    //   287: new java/lang/StringBuilder
    //   290: dup
    //   291: invokespecial <init> : ()V
    //   294: astore #24
    //   296: aload #24
    //   298: ldc 'Unknown animator name: '
    //   300: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   303: pop
    //   304: aload #24
    //   306: aload_3
    //   307: invokeinterface getName : ()Ljava/lang/String;
    //   312: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   315: pop
    //   316: new java/lang/RuntimeException
    //   319: dup
    //   320: aload #24
    //   322: invokevirtual toString : ()Ljava/lang/String;
    //   325: invokespecial <init> : (Ljava/lang/String;)V
    //   328: athrow
    //   329: aload #5
    //   331: ifnull -> 420
    //   334: aload #10
    //   336: ifnull -> 420
    //   339: aload #10
    //   341: invokevirtual size : ()I
    //   344: anewarray android/animation/Animator
    //   347: astore #13
    //   349: aload #10
    //   351: invokevirtual iterator : ()Ljava/util/Iterator;
    //   354: astore #14
    //   356: aload #14
    //   358: invokeinterface hasNext : ()Z
    //   363: ifeq -> 398
    //   366: aload #14
    //   368: invokeinterface next : ()Ljava/lang/Object;
    //   373: checkcast android/animation/Animator
    //   376: astore #15
    //   378: iload #12
    //   380: iconst_1
    //   381: iadd
    //   382: istore #16
    //   384: aload #13
    //   386: iload #12
    //   388: aload #15
    //   390: aastore
    //   391: iload #16
    //   393: istore #12
    //   395: goto -> 356
    //   398: iload #6
    //   400: ifne -> 413
    //   403: aload #5
    //   405: aload #13
    //   407: invokevirtual playTogether : ([Landroid/animation/Animator;)V
    //   410: aload #9
    //   412: areturn
    //   413: aload #5
    //   415: aload #13
    //   417: invokevirtual playSequentially : ([Landroid/animation/Animator;)V
    //   420: aload #9
    //   422: areturn
  }
  
  private static Keyframe createNewKeyframe(Keyframe paramKeyframe, float paramFloat) {
    return (paramKeyframe.getType() == float.class) ? Keyframe.ofFloat(paramFloat) : ((paramKeyframe.getType() == int.class) ? Keyframe.ofInt(paramFloat) : Keyframe.ofObject(paramFloat));
  }
  
  private static void distributeKeyframes(Keyframe[] paramArrayOfKeyframe, float paramFloat, int paramInt1, int paramInt2) {
    float f = paramFloat / (2 + paramInt2 - paramInt1);
    while (paramInt1 <= paramInt2) {
      paramArrayOfKeyframe[paramInt1].setFraction(f + paramArrayOfKeyframe[paramInt1 - 1].getFraction());
      paramInt1++;
    } 
  }
  
  private static void dumpKeyframes(Object[] paramArrayOfObject, String paramString) {
    if (paramArrayOfObject != null) {
      if (paramArrayOfObject.length == 0)
        return; 
      Log.d("AnimatorInflater", paramString);
      int i = paramArrayOfObject.length;
      for (byte b = 0; b < i; b++) {
        Float float_;
        Object object;
        Keyframe keyframe = (Keyframe)paramArrayOfObject[b];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Keyframe ");
        stringBuilder.append(b);
        stringBuilder.append(": fraction ");
        if (keyframe.getFraction() < 0.0F) {
          String str = "null";
        } else {
          float_ = Float.valueOf(keyframe.getFraction());
        } 
        stringBuilder.append(float_);
        stringBuilder.append(", ");
        stringBuilder.append(", value : ");
        if (keyframe.hasValue()) {
          object = keyframe.getValue();
        } else {
          object = "null";
        } 
        stringBuilder.append(object);
        Log.d("AnimatorInflater", stringBuilder.toString());
      } 
      return;
    } 
  }
  
  private static PropertyValuesHolder getPVH(TypedArray paramTypedArray, int paramInt1, int paramInt2, int paramInt3, String paramString) {
    // Byte code:
    //   0: aload_0
    //   1: iload_2
    //   2: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   5: astore #5
    //   7: aload #5
    //   9: ifnull -> 18
    //   12: iconst_1
    //   13: istore #6
    //   15: goto -> 21
    //   18: iconst_0
    //   19: istore #6
    //   21: iload #6
    //   23: ifeq -> 36
    //   26: aload #5
    //   28: getfield type : I
    //   31: istore #7
    //   33: goto -> 39
    //   36: iconst_0
    //   37: istore #7
    //   39: aload_0
    //   40: iload_3
    //   41: invokevirtual peekValue : (I)Landroid/util/TypedValue;
    //   44: astore #8
    //   46: aload #8
    //   48: ifnull -> 57
    //   51: iconst_1
    //   52: istore #9
    //   54: goto -> 60
    //   57: iconst_0
    //   58: istore #9
    //   60: iload #9
    //   62: ifeq -> 75
    //   65: aload #8
    //   67: getfield type : I
    //   70: istore #10
    //   72: goto -> 78
    //   75: iconst_0
    //   76: istore #10
    //   78: iload_1
    //   79: iconst_4
    //   80: if_icmpne -> 116
    //   83: iload #6
    //   85: ifeq -> 96
    //   88: iload #7
    //   90: invokestatic isColorType : (I)Z
    //   93: ifne -> 109
    //   96: iload #9
    //   98: ifeq -> 114
    //   101: iload #10
    //   103: invokestatic isColorType : (I)Z
    //   106: ifeq -> 114
    //   109: iconst_3
    //   110: istore_1
    //   111: goto -> 116
    //   114: iconst_0
    //   115: istore_1
    //   116: iload_1
    //   117: ifne -> 126
    //   120: iconst_1
    //   121: istore #11
    //   123: goto -> 129
    //   126: iconst_0
    //   127: istore #11
    //   129: iload_1
    //   130: iconst_2
    //   131: if_icmpne -> 339
    //   134: aload_0
    //   135: iload_2
    //   136: invokevirtual getString : (I)Ljava/lang/String;
    //   139: astore #21
    //   141: aload_0
    //   142: iload_3
    //   143: invokevirtual getString : (I)Ljava/lang/String;
    //   146: astore #22
    //   148: aload #21
    //   150: invokestatic createNodesFromPathData : (Ljava/lang/String;)[Landroid/support/v4/graphics/PathParser$PathDataNode;
    //   153: astore #23
    //   155: aload #22
    //   157: invokestatic createNodesFromPathData : (Ljava/lang/String;)[Landroid/support/v4/graphics/PathParser$PathDataNode;
    //   160: astore #24
    //   162: aload #23
    //   164: ifnonnull -> 175
    //   167: aconst_null
    //   168: astore #13
    //   170: aload #24
    //   172: ifnull -> 734
    //   175: aload #23
    //   177: ifnull -> 308
    //   180: new android/support/graphics/drawable/AnimatorInflaterCompat$PathDataEvaluator
    //   183: dup
    //   184: aconst_null
    //   185: invokespecial <init> : (Landroid/support/graphics/drawable/AnimatorInflaterCompat$1;)V
    //   188: astore #25
    //   190: aload #24
    //   192: ifnull -> 287
    //   195: aload #23
    //   197: aload #24
    //   199: invokestatic canMorph : ([Landroid/support/v4/graphics/PathParser$PathDataNode;[Landroid/support/v4/graphics/PathParser$PathDataNode;)Z
    //   202: ifeq -> 231
    //   205: aload #4
    //   207: aload #25
    //   209: iconst_2
    //   210: anewarray java/lang/Object
    //   213: dup
    //   214: iconst_0
    //   215: aload #23
    //   217: aastore
    //   218: dup
    //   219: iconst_1
    //   220: aload #24
    //   222: aastore
    //   223: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   226: astore #26
    //   228: goto -> 305
    //   231: new java/lang/StringBuilder
    //   234: dup
    //   235: invokespecial <init> : ()V
    //   238: astore #27
    //   240: aload #27
    //   242: ldc_w ' Can't morph from '
    //   245: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   248: pop
    //   249: aload #27
    //   251: aload #21
    //   253: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   256: pop
    //   257: aload #27
    //   259: ldc_w ' to '
    //   262: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   265: pop
    //   266: aload #27
    //   268: aload #22
    //   270: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   273: pop
    //   274: new android/view/InflateException
    //   277: dup
    //   278: aload #27
    //   280: invokevirtual toString : ()Ljava/lang/String;
    //   283: invokespecial <init> : (Ljava/lang/String;)V
    //   286: athrow
    //   287: aload #4
    //   289: aload #25
    //   291: iconst_1
    //   292: anewarray java/lang/Object
    //   295: dup
    //   296: iconst_0
    //   297: aload #23
    //   299: aastore
    //   300: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   303: astore #26
    //   305: aload #26
    //   307: areturn
    //   308: aconst_null
    //   309: astore #13
    //   311: aload #24
    //   313: ifnull -> 734
    //   316: aload #4
    //   318: new android/support/graphics/drawable/AnimatorInflaterCompat$PathDataEvaluator
    //   321: dup
    //   322: aconst_null
    //   323: invokespecial <init> : (Landroid/support/graphics/drawable/AnimatorInflaterCompat$1;)V
    //   326: iconst_1
    //   327: anewarray java/lang/Object
    //   330: dup
    //   331: iconst_0
    //   332: aload #24
    //   334: aastore
    //   335: invokestatic ofObject : (Ljava/lang/String;Landroid/animation/TypeEvaluator;[Ljava/lang/Object;)Landroid/animation/PropertyValuesHolder;
    //   338: areturn
    //   339: iload_1
    //   340: iconst_3
    //   341: if_icmpne -> 352
    //   344: invokestatic getInstance : ()Landroid/support/graphics/drawable/ArgbEvaluator;
    //   347: astore #12
    //   349: goto -> 355
    //   352: aconst_null
    //   353: astore #12
    //   355: iload #11
    //   357: ifeq -> 508
    //   360: iload #6
    //   362: ifeq -> 461
    //   365: iload #7
    //   367: iconst_5
    //   368: if_icmpne -> 382
    //   371: aload_0
    //   372: iload_2
    //   373: fconst_0
    //   374: invokevirtual getDimension : (IF)F
    //   377: fstore #19
    //   379: goto -> 390
    //   382: aload_0
    //   383: iload_2
    //   384: fconst_0
    //   385: invokevirtual getFloat : (IF)F
    //   388: fstore #19
    //   390: iload #9
    //   392: ifeq -> 443
    //   395: iload #10
    //   397: iconst_5
    //   398: if_icmpne -> 412
    //   401: aload_0
    //   402: iload_3
    //   403: fconst_0
    //   404: invokevirtual getDimension : (IF)F
    //   407: fstore #20
    //   409: goto -> 420
    //   412: aload_0
    //   413: iload_3
    //   414: fconst_0
    //   415: invokevirtual getFloat : (IF)F
    //   418: fstore #20
    //   420: aload #4
    //   422: iconst_2
    //   423: newarray float
    //   425: dup
    //   426: iconst_0
    //   427: fload #19
    //   429: fastore
    //   430: dup
    //   431: iconst_1
    //   432: fload #20
    //   434: fastore
    //   435: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   438: astore #18
    //   440: goto -> 501
    //   443: aload #4
    //   445: iconst_1
    //   446: newarray float
    //   448: dup
    //   449: iconst_0
    //   450: fload #19
    //   452: fastore
    //   453: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   456: astore #18
    //   458: goto -> 501
    //   461: iload #10
    //   463: iconst_5
    //   464: if_icmpne -> 478
    //   467: aload_0
    //   468: iload_3
    //   469: fconst_0
    //   470: invokevirtual getDimension : (IF)F
    //   473: fstore #17
    //   475: goto -> 486
    //   478: aload_0
    //   479: iload_3
    //   480: fconst_0
    //   481: invokevirtual getFloat : (IF)F
    //   484: fstore #17
    //   486: aload #4
    //   488: iconst_1
    //   489: newarray float
    //   491: dup
    //   492: iconst_0
    //   493: fload #17
    //   495: fastore
    //   496: invokestatic ofFloat : (Ljava/lang/String;[F)Landroid/animation/PropertyValuesHolder;
    //   499: astore #18
    //   501: aload #18
    //   503: astore #13
    //   505: goto -> 717
    //   508: iload #6
    //   510: ifeq -> 649
    //   513: iload #7
    //   515: iconst_5
    //   516: if_icmpne -> 531
    //   519: aload_0
    //   520: iload_2
    //   521: fconst_0
    //   522: invokevirtual getDimension : (IF)F
    //   525: f2i
    //   526: istore #15
    //   528: goto -> 558
    //   531: iload #7
    //   533: invokestatic isColorType : (I)Z
    //   536: ifeq -> 550
    //   539: aload_0
    //   540: iload_2
    //   541: iconst_0
    //   542: invokevirtual getColor : (II)I
    //   545: istore #15
    //   547: goto -> 558
    //   550: aload_0
    //   551: iload_2
    //   552: iconst_0
    //   553: invokevirtual getInt : (II)I
    //   556: istore #15
    //   558: iload #9
    //   560: ifeq -> 631
    //   563: iload #10
    //   565: iconst_5
    //   566: if_icmpne -> 581
    //   569: aload_0
    //   570: iload_3
    //   571: fconst_0
    //   572: invokevirtual getDimension : (IF)F
    //   575: f2i
    //   576: istore #16
    //   578: goto -> 608
    //   581: iload #10
    //   583: invokestatic isColorType : (I)Z
    //   586: ifeq -> 600
    //   589: aload_0
    //   590: iload_3
    //   591: iconst_0
    //   592: invokevirtual getColor : (II)I
    //   595: istore #16
    //   597: goto -> 608
    //   600: aload_0
    //   601: iload_3
    //   602: iconst_0
    //   603: invokevirtual getInt : (II)I
    //   606: istore #16
    //   608: aload #4
    //   610: iconst_2
    //   611: newarray int
    //   613: dup
    //   614: iconst_0
    //   615: iload #15
    //   617: iastore
    //   618: dup
    //   619: iconst_1
    //   620: iload #16
    //   622: iastore
    //   623: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   626: astore #13
    //   628: goto -> 717
    //   631: aload #4
    //   633: iconst_1
    //   634: newarray int
    //   636: dup
    //   637: iconst_0
    //   638: iload #15
    //   640: iastore
    //   641: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   644: astore #13
    //   646: goto -> 717
    //   649: aconst_null
    //   650: astore #13
    //   652: iload #9
    //   654: ifeq -> 717
    //   657: iload #10
    //   659: iconst_5
    //   660: if_icmpne -> 675
    //   663: aload_0
    //   664: iload_3
    //   665: fconst_0
    //   666: invokevirtual getDimension : (IF)F
    //   669: f2i
    //   670: istore #14
    //   672: goto -> 702
    //   675: iload #10
    //   677: invokestatic isColorType : (I)Z
    //   680: ifeq -> 694
    //   683: aload_0
    //   684: iload_3
    //   685: iconst_0
    //   686: invokevirtual getColor : (II)I
    //   689: istore #14
    //   691: goto -> 702
    //   694: aload_0
    //   695: iload_3
    //   696: iconst_0
    //   697: invokevirtual getInt : (II)I
    //   700: istore #14
    //   702: aload #4
    //   704: iconst_1
    //   705: newarray int
    //   707: dup
    //   708: iconst_0
    //   709: iload #14
    //   711: iastore
    //   712: invokestatic ofInt : (Ljava/lang/String;[I)Landroid/animation/PropertyValuesHolder;
    //   715: astore #13
    //   717: aload #13
    //   719: ifnull -> 734
    //   722: aload #12
    //   724: ifnull -> 734
    //   727: aload #13
    //   729: aload #12
    //   731: invokevirtual setEvaluator : (Landroid/animation/TypeEvaluator;)V
    //   734: aload #13
    //   736: areturn
  }
  
  private static int inferValueTypeFromValues(TypedArray paramTypedArray, int paramInt1, int paramInt2) {
    boolean bool2;
    boolean bool3;
    boolean bool4;
    TypedValue typedValue1 = paramTypedArray.peekValue(paramInt1);
    boolean bool1 = true;
    if (typedValue1 != null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool2) {
      bool3 = typedValue1.type;
    } else {
      bool3 = false;
    } 
    TypedValue typedValue2 = paramTypedArray.peekValue(paramInt2);
    if (typedValue2 == null)
      bool1 = false; 
    if (bool1) {
      bool4 = typedValue2.type;
    } else {
      bool4 = false;
    } 
    if (!bool2 || !isColorType(bool3)) {
      byte b = 0;
      if (bool1) {
        boolean bool = isColorType(bool4);
        b = 0;
        if (bool)
          return 3; 
      } 
      return b;
    } 
    return 3;
  }
  
  private static int inferValueTypeOfKeyframe(Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, XmlPullParser paramXmlPullParser) {
    boolean bool;
    TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_KEYFRAME);
    TypedValue typedValue = TypedArrayUtils.peekNamedValue(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null) {
      bool = true;
    } else {
      bool = false;
    } 
    byte b = 0;
    if (bool) {
      boolean bool1 = isColorType(typedValue.type);
      b = 0;
      if (bool1)
        b = 3; 
    } 
    typedArray.recycle();
    return b;
  }
  
  private static boolean isColorType(int paramInt) {
    return (paramInt >= 28 && paramInt <= 31);
  }
  
  public static Animator loadAnimator(Context paramContext, @AnimatorRes int paramInt) {
    return (Build.VERSION.SDK_INT >= 24) ? AnimatorInflater.loadAnimator(paramContext, paramInt) : loadAnimator(paramContext, paramContext.getResources(), paramContext.getTheme(), paramInt);
  }
  
  public static Animator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, @AnimatorRes int paramInt) {
    return loadAnimator(paramContext, paramResources, paramTheme, paramInt, 1.0F);
  }
  
  public static Animator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, @AnimatorRes int paramInt, float paramFloat) {
    XmlResourceParser xmlResourceParser = null;
    try {
      XmlResourceParser xmlResourceParser1 = paramResources.getAnimation(paramInt);
    } catch (XmlPullParserException xmlPullParserException) {
    
    } catch (IOException iOException) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Can't load animation resource ID #0x");
      stringBuilder1.append(Integer.toHexString(paramInt));
      Resources.NotFoundException notFoundException1 = new Resources.NotFoundException(stringBuilder1.toString());
      notFoundException1.initCause(iOException);
      throw notFoundException1;
    } finally {
      if (xmlResourceParser != null)
        xmlResourceParser.close(); 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Can't load animation resource ID #0x");
    stringBuilder.append(Integer.toHexString(paramInt));
    Resources.NotFoundException notFoundException = new Resources.NotFoundException(stringBuilder.toString());
    notFoundException.initCause((Throwable)xmlPullParserException);
    throw notFoundException;
  }
  
  private static ValueAnimator loadAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, ValueAnimator paramValueAnimator, float paramFloat, XmlPullParser paramXmlPullParser) {
    TypedArray typedArray1 = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_ANIMATOR);
    TypedArray typedArray2 = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_PROPERTY_ANIMATOR);
    if (paramValueAnimator == null)
      paramValueAnimator = new ValueAnimator(); 
    parseAnimatorFromTypeArray(paramValueAnimator, typedArray1, typedArray2, paramFloat, paramXmlPullParser);
    int i = TypedArrayUtils.getNamedResourceId(typedArray1, paramXmlPullParser, "interpolator", 0, 0);
    if (i > 0)
      paramValueAnimator.setInterpolator((TimeInterpolator)AnimationUtilsCompat.loadInterpolator(paramContext, i)); 
    typedArray1.recycle();
    if (typedArray2 != null)
      typedArray2.recycle(); 
    return paramValueAnimator;
  }
  
  private static Keyframe loadKeyframe(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, int paramInt, XmlPullParser paramXmlPullParser) {
    boolean bool;
    Keyframe keyframe;
    TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_KEYFRAME);
    float f = TypedArrayUtils.getNamedFloat(typedArray, paramXmlPullParser, "fraction", 3, -1.0F);
    TypedValue typedValue = TypedArrayUtils.peekNamedValue(typedArray, paramXmlPullParser, "value", 0);
    if (typedValue != null) {
      bool = true;
    } else {
      bool = false;
    } 
    if (paramInt == 4)
      if (bool && isColorType(typedValue.type)) {
        paramInt = 3;
      } else {
        paramInt = 0;
      }  
    if (bool) {
      if (paramInt != 3) {
        switch (paramInt) {
          default:
            keyframe = null;
            break;
          case 0:
            keyframe = Keyframe.ofFloat(f, TypedArrayUtils.getNamedFloat(typedArray, paramXmlPullParser, "value", 0, 0.0F));
            break;
          case 1:
            keyframe = Keyframe.ofInt(f, TypedArrayUtils.getNamedInt(typedArray, paramXmlPullParser, "value", 0, 0));
            break;
        } 
      } else {
      
      } 
    } else if (paramInt == 0) {
      keyframe = Keyframe.ofFloat(f);
    } else {
      keyframe = Keyframe.ofInt(f);
    } 
    int i = TypedArrayUtils.getNamedResourceId(typedArray, paramXmlPullParser, "interpolator", 1, 0);
    if (i > 0)
      keyframe.setInterpolator((TimeInterpolator)AnimationUtilsCompat.loadInterpolator(paramContext, i)); 
    typedArray.recycle();
    return keyframe;
  }
  
  private static ObjectAnimator loadObjectAnimator(Context paramContext, Resources paramResources, Resources.Theme paramTheme, AttributeSet paramAttributeSet, float paramFloat, XmlPullParser paramXmlPullParser) {
    ObjectAnimator objectAnimator = new ObjectAnimator();
    loadAnimator(paramContext, paramResources, paramTheme, paramAttributeSet, (ValueAnimator)objectAnimator, paramFloat, paramXmlPullParser);
    return objectAnimator;
  }
  
  private static PropertyValuesHolder loadPvh(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, String paramString, int paramInt) {
    int i = paramInt;
    ArrayList<Keyframe> arrayList = null;
    while (true) {
      int j = paramXmlPullParser.next();
      if (j != 3 && j != 1) {
        if (paramXmlPullParser.getName().equals("keyframe")) {
          if (i == 4)
            i = inferValueTypeOfKeyframe(paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), paramXmlPullParser); 
          Keyframe keyframe = loadKeyframe(paramContext, paramResources, paramTheme, Xml.asAttributeSet(paramXmlPullParser), i, paramXmlPullParser);
          if (keyframe != null) {
            if (arrayList == null)
              arrayList = new ArrayList(); 
            arrayList.add(keyframe);
          } 
          paramXmlPullParser.next();
        } 
        continue;
      } 
      break;
    } 
    PropertyValuesHolder propertyValuesHolder = null;
    if (arrayList != null) {
      int j = arrayList.size();
      propertyValuesHolder = null;
      if (j > 0) {
        byte b = 0;
        Keyframe keyframe1 = arrayList.get(0);
        Keyframe keyframe2 = arrayList.get(j - 1);
        float f1 = keyframe2.getFraction();
        if (f1 < 1.0F)
          if (f1 < 0.0F) {
            keyframe2.setFraction(1.0F);
          } else {
            arrayList.add(arrayList.size(), createNewKeyframe(keyframe2, 1.0F));
            j++;
          }  
        float f2 = keyframe1.getFraction();
        if (f2 != 0.0F)
          if (f2 < 0.0F) {
            keyframe1.setFraction(0.0F);
          } else {
            arrayList.add(0, createNewKeyframe(keyframe1, 0.0F));
            j++;
          }  
        Keyframe[] arrayOfKeyframe = new Keyframe[j];
        arrayList.toArray(arrayOfKeyframe);
        while (b < j) {
          Keyframe keyframe = arrayOfKeyframe[b];
          if (keyframe.getFraction() < 0.0F)
            if (b == 0) {
              keyframe.setFraction(0.0F);
            } else {
              int k = j - 1;
              if (b == k) {
                keyframe.setFraction(1.0F);
              } else {
                int m = b + 1;
                int n = b;
                while (m < k && arrayOfKeyframe[m].getFraction() < 0.0F) {
                  int i1 = m + 1;
                  n = m;
                  m = i1;
                } 
                distributeKeyframes(arrayOfKeyframe, arrayOfKeyframe[n + 1].getFraction() - arrayOfKeyframe[b - 1].getFraction(), b, n);
              } 
            }  
          b++;
        } 
        propertyValuesHolder = PropertyValuesHolder.ofKeyframe(paramString, arrayOfKeyframe);
        if (i == 3)
          propertyValuesHolder.setEvaluator(ArgbEvaluator.getInstance()); 
      } 
    } 
    return propertyValuesHolder;
  }
  
  private static PropertyValuesHolder[] loadValues(Context paramContext, Resources paramResources, Resources.Theme paramTheme, XmlPullParser paramXmlPullParser, AttributeSet paramAttributeSet) {
    byte b;
    ArrayList<PropertyValuesHolder> arrayList = null;
    while (true) {
      int i = paramXmlPullParser.getEventType();
      b = 0;
      if (i != 3 && i != 1) {
        if (i != 2) {
          paramXmlPullParser.next();
          continue;
        } 
        if (paramXmlPullParser.getName().equals("propertyValuesHolder")) {
          TypedArray typedArray = TypedArrayUtils.obtainAttributes(paramResources, paramTheme, paramAttributeSet, AndroidResources.STYLEABLE_PROPERTY_VALUES_HOLDER);
          String str = TypedArrayUtils.getNamedString(typedArray, paramXmlPullParser, "propertyName", 3);
          int j = TypedArrayUtils.getNamedInt(typedArray, paramXmlPullParser, "valueType", 2, 4);
          PropertyValuesHolder propertyValuesHolder = loadPvh(paramContext, paramResources, paramTheme, paramXmlPullParser, str, j);
          if (propertyValuesHolder == null)
            propertyValuesHolder = getPVH(typedArray, j, 0, 1, str); 
          if (propertyValuesHolder != null) {
            if (arrayList == null)
              arrayList = new ArrayList(); 
            arrayList.add(propertyValuesHolder);
          } 
          typedArray.recycle();
        } 
        paramXmlPullParser.next();
        continue;
      } 
      break;
    } 
    PropertyValuesHolder[] arrayOfPropertyValuesHolder = null;
    if (arrayList != null) {
      int i = arrayList.size();
      arrayOfPropertyValuesHolder = new PropertyValuesHolder[i];
      while (b < i) {
        arrayOfPropertyValuesHolder[b] = arrayList.get(b);
        b++;
      } 
    } 
    return arrayOfPropertyValuesHolder;
  }
  
  private static void parseAnimatorFromTypeArray(ValueAnimator paramValueAnimator, TypedArray paramTypedArray1, TypedArray paramTypedArray2, float paramFloat, XmlPullParser paramXmlPullParser) {
    long l1 = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "duration", 1, 300);
    long l2 = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "startOffset", 2, 0);
    int i = TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "valueType", 7, 4);
    if (TypedArrayUtils.hasAttribute(paramXmlPullParser, "valueFrom") && TypedArrayUtils.hasAttribute(paramXmlPullParser, "valueTo")) {
      if (i == 4)
        i = inferValueTypeFromValues(paramTypedArray1, 5, 6); 
      PropertyValuesHolder propertyValuesHolder = getPVH(paramTypedArray1, i, 5, 6, "");
      if (propertyValuesHolder != null)
        paramValueAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder }); 
    } 
    paramValueAnimator.setDuration(l1);
    paramValueAnimator.setStartDelay(l2);
    paramValueAnimator.setRepeatCount(TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "repeatCount", 3, 0));
    paramValueAnimator.setRepeatMode(TypedArrayUtils.getNamedInt(paramTypedArray1, paramXmlPullParser, "repeatMode", 4, 1));
    if (paramTypedArray2 != null)
      setupObjectAnimator(paramValueAnimator, paramTypedArray2, i, paramFloat, paramXmlPullParser); 
  }
  
  private static void setupObjectAnimator(ValueAnimator paramValueAnimator, TypedArray paramTypedArray, int paramInt, float paramFloat, XmlPullParser paramXmlPullParser) {
    // Byte code:
    //   0: aload_0
    //   1: checkcast android/animation/ObjectAnimator
    //   4: astore #5
    //   6: aload_1
    //   7: aload #4
    //   9: ldc_w 'pathData'
    //   12: iconst_1
    //   13: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   16: astore #6
    //   18: aload #6
    //   20: ifnull -> 126
    //   23: aload_1
    //   24: aload #4
    //   26: ldc_w 'propertyXName'
    //   29: iconst_2
    //   30: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   33: astore #7
    //   35: aload_1
    //   36: aload #4
    //   38: ldc_w 'propertyYName'
    //   41: iconst_3
    //   42: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   45: astore #8
    //   47: iload_2
    //   48: iconst_2
    //   49: if_icmpeq -> 52
    //   52: aload #7
    //   54: ifnonnull -> 106
    //   57: aload #8
    //   59: ifnull -> 65
    //   62: goto -> 106
    //   65: new java/lang/StringBuilder
    //   68: dup
    //   69: invokespecial <init> : ()V
    //   72: astore #9
    //   74: aload #9
    //   76: aload_1
    //   77: invokevirtual getPositionDescription : ()Ljava/lang/String;
    //   80: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   83: pop
    //   84: aload #9
    //   86: ldc_w ' propertyXName or propertyYName is needed for PathData'
    //   89: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   92: pop
    //   93: new android/view/InflateException
    //   96: dup
    //   97: aload #9
    //   99: invokevirtual toString : ()Ljava/lang/String;
    //   102: invokespecial <init> : (Ljava/lang/String;)V
    //   105: athrow
    //   106: aload #6
    //   108: invokestatic createPathFromPathData : (Ljava/lang/String;)Landroid/graphics/Path;
    //   111: aload #5
    //   113: fload_3
    //   114: ldc_w 0.5
    //   117: fmul
    //   118: aload #7
    //   120: aload #8
    //   122: invokestatic setupPathMotion : (Landroid/graphics/Path;Landroid/animation/ObjectAnimator;FLjava/lang/String;Ljava/lang/String;)V
    //   125: return
    //   126: aload #5
    //   128: aload_1
    //   129: aload #4
    //   131: ldc_w 'propertyName'
    //   134: iconst_0
    //   135: invokestatic getNamedString : (Landroid/content/res/TypedArray;Lorg/xmlpull/v1/XmlPullParser;Ljava/lang/String;I)Ljava/lang/String;
    //   138: invokevirtual setPropertyName : (Ljava/lang/String;)V
    //   141: return
  }
  
  private static void setupPathMotion(Path paramPath, ObjectAnimator paramObjectAnimator, float paramFloat, String paramString1, String paramString2) {
    PathMeasure pathMeasure = new PathMeasure(paramPath, false);
    ArrayList<Float> arrayList = new ArrayList();
    arrayList.add(Float.valueOf(0.0F));
    float f = 0.0F;
    while (true) {
      f += pathMeasure.getLength();
      arrayList.add(Float.valueOf(f));
      if (!pathMeasure.nextContour()) {
        PropertyValuesHolder propertyValuesHolder1;
        PathMeasure pathMeasure1 = new PathMeasure(paramPath, false);
        int i = Math.min(100, 1 + (int)(f / paramFloat));
        float[] arrayOfFloat1 = new float[i];
        float[] arrayOfFloat2 = new float[i];
        float[] arrayOfFloat3 = new float[2];
        float f1 = f / (i - 1);
        byte b = 0;
        float f2 = 0.0F;
        int j = 0;
        while (b < i) {
          pathMeasure1.getPosTan(f2, arrayOfFloat3, null);
          arrayOfFloat1[b] = arrayOfFloat3[0];
          arrayOfFloat2[b] = arrayOfFloat3[1];
          f2 += f1;
          int k = j + 1;
          if (k < arrayList.size() && f2 > ((Float)arrayList.get(k)).floatValue()) {
            f2 -= ((Float)arrayList.get(k)).floatValue();
            pathMeasure1.nextContour();
            j = k;
          } 
          b++;
        } 
        if (paramString1 != null) {
          propertyValuesHolder1 = PropertyValuesHolder.ofFloat(paramString1, arrayOfFloat1);
        } else {
          propertyValuesHolder1 = null;
        } 
        PropertyValuesHolder propertyValuesHolder2 = null;
        if (paramString2 != null)
          propertyValuesHolder2 = PropertyValuesHolder.ofFloat(paramString2, arrayOfFloat2); 
        if (propertyValuesHolder1 == null) {
          paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder2 });
          return;
        } 
        if (propertyValuesHolder2 == null) {
          paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder1 });
          return;
        } 
        paramObjectAnimator.setValues(new PropertyValuesHolder[] { propertyValuesHolder1, propertyValuesHolder2 });
        return;
      } 
    } 
  }
  
  private static class PathDataEvaluator implements TypeEvaluator<PathParser.PathDataNode[]> {
    private PathParser.PathDataNode[] mNodeArray;
    
    private PathDataEvaluator() {}
    
    public PathParser.PathDataNode[] evaluate(float param1Float, PathParser.PathDataNode[] param1ArrayOfPathDataNode1, PathParser.PathDataNode[] param1ArrayOfPathDataNode2) {
      if (PathParser.canMorph(param1ArrayOfPathDataNode1, param1ArrayOfPathDataNode2)) {
        if (this.mNodeArray == null || !PathParser.canMorph(this.mNodeArray, param1ArrayOfPathDataNode1))
          this.mNodeArray = PathParser.deepCopyNodes(param1ArrayOfPathDataNode1); 
        for (byte b = 0; b < param1ArrayOfPathDataNode1.length; b++)
          this.mNodeArray[b].interpolatePathDataNode(param1ArrayOfPathDataNode1[b], param1ArrayOfPathDataNode2[b], param1Float); 
        return this.mNodeArray;
      } 
      throw new IllegalArgumentException("Can't interpolate between two incompatible pathData");
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\graphics\drawable\AnimatorInflaterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */