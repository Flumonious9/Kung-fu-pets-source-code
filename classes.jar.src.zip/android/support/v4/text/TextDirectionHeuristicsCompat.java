package android.support.v4.text;

import java.nio.CharBuffer;
import java.util.Locale;

public final class TextDirectionHeuristicsCompat {
  public static final TextDirectionHeuristicCompat ANYRTL_LTR;
  
  public static final TextDirectionHeuristicCompat FIRSTSTRONG_LTR;
  
  public static final TextDirectionHeuristicCompat FIRSTSTRONG_RTL;
  
  public static final TextDirectionHeuristicCompat LOCALE;
  
  public static final TextDirectionHeuristicCompat LTR = new TextDirectionHeuristicInternal(null, false);
  
  public static final TextDirectionHeuristicCompat RTL = new TextDirectionHeuristicInternal(null, true);
  
  private static final int STATE_FALSE = 1;
  
  private static final int STATE_TRUE = 0;
  
  private static final int STATE_UNKNOWN = 2;
  
  static {
    FIRSTSTRONG_LTR = new TextDirectionHeuristicInternal(FirstStrong.a, false);
    FIRSTSTRONG_RTL = new TextDirectionHeuristicInternal(FirstStrong.a, true);
    ANYRTL_LTR = new TextDirectionHeuristicInternal(AnyStrong.a, false);
    LOCALE = TextDirectionHeuristicLocale.a;
  }
  
  static int a(int paramInt) {
    switch (paramInt) {
      default:
        return 2;
      case 1:
      case 2:
        return 0;
      case 0:
        break;
    } 
    return 1;
  }
  
  static int b(int paramInt) {
    switch (paramInt) {
      default:
        switch (paramInt) {
          default:
            return 2;
          case 16:
          case 17:
            return 0;
          case 14:
          case 15:
            break;
        } 
        break;
      case 1:
      case 2:
      
      case 0:
        break;
    } 
    return 1;
  }
  
  private static class AnyStrong implements TextDirectionAlgorithm {
    static final AnyStrong a = new AnyStrong(true);
    
    static final AnyStrong b = new AnyStrong(false);
    
    private final boolean mLookForRtl;
    
    private AnyStrong(boolean param1Boolean) {
      this.mLookForRtl = param1Boolean;
    }
    
    public int checkRtl(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1Int2 + param1Int1;
      boolean bool = false;
      while (param1Int1 < i) {
        switch (TextDirectionHeuristicsCompat.a(Character.getDirectionality(param1CharSequence.charAt(param1Int1)))) {
          case 1:
            if (!this.mLookForRtl)
              return 1; 
            bool = true;
            break;
          case 0:
            if (this.mLookForRtl)
              return 0; 
            bool = true;
            break;
        } 
        param1Int1++;
      } 
      return bool ? this.mLookForRtl : 2;
    }
  }
  
  private static class FirstStrong implements TextDirectionAlgorithm {
    static final FirstStrong a = new FirstStrong();
    
    public int checkRtl(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      int i = param1Int2 + param1Int1;
      int j = 2;
      while (param1Int1 < i && j == 2) {
        j = TextDirectionHeuristicsCompat.b(Character.getDirectionality(param1CharSequence.charAt(param1Int1)));
        param1Int1++;
      } 
      return j;
    }
  }
  
  private static interface TextDirectionAlgorithm {
    int checkRtl(CharSequence param1CharSequence, int param1Int1, int param1Int2);
  }
  
  private static abstract class TextDirectionHeuristicImpl implements TextDirectionHeuristicCompat {
    private final TextDirectionHeuristicsCompat.TextDirectionAlgorithm mAlgorithm;
    
    TextDirectionHeuristicImpl(TextDirectionHeuristicsCompat.TextDirectionAlgorithm param1TextDirectionAlgorithm) {
      this.mAlgorithm = param1TextDirectionAlgorithm;
    }
    
    private boolean doCheck(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      switch (this.mAlgorithm.checkRtl(param1CharSequence, param1Int1, param1Int2)) {
        default:
          return a();
        case 1:
          return false;
        case 0:
          break;
      } 
      return true;
    }
    
    protected abstract boolean a();
    
    public boolean isRtl(CharSequence param1CharSequence, int param1Int1, int param1Int2) {
      if (param1CharSequence != null && param1Int1 >= 0 && param1Int2 >= 0 && param1CharSequence.length() - param1Int2 >= param1Int1)
        return (this.mAlgorithm == null) ? a() : doCheck(param1CharSequence, param1Int1, param1Int2); 
      throw new IllegalArgumentException();
    }
    
    public boolean isRtl(char[] param1ArrayOfchar, int param1Int1, int param1Int2) {
      return isRtl(CharBuffer.wrap(param1ArrayOfchar), param1Int1, param1Int2);
    }
  }
  
  private static class TextDirectionHeuristicInternal extends TextDirectionHeuristicImpl {
    private final boolean mDefaultIsRtl;
    
    TextDirectionHeuristicInternal(TextDirectionHeuristicsCompat.TextDirectionAlgorithm param1TextDirectionAlgorithm, boolean param1Boolean) {
      super(param1TextDirectionAlgorithm);
      this.mDefaultIsRtl = param1Boolean;
    }
    
    protected boolean a() {
      return this.mDefaultIsRtl;
    }
  }
  
  private static class TextDirectionHeuristicLocale extends TextDirectionHeuristicImpl {
    static final TextDirectionHeuristicLocale a = new TextDirectionHeuristicLocale();
    
    TextDirectionHeuristicLocale() {
      super(null);
    }
    
    protected boolean a() {
      return (TextUtilsCompat.getLayoutDirectionFromLocale(Locale.getDefault()) == 1);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\text\TextDirectionHeuristicsCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */