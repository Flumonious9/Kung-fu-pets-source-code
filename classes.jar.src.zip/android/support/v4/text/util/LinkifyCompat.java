package android.support.v4.text.util;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.util.PatternsCompat;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.method.MovementMethod;
import android.text.style.URLSpan;
import android.text.util.Linkify;
import android.widget.TextView;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class LinkifyCompat {
  private static final Comparator<LinkSpec> COMPARATOR;
  
  private static final String[] EMPTY_STRING = new String[0];
  
  static {
    COMPARATOR = new Comparator<LinkSpec>() {
        public int compare(LinkifyCompat.LinkSpec param1LinkSpec1, LinkifyCompat.LinkSpec param1LinkSpec2) {
          return (param1LinkSpec1.c < param1LinkSpec2.c) ? -1 : ((param1LinkSpec1.c > param1LinkSpec2.c) ? 1 : ((param1LinkSpec1.d < param1LinkSpec2.d) ? 1 : ((param1LinkSpec1.d > param1LinkSpec2.d) ? -1 : 0)));
        }
      };
  }
  
  private static void addLinkMovementMethod(@NonNull TextView paramTextView) {
    MovementMethod movementMethod = paramTextView.getMovementMethod();
    if ((movementMethod == null || !(movementMethod instanceof LinkMovementMethod)) && paramTextView.getLinksClickable())
      paramTextView.setMovementMethod(LinkMovementMethod.getInstance()); 
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString);
      return;
    } 
    addLinks(paramTextView, paramPattern, paramString, (String[])null, (Linkify.MatchFilter)null, (Linkify.TransformFilter)null);
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramMatchFilter, paramTransformFilter);
      return;
    } 
    addLinks(paramTextView, paramPattern, paramString, (String[])null, paramMatchFilter, paramTransformFilter);
  }
  
  public static void addLinks(@NonNull TextView paramTextView, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    if (Build.VERSION.SDK_INT >= 26) {
      Linkify.addLinks(paramTextView, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter);
      return;
    } 
    SpannableString spannableString = SpannableString.valueOf(paramTextView.getText());
    if (addLinks((Spannable)spannableString, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter)) {
      paramTextView.setText((CharSequence)spannableString);
      addLinkMovementMethod(paramTextView);
    } 
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, int paramInt) {
    if (Build.VERSION.SDK_INT >= 27)
      return Linkify.addLinks(paramSpannable, paramInt); 
    if (paramInt == 0)
      return false; 
    URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, paramSpannable.length(), URLSpan.class);
    for (int i = arrayOfURLSpan.length - 1; i >= 0; i--)
      paramSpannable.removeSpan(arrayOfURLSpan[i]); 
    if ((paramInt & 0x4) != 0)
      Linkify.addLinks(paramSpannable, 4); 
    ArrayList<LinkSpec> arrayList = new ArrayList();
    if ((paramInt & 0x1) != 0)
      gatherLinks(arrayList, paramSpannable, PatternsCompat.AUTOLINK_WEB_URL, new String[] { "http://", "https://", "rtsp://" }, Linkify.sUrlMatchFilter, null); 
    if ((paramInt & 0x2) != 0)
      gatherLinks(arrayList, paramSpannable, PatternsCompat.AUTOLINK_EMAIL_ADDRESS, new String[] { "mailto:" }, null, null); 
    if ((paramInt & 0x8) != 0)
      gatherMapLinks(arrayList, paramSpannable); 
    pruneOverlaps(arrayList, paramSpannable);
    if (arrayList.size() == 0)
      return false; 
    for (LinkSpec linkSpec : arrayList) {
      if (linkSpec.a == null)
        applyLink(linkSpec.b, linkSpec.c, linkSpec.d, paramSpannable); 
    } 
    return true;
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString) {
    return (Build.VERSION.SDK_INT >= 26) ? Linkify.addLinks(paramSpannable, paramPattern, paramString) : addLinks(paramSpannable, paramPattern, paramString, (String[])null, (Linkify.MatchFilter)null, (Linkify.TransformFilter)null);
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    return (Build.VERSION.SDK_INT >= 26) ? Linkify.addLinks(paramSpannable, paramPattern, paramString, paramMatchFilter, paramTransformFilter) : addLinks(paramSpannable, paramPattern, paramString, (String[])null, paramMatchFilter, paramTransformFilter);
  }
  
  public static boolean addLinks(@NonNull Spannable paramSpannable, @NonNull Pattern paramPattern, @Nullable String paramString, @Nullable String[] paramArrayOfString, @Nullable Linkify.MatchFilter paramMatchFilter, @Nullable Linkify.TransformFilter paramTransformFilter) {
    if (Build.VERSION.SDK_INT >= 26)
      return Linkify.addLinks(paramSpannable, paramPattern, paramString, paramArrayOfString, paramMatchFilter, paramTransformFilter); 
    if (paramString == null)
      paramString = ""; 
    if (paramArrayOfString == null || paramArrayOfString.length < 1)
      paramArrayOfString = EMPTY_STRING; 
    String[] arrayOfString = new String[1 + paramArrayOfString.length];
    arrayOfString[0] = paramString.toLowerCase(Locale.ROOT);
    byte b = 0;
    while (b < paramArrayOfString.length) {
      String str2;
      String str1 = paramArrayOfString[b];
      b++;
      if (str1 == null) {
        str2 = "";
      } else {
        str2 = str1.toLowerCase(Locale.ROOT);
      } 
      arrayOfString[b] = str2;
    } 
    Matcher matcher = paramPattern.matcher((CharSequence)paramSpannable);
    boolean bool = false;
    while (matcher.find()) {
      boolean bool1;
      int i = matcher.start();
      int j = matcher.end();
      if (paramMatchFilter != null) {
        bool1 = paramMatchFilter.acceptMatch((CharSequence)paramSpannable, i, j);
      } else {
        bool1 = true;
      } 
      if (bool1) {
        applyLink(makeUrl(matcher.group(0), arrayOfString, matcher, paramTransformFilter), i, j, paramSpannable);
        bool = true;
      } 
    } 
    return bool;
  }
  
  public static boolean addLinks(@NonNull TextView paramTextView, int paramInt) {
    if (Build.VERSION.SDK_INT >= 26)
      return Linkify.addLinks(paramTextView, paramInt); 
    if (paramInt == 0)
      return false; 
    CharSequence charSequence = paramTextView.getText();
    if (charSequence instanceof Spannable) {
      if (addLinks((Spannable)charSequence, paramInt)) {
        addLinkMovementMethod(paramTextView);
        return true;
      } 
      return false;
    } 
    SpannableString spannableString = SpannableString.valueOf(charSequence);
    if (addLinks((Spannable)spannableString, paramInt)) {
      addLinkMovementMethod(paramTextView);
      paramTextView.setText((CharSequence)spannableString);
      return true;
    } 
    return false;
  }
  
  private static void applyLink(String paramString, int paramInt1, int paramInt2, Spannable paramSpannable) {
    paramSpannable.setSpan(new URLSpan(paramString), paramInt1, paramInt2, 33);
  }
  
  private static void gatherLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable, Pattern paramPattern, String[] paramArrayOfString, Linkify.MatchFilter paramMatchFilter, Linkify.TransformFilter paramTransformFilter) {
    Matcher matcher = paramPattern.matcher((CharSequence)paramSpannable);
    while (matcher.find()) {
      int i = matcher.start();
      int j = matcher.end();
      if (paramMatchFilter == null || paramMatchFilter.acceptMatch((CharSequence)paramSpannable, i, j)) {
        LinkSpec linkSpec = new LinkSpec();
        linkSpec.b = makeUrl(matcher.group(0), paramArrayOfString, matcher, paramTransformFilter);
        linkSpec.c = i;
        linkSpec.d = j;
        paramArrayList.add(linkSpec);
      } 
    } 
  }
  
  private static void gatherMapLinks(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual toString : ()Ljava/lang/String;
    //   4: astore_2
    //   5: iconst_0
    //   6: istore_3
    //   7: goto -> 11
    //   10: pop
    //   11: aload_2
    //   12: invokestatic findAddress : (Ljava/lang/String;)Ljava/lang/String;
    //   15: astore #4
    //   17: aload #4
    //   19: ifnull -> 138
    //   22: aload_2
    //   23: aload #4
    //   25: invokevirtual indexOf : (Ljava/lang/String;)I
    //   28: istore #5
    //   30: iload #5
    //   32: ifge -> 36
    //   35: return
    //   36: new android/support/v4/text/util/LinkifyCompat$LinkSpec
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #6
    //   45: iload #5
    //   47: aload #4
    //   49: invokevirtual length : ()I
    //   52: iadd
    //   53: istore #7
    //   55: aload #6
    //   57: iload #5
    //   59: iload_3
    //   60: iadd
    //   61: putfield c : I
    //   64: iload_3
    //   65: iload #7
    //   67: iadd
    //   68: istore_3
    //   69: aload #6
    //   71: iload_3
    //   72: putfield d : I
    //   75: aload_2
    //   76: iload #7
    //   78: invokevirtual substring : (I)Ljava/lang/String;
    //   81: astore_2
    //   82: aload #4
    //   84: ldc_w 'UTF-8'
    //   87: invokestatic encode : (Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   90: astore #8
    //   92: new java/lang/StringBuilder
    //   95: dup
    //   96: invokespecial <init> : ()V
    //   99: astore #9
    //   101: aload #9
    //   103: ldc_w 'geo:0,0?q='
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #9
    //   112: aload #8
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: aload #6
    //   120: aload #9
    //   122: invokevirtual toString : ()Ljava/lang/String;
    //   125: putfield b : Ljava/lang/String;
    //   128: aload_0
    //   129: aload #6
    //   131: invokevirtual add : (Ljava/lang/Object;)Z
    //   134: pop
    //   135: goto -> 10
    //   138: return
    //   139: return
    // Exception table:
    //   from	to	target	type
    //   10	11	139	java/lang/UnsupportedOperationException
    //   11	17	139	java/lang/UnsupportedOperationException
    //   22	30	139	java/lang/UnsupportedOperationException
    //   36	64	139	java/lang/UnsupportedOperationException
    //   69	82	139	java/lang/UnsupportedOperationException
    //   82	92	10	java/io/UnsupportedEncodingException
    //   82	92	139	java/lang/UnsupportedOperationException
    //   92	135	139	java/lang/UnsupportedOperationException
  }
  
  private static String makeUrl(@NonNull String paramString, @NonNull String[] paramArrayOfString, Matcher paramMatcher, @Nullable Linkify.TransformFilter paramTransformFilter) {
    boolean bool;
    if (paramTransformFilter != null)
      paramString = paramTransformFilter.transformUrl(paramMatcher, paramString); 
    byte b = 0;
    while (true) {
      int i = paramArrayOfString.length;
      bool = true;
      if (b < i) {
        String str = paramArrayOfString[b];
        int j = paramArrayOfString[b].length();
        if (paramString.regionMatches(true, 0, str, 0, j)) {
          String str1 = paramArrayOfString[b];
          int k = paramArrayOfString[b].length();
          if (!paramString.regionMatches(false, 0, str1, 0, k)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(paramArrayOfString[b]);
            stringBuilder.append(paramString.substring(paramArrayOfString[b].length()));
            paramString = stringBuilder.toString();
          } 
          break;
        } 
        b++;
        continue;
      } 
      bool = false;
      break;
    } 
    if (!bool && paramArrayOfString.length > 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramArrayOfString[0]);
      stringBuilder.append(paramString);
      paramString = stringBuilder.toString();
    } 
    return paramString;
  }
  
  private static void pruneOverlaps(ArrayList<LinkSpec> paramArrayList, Spannable paramSpannable) {
    int i = paramSpannable.length();
    int j = 0;
    URLSpan[] arrayOfURLSpan = (URLSpan[])paramSpannable.getSpans(0, i, URLSpan.class);
    for (byte b = 0; b < arrayOfURLSpan.length; b++) {
      LinkSpec linkSpec = new LinkSpec();
      linkSpec.a = arrayOfURLSpan[b];
      linkSpec.c = paramSpannable.getSpanStart(arrayOfURLSpan[b]);
      linkSpec.d = paramSpannable.getSpanEnd(arrayOfURLSpan[b]);
      paramArrayList.add(linkSpec);
    } 
    Collections.sort(paramArrayList, COMPARATOR);
    int k = paramArrayList.size();
    while (j < k - 1) {
      LinkSpec linkSpec1 = paramArrayList.get(j);
      int m = j + 1;
      LinkSpec linkSpec2 = paramArrayList.get(m);
      if (linkSpec1.c <= linkSpec2.c && linkSpec1.d > linkSpec2.c) {
        byte b1;
        if (linkSpec2.d <= linkSpec1.d || linkSpec1.d - linkSpec1.c > linkSpec2.d - linkSpec2.c) {
          b1 = m;
        } else if (linkSpec1.d - linkSpec1.c < linkSpec2.d - linkSpec2.c) {
          b1 = j;
        } else {
          b1 = -1;
        } 
        if (b1 != -1) {
          URLSpan uRLSpan = ((LinkSpec)paramArrayList.get(b1)).a;
          if (uRLSpan != null)
            paramSpannable.removeSpan(uRLSpan); 
          paramArrayList.remove(b1);
          k--;
          continue;
        } 
      } 
      j = m;
    } 
  }
  
  private static class LinkSpec {
    URLSpan a;
    
    String b;
    
    int c;
    
    int d;
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface LinkifyMask {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\tex\\util\LinkifyCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */