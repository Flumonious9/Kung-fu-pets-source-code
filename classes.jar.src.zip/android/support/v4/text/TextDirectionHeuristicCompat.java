package android.support.v4.text;

public interface TextDirectionHeuristicCompat {
  boolean isRtl(CharSequence paramCharSequence, int paramInt1, int paramInt2);
  
  boolean isRtl(char[] paramArrayOfchar, int paramInt1, int paramInt2);
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\text\TextDirectionHeuristicCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */