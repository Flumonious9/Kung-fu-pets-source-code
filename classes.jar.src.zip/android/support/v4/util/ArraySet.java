package android.support.v4.util;

import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public final class ArraySet<E> implements Collection<E>, Set<E> {
  private static final int BASE_SIZE = 4;
  
  private static final int CACHE_SIZE = 10;
  
  private static final boolean DEBUG = false;
  
  private static final int[] INT = new int[0];
  
  private static final Object[] OBJECT = new Object[0];
  
  private static final String TAG = "ArraySet";
  
  private static Object[] sBaseCache;
  
  private static int sBaseCacheSize;
  
  private static Object[] sTwiceBaseCache;
  
  private static int sTwiceBaseCacheSize;
  
  private Object[] mArray;
  
  private MapCollections<E, E> mCollections;
  
  private int[] mHashes;
  
  private int mSize;
  
  public ArraySet() {
    this(0);
  }
  
  public ArraySet(int paramInt) {
    if (paramInt == 0) {
      this.mHashes = INT;
      this.mArray = OBJECT;
    } else {
      allocArrays(paramInt);
    } 
    this.mSize = 0;
  }
  
  public ArraySet(@Nullable ArraySet<E> paramArraySet) {
    this();
    if (paramArraySet != null)
      addAll(paramArraySet); 
  }
  
  public ArraySet(@Nullable Collection<E> paramCollection) {
    this();
    if (paramCollection != null)
      addAll(paramCollection); 
  }
  
  private void allocArrays(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 89
    //   6: ldc android/support/v4/util/ArraySet
    //   8: monitorenter
    //   9: getstatic android/support/v4/util/ArraySet.sTwiceBaseCache : [Ljava/lang/Object;
    //   12: ifnull -> 75
    //   15: getstatic android/support/v4/util/ArraySet.sTwiceBaseCache : [Ljava/lang/Object;
    //   18: astore #5
    //   20: aload_0
    //   21: aload #5
    //   23: putfield mArray : [Ljava/lang/Object;
    //   26: aload #5
    //   28: iconst_0
    //   29: aaload
    //   30: checkcast [Ljava/lang/Object;
    //   33: checkcast [Ljava/lang/Object;
    //   36: putstatic android/support/v4/util/ArraySet.sTwiceBaseCache : [Ljava/lang/Object;
    //   39: aload_0
    //   40: aload #5
    //   42: iconst_1
    //   43: aaload
    //   44: checkcast [I
    //   47: checkcast [I
    //   50: putfield mHashes : [I
    //   53: aload #5
    //   55: iconst_1
    //   56: aconst_null
    //   57: aastore
    //   58: aload #5
    //   60: iconst_0
    //   61: aconst_null
    //   62: aastore
    //   63: getstatic android/support/v4/util/ArraySet.sTwiceBaseCacheSize : I
    //   66: iconst_1
    //   67: isub
    //   68: putstatic android/support/v4/util/ArraySet.sTwiceBaseCacheSize : I
    //   71: ldc android/support/v4/util/ArraySet
    //   73: monitorexit
    //   74: return
    //   75: ldc android/support/v4/util/ArraySet
    //   77: monitorexit
    //   78: goto -> 169
    //   81: astore #4
    //   83: ldc android/support/v4/util/ArraySet
    //   85: monitorexit
    //   86: aload #4
    //   88: athrow
    //   89: iload_1
    //   90: iconst_4
    //   91: if_icmpne -> 169
    //   94: ldc android/support/v4/util/ArraySet
    //   96: monitorenter
    //   97: getstatic android/support/v4/util/ArraySet.sBaseCache : [Ljava/lang/Object;
    //   100: ifnull -> 157
    //   103: getstatic android/support/v4/util/ArraySet.sBaseCache : [Ljava/lang/Object;
    //   106: astore_3
    //   107: aload_0
    //   108: aload_3
    //   109: putfield mArray : [Ljava/lang/Object;
    //   112: aload_3
    //   113: iconst_0
    //   114: aaload
    //   115: checkcast [Ljava/lang/Object;
    //   118: checkcast [Ljava/lang/Object;
    //   121: putstatic android/support/v4/util/ArraySet.sBaseCache : [Ljava/lang/Object;
    //   124: aload_0
    //   125: aload_3
    //   126: iconst_1
    //   127: aaload
    //   128: checkcast [I
    //   131: checkcast [I
    //   134: putfield mHashes : [I
    //   137: aload_3
    //   138: iconst_1
    //   139: aconst_null
    //   140: aastore
    //   141: aload_3
    //   142: iconst_0
    //   143: aconst_null
    //   144: aastore
    //   145: getstatic android/support/v4/util/ArraySet.sBaseCacheSize : I
    //   148: iconst_1
    //   149: isub
    //   150: putstatic android/support/v4/util/ArraySet.sBaseCacheSize : I
    //   153: ldc android/support/v4/util/ArraySet
    //   155: monitorexit
    //   156: return
    //   157: ldc android/support/v4/util/ArraySet
    //   159: monitorexit
    //   160: goto -> 169
    //   163: astore_2
    //   164: ldc android/support/v4/util/ArraySet
    //   166: monitorexit
    //   167: aload_2
    //   168: athrow
    //   169: aload_0
    //   170: iload_1
    //   171: newarray int
    //   173: putfield mHashes : [I
    //   176: aload_0
    //   177: iload_1
    //   178: anewarray java/lang/Object
    //   181: putfield mArray : [Ljava/lang/Object;
    //   184: return
    // Exception table:
    //   from	to	target	type
    //   9	74	81	finally
    //   75	78	81	finally
    //   83	86	81	finally
    //   97	156	163	finally
    //   157	160	163	finally
    //   164	167	163	finally
  }
  
  private static void freeArrays(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 74
    //   7: ldc android/support/v4/util/ArraySet
    //   9: monitorenter
    //   10: getstatic android/support/v4/util/ArraySet.sTwiceBaseCacheSize : I
    //   13: bipush #10
    //   15: if_icmpge -> 62
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic android/support/v4/util/ArraySet.sTwiceBaseCache : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: isub
    //   31: istore #6
    //   33: iload #6
    //   35: iconst_2
    //   36: if_icmplt -> 50
    //   39: aload_1
    //   40: iload #6
    //   42: aconst_null
    //   43: aastore
    //   44: iinc #6, -1
    //   47: goto -> 33
    //   50: aload_1
    //   51: putstatic android/support/v4/util/ArraySet.sTwiceBaseCache : [Ljava/lang/Object;
    //   54: iconst_1
    //   55: getstatic android/support/v4/util/ArraySet.sTwiceBaseCacheSize : I
    //   58: iadd
    //   59: putstatic android/support/v4/util/ArraySet.sTwiceBaseCacheSize : I
    //   62: ldc android/support/v4/util/ArraySet
    //   64: monitorexit
    //   65: return
    //   66: astore #5
    //   68: ldc android/support/v4/util/ArraySet
    //   70: monitorexit
    //   71: aload #5
    //   73: athrow
    //   74: aload_0
    //   75: arraylength
    //   76: iconst_4
    //   77: if_icmpne -> 145
    //   80: ldc android/support/v4/util/ArraySet
    //   82: monitorenter
    //   83: getstatic android/support/v4/util/ArraySet.sBaseCacheSize : I
    //   86: bipush #10
    //   88: if_icmpge -> 135
    //   91: aload_1
    //   92: iconst_0
    //   93: getstatic android/support/v4/util/ArraySet.sBaseCache : [Ljava/lang/Object;
    //   96: aastore
    //   97: aload_1
    //   98: iconst_1
    //   99: aload_0
    //   100: aastore
    //   101: iload_2
    //   102: iconst_1
    //   103: isub
    //   104: istore #4
    //   106: iload #4
    //   108: iconst_2
    //   109: if_icmplt -> 123
    //   112: aload_1
    //   113: iload #4
    //   115: aconst_null
    //   116: aastore
    //   117: iinc #4, -1
    //   120: goto -> 106
    //   123: aload_1
    //   124: putstatic android/support/v4/util/ArraySet.sBaseCache : [Ljava/lang/Object;
    //   127: iconst_1
    //   128: getstatic android/support/v4/util/ArraySet.sBaseCacheSize : I
    //   131: iadd
    //   132: putstatic android/support/v4/util/ArraySet.sBaseCacheSize : I
    //   135: ldc android/support/v4/util/ArraySet
    //   137: monitorexit
    //   138: return
    //   139: astore_3
    //   140: ldc android/support/v4/util/ArraySet
    //   142: monitorexit
    //   143: aload_3
    //   144: athrow
    //   145: return
    // Exception table:
    //   from	to	target	type
    //   10	28	66	finally
    //   39	44	66	finally
    //   50	62	66	finally
    //   62	65	66	finally
    //   68	71	66	finally
    //   83	101	139	finally
    //   112	117	139	finally
    //   123	135	139	finally
    //   135	138	139	finally
    //   140	143	139	finally
  }
  
  private MapCollections<E, E> getCollection() {
    if (this.mCollections == null)
      this.mCollections = new MapCollections<E, E>(this) {
          protected int a() {
            return ArraySet.a(this.a);
          }
          
          protected int a(Object param1Object) {
            return this.a.indexOf(param1Object);
          }
          
          protected Object a(int param1Int1, int param1Int2) {
            return ArraySet.b(this.a)[param1Int1];
          }
          
          protected E a(int param1Int, E param1E) {
            throw new UnsupportedOperationException("not a map");
          }
          
          protected void a(int param1Int) {
            this.a.removeAt(param1Int);
          }
          
          protected void a(E param1E1, E param1E2) {
            this.a.add(param1E1);
          }
          
          protected int b(Object param1Object) {
            return this.a.indexOf(param1Object);
          }
          
          protected Map<E, E> b() {
            throw new UnsupportedOperationException("not a map");
          }
          
          protected void c() {
            this.a.clear();
          }
        }; 
    return this.mCollections;
  }
  
  private int indexOf(Object paramObject, int paramInt) {
    int i = this.mSize;
    if (i == 0)
      return -1; 
    int j = ContainerHelpers.a(this.mHashes, i, paramInt);
    if (j < 0)
      return j; 
    if (paramObject.equals(this.mArray[j]))
      return j; 
    int k;
    for (k = j + 1; k < i && this.mHashes[k] == paramInt; k++) {
      if (paramObject.equals(this.mArray[k]))
        return k; 
    } 
    for (int m = j - 1; m >= 0 && this.mHashes[m] == paramInt; m--) {
      if (paramObject.equals(this.mArray[m]))
        return m; 
    } 
    return k ^ 0xFFFFFFFF;
  }
  
  private int indexOfNull() {
    int i = this.mSize;
    if (i == 0)
      return -1; 
    int j = ContainerHelpers.a(this.mHashes, i, 0);
    if (j < 0)
      return j; 
    if (this.mArray[j] == null)
      return j; 
    int k;
    for (k = j + 1; k < i && this.mHashes[k] == 0; k++) {
      if (this.mArray[k] == null)
        return k; 
    } 
    for (int m = j - 1; m >= 0 && this.mHashes[m] == 0; m--) {
      if (this.mArray[m] == null)
        return m; 
    } 
    return k ^ 0xFFFFFFFF;
  }
  
  public boolean add(@Nullable E paramE) {
    int i;
    int j;
    if (paramE == null) {
      j = indexOfNull();
      i = 0;
    } else {
      int m = paramE.hashCode();
      int n = indexOf(paramE, m);
      i = m;
      j = n;
    } 
    if (j >= 0)
      return false; 
    int k = j ^ 0xFFFFFFFF;
    if (this.mSize >= this.mHashes.length) {
      int m = this.mSize;
      int n = 4;
      if (m >= 8) {
        n = this.mSize + (this.mSize >> 1);
      } else if (this.mSize >= n) {
        n = 8;
      } 
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(n);
      if (this.mHashes.length > 0) {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, arrayOfInt.length);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, arrayOfObject.length);
      } 
      freeArrays(arrayOfInt, arrayOfObject, this.mSize);
    } 
    if (k < this.mSize) {
      int[] arrayOfInt1 = this.mHashes;
      int[] arrayOfInt2 = this.mHashes;
      int m = k + 1;
      System.arraycopy(arrayOfInt1, k, arrayOfInt2, m, this.mSize - k);
      System.arraycopy(this.mArray, k, this.mArray, m, this.mSize - k);
    } 
    this.mHashes[k] = i;
    this.mArray[k] = paramE;
    this.mSize = 1 + this.mSize;
    return true;
  }
  
  public void addAll(@NonNull ArraySet<? extends E> paramArraySet) {
    int i = paramArraySet.mSize;
    ensureCapacity(i + this.mSize);
    int j = this.mSize;
    byte b = 0;
    if (j == 0) {
      if (i > 0) {
        System.arraycopy(paramArraySet.mHashes, 0, this.mHashes, 0, i);
        System.arraycopy(paramArraySet.mArray, 0, this.mArray, 0, i);
        this.mSize = i;
        return;
      } 
    } else {
      while (b < i) {
        add(paramArraySet.valueAt(b));
        b++;
      } 
    } 
  }
  
  public boolean addAll(@NonNull Collection<? extends E> paramCollection) {
    ensureCapacity(this.mSize + paramCollection.size());
    Iterator<? extends E> iterator = paramCollection.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= add(iterator.next()));
    return bool;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void append(E paramE) {
    int j;
    int i = this.mSize;
    if (paramE == null) {
      j = 0;
    } else {
      j = paramE.hashCode();
    } 
    if (i < this.mHashes.length) {
      if (i > 0 && this.mHashes[i - 1] > j) {
        add(paramE);
        return;
      } 
      this.mSize = i + 1;
      this.mHashes[i] = j;
      this.mArray[i] = paramE;
      return;
    } 
    throw new IllegalStateException("Array is full");
  }
  
  public void clear() {
    if (this.mSize != 0) {
      freeArrays(this.mHashes, this.mArray, this.mSize);
      this.mHashes = INT;
      this.mArray = OBJECT;
      this.mSize = 0;
    } 
  }
  
  public boolean contains(Object paramObject) {
    return (indexOf(paramObject) >= 0);
  }
  
  public boolean containsAll(@NonNull Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    while (iterator.hasNext()) {
      if (!contains(iterator.next()))
        return false; 
    } 
    return true;
  }
  
  public void ensureCapacity(int paramInt) {
    if (this.mHashes.length < paramInt) {
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(paramInt);
      if (this.mSize > 0) {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, this.mSize);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, this.mSize);
      } 
      freeArrays(arrayOfInt, arrayOfObject, this.mSize);
    } 
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof Set) {
      Set set = (Set)paramObject;
      if (size() != set.size())
        return false; 
      byte b = 0;
      try {
        while (b < this.mSize) {
          boolean bool = set.contains(valueAt(b));
          if (!bool)
            return false; 
          b++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    return false;
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.mHashes;
    int i = this.mSize;
    byte b = 0;
    int j = 0;
    while (b < i) {
      j += arrayOfInt[b];
      b++;
    } 
    return j;
  }
  
  public int indexOf(Object paramObject) {
    return (paramObject == null) ? indexOfNull() : indexOf(paramObject, paramObject.hashCode());
  }
  
  public boolean isEmpty() {
    return (this.mSize <= 0);
  }
  
  public Iterator<E> iterator() {
    return getCollection().getKeySet().iterator();
  }
  
  public boolean remove(Object paramObject) {
    int i = indexOf(paramObject);
    if (i >= 0) {
      removeAt(i);
      return true;
    } 
    return false;
  }
  
  public boolean removeAll(ArraySet<? extends E> paramArraySet) {
    int i = paramArraySet.mSize;
    int j = this.mSize;
    for (byte b = 0; b < i; b++)
      remove(paramArraySet.valueAt(b)); 
    int k = this.mSize;
    boolean bool = false;
    if (j != k)
      bool = true; 
    return bool;
  }
  
  public boolean removeAll(@NonNull Collection<?> paramCollection) {
    Iterator<?> iterator = paramCollection.iterator();
    boolean bool;
    for (bool = false; iterator.hasNext(); bool |= remove(iterator.next()));
    return bool;
  }
  
  public E removeAt(int paramInt) {
    Object object = this.mArray[paramInt];
    if (this.mSize <= 1) {
      freeArrays(this.mHashes, this.mArray, this.mSize);
      this.mHashes = INT;
      this.mArray = OBJECT;
      this.mSize = 0;
      return (E)object;
    } 
    int i = this.mHashes.length;
    int j = 8;
    if (i > j && this.mSize < this.mHashes.length / 3) {
      if (this.mSize > j)
        j = this.mSize + (this.mSize >> 1); 
      int[] arrayOfInt = this.mHashes;
      Object[] arrayOfObject = this.mArray;
      allocArrays(j);
      this.mSize--;
      if (paramInt > 0) {
        System.arraycopy(arrayOfInt, 0, this.mHashes, 0, paramInt);
        System.arraycopy(arrayOfObject, 0, this.mArray, 0, paramInt);
      } 
      if (paramInt < this.mSize) {
        int k = paramInt + 1;
        System.arraycopy(arrayOfInt, k, this.mHashes, paramInt, this.mSize - paramInt);
        System.arraycopy(arrayOfObject, k, this.mArray, paramInt, this.mSize - paramInt);
        return (E)object;
      } 
    } else {
      this.mSize--;
      if (paramInt < this.mSize) {
        int[] arrayOfInt = this.mHashes;
        int k = paramInt + 1;
        System.arraycopy(arrayOfInt, k, this.mHashes, paramInt, this.mSize - paramInt);
        System.arraycopy(this.mArray, k, this.mArray, paramInt, this.mSize - paramInt);
      } 
      this.mArray[this.mSize] = null;
    } 
    return (E)object;
  }
  
  public boolean retainAll(@NonNull Collection<?> paramCollection) {
    int i = this.mSize - 1;
    boolean bool = false;
    while (i >= 0) {
      if (!paramCollection.contains(this.mArray[i])) {
        removeAt(i);
        bool = true;
      } 
      i--;
    } 
    return bool;
  }
  
  public int size() {
    return this.mSize;
  }
  
  @NonNull
  public Object[] toArray() {
    Object[] arrayOfObject = new Object[this.mSize];
    System.arraycopy(this.mArray, 0, arrayOfObject, 0, this.mSize);
    return arrayOfObject;
  }
  
  @NonNull
  public <T> T[] toArray(@NonNull T[] paramArrayOfT) {
    if (paramArrayOfT.length < this.mSize)
      paramArrayOfT = (T[])Array.newInstance(paramArrayOfT.getClass().getComponentType(), this.mSize); 
    System.arraycopy(this.mArray, 0, paramArrayOfT, 0, this.mSize);
    if (paramArrayOfT.length > this.mSize)
      paramArrayOfT[this.mSize] = null; 
    return paramArrayOfT;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(14 * this.mSize);
    stringBuilder.append('{');
    for (byte b = 0; b < this.mSize; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      E e = valueAt(b);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Set)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  @Nullable
  public E valueAt(int paramInt) {
    return (E)this.mArray[paramInt];
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v\\util\ArraySet.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */