package android.support.v4.util;

import android.support.annotation.RestrictTo;
import java.io.PrintWriter;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public final class TimeUtils {
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final int HUNDRED_DAY_FIELD_LEN = 19;
  
  private static final int SECONDS_PER_DAY = 86400;
  
  private static final int SECONDS_PER_HOUR = 3600;
  
  private static final int SECONDS_PER_MINUTE = 60;
  
  private static char[] sFormatStr;
  
  private static final Object sFormatSync = new Object();
  
  static {
    sFormatStr = new char[24];
  }
  
  private static int accumField(int paramInt1, int paramInt2, boolean paramBoolean, int paramInt3) {
    return (paramInt1 > 99 || (paramBoolean && paramInt3 >= 3)) ? (paramInt2 + 3) : ((paramInt1 > 9 || (paramBoolean && paramInt3 >= 2)) ? (paramInt2 + 2) : ((paramBoolean || paramInt1 > 0) ? (paramInt2 + 1) : 0));
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static void formatDuration(long paramLong1, long paramLong2, PrintWriter paramPrintWriter) {
    if (paramLong1 == 0L) {
      paramPrintWriter.print("--");
      return;
    } 
    formatDuration(paramLong1 - paramLong2, paramPrintWriter, 0);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static void formatDuration(long paramLong, PrintWriter paramPrintWriter) {
    formatDuration(paramLong, paramPrintWriter, 0);
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static void formatDuration(long paramLong, PrintWriter paramPrintWriter, int paramInt) {
    synchronized (sFormatSync) {
      int i = formatDurationLocked(paramLong, paramInt);
      paramPrintWriter.print(new String(sFormatStr, 0, i));
      return;
    } 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static void formatDuration(long paramLong, StringBuilder paramStringBuilder) {
    synchronized (sFormatSync) {
      int i = formatDurationLocked(paramLong, 0);
      paramStringBuilder.append(sFormatStr, 0, i);
      return;
    } 
  }
  
  private static int formatDurationLocked(long paramLong, int paramInt) {
    byte b1;
    boolean bool1;
    boolean bool2;
    int k;
    boolean bool3;
    byte b2;
    boolean bool4;
    boolean bool5;
    boolean bool6;
    boolean bool7;
    boolean bool8;
    boolean bool9;
    boolean bool10;
    boolean bool11;
    long l = paramLong;
    if (sFormatStr.length < paramInt)
      sFormatStr = new char[paramInt]; 
    char[] arrayOfChar = sFormatStr;
    if (l == 0L) {
      int i5 = paramInt - 1;
      while (i5 > 0)
        arrayOfChar[0] = ' '; 
      arrayOfChar[0] = '0';
      return 1;
    } 
    if (l > 0L) {
      b1 = 43;
    } else {
      b1 = 45;
      l = -l;
    } 
    int i = (int)(l % 1000L);
    int j = (int)Math.floor((l / 1000L));
    if (j > 86400) {
      bool1 = j / 86400;
      j -= 86400 * bool1;
    } else {
      bool1 = false;
    } 
    if (j > 3600) {
      bool2 = j / 3600;
      j -= bool2 * 3600;
    } else {
      bool2 = false;
    } 
    if (j > 60) {
      int i5 = j / 60;
      k = j - i5 * 60;
      bool3 = i5;
    } else {
      k = j;
      bool3 = false;
    } 
    if (paramInt != 0) {
      boolean bool12;
      boolean bool13;
      boolean bool14;
      boolean bool15;
      int i5 = accumField(bool1, 1, false, 0);
      if (i5 > 0) {
        bool12 = true;
      } else {
        bool12 = false;
      } 
      int i6 = i5 + accumField(bool2, 1, bool12, 2);
      if (i6 > 0) {
        bool13 = true;
      } else {
        bool13 = false;
      } 
      int i7 = i6 + accumField(bool3, 1, bool13, 2);
      if (i7 > 0) {
        bool14 = true;
      } else {
        bool14 = false;
      } 
      int i8 = i7 + accumField(k, 1, bool14, 2);
      if (i8 > 0) {
        bool15 = true;
      } else {
        bool15 = false;
      } 
      int i9 = i8 + 1 + accumField(i, 2, true, bool15);
      b2 = 0;
      while (i9 < paramInt) {
        arrayOfChar[b2] = ' ';
        b2++;
        i9++;
      } 
    } else {
      b2 = 0;
    } 
    arrayOfChar[b2] = b1;
    int m = b2 + 1;
    if (paramInt != 0) {
      bool4 = true;
    } else {
      bool4 = false;
    } 
    int n = printField(arrayOfChar, bool1, 'd', m, false, 0);
    if (n != m) {
      bool5 = true;
    } else {
      bool5 = false;
    } 
    if (bool4) {
      bool6 = true;
    } else {
      bool6 = false;
    } 
    int i1 = printField(arrayOfChar, bool2, 'h', n, bool5, bool6);
    if (i1 != m) {
      bool7 = true;
    } else {
      bool7 = false;
    } 
    if (bool4) {
      bool8 = true;
    } else {
      bool8 = false;
    } 
    int i2 = printField(arrayOfChar, bool3, 'm', i1, bool7, bool8);
    if (i2 != m) {
      bool9 = true;
    } else {
      bool9 = false;
    } 
    if (bool4) {
      bool10 = true;
    } else {
      bool10 = false;
    } 
    int i3 = printField(arrayOfChar, k, 's', i2, bool9, bool10);
    if (bool4 && i3 != m) {
      bool11 = true;
    } else {
      bool11 = false;
    } 
    int i4 = printField(arrayOfChar, i, 'm', i3, true, bool11);
    arrayOfChar[i4] = 's';
    return i4 + 1;
  }
  
  private static int printField(char[] paramArrayOfchar, int paramInt1, char paramChar, int paramInt2, boolean paramBoolean, int paramInt3) {
    if (paramBoolean || paramInt1 > 0) {
      int i;
      if ((paramBoolean && paramInt3 >= 3) || paramInt1 > 99) {
        int k = paramInt1 / 100;
        paramArrayOfchar[paramInt2] = (char)(k + 48);
        i = paramInt2 + 1;
        paramInt1 -= k * 100;
      } else {
        i = paramInt2;
      } 
      if ((paramBoolean && paramInt3 >= 2) || paramInt1 > 9 || paramInt2 != i) {
        int k = paramInt1 / 10;
        paramArrayOfchar[i] = (char)(k + 48);
        i++;
        paramInt1 -= k * 10;
      } 
      paramArrayOfchar[i] = (char)(paramInt1 + 48);
      int j = i + 1;
      paramArrayOfchar[j] = paramChar;
      paramInt2 = j + 1;
    } 
    return paramInt2;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v\\util\TimeUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */