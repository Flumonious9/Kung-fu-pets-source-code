package android.support.v4.util;

import java.util.LinkedHashMap;
import java.util.Map;

public class LruCache<K, V> {
  private int createCount;
  
  private int evictionCount;
  
  private int hitCount;
  
  private final LinkedHashMap<K, V> map;
  
  private int maxSize;
  
  private int missCount;
  
  private int putCount;
  
  private int size;
  
  public LruCache(int paramInt) {
    if (paramInt > 0) {
      this.maxSize = paramInt;
      this.map = new LinkedHashMap<K, V>(0, 0.75F, true);
      return;
    } 
    throw new IllegalArgumentException("maxSize <= 0");
  }
  
  private int safeSizeOf(K paramK, V paramV) {
    int i = sizeOf(paramK, paramV);
    if (i >= 0)
      return i; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Negative size: ");
    stringBuilder.append(paramK);
    stringBuilder.append("=");
    stringBuilder.append(paramV);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  protected V create(K paramK) {
    return null;
  }
  
  public final int createCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield createCount : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  protected void entryRemoved(boolean paramBoolean, K paramK, V paramV1, V paramV2) {}
  
  public final void evictAll() {
    trimToSize(-1);
  }
  
  public final int evictionCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield evictionCount : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V get(K paramK) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 161
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield map : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual get : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 33
    //   19: aload_0
    //   20: iconst_1
    //   21: aload_0
    //   22: getfield hitCount : I
    //   25: iadd
    //   26: putfield hitCount : I
    //   29: aload_0
    //   30: monitorexit
    //   31: aload_3
    //   32: areturn
    //   33: aload_0
    //   34: iconst_1
    //   35: aload_0
    //   36: getfield missCount : I
    //   39: iadd
    //   40: putfield missCount : I
    //   43: aload_0
    //   44: monitorexit
    //   45: aload_0
    //   46: aload_1
    //   47: invokevirtual create : (Ljava/lang/Object;)Ljava/lang/Object;
    //   50: astore #4
    //   52: aload #4
    //   54: ifnonnull -> 59
    //   57: aconst_null
    //   58: areturn
    //   59: aload_0
    //   60: monitorenter
    //   61: aload_0
    //   62: iconst_1
    //   63: aload_0
    //   64: getfield createCount : I
    //   67: iadd
    //   68: putfield createCount : I
    //   71: aload_0
    //   72: getfield map : Ljava/util/LinkedHashMap;
    //   75: aload_1
    //   76: aload #4
    //   78: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   81: astore #6
    //   83: aload #6
    //   85: ifnull -> 102
    //   88: aload_0
    //   89: getfield map : Ljava/util/LinkedHashMap;
    //   92: aload_1
    //   93: aload #6
    //   95: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   98: pop
    //   99: goto -> 118
    //   102: aload_0
    //   103: aload_0
    //   104: getfield size : I
    //   107: aload_0
    //   108: aload_1
    //   109: aload #4
    //   111: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   114: iadd
    //   115: putfield size : I
    //   118: aload_0
    //   119: monitorexit
    //   120: aload #6
    //   122: ifnull -> 138
    //   125: aload_0
    //   126: iconst_0
    //   127: aload_1
    //   128: aload #4
    //   130: aload #6
    //   132: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   135: aload #6
    //   137: areturn
    //   138: aload_0
    //   139: aload_0
    //   140: getfield maxSize : I
    //   143: invokevirtual trimToSize : (I)V
    //   146: aload #4
    //   148: areturn
    //   149: astore #5
    //   151: aload_0
    //   152: monitorexit
    //   153: aload #5
    //   155: athrow
    //   156: astore_2
    //   157: aload_0
    //   158: monitorexit
    //   159: aload_2
    //   160: athrow
    //   161: new java/lang/NullPointerException
    //   164: dup
    //   165: ldc 'key == null'
    //   167: invokespecial <init> : (Ljava/lang/String;)V
    //   170: athrow
    // Exception table:
    //   from	to	target	type
    //   6	15	156	finally
    //   19	31	156	finally
    //   33	45	156	finally
    //   61	83	149	finally
    //   88	99	149	finally
    //   102	118	149	finally
    //   118	120	149	finally
    //   151	153	149	finally
    //   157	159	156	finally
  }
  
  public final int hitCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hitCount : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final int maxSize() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield maxSize : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final int missCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield missCount : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V put(K paramK, V paramV) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 99
    //   4: aload_2
    //   5: ifnull -> 99
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: iconst_1
    //   12: aload_0
    //   13: getfield putCount : I
    //   16: iadd
    //   17: putfield putCount : I
    //   20: aload_0
    //   21: aload_0
    //   22: getfield size : I
    //   25: aload_0
    //   26: aload_1
    //   27: aload_2
    //   28: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   31: iadd
    //   32: putfield size : I
    //   35: aload_0
    //   36: getfield map : Ljava/util/LinkedHashMap;
    //   39: aload_1
    //   40: aload_2
    //   41: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   44: astore #4
    //   46: aload #4
    //   48: ifnull -> 67
    //   51: aload_0
    //   52: aload_0
    //   53: getfield size : I
    //   56: aload_0
    //   57: aload_1
    //   58: aload #4
    //   60: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   63: isub
    //   64: putfield size : I
    //   67: aload_0
    //   68: monitorexit
    //   69: aload #4
    //   71: ifnull -> 83
    //   74: aload_0
    //   75: iconst_0
    //   76: aload_1
    //   77: aload #4
    //   79: aload_2
    //   80: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   83: aload_0
    //   84: aload_0
    //   85: getfield maxSize : I
    //   88: invokevirtual trimToSize : (I)V
    //   91: aload #4
    //   93: areturn
    //   94: astore_3
    //   95: aload_0
    //   96: monitorexit
    //   97: aload_3
    //   98: athrow
    //   99: new java/lang/NullPointerException
    //   102: dup
    //   103: ldc 'key == null || value == null'
    //   105: invokespecial <init> : (Ljava/lang/String;)V
    //   108: athrow
    // Exception table:
    //   from	to	target	type
    //   10	46	94	finally
    //   51	67	94	finally
    //   67	69	94	finally
    //   95	97	94	finally
  }
  
  public final int putCount() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield putCount : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  public final V remove(K paramK) {
    // Byte code:
    //   0: aload_1
    //   1: ifnull -> 55
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield map : Ljava/util/LinkedHashMap;
    //   10: aload_1
    //   11: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   14: astore_3
    //   15: aload_3
    //   16: ifnull -> 34
    //   19: aload_0
    //   20: aload_0
    //   21: getfield size : I
    //   24: aload_0
    //   25: aload_1
    //   26: aload_3
    //   27: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   30: isub
    //   31: putfield size : I
    //   34: aload_0
    //   35: monitorexit
    //   36: aload_3
    //   37: ifnull -> 48
    //   40: aload_0
    //   41: iconst_0
    //   42: aload_1
    //   43: aload_3
    //   44: aconst_null
    //   45: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   48: aload_3
    //   49: areturn
    //   50: astore_2
    //   51: aload_0
    //   52: monitorexit
    //   53: aload_2
    //   54: athrow
    //   55: new java/lang/NullPointerException
    //   58: dup
    //   59: ldc 'key == null'
    //   61: invokespecial <init> : (Ljava/lang/String;)V
    //   64: athrow
    // Exception table:
    //   from	to	target	type
    //   6	15	50	finally
    //   19	34	50	finally
    //   34	36	50	finally
    //   51	53	50	finally
  }
  
  public void resize(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: ifle -> 24
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: iload_1
    //   8: putfield maxSize : I
    //   11: aload_0
    //   12: monitorexit
    //   13: aload_0
    //   14: iload_1
    //   15: invokevirtual trimToSize : (I)V
    //   18: return
    //   19: astore_2
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_2
    //   23: athrow
    //   24: new java/lang/IllegalArgumentException
    //   27: dup
    //   28: ldc 'maxSize <= 0'
    //   30: invokespecial <init> : (Ljava/lang/String;)V
    //   33: athrow
    // Exception table:
    //   from	to	target	type
    //   6	13	19	finally
    //   20	22	19	finally
  }
  
  public final int size() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield size : I
    //   6: istore_2
    //   7: aload_0
    //   8: monitorexit
    //   9: iload_2
    //   10: ireturn
    //   11: astore_1
    //   12: aload_0
    //   13: monitorexit
    //   14: aload_1
    //   15: athrow
    // Exception table:
    //   from	to	target	type
    //   2	7	11	finally
  }
  
  protected int sizeOf(K paramK, V paramV) {
    return 1;
  }
  
  public final Map<K, V> snapshot() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: new java/util/LinkedHashMap
    //   5: dup
    //   6: aload_0
    //   7: getfield map : Ljava/util/LinkedHashMap;
    //   10: invokespecial <init> : (Ljava/util/Map;)V
    //   13: astore_1
    //   14: aload_0
    //   15: monitorexit
    //   16: aload_1
    //   17: areturn
    //   18: astore_2
    //   19: aload_0
    //   20: monitorexit
    //   21: aload_2
    //   22: athrow
    // Exception table:
    //   from	to	target	type
    //   2	14	18	finally
  }
  
  public final String toString() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield hitCount : I
    //   6: aload_0
    //   7: getfield missCount : I
    //   10: iadd
    //   11: istore_2
    //   12: iload_2
    //   13: ifeq -> 102
    //   16: bipush #100
    //   18: aload_0
    //   19: getfield hitCount : I
    //   22: imul
    //   23: iload_2
    //   24: idiv
    //   25: istore_3
    //   26: goto -> 29
    //   29: getstatic java/util/Locale.US : Ljava/util/Locale;
    //   32: astore #4
    //   34: iconst_4
    //   35: anewarray java/lang/Object
    //   38: astore #5
    //   40: aload #5
    //   42: iconst_0
    //   43: aload_0
    //   44: getfield maxSize : I
    //   47: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   50: aastore
    //   51: aload #5
    //   53: iconst_1
    //   54: aload_0
    //   55: getfield hitCount : I
    //   58: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   61: aastore
    //   62: aload #5
    //   64: iconst_2
    //   65: aload_0
    //   66: getfield missCount : I
    //   69: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   72: aastore
    //   73: aload #5
    //   75: iconst_3
    //   76: iload_3
    //   77: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   80: aastore
    //   81: aload #4
    //   83: ldc 'LruCache[maxSize=%d,hits=%d,misses=%d,hitRate=%d%%]'
    //   85: aload #5
    //   87: invokestatic format : (Ljava/util/Locale;Ljava/lang/String;[Ljava/lang/Object;)Ljava/lang/String;
    //   90: astore #6
    //   92: aload_0
    //   93: monitorexit
    //   94: aload #6
    //   96: areturn
    //   97: astore_1
    //   98: aload_0
    //   99: monitorexit
    //   100: aload_1
    //   101: athrow
    //   102: iconst_0
    //   103: istore_3
    //   104: goto -> 29
    // Exception table:
    //   from	to	target	type
    //   2	12	97	finally
    //   16	26	97	finally
    //   29	92	97	finally
  }
  
  public void trimToSize(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield size : I
    //   6: iflt -> 142
    //   9: aload_0
    //   10: getfield map : Ljava/util/LinkedHashMap;
    //   13: invokevirtual isEmpty : ()Z
    //   16: ifeq -> 26
    //   19: aload_0
    //   20: getfield size : I
    //   23: ifne -> 142
    //   26: aload_0
    //   27: getfield size : I
    //   30: iload_1
    //   31: if_icmple -> 139
    //   34: aload_0
    //   35: getfield map : Ljava/util/LinkedHashMap;
    //   38: invokevirtual isEmpty : ()Z
    //   41: ifeq -> 47
    //   44: goto -> 139
    //   47: aload_0
    //   48: getfield map : Ljava/util/LinkedHashMap;
    //   51: invokevirtual entrySet : ()Ljava/util/Set;
    //   54: invokeinterface iterator : ()Ljava/util/Iterator;
    //   59: invokeinterface next : ()Ljava/lang/Object;
    //   64: checkcast java/util/Map$Entry
    //   67: astore #6
    //   69: aload #6
    //   71: invokeinterface getKey : ()Ljava/lang/Object;
    //   76: astore #7
    //   78: aload #6
    //   80: invokeinterface getValue : ()Ljava/lang/Object;
    //   85: astore #8
    //   87: aload_0
    //   88: getfield map : Ljava/util/LinkedHashMap;
    //   91: aload #7
    //   93: invokevirtual remove : (Ljava/lang/Object;)Ljava/lang/Object;
    //   96: pop
    //   97: aload_0
    //   98: aload_0
    //   99: getfield size : I
    //   102: aload_0
    //   103: aload #7
    //   105: aload #8
    //   107: invokespecial safeSizeOf : (Ljava/lang/Object;Ljava/lang/Object;)I
    //   110: isub
    //   111: putfield size : I
    //   114: aload_0
    //   115: iconst_1
    //   116: aload_0
    //   117: getfield evictionCount : I
    //   120: iadd
    //   121: putfield evictionCount : I
    //   124: aload_0
    //   125: monitorexit
    //   126: aload_0
    //   127: iconst_1
    //   128: aload #7
    //   130: aload #8
    //   132: aconst_null
    //   133: invokevirtual entryRemoved : (ZLjava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)V
    //   136: goto -> 0
    //   139: aload_0
    //   140: monitorexit
    //   141: return
    //   142: new java/lang/StringBuilder
    //   145: dup
    //   146: invokespecial <init> : ()V
    //   149: astore_3
    //   150: aload_3
    //   151: aload_0
    //   152: invokevirtual getClass : ()Ljava/lang/Class;
    //   155: invokevirtual getName : ()Ljava/lang/String;
    //   158: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   161: pop
    //   162: aload_3
    //   163: ldc '.sizeOf() is reporting inconsistent results!'
    //   165: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   168: pop
    //   169: new java/lang/IllegalStateException
    //   172: dup
    //   173: aload_3
    //   174: invokevirtual toString : ()Ljava/lang/String;
    //   177: invokespecial <init> : (Ljava/lang/String;)V
    //   180: athrow
    //   181: astore_2
    //   182: aload_0
    //   183: monitorexit
    //   184: aload_2
    //   185: athrow
    // Exception table:
    //   from	to	target	type
    //   2	26	181	finally
    //   26	44	181	finally
    //   47	126	181	finally
    //   139	141	181	finally
    //   142	181	181	finally
    //   182	184	181	finally
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v\\util\LruCache.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */