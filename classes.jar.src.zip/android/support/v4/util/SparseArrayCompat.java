package android.support.v4.util;

public class SparseArrayCompat<E> implements Cloneable {
  private static final Object DELETED = new Object();
  
  private boolean mGarbage = false;
  
  private int[] mKeys;
  
  private int mSize;
  
  private Object[] mValues;
  
  public SparseArrayCompat() {
    this(10);
  }
  
  public SparseArrayCompat(int paramInt) {
    if (paramInt == 0) {
      this.mKeys = ContainerHelpers.a;
      this.mValues = ContainerHelpers.c;
    } else {
      int i = ContainerHelpers.idealIntArraySize(paramInt);
      this.mKeys = new int[i];
      this.mValues = new Object[i];
    } 
    this.mSize = 0;
  }
  
  private void gc() {
    int i = this.mSize;
    int[] arrayOfInt = this.mKeys;
    Object[] arrayOfObject = this.mValues;
    byte b1 = 0;
    byte b2 = 0;
    while (b1 < i) {
      Object object = arrayOfObject[b1];
      if (object != DELETED) {
        if (b1 != b2) {
          arrayOfInt[b2] = arrayOfInt[b1];
          arrayOfObject[b2] = object;
          arrayOfObject[b1] = null;
        } 
        b2++;
      } 
      b1++;
    } 
    this.mGarbage = false;
    this.mSize = b2;
  }
  
  public void append(int paramInt, E paramE) {
    if (this.mSize != 0 && paramInt <= this.mKeys[-1 + this.mSize]) {
      put(paramInt, paramE);
      return;
    } 
    if (this.mGarbage && this.mSize >= this.mKeys.length)
      gc(); 
    int i = this.mSize;
    if (i >= this.mKeys.length) {
      int j = ContainerHelpers.idealIntArraySize(i + 1);
      int[] arrayOfInt = new int[j];
      Object[] arrayOfObject = new Object[j];
      System.arraycopy(this.mKeys, 0, arrayOfInt, 0, this.mKeys.length);
      System.arraycopy(this.mValues, 0, arrayOfObject, 0, this.mValues.length);
      this.mKeys = arrayOfInt;
      this.mValues = arrayOfObject;
    } 
    this.mKeys[i] = paramInt;
    this.mValues[i] = paramE;
    this.mSize = i + 1;
  }
  
  public void clear() {
    int i = this.mSize;
    Object[] arrayOfObject = this.mValues;
    for (byte b = 0; b < i; b++)
      arrayOfObject[b] = null; 
    this.mSize = 0;
    this.mGarbage = false;
  }
  
  public SparseArrayCompat<E> clone() {
    SparseArrayCompat sparseArrayCompat;
    try {
      sparseArrayCompat = (SparseArrayCompat)super.clone();
      try {
        sparseArrayCompat.mKeys = (int[])this.mKeys.clone();
        sparseArrayCompat.mValues = (Object[])this.mValues.clone();
        return sparseArrayCompat;
      } catch (CloneNotSupportedException cloneNotSupportedException) {}
    } catch (CloneNotSupportedException cloneNotSupportedException) {}
    return sparseArrayCompat;
  }
  
  public void delete(int paramInt) {
    int i = ContainerHelpers.a(this.mKeys, this.mSize, paramInt);
    if (i >= 0 && this.mValues[i] != DELETED) {
      this.mValues[i] = DELETED;
      this.mGarbage = true;
    } 
  }
  
  public E get(int paramInt) {
    return get(paramInt, null);
  }
  
  public E get(int paramInt, E paramE) {
    int i = ContainerHelpers.a(this.mKeys, this.mSize, paramInt);
    return (E)((i >= 0) ? ((this.mValues[i] == DELETED) ? (Object)paramE : this.mValues[i]) : (Object)paramE);
  }
  
  public int indexOfKey(int paramInt) {
    if (this.mGarbage)
      gc(); 
    return ContainerHelpers.a(this.mKeys, this.mSize, paramInt);
  }
  
  public int indexOfValue(E paramE) {
    if (this.mGarbage)
      gc(); 
    for (byte b = 0; b < this.mSize; b++) {
      if (this.mValues[b] == paramE)
        return b; 
    } 
    return -1;
  }
  
  public int keyAt(int paramInt) {
    if (this.mGarbage)
      gc(); 
    return this.mKeys[paramInt];
  }
  
  public void put(int paramInt, E paramE) {
    int i = ContainerHelpers.a(this.mKeys, this.mSize, paramInt);
    if (i >= 0) {
      this.mValues[i] = paramE;
      return;
    } 
    int j = i ^ 0xFFFFFFFF;
    if (j < this.mSize && this.mValues[j] == DELETED) {
      this.mKeys[j] = paramInt;
      this.mValues[j] = paramE;
      return;
    } 
    if (this.mGarbage && this.mSize >= this.mKeys.length) {
      gc();
      j = 0xFFFFFFFF ^ ContainerHelpers.a(this.mKeys, this.mSize, paramInt);
    } 
    if (this.mSize >= this.mKeys.length) {
      int k = ContainerHelpers.idealIntArraySize(1 + this.mSize);
      int[] arrayOfInt = new int[k];
      Object[] arrayOfObject = new Object[k];
      System.arraycopy(this.mKeys, 0, arrayOfInt, 0, this.mKeys.length);
      System.arraycopy(this.mValues, 0, arrayOfObject, 0, this.mValues.length);
      this.mKeys = arrayOfInt;
      this.mValues = arrayOfObject;
    } 
    if (this.mSize - j != 0) {
      int[] arrayOfInt1 = this.mKeys;
      int[] arrayOfInt2 = this.mKeys;
      int k = j + 1;
      System.arraycopy(arrayOfInt1, j, arrayOfInt2, k, this.mSize - j);
      System.arraycopy(this.mValues, j, this.mValues, k, this.mSize - j);
    } 
    this.mKeys[j] = paramInt;
    this.mValues[j] = paramE;
    this.mSize = 1 + this.mSize;
  }
  
  public void remove(int paramInt) {
    delete(paramInt);
  }
  
  public void removeAt(int paramInt) {
    if (this.mValues[paramInt] != DELETED) {
      this.mValues[paramInt] = DELETED;
      this.mGarbage = true;
    } 
  }
  
  public void removeAtRange(int paramInt1, int paramInt2) {
    int i = Math.min(this.mSize, paramInt2 + paramInt1);
    while (paramInt1 < i) {
      removeAt(paramInt1);
      paramInt1++;
    } 
  }
  
  public void setValueAt(int paramInt, E paramE) {
    if (this.mGarbage)
      gc(); 
    this.mValues[paramInt] = paramE;
  }
  
  public int size() {
    if (this.mGarbage)
      gc(); 
    return this.mSize;
  }
  
  public String toString() {
    if (size() <= 0)
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(28 * this.mSize);
    stringBuilder.append('{');
    for (byte b = 0; b < this.mSize; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      stringBuilder.append(keyAt(b));
      stringBuilder.append('=');
      E e = valueAt(b);
      if (e != this) {
        stringBuilder.append(e);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public E valueAt(int paramInt) {
    if (this.mGarbage)
      gc(); 
    return (E)this.mValues[paramInt];
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v\\util\SparseArrayCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */