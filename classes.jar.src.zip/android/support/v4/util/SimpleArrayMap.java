package android.support.v4.util;

import java.util.ConcurrentModificationException;
import java.util.Map;

public class SimpleArrayMap<K, V> {
  private static final int BASE_SIZE = 4;
  
  private static final int CACHE_SIZE = 10;
  
  private static final boolean CONCURRENT_MODIFICATION_EXCEPTIONS = true;
  
  private static final boolean DEBUG = false;
  
  private static final String TAG = "ArrayMap";
  
  static Object[] b;
  
  static int c;
  
  static Object[] d;
  
  static int e;
  
  int[] f;
  
  Object[] g;
  
  int h;
  
  public SimpleArrayMap() {
    this.f = ContainerHelpers.a;
    this.g = ContainerHelpers.c;
    this.h = 0;
  }
  
  public SimpleArrayMap(int paramInt) {
    if (paramInt == 0) {
      this.f = ContainerHelpers.a;
      this.g = ContainerHelpers.c;
    } else {
      allocArrays(paramInt);
    } 
    this.h = 0;
  }
  
  public SimpleArrayMap(SimpleArrayMap<K, V> paramSimpleArrayMap) {
    this();
    if (paramSimpleArrayMap != null)
      putAll(paramSimpleArrayMap); 
  }
  
  private void allocArrays(int paramInt) {
    // Byte code:
    //   0: iload_1
    //   1: bipush #8
    //   3: if_icmpne -> 89
    //   6: ldc android/support/v4/util/ArrayMap
    //   8: monitorenter
    //   9: getstatic android/support/v4/util/SimpleArrayMap.d : [Ljava/lang/Object;
    //   12: ifnull -> 75
    //   15: getstatic android/support/v4/util/SimpleArrayMap.d : [Ljava/lang/Object;
    //   18: astore #5
    //   20: aload_0
    //   21: aload #5
    //   23: putfield g : [Ljava/lang/Object;
    //   26: aload #5
    //   28: iconst_0
    //   29: aaload
    //   30: checkcast [Ljava/lang/Object;
    //   33: checkcast [Ljava/lang/Object;
    //   36: putstatic android/support/v4/util/SimpleArrayMap.d : [Ljava/lang/Object;
    //   39: aload_0
    //   40: aload #5
    //   42: iconst_1
    //   43: aaload
    //   44: checkcast [I
    //   47: checkcast [I
    //   50: putfield f : [I
    //   53: aload #5
    //   55: iconst_1
    //   56: aconst_null
    //   57: aastore
    //   58: aload #5
    //   60: iconst_0
    //   61: aconst_null
    //   62: aastore
    //   63: getstatic android/support/v4/util/SimpleArrayMap.e : I
    //   66: iconst_1
    //   67: isub
    //   68: putstatic android/support/v4/util/SimpleArrayMap.e : I
    //   71: ldc android/support/v4/util/ArrayMap
    //   73: monitorexit
    //   74: return
    //   75: ldc android/support/v4/util/ArrayMap
    //   77: monitorexit
    //   78: goto -> 169
    //   81: astore #4
    //   83: ldc android/support/v4/util/ArrayMap
    //   85: monitorexit
    //   86: aload #4
    //   88: athrow
    //   89: iload_1
    //   90: iconst_4
    //   91: if_icmpne -> 169
    //   94: ldc android/support/v4/util/ArrayMap
    //   96: monitorenter
    //   97: getstatic android/support/v4/util/SimpleArrayMap.b : [Ljava/lang/Object;
    //   100: ifnull -> 157
    //   103: getstatic android/support/v4/util/SimpleArrayMap.b : [Ljava/lang/Object;
    //   106: astore_3
    //   107: aload_0
    //   108: aload_3
    //   109: putfield g : [Ljava/lang/Object;
    //   112: aload_3
    //   113: iconst_0
    //   114: aaload
    //   115: checkcast [Ljava/lang/Object;
    //   118: checkcast [Ljava/lang/Object;
    //   121: putstatic android/support/v4/util/SimpleArrayMap.b : [Ljava/lang/Object;
    //   124: aload_0
    //   125: aload_3
    //   126: iconst_1
    //   127: aaload
    //   128: checkcast [I
    //   131: checkcast [I
    //   134: putfield f : [I
    //   137: aload_3
    //   138: iconst_1
    //   139: aconst_null
    //   140: aastore
    //   141: aload_3
    //   142: iconst_0
    //   143: aconst_null
    //   144: aastore
    //   145: getstatic android/support/v4/util/SimpleArrayMap.c : I
    //   148: iconst_1
    //   149: isub
    //   150: putstatic android/support/v4/util/SimpleArrayMap.c : I
    //   153: ldc android/support/v4/util/ArrayMap
    //   155: monitorexit
    //   156: return
    //   157: ldc android/support/v4/util/ArrayMap
    //   159: monitorexit
    //   160: goto -> 169
    //   163: astore_2
    //   164: ldc android/support/v4/util/ArrayMap
    //   166: monitorexit
    //   167: aload_2
    //   168: athrow
    //   169: aload_0
    //   170: iload_1
    //   171: newarray int
    //   173: putfield f : [I
    //   176: aload_0
    //   177: iload_1
    //   178: iconst_1
    //   179: ishl
    //   180: anewarray java/lang/Object
    //   183: putfield g : [Ljava/lang/Object;
    //   186: return
    // Exception table:
    //   from	to	target	type
    //   9	74	81	finally
    //   75	78	81	finally
    //   83	86	81	finally
    //   97	156	163	finally
    //   157	160	163	finally
    //   164	167	163	finally
  }
  
  private static int binarySearchHashes(int[] paramArrayOfint, int paramInt1, int paramInt2) {
    try {
      return ContainerHelpers.a(paramArrayOfint, paramInt1, paramInt2);
    } catch (ArrayIndexOutOfBoundsException arrayIndexOutOfBoundsException) {
      throw new ConcurrentModificationException();
    } 
  }
  
  private static void freeArrays(int[] paramArrayOfint, Object[] paramArrayOfObject, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: arraylength
    //   2: bipush #8
    //   4: if_icmpne -> 76
    //   7: ldc android/support/v4/util/ArrayMap
    //   9: monitorenter
    //   10: getstatic android/support/v4/util/SimpleArrayMap.e : I
    //   13: bipush #10
    //   15: if_icmpge -> 64
    //   18: aload_1
    //   19: iconst_0
    //   20: getstatic android/support/v4/util/SimpleArrayMap.d : [Ljava/lang/Object;
    //   23: aastore
    //   24: aload_1
    //   25: iconst_1
    //   26: aload_0
    //   27: aastore
    //   28: iload_2
    //   29: iconst_1
    //   30: ishl
    //   31: iconst_1
    //   32: isub
    //   33: istore #6
    //   35: iload #6
    //   37: iconst_2
    //   38: if_icmplt -> 52
    //   41: aload_1
    //   42: iload #6
    //   44: aconst_null
    //   45: aastore
    //   46: iinc #6, -1
    //   49: goto -> 35
    //   52: aload_1
    //   53: putstatic android/support/v4/util/SimpleArrayMap.d : [Ljava/lang/Object;
    //   56: iconst_1
    //   57: getstatic android/support/v4/util/SimpleArrayMap.e : I
    //   60: iadd
    //   61: putstatic android/support/v4/util/SimpleArrayMap.e : I
    //   64: ldc android/support/v4/util/ArrayMap
    //   66: monitorexit
    //   67: return
    //   68: astore #5
    //   70: ldc android/support/v4/util/ArrayMap
    //   72: monitorexit
    //   73: aload #5
    //   75: athrow
    //   76: aload_0
    //   77: arraylength
    //   78: iconst_4
    //   79: if_icmpne -> 149
    //   82: ldc android/support/v4/util/ArrayMap
    //   84: monitorenter
    //   85: getstatic android/support/v4/util/SimpleArrayMap.c : I
    //   88: bipush #10
    //   90: if_icmpge -> 139
    //   93: aload_1
    //   94: iconst_0
    //   95: getstatic android/support/v4/util/SimpleArrayMap.b : [Ljava/lang/Object;
    //   98: aastore
    //   99: aload_1
    //   100: iconst_1
    //   101: aload_0
    //   102: aastore
    //   103: iload_2
    //   104: iconst_1
    //   105: ishl
    //   106: iconst_1
    //   107: isub
    //   108: istore #4
    //   110: iload #4
    //   112: iconst_2
    //   113: if_icmplt -> 127
    //   116: aload_1
    //   117: iload #4
    //   119: aconst_null
    //   120: aastore
    //   121: iinc #4, -1
    //   124: goto -> 110
    //   127: aload_1
    //   128: putstatic android/support/v4/util/SimpleArrayMap.b : [Ljava/lang/Object;
    //   131: iconst_1
    //   132: getstatic android/support/v4/util/SimpleArrayMap.c : I
    //   135: iadd
    //   136: putstatic android/support/v4/util/SimpleArrayMap.c : I
    //   139: ldc android/support/v4/util/ArrayMap
    //   141: monitorexit
    //   142: return
    //   143: astore_3
    //   144: ldc android/support/v4/util/ArrayMap
    //   146: monitorexit
    //   147: aload_3
    //   148: athrow
    //   149: return
    // Exception table:
    //   from	to	target	type
    //   10	28	68	finally
    //   41	46	68	finally
    //   52	64	68	finally
    //   64	67	68	finally
    //   70	73	68	finally
    //   85	103	143	finally
    //   116	121	143	finally
    //   127	139	143	finally
    //   139	142	143	finally
    //   144	147	143	finally
  }
  
  int a() {
    int i = this.h;
    if (i == 0)
      return -1; 
    int j = binarySearchHashes(this.f, i, 0);
    if (j < 0)
      return j; 
    if (this.g[j << 1] == null)
      return j; 
    int k;
    for (k = j + 1; k < i && this.f[k] == 0; k++) {
      if (this.g[k << 1] == null)
        return k; 
    } 
    for (int m = j - 1; m >= 0 && this.f[m] == 0; m--) {
      if (this.g[m << 1] == null)
        return m; 
    } 
    return k ^ 0xFFFFFFFF;
  }
  
  int a(Object paramObject) {
    int i = 2 * this.h;
    Object[] arrayOfObject = this.g;
    if (paramObject == null) {
      for (byte b = 1; b < i; b += 2) {
        if (arrayOfObject[b] == null)
          return b >> 1; 
      } 
    } else {
      for (byte b = 1; b < i; b += 2) {
        if (paramObject.equals(arrayOfObject[b]))
          return b >> 1; 
      } 
    } 
    return -1;
  }
  
  int a(Object paramObject, int paramInt) {
    int i = this.h;
    if (i == 0)
      return -1; 
    int j = binarySearchHashes(this.f, i, paramInt);
    if (j < 0)
      return j; 
    if (paramObject.equals(this.g[j << 1]))
      return j; 
    int k;
    for (k = j + 1; k < i && this.f[k] == paramInt; k++) {
      if (paramObject.equals(this.g[k << 1]))
        return k; 
    } 
    for (int m = j - 1; m >= 0 && this.f[m] == paramInt; m--) {
      if (paramObject.equals(this.g[m << 1]))
        return m; 
    } 
    return k ^ 0xFFFFFFFF;
  }
  
  public void clear() {
    if (this.h > 0) {
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      int i = this.h;
      this.f = ContainerHelpers.a;
      this.g = ContainerHelpers.c;
      this.h = 0;
      freeArrays(arrayOfInt, arrayOfObject, i);
    } 
    if (this.h <= 0)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public boolean containsKey(Object paramObject) {
    return (indexOfKey(paramObject) >= 0);
  }
  
  public boolean containsValue(Object paramObject) {
    return (a(paramObject) >= 0);
  }
  
  public void ensureCapacity(int paramInt) {
    int i = this.h;
    if (this.f.length < paramInt) {
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      allocArrays(paramInt);
      if (this.h > 0) {
        System.arraycopy(arrayOfInt, 0, this.f, 0, i);
        System.arraycopy(arrayOfObject, 0, this.g, 0, i << 1);
      } 
      freeArrays(arrayOfInt, arrayOfObject, i);
    } 
    if (this.h == i)
      return; 
    throw new ConcurrentModificationException();
  }
  
  public boolean equals(Object paramObject) {
    if (this == paramObject)
      return true; 
    if (paramObject instanceof SimpleArrayMap) {
      SimpleArrayMap simpleArrayMap = (SimpleArrayMap)paramObject;
      if (size() != simpleArrayMap.size())
        return false; 
      byte b = 0;
      try {
        while (b < this.h) {
          K k = keyAt(b);
          V v = valueAt(b);
          Object object = simpleArrayMap.get(k);
          if (v == null) {
            if (object == null) {
              if (!simpleArrayMap.containsKey(k))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          b++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    if (paramObject instanceof Map) {
      Map map = (Map)paramObject;
      if (size() != map.size())
        return false; 
      byte b = 0;
      try {
        while (b < this.h) {
          K k = keyAt(b);
          V v = valueAt(b);
          Object object = map.get(k);
          if (v == null) {
            if (object == null) {
              if (!map.containsKey(k))
                return false; 
            } else {
              return false;
            } 
          } else {
            boolean bool = v.equals(object);
            if (!bool)
              return false; 
          } 
          b++;
        } 
        return true;
      } catch (NullPointerException nullPointerException) {
        return false;
      } catch (ClassCastException classCastException) {
        return false;
      } 
    } 
    return false;
  }
  
  public V get(Object paramObject) {
    int i = indexOfKey(paramObject);
    return (V)((i >= 0) ? this.g[1 + (i << 1)] : null);
  }
  
  public int hashCode() {
    int[] arrayOfInt = this.f;
    Object[] arrayOfObject = this.g;
    int i = this.h;
    byte b = 0;
    boolean bool = true;
    int j = 0;
    while (b < i) {
      int m;
      Object object = arrayOfObject[bool];
      int k = arrayOfInt[b];
      if (object == null) {
        m = 0;
      } else {
        m = object.hashCode();
      } 
      j += m ^ k;
      b++;
      bool += true;
    } 
    return j;
  }
  
  public int indexOfKey(Object paramObject) {
    return (paramObject == null) ? a() : a(paramObject, paramObject.hashCode());
  }
  
  public boolean isEmpty() {
    return (this.h <= 0);
  }
  
  public K keyAt(int paramInt) {
    return (K)this.g[paramInt << 1];
  }
  
  public V put(K paramK, V paramV) {
    int j;
    int k;
    int i = this.h;
    if (paramK == null) {
      k = a();
      j = 0;
    } else {
      int n = paramK.hashCode();
      int i1 = a(paramK, n);
      j = n;
      k = i1;
    } 
    if (k >= 0) {
      int n = 1 + (k << 1);
      Object object = this.g[n];
      this.g[n] = paramV;
      return (V)object;
    } 
    int m = k ^ 0xFFFFFFFF;
    if (i >= this.f.length) {
      int n = 4;
      if (i >= 8) {
        n = i + (i >> 1);
      } else if (i >= n) {
        n = 8;
      } 
      int[] arrayOfInt = this.f;
      Object[] arrayOfObject = this.g;
      allocArrays(n);
      if (i == this.h) {
        if (this.f.length > 0) {
          System.arraycopy(arrayOfInt, 0, this.f, 0, arrayOfInt.length);
          System.arraycopy(arrayOfObject, 0, this.g, 0, arrayOfObject.length);
        } 
        freeArrays(arrayOfInt, arrayOfObject, i);
      } else {
        throw new ConcurrentModificationException();
      } 
    } 
    if (m < i) {
      int[] arrayOfInt1 = this.f;
      int[] arrayOfInt2 = this.f;
      int n = m + 1;
      System.arraycopy(arrayOfInt1, m, arrayOfInt2, n, i - m);
      System.arraycopy(this.g, m << 1, this.g, n << 1, this.h - m << 1);
    } 
    if (i == this.h && m < this.f.length) {
      this.f[m] = j;
      Object[] arrayOfObject = this.g;
      int n = m << 1;
      arrayOfObject[n] = paramK;
      this.g[n + 1] = paramV;
      this.h = 1 + this.h;
      return null;
    } 
    throw new ConcurrentModificationException();
  }
  
  public void putAll(SimpleArrayMap<? extends K, ? extends V> paramSimpleArrayMap) {
    int i = paramSimpleArrayMap.h;
    ensureCapacity(i + this.h);
    int j = this.h;
    byte b = 0;
    if (j == 0) {
      if (i > 0) {
        System.arraycopy(paramSimpleArrayMap.f, 0, this.f, 0, i);
        System.arraycopy(paramSimpleArrayMap.g, 0, this.g, 0, i << 1);
        this.h = i;
        return;
      } 
    } else {
      while (b < i) {
        put(paramSimpleArrayMap.keyAt(b), paramSimpleArrayMap.valueAt(b));
        b++;
      } 
    } 
  }
  
  public V remove(Object paramObject) {
    int i = indexOfKey(paramObject);
    return (i >= 0) ? removeAt(i) : null;
  }
  
  public V removeAt(int paramInt) {
    int k;
    Object[] arrayOfObject = this.g;
    int i = paramInt << 1;
    Object object = arrayOfObject[i + 1];
    int j = this.h;
    if (j <= 1) {
      freeArrays(this.f, this.g, j);
      this.f = ContainerHelpers.a;
      this.g = ContainerHelpers.c;
      k = 0;
    } else {
      int m = j - 1;
      int n = this.f.length;
      int i1 = 8;
      if (n > i1 && this.h < this.f.length / 3) {
        if (j > i1)
          i1 = j + (j >> 1); 
        int[] arrayOfInt = this.f;
        Object[] arrayOfObject1 = this.g;
        allocArrays(i1);
        if (j == this.h) {
          if (paramInt > 0) {
            System.arraycopy(arrayOfInt, 0, this.f, 0, paramInt);
            System.arraycopy(arrayOfObject1, 0, this.g, 0, i);
          } 
          if (paramInt < m) {
            int i2 = paramInt + 1;
            int[] arrayOfInt1 = this.f;
            int i3 = m - paramInt;
            System.arraycopy(arrayOfInt, i2, arrayOfInt1, paramInt, i3);
            System.arraycopy(arrayOfObject1, i2 << 1, this.g, i, i3 << 1);
          } 
        } else {
          throw new ConcurrentModificationException();
        } 
      } else {
        if (paramInt < m) {
          int[] arrayOfInt1 = this.f;
          int i3 = paramInt + 1;
          int[] arrayOfInt2 = this.f;
          int i4 = m - paramInt;
          System.arraycopy(arrayOfInt1, i3, arrayOfInt2, paramInt, i4);
          System.arraycopy(this.g, i3 << 1, this.g, i, i4 << 1);
        } 
        Object[] arrayOfObject1 = this.g;
        int i2 = m << 1;
        arrayOfObject1[i2] = null;
        this.g[i2 + 1] = null;
      } 
      k = m;
    } 
    if (j == this.h) {
      this.h = k;
      return (V)object;
    } 
    throw new ConcurrentModificationException();
  }
  
  public V setValueAt(int paramInt, V paramV) {
    int i = 1 + (paramInt << 1);
    Object object = this.g[i];
    this.g[i] = paramV;
    return (V)object;
  }
  
  public int size() {
    return this.h;
  }
  
  public String toString() {
    if (isEmpty())
      return "{}"; 
    StringBuilder stringBuilder = new StringBuilder(28 * this.h);
    stringBuilder.append('{');
    for (byte b = 0; b < this.h; b++) {
      if (b > 0)
        stringBuilder.append(", "); 
      K k = keyAt(b);
      if (k != this) {
        stringBuilder.append(k);
      } else {
        stringBuilder.append("(this Map)");
      } 
      stringBuilder.append('=');
      V v = valueAt(b);
      if (v != this) {
        stringBuilder.append(v);
      } else {
        stringBuilder.append("(this Map)");
      } 
    } 
    stringBuilder.append('}');
    return stringBuilder.toString();
  }
  
  public V valueAt(int paramInt) {
    return (V)this.g[1 + (paramInt << 1)];
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v\\util\SimpleArrayMap.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */