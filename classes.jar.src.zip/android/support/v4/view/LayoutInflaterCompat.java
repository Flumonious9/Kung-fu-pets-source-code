package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import java.lang.reflect.Field;

public final class LayoutInflaterCompat {
  private static final String TAG = "LayoutInflaterCompatHC";
  
  static final LayoutInflaterCompatBaseImpl a = new LayoutInflaterCompatBaseImpl();
  
  private static boolean sCheckedField;
  
  private static Field sLayoutInflaterFactory2Field;
  
  static void a(LayoutInflater paramLayoutInflater, LayoutInflater.Factory2 paramFactory2) {
    if (!sCheckedField) {
      try {
        sLayoutInflaterFactory2Field = LayoutInflater.class.getDeclaredField("mFactory2");
        sLayoutInflaterFactory2Field.setAccessible(true);
      } catch (NoSuchFieldException noSuchFieldException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("forceSetFactory2 Could not find field 'mFactory2' on class ");
        stringBuilder.append(LayoutInflater.class.getName());
        stringBuilder.append("; inflation may have unexpected results.");
        Log.e("LayoutInflaterCompatHC", stringBuilder.toString(), noSuchFieldException);
      } 
      sCheckedField = true;
    } 
    if (sLayoutInflaterFactory2Field != null)
      try {
        sLayoutInflaterFactory2Field.set(paramLayoutInflater, paramFactory2);
        return;
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("forceSetFactory2 could not set the Factory2 on LayoutInflater ");
        stringBuilder.append(paramLayoutInflater);
        stringBuilder.append("; inflation may have unexpected results.");
        Log.e("LayoutInflaterCompatHC", stringBuilder.toString(), illegalAccessException);
      }  
  }
  
  @Deprecated
  public static LayoutInflaterFactory getFactory(LayoutInflater paramLayoutInflater) {
    return a.getFactory(paramLayoutInflater);
  }
  
  @Deprecated
  public static void setFactory(@NonNull LayoutInflater paramLayoutInflater, @NonNull LayoutInflaterFactory paramLayoutInflaterFactory) {
    a.setFactory(paramLayoutInflater, paramLayoutInflaterFactory);
  }
  
  public static void setFactory2(@NonNull LayoutInflater paramLayoutInflater, @NonNull LayoutInflater.Factory2 paramFactory2) {
    a.setFactory2(paramLayoutInflater, paramFactory2);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      a = new LayoutInflaterCompatApi21Impl();
      return;
    } 
  }
  
  static class Factory2Wrapper implements LayoutInflater.Factory2 {
    final LayoutInflaterFactory a;
    
    Factory2Wrapper(LayoutInflaterFactory param1LayoutInflaterFactory) {
      this.a = param1LayoutInflaterFactory;
    }
    
    public View onCreateView(View param1View, String param1String, Context param1Context, AttributeSet param1AttributeSet) {
      return this.a.onCreateView(param1View, param1String, param1Context, param1AttributeSet);
    }
    
    public View onCreateView(String param1String, Context param1Context, AttributeSet param1AttributeSet) {
      return this.a.onCreateView(null, param1String, param1Context, param1AttributeSet);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(getClass().getName());
      stringBuilder.append("{");
      stringBuilder.append(this.a);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
  
  @RequiresApi(21)
  static class LayoutInflaterCompatApi21Impl extends LayoutInflaterCompatBaseImpl {
    public void setFactory(LayoutInflater param1LayoutInflater, LayoutInflaterFactory param1LayoutInflaterFactory) {
      LayoutInflater.Factory2 factory2;
      if (param1LayoutInflaterFactory != null) {
        factory2 = new LayoutInflaterCompat.Factory2Wrapper(param1LayoutInflaterFactory);
      } else {
        factory2 = null;
      } 
      param1LayoutInflater.setFactory2(factory2);
    }
    
    public void setFactory2(LayoutInflater param1LayoutInflater, LayoutInflater.Factory2 param1Factory2) {
      param1LayoutInflater.setFactory2(param1Factory2);
    }
  }
  
  static class LayoutInflaterCompatBaseImpl {
    public LayoutInflaterFactory getFactory(LayoutInflater param1LayoutInflater) {
      LayoutInflater.Factory factory = param1LayoutInflater.getFactory();
      return (factory instanceof LayoutInflaterCompat.Factory2Wrapper) ? ((LayoutInflaterCompat.Factory2Wrapper)factory).a : null;
    }
    
    public void setFactory(LayoutInflater param1LayoutInflater, LayoutInflaterFactory param1LayoutInflaterFactory) {
      LayoutInflater.Factory2 factory2;
      if (param1LayoutInflaterFactory != null) {
        factory2 = new LayoutInflaterCompat.Factory2Wrapper(param1LayoutInflaterFactory);
      } else {
        factory2 = null;
      } 
      setFactory2(param1LayoutInflater, factory2);
    }
    
    public void setFactory2(LayoutInflater param1LayoutInflater, LayoutInflater.Factory2 param1Factory2) {
      param1LayoutInflater.setFactory2(param1Factory2);
      LayoutInflater.Factory factory = param1LayoutInflater.getFactory();
      if (factory instanceof LayoutInflater.Factory2) {
        LayoutInflaterCompat.a(param1LayoutInflater, (LayoutInflater.Factory2)factory);
        return;
      } 
      LayoutInflaterCompat.a(param1LayoutInflater, param1Factory2);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\view\LayoutInflaterCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */