package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.CallSuper;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.Scroller;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ViewPager extends ViewGroup {
  private static final int CLOSE_ENOUGH = 2;
  
  private static final Comparator<ItemInfo> COMPARATOR;
  
  private static final boolean DEBUG = false;
  
  private static final int DEFAULT_GUTTER_SIZE = 16;
  
  private static final int DEFAULT_OFFSCREEN_PAGES = 1;
  
  private static final int DRAW_ORDER_DEFAULT = 0;
  
  private static final int DRAW_ORDER_FORWARD = 1;
  
  private static final int DRAW_ORDER_REVERSE = 2;
  
  private static final int INVALID_POINTER = -1;
  
  private static final int MAX_SETTLE_DURATION = 600;
  
  private static final int MIN_DISTANCE_FOR_FLING = 25;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  public static final int SCROLL_STATE_DRAGGING = 1;
  
  public static final int SCROLL_STATE_IDLE = 0;
  
  public static final int SCROLL_STATE_SETTLING = 2;
  
  private static final String TAG = "ViewPager";
  
  private static final boolean USE_CACHE = false;
  
  static final int[] a = new int[] { 16842931 };
  
  private static final Interpolator sInterpolator;
  
  private static final ViewPositionComparator sPositionComparator;
  
  PagerAdapter b;
  
  int c;
  
  private int mActivePointerId = -1;
  
  private List<OnAdapterChangeListener> mAdapterChangeListeners;
  
  private int mBottomPageBounds;
  
  private boolean mCalledSuper;
  
  private int mChildHeightMeasureSpec;
  
  private int mChildWidthMeasureSpec;
  
  private int mCloseEnough;
  
  private int mDecorChildCount;
  
  private int mDefaultGutterSize;
  
  private int mDrawingOrder;
  
  private ArrayList<View> mDrawingOrderedChildren;
  
  private final Runnable mEndScrollRunnable = new Runnable(this) {
      public void run() {
        this.a.setScrollState(0);
        this.a.c();
      }
    };
  
  private int mExpectedAdapterCount;
  
  private long mFakeDragBeginTime;
  
  private boolean mFakeDragging;
  
  private boolean mFirstLayout = true;
  
  private float mFirstOffset = -3.4028235E38F;
  
  private int mFlingDistance;
  
  private int mGutterSize;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private OnPageChangeListener mInternalPageChangeListener;
  
  private boolean mIsBeingDragged;
  
  private boolean mIsScrollStarted;
  
  private boolean mIsUnableToDrag;
  
  private final ArrayList<ItemInfo> mItems = new ArrayList<ItemInfo>();
  
  private float mLastMotionX;
  
  private float mLastMotionY;
  
  private float mLastOffset = Float.MAX_VALUE;
  
  private EdgeEffect mLeftEdge;
  
  private Drawable mMarginDrawable;
  
  private int mMaximumVelocity;
  
  private int mMinimumVelocity;
  
  private boolean mNeedCalculatePageOffsets = false;
  
  private PagerObserver mObserver;
  
  private int mOffscreenPageLimit = 1;
  
  private OnPageChangeListener mOnPageChangeListener;
  
  private List<OnPageChangeListener> mOnPageChangeListeners;
  
  private int mPageMargin;
  
  private PageTransformer mPageTransformer;
  
  private int mPageTransformerLayerType;
  
  private boolean mPopulatePending;
  
  private Parcelable mRestoredAdapterState = null;
  
  private ClassLoader mRestoredClassLoader = null;
  
  private int mRestoredCurItem = -1;
  
  private EdgeEffect mRightEdge;
  
  private int mScrollState = 0;
  
  private Scroller mScroller;
  
  private boolean mScrollingCacheEnabled;
  
  private final ItemInfo mTempItem = new ItemInfo();
  
  private final Rect mTempRect = new Rect();
  
  private int mTopPageBounds;
  
  private int mTouchSlop;
  
  private VelocityTracker mVelocityTracker;
  
  static {
    COMPARATOR = new Comparator<ItemInfo>() {
        public int compare(ViewPager.ItemInfo param1ItemInfo1, ViewPager.ItemInfo param1ItemInfo2) {
          return param1ItemInfo1.b - param1ItemInfo2.b;
        }
      };
    sInterpolator = new Interpolator() {
        public float getInterpolation(float param1Float) {
          float f = param1Float - 1.0F;
          return 1.0F + f * f * f * f * f;
        }
      };
    sPositionComparator = new ViewPositionComparator();
  }
  
  public ViewPager(@NonNull Context paramContext) {
    super(paramContext);
    a();
  }
  
  public ViewPager(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    a();
  }
  
  private void calculatePageOffsets(ItemInfo paramItemInfo1, int paramInt, ItemInfo paramItemInfo2) {
    float f1;
    float f3;
    float f4;
    int i = this.b.getCount();
    int j = getClientWidth();
    if (j > 0) {
      f1 = this.mPageMargin / j;
    } else {
      f1 = 0.0F;
    } 
    if (paramItemInfo2 != null) {
      int i5 = paramItemInfo2.b;
      if (i5 < paramItemInfo1.b) {
        float f = f1 + paramItemInfo2.e + paramItemInfo2.d;
        int i6 = i5 + 1;
        byte b = 0;
        while (i6 <= paramItemInfo1.b && b < this.mItems.size()) {
          ItemInfo itemInfo;
          for (itemInfo = this.mItems.get(b); i6 > itemInfo.b && b < -1 + this.mItems.size(); itemInfo = this.mItems.get(++b));
          while (i6 < itemInfo.b) {
            f += f1 + this.b.getPageWidth(i6);
            i6++;
          } 
          itemInfo.e = f;
          f += f1 + itemInfo.d;
          i6++;
        } 
      } else if (i5 > paramItemInfo1.b) {
        int i6 = -1 + this.mItems.size();
        float f = paramItemInfo2.e;
        for (int i7 = i5 - 1; i7 >= paramItemInfo1.b && i6 >= 0; i7--) {
          ItemInfo itemInfo;
          for (itemInfo = this.mItems.get(i6); i7 < itemInfo.b && i6 > 0; itemInfo = this.mItems.get(--i6));
          while (i7 > itemInfo.b) {
            f -= f1 + this.b.getPageWidth(i7);
            i7--;
          } 
          f -= f1 + itemInfo.d;
          itemInfo.e = f;
        } 
      } 
    } 
    int k = this.mItems.size();
    float f2 = paramItemInfo1.e;
    int m = -1 + paramItemInfo1.b;
    if (paramItemInfo1.b == 0) {
      f3 = paramItemInfo1.e;
    } else {
      f3 = -3.4028235E38F;
    } 
    this.mFirstOffset = f3;
    int n = paramItemInfo1.b;
    int i1 = i - 1;
    if (n == i1) {
      f4 = paramItemInfo1.e + paramItemInfo1.d - 1.0F;
    } else {
      f4 = Float.MAX_VALUE;
    } 
    this.mLastOffset = f4;
    int i2 = paramInt - 1;
    while (i2 >= 0) {
      ItemInfo itemInfo = this.mItems.get(i2);
      while (m > itemInfo.b) {
        PagerAdapter pagerAdapter = this.b;
        int i5 = m - 1;
        f2 -= f1 + pagerAdapter.getPageWidth(m);
        m = i5;
      } 
      f2 -= f1 + itemInfo.d;
      itemInfo.e = f2;
      if (itemInfo.b == 0)
        this.mFirstOffset = f2; 
      i2--;
      m--;
    } 
    float f5 = f1 + paramItemInfo1.e + paramItemInfo1.d;
    int i3 = 1 + paramItemInfo1.b;
    int i4 = paramInt + 1;
    while (i4 < k) {
      ItemInfo itemInfo = this.mItems.get(i4);
      while (i3 < itemInfo.b) {
        PagerAdapter pagerAdapter = this.b;
        int i5 = i3 + 1;
        f5 += f1 + pagerAdapter.getPageWidth(i3);
        i3 = i5;
      } 
      if (itemInfo.b == i1)
        this.mLastOffset = f5 + itemInfo.d - 1.0F; 
      itemInfo.e = f5;
      f5 += f1 + itemInfo.d;
      i4++;
      i3++;
    } 
    this.mNeedCalculatePageOffsets = false;
  }
  
  private void completeScroll(boolean paramBoolean) {
    boolean bool1;
    if (this.mScrollState == 2) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (bool1) {
      setScrollingCacheEnabled(false);
      if ((true ^ this.mScroller.isFinished()) != 0) {
        this.mScroller.abortAnimation();
        int i = getScrollX();
        int j = getScrollY();
        int k = this.mScroller.getCurrX();
        int m = this.mScroller.getCurrY();
        if (i != k || j != m) {
          scrollTo(k, m);
          if (k != i)
            pageScrolled(k); 
        } 
      } 
    } 
    this.mPopulatePending = false;
    boolean bool2 = bool1;
    for (byte b = 0; b < this.mItems.size(); b++) {
      ItemInfo itemInfo = this.mItems.get(b);
      if (itemInfo.c) {
        itemInfo.c = false;
        bool2 = true;
      } 
    } 
    if (bool2) {
      if (paramBoolean) {
        ViewCompat.postOnAnimation((View)this, this.mEndScrollRunnable);
        return;
      } 
      this.mEndScrollRunnable.run();
    } 
  }
  
  private int determineTargetPage(int paramInt1, float paramFloat, int paramInt2, int paramInt3) {
    if (Math.abs(paramInt3) > this.mFlingDistance && Math.abs(paramInt2) > this.mMinimumVelocity) {
      if (paramInt2 <= 0)
        paramInt1++; 
    } else {
      float f;
      if (paramInt1 >= this.c) {
        f = 0.4F;
      } else {
        f = 0.6F;
      } 
      paramInt1 += (int)(paramFloat + f);
    } 
    if (this.mItems.size() > 0) {
      ItemInfo itemInfo1 = this.mItems.get(0);
      ItemInfo itemInfo2 = this.mItems.get(-1 + this.mItems.size());
      paramInt1 = Math.max(itemInfo1.b, Math.min(paramInt1, itemInfo2.b));
    } 
    return paramInt1;
  }
  
  private void dispatchOnPageScrolled(int paramInt1, float paramFloat, int paramInt2) {
    if (this.mOnPageChangeListener != null)
      this.mOnPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2); 
    if (this.mOnPageChangeListeners != null) {
      byte b = 0;
      int i = this.mOnPageChangeListeners.size();
      while (b < i) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(b);
        if (onPageChangeListener != null)
          onPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2); 
        b++;
      } 
    } 
    if (this.mInternalPageChangeListener != null)
      this.mInternalPageChangeListener.onPageScrolled(paramInt1, paramFloat, paramInt2); 
  }
  
  private void dispatchOnPageSelected(int paramInt) {
    if (this.mOnPageChangeListener != null)
      this.mOnPageChangeListener.onPageSelected(paramInt); 
    if (this.mOnPageChangeListeners != null) {
      byte b = 0;
      int i = this.mOnPageChangeListeners.size();
      while (b < i) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(b);
        if (onPageChangeListener != null)
          onPageChangeListener.onPageSelected(paramInt); 
        b++;
      } 
    } 
    if (this.mInternalPageChangeListener != null)
      this.mInternalPageChangeListener.onPageSelected(paramInt); 
  }
  
  private void dispatchOnScrollStateChanged(int paramInt) {
    if (this.mOnPageChangeListener != null)
      this.mOnPageChangeListener.onPageScrollStateChanged(paramInt); 
    if (this.mOnPageChangeListeners != null) {
      byte b = 0;
      int i = this.mOnPageChangeListeners.size();
      while (b < i) {
        OnPageChangeListener onPageChangeListener = this.mOnPageChangeListeners.get(b);
        if (onPageChangeListener != null)
          onPageChangeListener.onPageScrollStateChanged(paramInt); 
        b++;
      } 
    } 
    if (this.mInternalPageChangeListener != null)
      this.mInternalPageChangeListener.onPageScrollStateChanged(paramInt); 
  }
  
  private void enableLayers(boolean paramBoolean) {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      boolean bool;
      if (paramBoolean) {
        bool = this.mPageTransformerLayerType;
      } else {
        bool = false;
      } 
      getChildAt(b).setLayerType(bool, null);
    } 
  }
  
  private void endDrag() {
    this.mIsBeingDragged = false;
    this.mIsUnableToDrag = false;
    if (this.mVelocityTracker != null) {
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
    } 
  }
  
  private Rect getChildRectInPagerCoordinates(Rect paramRect, View paramView) {
    if (paramRect == null)
      paramRect = new Rect(); 
    if (paramView == null) {
      paramRect.set(0, 0, 0, 0);
      return paramRect;
    } 
    paramRect.left = paramView.getLeft();
    paramRect.right = paramView.getRight();
    paramRect.top = paramView.getTop();
    paramRect.bottom = paramView.getBottom();
    for (ViewParent viewParent = paramView.getParent(); viewParent instanceof ViewGroup && viewParent != this; viewParent = viewGroup.getParent()) {
      ViewGroup viewGroup = (ViewGroup)viewParent;
      paramRect.left += viewGroup.getLeft();
      paramRect.right += viewGroup.getRight();
      paramRect.top += viewGroup.getTop();
      paramRect.bottom += viewGroup.getBottom();
    } 
    return paramRect;
  }
  
  private int getClientWidth() {
    return getMeasuredWidth() - getPaddingLeft() - getPaddingRight();
  }
  
  private ItemInfo infoForCurrentScrollPosition() {
    float f1;
    float f2;
    int i = getClientWidth();
    if (i > 0) {
      f1 = getScrollX() / i;
    } else {
      f1 = 0.0F;
    } 
    if (i > 0) {
      f2 = this.mPageMargin / i;
    } else {
      f2 = 0.0F;
    } 
    ItemInfo itemInfo = null;
    byte b = 0;
    boolean bool = true;
    int j = -1;
    float f3 = 0.0F;
    float f4 = 0.0F;
    while (b < this.mItems.size()) {
      ItemInfo itemInfo1 = this.mItems.get(b);
      if (!bool) {
        int k = itemInfo1.b;
        int m = j + 1;
        if (k != m) {
          itemInfo1 = this.mTempItem;
          itemInfo1.e = f2 + f3 + f4;
          itemInfo1.b = m;
          itemInfo1.d = this.b.getPageWidth(itemInfo1.b);
          b--;
        } 
      } 
      f3 = itemInfo1.e;
      float f = f2 + f3 + itemInfo1.d;
      if (bool || f1 >= f3) {
        if (f1 >= f) {
          if (b == this.mItems.size() - 1)
            return itemInfo1; 
          j = itemInfo1.b;
          f4 = itemInfo1.d;
          b++;
          itemInfo = itemInfo1;
          bool = false;
          continue;
        } 
        return itemInfo1;
      } 
      return itemInfo;
    } 
    return itemInfo;
  }
  
  private static boolean isDecorView(@NonNull View paramView) {
    return (paramView.getClass().getAnnotation(DecorView.class) != null);
  }
  
  private boolean isGutterDrag(float paramFloat1, float paramFloat2) {
    return ((paramFloat1 < this.mGutterSize && paramFloat2 > 0.0F) || (paramFloat1 > (getWidth() - this.mGutterSize) && paramFloat2 < 0.0F));
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.mActivePointerId) {
      boolean bool;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mLastMotionX = paramMotionEvent.getX(bool);
      this.mActivePointerId = paramMotionEvent.getPointerId(bool);
      if (this.mVelocityTracker != null)
        this.mVelocityTracker.clear(); 
    } 
  }
  
  private boolean pageScrolled(int paramInt) {
    if (this.mItems.size() == 0) {
      if (this.mFirstLayout)
        return false; 
      this.mCalledSuper = false;
      onPageScrolled(0, 0.0F, 0);
      if (this.mCalledSuper)
        return false; 
      throw new IllegalStateException("onPageScrolled did not call superclass implementation");
    } 
    ItemInfo itemInfo = infoForCurrentScrollPosition();
    int i = getClientWidth();
    int j = i + this.mPageMargin;
    float f1 = this.mPageMargin;
    float f2 = i;
    float f3 = f1 / f2;
    int k = itemInfo.b;
    float f4 = (paramInt / f2 - itemInfo.e) / (f3 + itemInfo.d);
    int m = (int)(f4 * j);
    this.mCalledSuper = false;
    onPageScrolled(k, f4, m);
    if (this.mCalledSuper)
      return true; 
    throw new IllegalStateException("onPageScrolled did not call superclass implementation");
  }
  
  private boolean performDrag(float paramFloat) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    float f1 = this.mLastMotionX - paramFloat;
    this.mLastMotionX = paramFloat;
    float f2 = f1 + getScrollX();
    float f3 = getClientWidth();
    float f4 = f3 * this.mFirstOffset;
    float f5 = f3 * this.mLastOffset;
    ItemInfo itemInfo1 = this.mItems.get(0);
    ItemInfo itemInfo2 = this.mItems.get(this.mItems.size() - 1);
    if (itemInfo1.b != 0) {
      f4 = f3 * itemInfo1.e;
      bool1 = false;
    } else {
      bool1 = true;
    } 
    if (itemInfo2.b != this.b.getCount() - 1) {
      f5 = f3 * itemInfo2.e;
      bool2 = false;
    } else {
      bool2 = true;
    } 
    if (f2 < f4) {
      bool3 = false;
      if (bool1) {
        float f = f4 - f2;
        this.mLeftEdge.onPull(Math.abs(f) / f3);
        bool3 = true;
      } 
      f2 = f4;
    } else {
      int j = f2 cmp f5;
      bool3 = false;
      if (j > 0) {
        bool3 = false;
        if (bool2) {
          float f = f2 - f5;
          this.mRightEdge.onPull(Math.abs(f) / f3);
          bool3 = true;
        } 
        f2 = f5;
      } 
    } 
    float f6 = this.mLastMotionX;
    int i = (int)f2;
    this.mLastMotionX = f6 + f2 - i;
    scrollTo(i, getScrollY());
    pageScrolled(i);
    return bool3;
  }
  
  private void recomputeScrollPosition(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    float f;
    if (paramInt2 > 0 && !this.mItems.isEmpty()) {
      if (!this.mScroller.isFinished()) {
        this.mScroller.setFinalX(getCurrentItem() * getClientWidth());
        return;
      } 
      int j = paramInt3 + paramInt1 - getPaddingLeft() - getPaddingRight();
      int k = paramInt4 + paramInt2 - getPaddingLeft() - getPaddingRight();
      scrollTo((int)(getScrollX() / k * j), getScrollY());
      return;
    } 
    ItemInfo itemInfo = b(this.c);
    if (itemInfo != null) {
      f = Math.min(itemInfo.e, this.mLastOffset);
    } else {
      f = 0.0F;
    } 
    int i = (int)(f * (paramInt1 - getPaddingLeft() - getPaddingRight()));
    if (i != getScrollX()) {
      completeScroll(false);
      scrollTo(i, getScrollY());
    } 
  }
  
  private void removeNonDecorViews() {
    for (byte b = 0; b < getChildCount(); b++) {
      if (!((LayoutParams)getChildAt(b).getLayoutParams()).isDecor) {
        removeViewAt(b);
        b--;
      } 
    } 
  }
  
  private void requestParentDisallowInterceptTouchEvent(boolean paramBoolean) {
    ViewParent viewParent = getParent();
    if (viewParent != null)
      viewParent.requestDisallowInterceptTouchEvent(paramBoolean); 
  }
  
  private boolean resetTouch() {
    this.mActivePointerId = -1;
    endDrag();
    this.mLeftEdge.onRelease();
    this.mRightEdge.onRelease();
    return (this.mLeftEdge.isFinished() || this.mRightEdge.isFinished());
  }
  
  private void scrollToItem(int paramInt1, boolean paramBoolean1, int paramInt2, boolean paramBoolean2) {
    boolean bool;
    ItemInfo itemInfo = b(paramInt1);
    if (itemInfo != null) {
      bool = (int)(getClientWidth() * Math.max(this.mFirstOffset, Math.min(itemInfo.e, this.mLastOffset)));
    } else {
      bool = false;
    } 
    if (paramBoolean1) {
      a(bool, 0, paramInt2);
      if (paramBoolean2) {
        dispatchOnPageSelected(paramInt1);
        return;
      } 
    } else {
      if (paramBoolean2)
        dispatchOnPageSelected(paramInt1); 
      completeScroll(false);
      scrollTo(bool, 0);
      pageScrolled(bool);
    } 
  }
  
  private void setScrollingCacheEnabled(boolean paramBoolean) {
    if (this.mScrollingCacheEnabled != paramBoolean)
      this.mScrollingCacheEnabled = paramBoolean; 
  }
  
  private void sortChildDrawingOrder() {
    if (this.mDrawingOrder != 0) {
      if (this.mDrawingOrderedChildren == null) {
        this.mDrawingOrderedChildren = new ArrayList<View>();
      } else {
        this.mDrawingOrderedChildren.clear();
      } 
      int i = getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = getChildAt(b);
        this.mDrawingOrderedChildren.add(view);
      } 
      Collections.sort(this.mDrawingOrderedChildren, sPositionComparator);
    } 
  }
  
  float a(float paramFloat) {
    return (float)Math.sin((0.47123894F * (paramFloat - 0.5F)));
  }
  
  ItemInfo a(int paramInt1, int paramInt2) {
    ItemInfo itemInfo = new ItemInfo();
    itemInfo.b = paramInt1;
    itemInfo.a = this.b.instantiateItem(this, paramInt1);
    itemInfo.d = this.b.getPageWidth(paramInt1);
    if (paramInt2 < 0 || paramInt2 >= this.mItems.size()) {
      this.mItems.add(itemInfo);
      return itemInfo;
    } 
    this.mItems.add(paramInt2, itemInfo);
    return itemInfo;
  }
  
  ItemInfo a(View paramView) {
    for (byte b = 0; b < this.mItems.size(); b++) {
      ItemInfo itemInfo = this.mItems.get(b);
      if (this.b.isViewFromObject(paramView, itemInfo.a))
        return itemInfo; 
    } 
    return null;
  }
  
  OnPageChangeListener a(OnPageChangeListener paramOnPageChangeListener) {
    OnPageChangeListener onPageChangeListener = this.mInternalPageChangeListener;
    this.mInternalPageChangeListener = paramOnPageChangeListener;
    return onPageChangeListener;
  }
  
  void a() {
    setWillNotDraw(false);
    setDescendantFocusability(262144);
    setFocusable(true);
    Context context = getContext();
    this.mScroller = new Scroller(context, sInterpolator);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(context);
    float f = (context.getResources().getDisplayMetrics()).density;
    this.mTouchSlop = viewConfiguration.getScaledPagingTouchSlop();
    this.mMinimumVelocity = (int)(400.0F * f);
    this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
    this.mLeftEdge = new EdgeEffect(context);
    this.mRightEdge = new EdgeEffect(context);
    this.mFlingDistance = (int)(25.0F * f);
    this.mCloseEnough = (int)(2.0F * f);
    this.mDefaultGutterSize = (int)(f * 16.0F);
    ViewCompat.setAccessibilityDelegate((View)this, new MyAccessibilityDelegate(this));
    if (ViewCompat.getImportantForAccessibility((View)this) == 0)
      ViewCompat.setImportantForAccessibility((View)this, 1); 
    ViewCompat.setOnApplyWindowInsetsListener((View)this, new OnApplyWindowInsetsListener(this) {
          private final Rect mTempRect = new Rect();
          
          public WindowInsetsCompat onApplyWindowInsets(View param1View, WindowInsetsCompat param1WindowInsetsCompat) {
            WindowInsetsCompat windowInsetsCompat = ViewCompat.onApplyWindowInsets(param1View, param1WindowInsetsCompat);
            if (windowInsetsCompat.isConsumed())
              return windowInsetsCompat; 
            Rect rect = this.mTempRect;
            rect.left = windowInsetsCompat.getSystemWindowInsetLeft();
            rect.top = windowInsetsCompat.getSystemWindowInsetTop();
            rect.right = windowInsetsCompat.getSystemWindowInsetRight();
            rect.bottom = windowInsetsCompat.getSystemWindowInsetBottom();
            byte b = 0;
            int i = this.a.getChildCount();
            while (b < i) {
              WindowInsetsCompat windowInsetsCompat1 = ViewCompat.dispatchApplyWindowInsets(this.a.getChildAt(b), windowInsetsCompat);
              rect.left = Math.min(windowInsetsCompat1.getSystemWindowInsetLeft(), rect.left);
              rect.top = Math.min(windowInsetsCompat1.getSystemWindowInsetTop(), rect.top);
              rect.right = Math.min(windowInsetsCompat1.getSystemWindowInsetRight(), rect.right);
              rect.bottom = Math.min(windowInsetsCompat1.getSystemWindowInsetBottom(), rect.bottom);
              b++;
            } 
            return windowInsetsCompat.replaceSystemWindowInsets(rect.left, rect.top, rect.right, rect.bottom);
          }
        });
  }
  
  void a(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: getfield c : I
    //   4: iload_1
    //   5: if_icmpeq -> 25
    //   8: aload_0
    //   9: aload_0
    //   10: getfield c : I
    //   13: invokevirtual b : (I)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   16: astore_2
    //   17: aload_0
    //   18: iload_1
    //   19: putfield c : I
    //   22: goto -> 27
    //   25: aconst_null
    //   26: astore_2
    //   27: aload_0
    //   28: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   31: ifnonnull -> 39
    //   34: aload_0
    //   35: invokespecial sortChildDrawingOrder : ()V
    //   38: return
    //   39: aload_0
    //   40: getfield mPopulatePending : Z
    //   43: ifeq -> 51
    //   46: aload_0
    //   47: invokespecial sortChildDrawingOrder : ()V
    //   50: return
    //   51: aload_0
    //   52: invokevirtual getWindowToken : ()Landroid/os/IBinder;
    //   55: ifnonnull -> 59
    //   58: return
    //   59: aload_0
    //   60: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   63: aload_0
    //   64: invokevirtual startUpdate : (Landroid/view/ViewGroup;)V
    //   67: aload_0
    //   68: getfield mOffscreenPageLimit : I
    //   71: istore_3
    //   72: iconst_0
    //   73: aload_0
    //   74: getfield c : I
    //   77: iload_3
    //   78: isub
    //   79: invokestatic max : (II)I
    //   82: istore #4
    //   84: aload_0
    //   85: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   88: invokevirtual getCount : ()I
    //   91: istore #5
    //   93: iload #5
    //   95: iconst_1
    //   96: isub
    //   97: iload_3
    //   98: aload_0
    //   99: getfield c : I
    //   102: iadd
    //   103: invokestatic min : (II)I
    //   106: istore #6
    //   108: iload #5
    //   110: aload_0
    //   111: getfield mExpectedAdapterCount : I
    //   114: if_icmpne -> 1045
    //   117: iconst_0
    //   118: istore #19
    //   120: iload #19
    //   122: aload_0
    //   123: getfield mItems : Ljava/util/ArrayList;
    //   126: invokevirtual size : ()I
    //   129: if_icmpge -> 179
    //   132: aload_0
    //   133: getfield mItems : Ljava/util/ArrayList;
    //   136: iload #19
    //   138: invokevirtual get : (I)Ljava/lang/Object;
    //   141: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   144: astore #20
    //   146: aload #20
    //   148: getfield b : I
    //   151: aload_0
    //   152: getfield c : I
    //   155: if_icmplt -> 173
    //   158: aload #20
    //   160: getfield b : I
    //   163: aload_0
    //   164: getfield c : I
    //   167: if_icmpne -> 179
    //   170: goto -> 182
    //   173: iinc #19, 1
    //   176: goto -> 120
    //   179: aconst_null
    //   180: astore #20
    //   182: aload #20
    //   184: ifnonnull -> 204
    //   187: iload #5
    //   189: ifle -> 204
    //   192: aload_0
    //   193: aload_0
    //   194: getfield c : I
    //   197: iload #19
    //   199: invokevirtual a : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   202: astore #20
    //   204: aload #20
    //   206: ifnull -> 824
    //   209: iload #19
    //   211: iconst_1
    //   212: isub
    //   213: istore #31
    //   215: iload #31
    //   217: iflt -> 237
    //   220: aload_0
    //   221: getfield mItems : Ljava/util/ArrayList;
    //   224: iload #31
    //   226: invokevirtual get : (I)Ljava/lang/Object;
    //   229: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   232: astore #32
    //   234: goto -> 240
    //   237: aconst_null
    //   238: astore #32
    //   240: aload_0
    //   241: invokespecial getClientWidth : ()I
    //   244: istore #33
    //   246: iload #33
    //   248: ifgt -> 257
    //   251: fconst_0
    //   252: fstore #34
    //   254: goto -> 276
    //   257: fconst_2
    //   258: aload #20
    //   260: getfield d : F
    //   263: fsub
    //   264: aload_0
    //   265: invokevirtual getPaddingLeft : ()I
    //   268: i2f
    //   269: iload #33
    //   271: i2f
    //   272: fdiv
    //   273: fadd
    //   274: fstore #34
    //   276: iconst_m1
    //   277: aload_0
    //   278: getfield c : I
    //   281: iadd
    //   282: istore #35
    //   284: iload #19
    //   286: istore #36
    //   288: fconst_0
    //   289: fstore #37
    //   291: iload #35
    //   293: iflt -> 496
    //   296: fload #37
    //   298: fload #34
    //   300: fcmpl
    //   301: iflt -> 390
    //   304: iload #35
    //   306: iload #4
    //   308: if_icmpge -> 390
    //   311: aload #32
    //   313: ifnonnull -> 319
    //   316: goto -> 496
    //   319: iload #35
    //   321: aload #32
    //   323: getfield b : I
    //   326: if_icmpne -> 490
    //   329: aload #32
    //   331: getfield c : Z
    //   334: ifne -> 490
    //   337: aload_0
    //   338: getfield mItems : Ljava/util/ArrayList;
    //   341: iload #31
    //   343: invokevirtual remove : (I)Ljava/lang/Object;
    //   346: pop
    //   347: aload_0
    //   348: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   351: aload_0
    //   352: iload #35
    //   354: aload #32
    //   356: getfield a : Ljava/lang/Object;
    //   359: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   362: iinc #31, -1
    //   365: iinc #36, -1
    //   368: iload #31
    //   370: iflt -> 483
    //   373: aload_0
    //   374: getfield mItems : Ljava/util/ArrayList;
    //   377: iload #31
    //   379: invokevirtual get : (I)Ljava/lang/Object;
    //   382: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   385: astore #45
    //   387: goto -> 486
    //   390: aload #32
    //   392: ifnull -> 440
    //   395: iload #35
    //   397: aload #32
    //   399: getfield b : I
    //   402: if_icmpne -> 440
    //   405: fload #37
    //   407: aload #32
    //   409: getfield d : F
    //   412: fadd
    //   413: fstore #37
    //   415: iinc #31, -1
    //   418: iload #31
    //   420: iflt -> 483
    //   423: aload_0
    //   424: getfield mItems : Ljava/util/ArrayList;
    //   427: iload #31
    //   429: invokevirtual get : (I)Ljava/lang/Object;
    //   432: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   435: astore #45
    //   437: goto -> 486
    //   440: fload #37
    //   442: aload_0
    //   443: iload #35
    //   445: iload #31
    //   447: iconst_1
    //   448: iadd
    //   449: invokevirtual a : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   452: getfield d : F
    //   455: fadd
    //   456: fstore #37
    //   458: iinc #36, 1
    //   461: iload #31
    //   463: iflt -> 483
    //   466: aload_0
    //   467: getfield mItems : Ljava/util/ArrayList;
    //   470: iload #31
    //   472: invokevirtual get : (I)Ljava/lang/Object;
    //   475: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   478: astore #45
    //   480: goto -> 486
    //   483: aconst_null
    //   484: astore #45
    //   486: aload #45
    //   488: astore #32
    //   490: iinc #35, -1
    //   493: goto -> 291
    //   496: aload #20
    //   498: getfield d : F
    //   501: fstore #38
    //   503: iload #36
    //   505: iconst_1
    //   506: iadd
    //   507: istore #39
    //   509: fload #38
    //   511: fconst_2
    //   512: fcmpg
    //   513: ifge -> 798
    //   516: iload #39
    //   518: aload_0
    //   519: getfield mItems : Ljava/util/ArrayList;
    //   522: invokevirtual size : ()I
    //   525: if_icmpge -> 545
    //   528: aload_0
    //   529: getfield mItems : Ljava/util/ArrayList;
    //   532: iload #39
    //   534: invokevirtual get : (I)Ljava/lang/Object;
    //   537: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   540: astore #40
    //   542: goto -> 548
    //   545: aconst_null
    //   546: astore #40
    //   548: iload #33
    //   550: ifgt -> 559
    //   553: fconst_0
    //   554: fstore #41
    //   556: goto -> 572
    //   559: fconst_2
    //   560: aload_0
    //   561: invokevirtual getPaddingRight : ()I
    //   564: i2f
    //   565: iload #33
    //   567: i2f
    //   568: fdiv
    //   569: fadd
    //   570: fstore #41
    //   572: aload_0
    //   573: getfield c : I
    //   576: istore #42
    //   578: iinc #42, 1
    //   581: iload #42
    //   583: iload #5
    //   585: if_icmpge -> 798
    //   588: fload #38
    //   590: fload #41
    //   592: fcmpl
    //   593: iflt -> 689
    //   596: iload #42
    //   598: iload #6
    //   600: if_icmple -> 689
    //   603: aload #40
    //   605: ifnonnull -> 611
    //   608: goto -> 798
    //   611: iload #42
    //   613: aload #40
    //   615: getfield b : I
    //   618: if_icmpne -> 795
    //   621: aload #40
    //   623: getfield c : Z
    //   626: ifne -> 795
    //   629: aload_0
    //   630: getfield mItems : Ljava/util/ArrayList;
    //   633: iload #39
    //   635: invokevirtual remove : (I)Ljava/lang/Object;
    //   638: pop
    //   639: aload_0
    //   640: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   643: aload_0
    //   644: iload #42
    //   646: aload #40
    //   648: getfield a : Ljava/lang/Object;
    //   651: invokevirtual destroyItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   654: iload #39
    //   656: aload_0
    //   657: getfield mItems : Ljava/util/ArrayList;
    //   660: invokevirtual size : ()I
    //   663: if_icmpge -> 683
    //   666: aload_0
    //   667: getfield mItems : Ljava/util/ArrayList;
    //   670: iload #39
    //   672: invokevirtual get : (I)Ljava/lang/Object;
    //   675: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   678: astore #40
    //   680: goto -> 795
    //   683: aconst_null
    //   684: astore #40
    //   686: goto -> 795
    //   689: aload #40
    //   691: ifnull -> 746
    //   694: iload #42
    //   696: aload #40
    //   698: getfield b : I
    //   701: if_icmpne -> 746
    //   704: fload #38
    //   706: aload #40
    //   708: getfield d : F
    //   711: fadd
    //   712: fstore #38
    //   714: iinc #39, 1
    //   717: iload #39
    //   719: aload_0
    //   720: getfield mItems : Ljava/util/ArrayList;
    //   723: invokevirtual size : ()I
    //   726: if_icmpge -> 683
    //   729: aload_0
    //   730: getfield mItems : Ljava/util/ArrayList;
    //   733: iload #39
    //   735: invokevirtual get : (I)Ljava/lang/Object;
    //   738: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   741: astore #40
    //   743: goto -> 795
    //   746: aload_0
    //   747: iload #42
    //   749: iload #39
    //   751: invokevirtual a : (II)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   754: astore #43
    //   756: iinc #39, 1
    //   759: fload #38
    //   761: aload #43
    //   763: getfield d : F
    //   766: fadd
    //   767: fstore #38
    //   769: iload #39
    //   771: aload_0
    //   772: getfield mItems : Ljava/util/ArrayList;
    //   775: invokevirtual size : ()I
    //   778: if_icmpge -> 683
    //   781: aload_0
    //   782: getfield mItems : Ljava/util/ArrayList;
    //   785: iload #39
    //   787: invokevirtual get : (I)Ljava/lang/Object;
    //   790: checkcast android/support/v4/view/ViewPager$ItemInfo
    //   793: astore #40
    //   795: goto -> 578
    //   798: aload_0
    //   799: aload #20
    //   801: iload #36
    //   803: aload_2
    //   804: invokespecial calculatePageOffsets : (Landroid/support/v4/view/ViewPager$ItemInfo;ILandroid/support/v4/view/ViewPager$ItemInfo;)V
    //   807: aload_0
    //   808: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   811: aload_0
    //   812: aload_0
    //   813: getfield c : I
    //   816: aload #20
    //   818: getfield a : Ljava/lang/Object;
    //   821: invokevirtual setPrimaryItem : (Landroid/view/ViewGroup;ILjava/lang/Object;)V
    //   824: aload_0
    //   825: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   828: aload_0
    //   829: invokevirtual finishUpdate : (Landroid/view/ViewGroup;)V
    //   832: aload_0
    //   833: invokevirtual getChildCount : ()I
    //   836: istore #21
    //   838: iconst_0
    //   839: istore #22
    //   841: iload #22
    //   843: iload #21
    //   845: if_icmpge -> 930
    //   848: aload_0
    //   849: iload #22
    //   851: invokevirtual getChildAt : (I)Landroid/view/View;
    //   854: astore #28
    //   856: aload #28
    //   858: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   861: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   864: astore #29
    //   866: aload #29
    //   868: iload #22
    //   870: putfield d : I
    //   873: aload #29
    //   875: getfield isDecor : Z
    //   878: ifne -> 924
    //   881: aload #29
    //   883: getfield a : F
    //   886: fconst_0
    //   887: fcmpl
    //   888: ifne -> 924
    //   891: aload_0
    //   892: aload #28
    //   894: invokevirtual a : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   897: astore #30
    //   899: aload #30
    //   901: ifnull -> 924
    //   904: aload #29
    //   906: aload #30
    //   908: getfield d : F
    //   911: putfield a : F
    //   914: aload #29
    //   916: aload #30
    //   918: getfield b : I
    //   921: putfield c : I
    //   924: iinc #22, 1
    //   927: goto -> 841
    //   930: aload_0
    //   931: invokespecial sortChildDrawingOrder : ()V
    //   934: aload_0
    //   935: invokevirtual hasFocus : ()Z
    //   938: ifeq -> 1044
    //   941: aload_0
    //   942: invokevirtual findFocus : ()Landroid/view/View;
    //   945: astore #23
    //   947: aload #23
    //   949: ifnull -> 963
    //   952: aload_0
    //   953: aload #23
    //   955: invokevirtual b : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   958: astore #24
    //   960: goto -> 966
    //   963: aconst_null
    //   964: astore #24
    //   966: aload #24
    //   968: ifnull -> 983
    //   971: aload #24
    //   973: getfield b : I
    //   976: aload_0
    //   977: getfield c : I
    //   980: if_icmpeq -> 1044
    //   983: iconst_0
    //   984: istore #25
    //   986: iload #25
    //   988: aload_0
    //   989: invokevirtual getChildCount : ()I
    //   992: if_icmpge -> 1044
    //   995: aload_0
    //   996: iload #25
    //   998: invokevirtual getChildAt : (I)Landroid/view/View;
    //   1001: astore #26
    //   1003: aload_0
    //   1004: aload #26
    //   1006: invokevirtual a : (Landroid/view/View;)Landroid/support/v4/view/ViewPager$ItemInfo;
    //   1009: astore #27
    //   1011: aload #27
    //   1013: ifnull -> 1038
    //   1016: aload #27
    //   1018: getfield b : I
    //   1021: aload_0
    //   1022: getfield c : I
    //   1025: if_icmpne -> 1038
    //   1028: aload #26
    //   1030: iconst_2
    //   1031: invokevirtual requestFocus : (I)Z
    //   1034: ifeq -> 1038
    //   1037: return
    //   1038: iinc #25, 1
    //   1041: goto -> 986
    //   1044: return
    //   1045: aload_0
    //   1046: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   1049: aload_0
    //   1050: invokevirtual getId : ()I
    //   1053: invokevirtual getResourceName : (I)Ljava/lang/String;
    //   1056: astore #7
    //   1058: goto -> 1070
    //   1061: aload_0
    //   1062: invokevirtual getId : ()I
    //   1065: invokestatic toHexString : (I)Ljava/lang/String;
    //   1068: astore #7
    //   1070: new java/lang/StringBuilder
    //   1073: dup
    //   1074: invokespecial <init> : ()V
    //   1077: astore #8
    //   1079: aload #8
    //   1081: ldc_w 'The application's PagerAdapter changed the adapter's contents without calling PagerAdapter#notifyDataSetChanged! Expected adapter item count: '
    //   1084: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1087: pop
    //   1088: aload #8
    //   1090: aload_0
    //   1091: getfield mExpectedAdapterCount : I
    //   1094: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1097: pop
    //   1098: aload #8
    //   1100: ldc_w ', found: '
    //   1103: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1106: pop
    //   1107: aload #8
    //   1109: iload #5
    //   1111: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   1114: pop
    //   1115: aload #8
    //   1117: ldc_w ' Pager id: '
    //   1120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1123: pop
    //   1124: aload #8
    //   1126: aload #7
    //   1128: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1131: pop
    //   1132: aload #8
    //   1134: ldc_w ' Pager class: '
    //   1137: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1140: pop
    //   1141: aload #8
    //   1143: aload_0
    //   1144: invokevirtual getClass : ()Ljava/lang/Class;
    //   1147: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1150: pop
    //   1151: aload #8
    //   1153: ldc_w ' Problematic adapter: '
    //   1156: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   1159: pop
    //   1160: aload #8
    //   1162: aload_0
    //   1163: getfield b : Landroid/support/v4/view/PagerAdapter;
    //   1166: invokevirtual getClass : ()Ljava/lang/Class;
    //   1169: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   1172: pop
    //   1173: new java/lang/IllegalStateException
    //   1176: dup
    //   1177: aload #8
    //   1179: invokevirtual toString : ()Ljava/lang/String;
    //   1182: invokespecial <init> : (Ljava/lang/String;)V
    //   1185: athrow
    // Exception table:
    //   from	to	target	type
    //   1045	1058	1061	android/content/res/Resources$NotFoundException
  }
  
  void a(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool;
    int i;
    int i4;
    if (getChildCount() == 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (this.mScroller != null && !this.mScroller.isFinished()) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (this.mIsScrollStarted) {
        i = this.mScroller.getCurrX();
      } else {
        i = this.mScroller.getStartX();
      } 
      this.mScroller.abortAnimation();
      setScrollingCacheEnabled(false);
    } else {
      i = getScrollX();
    } 
    int j = i;
    int k = getScrollY();
    int m = paramInt1 - j;
    int n = paramInt2 - k;
    if (m == 0 && n == 0) {
      completeScroll(false);
      c();
      setScrollState(0);
      return;
    } 
    setScrollingCacheEnabled(true);
    setScrollState(2);
    int i1 = getClientWidth();
    int i2 = i1 / 2;
    float f1 = 1.0F * Math.abs(m);
    float f2 = i1;
    float f3 = Math.min(1.0F, f1 / f2);
    float f4 = i2;
    float f5 = f4 + f4 * a(f3);
    int i3 = Math.abs(paramInt3);
    if (i3 > 0) {
      i4 = 4 * Math.round(1000.0F * Math.abs(f5 / i3));
    } else {
      float f = f2 * this.b.getPageWidth(this.c);
      i4 = (int)(100.0F * (1.0F + Math.abs(m) / (f + this.mPageMargin)));
    } 
    int i5 = Math.min(i4, 600);
    this.mIsScrollStarted = false;
    this.mScroller.startScroll(j, k, m, n, i5);
    ViewCompat.postInvalidateOnAnimation((View)this);
  }
  
  void a(int paramInt, boolean paramBoolean1, boolean paramBoolean2) {
    a(paramInt, paramBoolean1, paramBoolean2, 0);
  }
  
  void a(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, int paramInt2) {
    if (this.b == null || this.b.getCount() <= 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    if (!paramBoolean2 && this.c == paramInt1 && this.mItems.size() != 0) {
      setScrollingCacheEnabled(false);
      return;
    } 
    byte b = 1;
    if (paramInt1 < 0) {
      paramInt1 = 0;
    } else if (paramInt1 >= this.b.getCount()) {
      paramInt1 = this.b.getCount() - b;
    } 
    int i = this.mOffscreenPageLimit;
    if (paramInt1 > i + this.c || paramInt1 < this.c - i)
      for (byte b1 = 0; b1 < this.mItems.size(); b1++)
        ((ItemInfo)this.mItems.get(b1)).c = b;  
    if (this.c == paramInt1)
      b = 0; 
    if (this.mFirstLayout) {
      this.c = paramInt1;
      if (b != 0)
        dispatchOnPageSelected(paramInt1); 
      requestLayout();
      return;
    } 
    a(paramInt1);
    scrollToItem(paramInt1, paramBoolean1, paramInt2, b);
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    int i = paramArrayList.size();
    int j = getDescendantFocusability();
    if (j != 393216)
      for (byte b = 0; b < getChildCount(); b++) {
        View view = getChildAt(b);
        if (view.getVisibility() == 0) {
          ItemInfo itemInfo = a(view);
          if (itemInfo != null && itemInfo.b == this.c)
            view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        } 
      }  
    if (j != 262144 || i == paramArrayList.size()) {
      if (!isFocusable())
        return; 
      if ((paramInt2 & 0x1) == 1 && isInTouchMode() && !isFocusableInTouchMode())
        return; 
      if (paramArrayList != null)
        paramArrayList.add(this); 
    } 
  }
  
  public void addOnAdapterChangeListener(@NonNull OnAdapterChangeListener paramOnAdapterChangeListener) {
    if (this.mAdapterChangeListeners == null)
      this.mAdapterChangeListeners = new ArrayList<OnAdapterChangeListener>(); 
    this.mAdapterChangeListeners.add(paramOnAdapterChangeListener);
  }
  
  public void addOnPageChangeListener(@NonNull OnPageChangeListener paramOnPageChangeListener) {
    if (this.mOnPageChangeListeners == null)
      this.mOnPageChangeListeners = new ArrayList<OnPageChangeListener>(); 
    this.mOnPageChangeListeners.add(paramOnPageChangeListener);
  }
  
  public void addTouchables(ArrayList<View> paramArrayList) {
    for (byte b = 0; b < getChildCount(); b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = a(view);
        if (itemInfo != null && itemInfo.b == this.c)
          view.addTouchables(paramArrayList); 
      } 
    } 
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (!checkLayoutParams(paramLayoutParams))
      paramLayoutParams = generateLayoutParams(paramLayoutParams); 
    LayoutParams layoutParams = (LayoutParams)paramLayoutParams;
    layoutParams.isDecor |= isDecorView(paramView);
    if (this.mInLayout) {
      if (layoutParams == null || !layoutParams.isDecor) {
        layoutParams.b = true;
        addViewInLayout(paramView, paramInt, paramLayoutParams);
        return;
      } 
      throw new IllegalStateException("Cannot add pager decor view during layout");
    } 
    super.addView(paramView, paramInt, paramLayoutParams);
  }
  
  public boolean arrowScroll(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual findFocus : ()Landroid/view/View;
    //   4: astore_2
    //   5: aload_2
    //   6: aload_0
    //   7: if_acmpne -> 15
    //   10: aconst_null
    //   11: astore_3
    //   12: goto -> 183
    //   15: aload_2
    //   16: ifnull -> 181
    //   19: aload_2
    //   20: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   23: astore #11
    //   25: aload #11
    //   27: instanceof android/view/ViewGroup
    //   30: ifeq -> 57
    //   33: aload #11
    //   35: aload_0
    //   36: if_acmpne -> 45
    //   39: iconst_1
    //   40: istore #12
    //   42: goto -> 60
    //   45: aload #11
    //   47: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   52: astore #11
    //   54: goto -> 25
    //   57: iconst_0
    //   58: istore #12
    //   60: iload #12
    //   62: ifne -> 181
    //   65: new java/lang/StringBuilder
    //   68: dup
    //   69: invokespecial <init> : ()V
    //   72: astore #13
    //   74: aload #13
    //   76: aload_2
    //   77: invokevirtual getClass : ()Ljava/lang/Class;
    //   80: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload_2
    //   88: invokevirtual getParent : ()Landroid/view/ViewParent;
    //   91: astore #15
    //   93: aload #15
    //   95: instanceof android/view/ViewGroup
    //   98: ifeq -> 136
    //   101: aload #13
    //   103: ldc_w ' => '
    //   106: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   109: pop
    //   110: aload #13
    //   112: aload #15
    //   114: invokevirtual getClass : ()Ljava/lang/Class;
    //   117: invokevirtual getSimpleName : ()Ljava/lang/String;
    //   120: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   123: pop
    //   124: aload #15
    //   126: invokeinterface getParent : ()Landroid/view/ViewParent;
    //   131: astore #15
    //   133: goto -> 93
    //   136: new java/lang/StringBuilder
    //   139: dup
    //   140: invokespecial <init> : ()V
    //   143: astore #16
    //   145: aload #16
    //   147: ldc_w 'arrowScroll tried to find focus based on non-child current focused view '
    //   150: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   153: pop
    //   154: aload #16
    //   156: aload #13
    //   158: invokevirtual toString : ()Ljava/lang/String;
    //   161: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   164: pop
    //   165: ldc 'ViewPager'
    //   167: aload #16
    //   169: invokevirtual toString : ()Ljava/lang/String;
    //   172: invokestatic e : (Ljava/lang/String;Ljava/lang/String;)I
    //   175: pop
    //   176: aconst_null
    //   177: astore_3
    //   178: goto -> 183
    //   181: aload_2
    //   182: astore_3
    //   183: invokestatic getInstance : ()Landroid/view/FocusFinder;
    //   186: aload_0
    //   187: aload_3
    //   188: iload_1
    //   189: invokevirtual findNextFocus : (Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;
    //   192: astore #4
    //   194: aload #4
    //   196: ifnull -> 342
    //   199: aload #4
    //   201: aload_3
    //   202: if_acmpeq -> 342
    //   205: iload_1
    //   206: bipush #17
    //   208: if_icmpne -> 274
    //   211: aload_0
    //   212: aload_0
    //   213: getfield mTempRect : Landroid/graphics/Rect;
    //   216: aload #4
    //   218: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   221: getfield left : I
    //   224: istore #9
    //   226: aload_0
    //   227: aload_0
    //   228: getfield mTempRect : Landroid/graphics/Rect;
    //   231: aload_3
    //   232: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   235: getfield left : I
    //   238: istore #10
    //   240: aload_3
    //   241: ifnull -> 260
    //   244: iload #9
    //   246: iload #10
    //   248: if_icmplt -> 260
    //   251: aload_0
    //   252: invokevirtual d : ()Z
    //   255: istore #8
    //   257: goto -> 267
    //   260: aload #4
    //   262: invokevirtual requestFocus : ()Z
    //   265: istore #8
    //   267: iload #8
    //   269: istore #5
    //   271: goto -> 385
    //   274: iconst_0
    //   275: istore #5
    //   277: iload_1
    //   278: bipush #66
    //   280: if_icmpne -> 385
    //   283: aload_0
    //   284: aload_0
    //   285: getfield mTempRect : Landroid/graphics/Rect;
    //   288: aload #4
    //   290: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   293: getfield left : I
    //   296: istore #6
    //   298: aload_0
    //   299: aload_0
    //   300: getfield mTempRect : Landroid/graphics/Rect;
    //   303: aload_3
    //   304: invokespecial getChildRectInPagerCoordinates : (Landroid/graphics/Rect;Landroid/view/View;)Landroid/graphics/Rect;
    //   307: getfield left : I
    //   310: istore #7
    //   312: aload_3
    //   313: ifnull -> 332
    //   316: iload #6
    //   318: iload #7
    //   320: if_icmpgt -> 332
    //   323: aload_0
    //   324: invokevirtual e : ()Z
    //   327: istore #8
    //   329: goto -> 267
    //   332: aload #4
    //   334: invokevirtual requestFocus : ()Z
    //   337: istore #8
    //   339: goto -> 267
    //   342: iload_1
    //   343: bipush #17
    //   345: if_icmpeq -> 379
    //   348: iload_1
    //   349: iconst_1
    //   350: if_icmpne -> 356
    //   353: goto -> 379
    //   356: iload_1
    //   357: bipush #66
    //   359: if_icmpeq -> 370
    //   362: iconst_0
    //   363: istore #5
    //   365: iload_1
    //   366: iconst_2
    //   367: if_icmpne -> 385
    //   370: aload_0
    //   371: invokevirtual e : ()Z
    //   374: istore #5
    //   376: goto -> 385
    //   379: aload_0
    //   380: invokevirtual d : ()Z
    //   383: istore #5
    //   385: iload #5
    //   387: ifeq -> 398
    //   390: aload_0
    //   391: iload_1
    //   392: invokestatic getContantForFocusDirection : (I)I
    //   395: invokevirtual playSoundEffect : (I)V
    //   398: iload #5
    //   400: ireturn
  }
  
  ItemInfo b(int paramInt) {
    for (byte b = 0; b < this.mItems.size(); b++) {
      ItemInfo itemInfo = this.mItems.get(b);
      if (itemInfo.b == paramInt)
        return itemInfo; 
    } 
    return null;
  }
  
  ItemInfo b(View paramView) {
    while (true) {
      ViewParent viewParent = paramView.getParent();
      if (viewParent != this) {
        if (viewParent != null) {
          if (!(viewParent instanceof View))
            return null; 
          paramView = (View)viewParent;
          continue;
        } 
        continue;
      } 
      return a(paramView);
    } 
  }
  
  void b() {
    boolean bool1;
    int i = this.b.getCount();
    this.mExpectedAdapterCount = i;
    if (this.mItems.size() < 1 + 2 * this.mOffscreenPageLimit && this.mItems.size() < i) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int j = this.c;
    boolean bool2 = bool1;
    int k = j;
    byte b = 0;
    boolean bool3 = false;
    while (b < this.mItems.size()) {
      ItemInfo itemInfo = this.mItems.get(b);
      int m = this.b.getItemPosition(itemInfo.a);
      if (m == -1)
        continue; 
      if (m == -2) {
        this.mItems.remove(b);
        b--;
        if (!bool3) {
          this.b.startUpdate(this);
          bool3 = true;
        } 
        this.b.destroyItem(this, itemInfo.b, itemInfo.a);
        if (this.c == itemInfo.b)
          k = Math.max(0, Math.min(this.c, i - 1)); 
      } else if (itemInfo.b != m) {
        if (itemInfo.b == this.c)
          k = m; 
        itemInfo.b = m;
      } else {
        continue;
      } 
      bool2 = true;
      continue;
      b++;
    } 
    if (bool3)
      this.b.finishUpdate(this); 
    Collections.sort(this.mItems, COMPARATOR);
    if (bool2) {
      int m = getChildCount();
      for (byte b1 = 0; b1 < m; b1++) {
        LayoutParams layoutParams = (LayoutParams)getChildAt(b1).getLayoutParams();
        if (!layoutParams.isDecor)
          layoutParams.a = 0.0F; 
      } 
      a(k, false, true);
      requestLayout();
    } 
  }
  
  public boolean beginFakeDrag() {
    if (this.mIsBeingDragged)
      return false; 
    this.mFakeDragging = true;
    setScrollState(1);
    this.mLastMotionX = 0.0F;
    this.mInitialMotionX = 0.0F;
    if (this.mVelocityTracker == null) {
      this.mVelocityTracker = VelocityTracker.obtain();
    } else {
      this.mVelocityTracker.clear();
    } 
    long l = SystemClock.uptimeMillis();
    MotionEvent motionEvent = MotionEvent.obtain(l, l, 0, 0.0F, 0.0F, 0);
    this.mVelocityTracker.addMovement(motionEvent);
    motionEvent.recycle();
    this.mFakeDragBeginTime = l;
    return true;
  }
  
  void c() {
    a(this.c);
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = paramView.getScrollX();
      int j = paramView.getScrollY();
      for (int k = viewGroup.getChildCount() - 1; k >= 0; k--) {
        View view = viewGroup.getChildAt(k);
        int m = paramInt2 + i;
        if (m >= view.getLeft() && m < view.getRight()) {
          int n = paramInt3 + j;
          if (n >= view.getTop() && n < view.getBottom() && canScroll(view, true, paramInt1, m - view.getLeft(), n - view.getTop()))
            return true; 
        } 
      } 
    } 
    return (paramBoolean && paramView.canScrollHorizontally(-paramInt1));
  }
  
  public boolean canScrollHorizontally(int paramInt) {
    if (this.b == null)
      return false; 
    int i = getClientWidth();
    int j = getScrollX();
    if (paramInt < 0) {
      int k = (int)(i * this.mFirstOffset);
      boolean bool = false;
      if (j > k)
        bool = true; 
      return bool;
    } 
    if (paramInt > 0) {
      int k = (int)(i * this.mLastOffset);
      boolean bool = false;
      if (j < k)
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void clearOnPageChangeListeners() {
    if (this.mOnPageChangeListeners != null)
      this.mOnPageChangeListeners.clear(); 
  }
  
  public void computeScroll() {
    this.mIsScrollStarted = true;
    if (!this.mScroller.isFinished() && this.mScroller.computeScrollOffset()) {
      int i = getScrollX();
      int j = getScrollY();
      int k = this.mScroller.getCurrX();
      int m = this.mScroller.getCurrY();
      if (i != k || j != m) {
        scrollTo(k, m);
        if (!pageScrolled(k)) {
          this.mScroller.abortAnimation();
          scrollTo(0, m);
        } 
      } 
      ViewCompat.postInvalidateOnAnimation((View)this);
      return;
    } 
    completeScroll(true);
  }
  
  boolean d() {
    if (this.c > 0) {
      setCurrentItem(this.c - 1, true);
      return true;
    } 
    return false;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || executeKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent paramAccessibilityEvent) {
    if (paramAccessibilityEvent.getEventType() == 4096)
      return super.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent); 
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = a(view);
        if (itemInfo != null && itemInfo.b == this.c && view.dispatchPopulateAccessibilityEvent(paramAccessibilityEvent))
          return true; 
      } 
    } 
    return false;
  }
  
  public void draw(Canvas paramCanvas) {
    boolean bool;
    super.draw(paramCanvas);
    int i = getOverScrollMode();
    if (i == 0 || (i == 1 && this.b != null && this.b.getCount() > 1)) {
      boolean bool1 = this.mLeftEdge.isFinished();
      bool = false;
      if (!bool1) {
        int j = paramCanvas.save();
        int k = getHeight() - getPaddingTop() - getPaddingBottom();
        int m = getWidth();
        paramCanvas.rotate(270.0F);
        paramCanvas.translate((-k + getPaddingTop()), this.mFirstOffset * m);
        this.mLeftEdge.setSize(k, m);
        bool = false | this.mLeftEdge.draw(paramCanvas);
        paramCanvas.restoreToCount(j);
      } 
      if (!this.mRightEdge.isFinished()) {
        int j = paramCanvas.save();
        int k = getWidth();
        int m = getHeight() - getPaddingTop() - getPaddingBottom();
        paramCanvas.rotate(90.0F);
        paramCanvas.translate(-getPaddingTop(), -(1.0F + this.mLastOffset) * k);
        this.mRightEdge.setSize(m, k);
        boolean bool2 = bool | this.mRightEdge.draw(paramCanvas);
        paramCanvas.restoreToCount(j);
      } 
    } else {
      this.mLeftEdge.finish();
      this.mRightEdge.finish();
      bool = false;
    } 
    if (bool)
      ViewCompat.postInvalidateOnAnimation((View)this); 
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    Drawable drawable = this.mMarginDrawable;
    if (drawable != null && drawable.isStateful())
      drawable.setState(getDrawableState()); 
  }
  
  boolean e() {
    if (this.b != null && this.c < this.b.getCount() - 1) {
      setCurrentItem(1 + this.c, true);
      return true;
    } 
    return false;
  }
  
  public void endFakeDrag() {
    if (this.mFakeDragging) {
      if (this.b != null) {
        VelocityTracker velocityTracker = this.mVelocityTracker;
        velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
        int i = (int)velocityTracker.getXVelocity(this.mActivePointerId);
        this.mPopulatePending = true;
        int j = getClientWidth();
        int k = getScrollX();
        ItemInfo itemInfo = infoForCurrentScrollPosition();
        a(determineTargetPage(itemInfo.b, (k / j - itemInfo.e) / itemInfo.d, i, (int)(this.mLastMotionX - this.mInitialMotionX)), true, true, i);
      } 
      endDrag();
      this.mFakeDragging = false;
      return;
    } 
    throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
  }
  
  public boolean executeKeyEvent(@NonNull KeyEvent paramKeyEvent) {
    if (paramKeyEvent.getAction() == 0) {
      int i = paramKeyEvent.getKeyCode();
      if (i != 61) {
        switch (i) {
          default:
            return false;
          case 22:
            return paramKeyEvent.hasModifiers(2) ? e() : arrowScroll(66);
          case 21:
            break;
        } 
        return paramKeyEvent.hasModifiers(2) ? d() : arrowScroll(17);
      } 
      if (paramKeyEvent.hasNoModifiers())
        return arrowScroll(2); 
      if (paramKeyEvent.hasModifiers(1))
        return arrowScroll(1); 
    } 
  }
  
  public void fakeDragBy(float paramFloat) {
    if (this.mFakeDragging) {
      if (this.b == null)
        return; 
      this.mLastMotionX = paramFloat + this.mLastMotionX;
      float f1 = getScrollX() - paramFloat;
      float f2 = getClientWidth();
      float f3 = f2 * this.mFirstOffset;
      float f4 = f2 * this.mLastOffset;
      ItemInfo itemInfo1 = this.mItems.get(0);
      ItemInfo itemInfo2 = this.mItems.get(-1 + this.mItems.size());
      if (itemInfo1.b != 0)
        f3 = f2 * itemInfo1.e; 
      if (itemInfo2.b != -1 + this.b.getCount())
        f4 = f2 * itemInfo2.e; 
      if (f1 < f3) {
        f1 = f3;
      } else if (f1 > f4) {
        f1 = f4;
      } 
      float f5 = this.mLastMotionX;
      int i = (int)f1;
      this.mLastMotionX = f5 + f1 - i;
      scrollTo(i, getScrollY());
      pageScrolled(i);
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(this.mFakeDragBeginTime, l, 2, this.mLastMotionX, 0.0F, 0);
      this.mVelocityTracker.addMovement(motionEvent);
      motionEvent.recycle();
      return;
    } 
    throw new IllegalStateException("No fake drag in progress. Call beginFakeDrag first.");
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return generateDefaultLayoutParams();
  }
  
  @Nullable
  public PagerAdapter getAdapter() {
    return this.b;
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    if (this.mDrawingOrder == 2)
      paramInt2 = paramInt1 - 1 - paramInt2; 
    return ((LayoutParams)((View)this.mDrawingOrderedChildren.get(paramInt2)).getLayoutParams()).d;
  }
  
  public int getCurrentItem() {
    return this.c;
  }
  
  public int getOffscreenPageLimit() {
    return this.mOffscreenPageLimit;
  }
  
  public int getPageMargin() {
    return this.mPageMargin;
  }
  
  public boolean isFakeDragging() {
    return this.mFakeDragging;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    removeCallbacks(this.mEndScrollRunnable);
    if (this.mScroller != null && !this.mScroller.isFinished())
      this.mScroller.abortAnimation(); 
    super.onDetachedFromWindow();
  }
  
  protected void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mPageMargin > 0 && this.mMarginDrawable != null && this.mItems.size() > 0 && this.b != null) {
      int i = getScrollX();
      int j = getWidth();
      float f1 = this.mPageMargin;
      float f2 = j;
      float f3 = f1 / f2;
      ArrayList<ItemInfo> arrayList = this.mItems;
      byte b = 0;
      ItemInfo itemInfo = arrayList.get(0);
      float f4 = itemInfo.e;
      int k = this.mItems.size();
      int m = itemInfo.b;
      int n = ((ItemInfo)this.mItems.get(k - 1)).b;
      while (m < n) {
        float f5;
        float f6;
        float f7;
        while (m > itemInfo.b && b < k) {
          ArrayList<ItemInfo> arrayList1 = this.mItems;
          itemInfo = arrayList1.get(++b);
        } 
        if (m == itemInfo.b) {
          f6 = f2 * (itemInfo.e + itemInfo.d);
          f5 = f3 + itemInfo.e + itemInfo.d;
        } else {
          float f8 = this.b.getPageWidth(m);
          float f9 = f2 * (f4 + f8);
          f5 = f4 + f8 + f3;
          f6 = f9;
        } 
        if (f6 + this.mPageMargin > i) {
          Drawable drawable = this.mMarginDrawable;
          int i1 = Math.round(f6);
          int i2 = this.mTopPageBounds;
          int i3 = Math.round(f6 + this.mPageMargin);
          f7 = f3;
          drawable.setBounds(i1, i2, i3, this.mBottomPageBounds);
          this.mMarginDrawable.draw(paramCanvas);
        } else {
          f7 = f3;
        } 
        if (f6 > (i + j))
          return; 
        m++;
        f4 = f5;
        f3 = f7;
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = 0xFF & paramMotionEvent.getAction();
    if (i == 3 || i == 1) {
      resetTouch();
      return false;
    } 
    if (i != 0) {
      if (this.mIsBeingDragged)
        return true; 
      if (this.mIsUnableToDrag)
        return false; 
    } 
    if (i != 0) {
      if (i != 2) {
        if (i == 6)
          onSecondaryPointerUp(paramMotionEvent); 
      } else {
        int j = this.mActivePointerId;
        if (j != -1) {
          int k = paramMotionEvent.findPointerIndex(j);
          float f1 = paramMotionEvent.getX(k);
          float f2 = f1 - this.mLastMotionX;
          float f3 = Math.abs(f2);
          float f4 = paramMotionEvent.getY(k);
          float f5 = Math.abs(f4 - this.mInitialMotionY);
          if (f2 != 0.0F && !isGutterDrag(this.mLastMotionX, f2) && canScroll((View)this, false, (int)f2, (int)f1, (int)f4)) {
            this.mLastMotionX = f1;
            this.mLastMotionY = f4;
            this.mIsUnableToDrag = true;
            return false;
          } 
          if (f3 > this.mTouchSlop && f3 * 0.5F > f5) {
            float f;
            this.mIsBeingDragged = true;
            requestParentDisallowInterceptTouchEvent(true);
            setScrollState(1);
            if (f2 > 0.0F) {
              f = this.mInitialMotionX + this.mTouchSlop;
            } else {
              f = this.mInitialMotionX - this.mTouchSlop;
            } 
            this.mLastMotionX = f;
            this.mLastMotionY = f4;
            setScrollingCacheEnabled(true);
          } else if (f5 > this.mTouchSlop) {
            this.mIsUnableToDrag = true;
          } 
          if (this.mIsBeingDragged && performDrag(f1))
            ViewCompat.postInvalidateOnAnimation((View)this); 
        } 
      } 
    } else {
      float f1 = paramMotionEvent.getX();
      this.mInitialMotionX = f1;
      this.mLastMotionX = f1;
      float f2 = paramMotionEvent.getY();
      this.mInitialMotionY = f2;
      this.mLastMotionY = f2;
      this.mActivePointerId = paramMotionEvent.getPointerId(0);
      this.mIsUnableToDrag = false;
      this.mIsScrollStarted = true;
      this.mScroller.computeScrollOffset();
      if (this.mScrollState == 2 && Math.abs(this.mScroller.getFinalX() - this.mScroller.getCurrX()) > this.mCloseEnough) {
        this.mScroller.abortAnimation();
        this.mPopulatePending = false;
        c();
        this.mIsBeingDragged = true;
        requestParentDisallowInterceptTouchEvent(true);
        setScrollState(1);
      } else {
        completeScroll(false);
        this.mIsBeingDragged = false;
      } 
    } 
    if (this.mVelocityTracker == null)
      this.mVelocityTracker = VelocityTracker.obtain(); 
    this.mVelocityTracker.addMovement(paramMotionEvent);
    return this.mIsBeingDragged;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getChildCount();
    int j = paramInt3 - paramInt1;
    int k = paramInt4 - paramInt2;
    int m = getPaddingLeft();
    int n = getPaddingTop();
    int i1 = getPaddingRight();
    int i2 = getPaddingBottom();
    int i3 = getScrollX();
    int i4 = i2;
    byte b1 = 0;
    int i5 = n;
    int i6 = m;
    for (byte b2 = 0; b2 < i; b2++) {
      View view = getChildAt(b2);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isDecor) {
          int i10;
          int i11;
          int i8 = 0x7 & layoutParams.gravity;
          int i9 = 0x70 & layoutParams.gravity;
          if (i8 != 1) {
            if (i8 != 3) {
              if (i8 != 5) {
                i10 = i6;
              } else {
                i10 = j - i1 - view.getMeasuredWidth();
                i1 += view.getMeasuredWidth();
              } 
            } else {
              int i13 = i6 + view.getMeasuredWidth();
              i10 = i6;
              i6 = i13;
            } 
          } else {
            i10 = Math.max((j - view.getMeasuredWidth()) / 2, i6);
          } 
          if (i9 != 16) {
            if (i9 != 48) {
              if (i9 != 80) {
                i11 = i5;
              } else {
                i11 = k - i4 - view.getMeasuredHeight();
                i4 += view.getMeasuredHeight();
              } 
            } else {
              int i13 = i5 + view.getMeasuredHeight();
              i11 = i5;
              i5 = i13;
            } 
          } else {
            i11 = Math.max((k - view.getMeasuredHeight()) / 2, i5);
          } 
          int i12 = i10 + i3;
          view.layout(i12, i11, i12 + view.getMeasuredWidth(), i11 + view.getMeasuredHeight());
          b1++;
        } 
      } 
    } 
    int i7 = j - i6 - i1;
    for (byte b3 = 0; b3 < i; b3++) {
      View view = getChildAt(b3);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (!layoutParams.isDecor) {
          ItemInfo itemInfo = a(view);
          if (itemInfo != null) {
            float f = i7;
            int i8 = i6 + (int)(f * itemInfo.e);
            if (layoutParams.b) {
              layoutParams.b = false;
              view.measure(View.MeasureSpec.makeMeasureSpec((int)(f * layoutParams.a), 1073741824), View.MeasureSpec.makeMeasureSpec(k - i5 - i4, 1073741824));
            } 
            view.layout(i8, i5, i8 + view.getMeasuredWidth(), i5 + view.getMeasuredHeight());
          } 
        } 
      } 
    } 
    this.mTopPageBounds = i5;
    this.mBottomPageBounds = k - i4;
    this.mDecorChildCount = b1;
    if (this.mFirstLayout)
      scrollToItem(this.c, false, 0, false); 
    this.mFirstLayout = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_0
    //   2: iload_1
    //   3: invokestatic getDefaultSize : (II)I
    //   6: iconst_0
    //   7: iload_2
    //   8: invokestatic getDefaultSize : (II)I
    //   11: invokevirtual setMeasuredDimension : (II)V
    //   14: aload_0
    //   15: invokevirtual getMeasuredWidth : ()I
    //   18: istore_3
    //   19: aload_0
    //   20: iload_3
    //   21: bipush #10
    //   23: idiv
    //   24: aload_0
    //   25: getfield mDefaultGutterSize : I
    //   28: invokestatic min : (II)I
    //   31: putfield mGutterSize : I
    //   34: iload_3
    //   35: aload_0
    //   36: invokevirtual getPaddingLeft : ()I
    //   39: isub
    //   40: aload_0
    //   41: invokevirtual getPaddingRight : ()I
    //   44: isub
    //   45: istore #4
    //   47: aload_0
    //   48: invokevirtual getMeasuredHeight : ()I
    //   51: aload_0
    //   52: invokevirtual getPaddingTop : ()I
    //   55: isub
    //   56: aload_0
    //   57: invokevirtual getPaddingBottom : ()I
    //   60: isub
    //   61: istore #5
    //   63: aload_0
    //   64: invokevirtual getChildCount : ()I
    //   67: istore #6
    //   69: iload #5
    //   71: istore #7
    //   73: iload #4
    //   75: istore #8
    //   77: iconst_0
    //   78: istore #9
    //   80: iconst_1
    //   81: istore #10
    //   83: ldc_w 1073741824
    //   86: istore #11
    //   88: iload #9
    //   90: iload #6
    //   92: if_icmpge -> 380
    //   95: aload_0
    //   96: iload #9
    //   98: invokevirtual getChildAt : (I)Landroid/view/View;
    //   101: astore #16
    //   103: aload #16
    //   105: invokevirtual getVisibility : ()I
    //   108: bipush #8
    //   110: if_icmpeq -> 374
    //   113: aload #16
    //   115: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   118: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   121: astore #17
    //   123: aload #17
    //   125: ifnull -> 374
    //   128: aload #17
    //   130: getfield isDecor : Z
    //   133: ifeq -> 374
    //   136: bipush #7
    //   138: aload #17
    //   140: getfield gravity : I
    //   143: iand
    //   144: istore #18
    //   146: bipush #112
    //   148: aload #17
    //   150: getfield gravity : I
    //   153: iand
    //   154: istore #19
    //   156: iload #19
    //   158: bipush #48
    //   160: if_icmpeq -> 179
    //   163: iload #19
    //   165: bipush #80
    //   167: if_icmpne -> 173
    //   170: goto -> 179
    //   173: iconst_0
    //   174: istore #20
    //   176: goto -> 182
    //   179: iconst_1
    //   180: istore #20
    //   182: iload #18
    //   184: iconst_3
    //   185: if_icmpeq -> 200
    //   188: iload #18
    //   190: iconst_5
    //   191: if_icmpne -> 197
    //   194: goto -> 200
    //   197: iconst_0
    //   198: istore #10
    //   200: ldc_w -2147483648
    //   203: istore #21
    //   205: iload #20
    //   207: ifeq -> 223
    //   210: ldc_w 1073741824
    //   213: istore #21
    //   215: ldc_w -2147483648
    //   218: istore #22
    //   220: goto -> 233
    //   223: iload #10
    //   225: ifeq -> 215
    //   228: ldc_w 1073741824
    //   231: istore #22
    //   233: aload #17
    //   235: getfield width : I
    //   238: bipush #-2
    //   240: if_icmpeq -> 274
    //   243: aload #17
    //   245: getfield width : I
    //   248: iconst_m1
    //   249: if_icmpeq -> 262
    //   252: aload #17
    //   254: getfield width : I
    //   257: istore #23
    //   259: goto -> 266
    //   262: iload #8
    //   264: istore #23
    //   266: ldc_w 1073741824
    //   269: istore #21
    //   271: goto -> 278
    //   274: iload #8
    //   276: istore #23
    //   278: aload #17
    //   280: getfield height : I
    //   283: bipush #-2
    //   285: if_icmpeq -> 314
    //   288: aload #17
    //   290: getfield height : I
    //   293: iconst_m1
    //   294: if_icmpeq -> 307
    //   297: aload #17
    //   299: getfield height : I
    //   302: istore #24
    //   304: goto -> 322
    //   307: iload #7
    //   309: istore #24
    //   311: goto -> 322
    //   314: iload #7
    //   316: istore #24
    //   318: iload #22
    //   320: istore #11
    //   322: aload #16
    //   324: iload #23
    //   326: iload #21
    //   328: invokestatic makeMeasureSpec : (II)I
    //   331: iload #24
    //   333: iload #11
    //   335: invokestatic makeMeasureSpec : (II)I
    //   338: invokevirtual measure : (II)V
    //   341: iload #20
    //   343: ifeq -> 359
    //   346: iload #7
    //   348: aload #16
    //   350: invokevirtual getMeasuredHeight : ()I
    //   353: isub
    //   354: istore #7
    //   356: goto -> 374
    //   359: iload #10
    //   361: ifeq -> 374
    //   364: iload #8
    //   366: aload #16
    //   368: invokevirtual getMeasuredWidth : ()I
    //   371: isub
    //   372: istore #8
    //   374: iinc #9, 1
    //   377: goto -> 80
    //   380: aload_0
    //   381: iload #8
    //   383: iload #11
    //   385: invokestatic makeMeasureSpec : (II)I
    //   388: putfield mChildWidthMeasureSpec : I
    //   391: aload_0
    //   392: iload #7
    //   394: iload #11
    //   396: invokestatic makeMeasureSpec : (II)I
    //   399: putfield mChildHeightMeasureSpec : I
    //   402: aload_0
    //   403: iload #10
    //   405: putfield mInLayout : Z
    //   408: aload_0
    //   409: invokevirtual c : ()V
    //   412: iconst_0
    //   413: istore #12
    //   415: aload_0
    //   416: iconst_0
    //   417: putfield mInLayout : Z
    //   420: aload_0
    //   421: invokevirtual getChildCount : ()I
    //   424: istore #13
    //   426: iload #12
    //   428: iload #13
    //   430: if_icmpge -> 504
    //   433: aload_0
    //   434: iload #12
    //   436: invokevirtual getChildAt : (I)Landroid/view/View;
    //   439: astore #14
    //   441: aload #14
    //   443: invokevirtual getVisibility : ()I
    //   446: bipush #8
    //   448: if_icmpeq -> 498
    //   451: aload #14
    //   453: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   456: checkcast android/support/v4/view/ViewPager$LayoutParams
    //   459: astore #15
    //   461: aload #15
    //   463: ifnull -> 474
    //   466: aload #15
    //   468: getfield isDecor : Z
    //   471: ifne -> 498
    //   474: aload #14
    //   476: iload #8
    //   478: i2f
    //   479: aload #15
    //   481: getfield a : F
    //   484: fmul
    //   485: f2i
    //   486: iload #11
    //   488: invokestatic makeMeasureSpec : (II)I
    //   491: aload_0
    //   492: getfield mChildHeightMeasureSpec : I
    //   495: invokevirtual measure : (II)V
    //   498: iinc #12, 1
    //   501: goto -> 426
    //   504: return
  }
  
  @CallSuper
  protected void onPageScrolled(int paramInt1, float paramFloat, int paramInt2) {
    int i = this.mDecorChildCount;
    byte b = 0;
    if (i > 0) {
      int j = getScrollX();
      int k = getPaddingLeft();
      int m = getPaddingRight();
      int n = getWidth();
      int i1 = getChildCount();
      int i2 = m;
      int i3 = k;
      for (byte b1 = 0; b1 < i1; b1++) {
        View view = getChildAt(b1);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isDecor) {
          int i5;
          int i4 = 0x7 & layoutParams.gravity;
          if (i4 != 1) {
            if (i4 != 3) {
              if (i4 != 5) {
                i5 = i3;
              } else {
                int i7 = n - i2 - view.getMeasuredWidth();
                i2 += view.getMeasuredWidth();
                int i8 = i7;
                i5 = i3;
                i3 = i8;
              } 
            } else {
              i5 = i3 + view.getWidth();
            } 
          } else {
            int i7 = Math.max((n - view.getMeasuredWidth()) / 2, i3);
            int i8 = i7;
            i5 = i3;
            i3 = i8;
          } 
          int i6 = i3 + j - view.getLeft();
          if (i6 != 0)
            view.offsetLeftAndRight(i6); 
          i3 = i5;
        } 
      } 
    } 
    dispatchOnPageScrolled(paramInt1, paramFloat, paramInt2);
    if (this.mPageTransformer != null) {
      int j = getScrollX();
      int k = getChildCount();
      while (b < k) {
        View view = getChildAt(b);
        if (!((LayoutParams)view.getLayoutParams()).isDecor) {
          float f = (view.getLeft() - j) / getClientWidth();
          this.mPageTransformer.transformPage(view, f);
        } 
        b++;
      } 
    } 
    this.mCalledSuper = true;
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    int m;
    byte b;
    int i = getChildCount();
    int j = paramInt & 0x2;
    int k = -1;
    if (j != 0) {
      k = i;
      b = 1;
      m = 0;
    } else {
      m = i - 1;
      b = -1;
    } 
    while (m != k) {
      View view = getChildAt(m);
      if (view.getVisibility() == 0) {
        ItemInfo itemInfo = a(view);
        if (itemInfo != null && itemInfo.b == this.c && view.requestFocus(paramInt, paramRect))
          return true; 
      } 
      m += b;
    } 
    return false;
  }
  
  public void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (this.b != null) {
      this.b.restoreState(savedState.b, savedState.c);
      a(savedState.a, false, true);
      return;
    } 
    this.mRestoredCurItem = savedState.a;
    this.mRestoredAdapterState = savedState.b;
    this.mRestoredClassLoader = savedState.c;
  }
  
  public Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.a = this.c;
    if (this.b != null)
      savedState.b = this.b.saveState(); 
    return savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      recomputeScrollPosition(paramInt1, paramInt3, this.mPageMargin, this.mPageMargin); 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (this.mFakeDragging)
      return true; 
    int i = paramMotionEvent.getAction();
    boolean bool = false;
    if (i == 0 && paramMotionEvent.getEdgeFlags() != 0)
      return false; 
    if (this.b != null) {
      float f1;
      float f2;
      boolean bool1;
      boolean bool2;
      boolean bool3;
      int j;
      if (this.b.getCount() == 0)
        return false; 
      if (this.mVelocityTracker == null)
        this.mVelocityTracker = VelocityTracker.obtain(); 
      this.mVelocityTracker.addMovement(paramMotionEvent);
      switch (0xFF & paramMotionEvent.getAction()) {
        default:
          bool = false;
          break;
        case 6:
          onSecondaryPointerUp(paramMotionEvent);
          this.mLastMotionX = paramMotionEvent.getX(paramMotionEvent.findPointerIndex(this.mActivePointerId));
          bool = false;
          break;
        case 5:
          j = paramMotionEvent.getActionIndex();
          this.mLastMotionX = paramMotionEvent.getX(j);
          this.mActivePointerId = paramMotionEvent.getPointerId(j);
          bool = false;
          break;
        case 3:
          bool3 = this.mIsBeingDragged;
          bool = false;
          if (bool3) {
            scrollToItem(this.c, true, 0, false);
            bool = resetTouch();
          } 
          break;
        case 2:
          if (!this.mIsBeingDragged) {
            int k = paramMotionEvent.findPointerIndex(this.mActivePointerId);
            if (k == -1) {
              bool = resetTouch();
              break;
            } 
            float f3 = paramMotionEvent.getX(k);
            float f4 = Math.abs(f3 - this.mLastMotionX);
            float f5 = paramMotionEvent.getY(k);
            float f6 = Math.abs(f5 - this.mLastMotionY);
            if (f4 > this.mTouchSlop && f4 > f6) {
              float f;
              this.mIsBeingDragged = true;
              requestParentDisallowInterceptTouchEvent(true);
              if (f3 - this.mInitialMotionX > 0.0F) {
                f = this.mInitialMotionX + this.mTouchSlop;
              } else {
                f = this.mInitialMotionX - this.mTouchSlop;
              } 
              this.mLastMotionX = f;
              this.mLastMotionY = f5;
              setScrollState(1);
              setScrollingCacheEnabled(true);
              ViewParent viewParent = getParent();
              if (viewParent != null)
                viewParent.requestDisallowInterceptTouchEvent(true); 
            } 
          } 
          bool2 = this.mIsBeingDragged;
          bool = false;
          if (bool2)
            int k = false | performDrag(paramMotionEvent.getX(paramMotionEvent.findPointerIndex(this.mActivePointerId))); 
          break;
        case 1:
          bool1 = this.mIsBeingDragged;
          bool = false;
          if (bool1) {
            VelocityTracker velocityTracker = this.mVelocityTracker;
            velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
            int k = (int)velocityTracker.getXVelocity(this.mActivePointerId);
            this.mPopulatePending = true;
            int m = getClientWidth();
            int n = getScrollX();
            ItemInfo itemInfo = infoForCurrentScrollPosition();
            float f3 = this.mPageMargin;
            float f4 = m;
            float f5 = f3 / f4;
            a(determineTargetPage(itemInfo.b, (n / f4 - itemInfo.e) / (f5 + itemInfo.d), k, (int)(paramMotionEvent.getX(paramMotionEvent.findPointerIndex(this.mActivePointerId)) - this.mInitialMotionX)), true, true, k);
            bool = resetTouch();
          } 
          break;
        case 0:
          this.mScroller.abortAnimation();
          this.mPopulatePending = false;
          c();
          f1 = paramMotionEvent.getX();
          this.mInitialMotionX = f1;
          this.mLastMotionX = f1;
          f2 = paramMotionEvent.getY();
          this.mInitialMotionY = f2;
          this.mLastMotionY = f2;
          this.mActivePointerId = paramMotionEvent.getPointerId(0);
          break;
      } 
      if (bool)
        ViewCompat.postInvalidateOnAnimation((View)this); 
      return true;
    } 
    return false;
  }
  
  public void removeOnAdapterChangeListener(@NonNull OnAdapterChangeListener paramOnAdapterChangeListener) {
    if (this.mAdapterChangeListeners != null)
      this.mAdapterChangeListeners.remove(paramOnAdapterChangeListener); 
  }
  
  public void removeOnPageChangeListener(@NonNull OnPageChangeListener paramOnPageChangeListener) {
    if (this.mOnPageChangeListeners != null)
      this.mOnPageChangeListeners.remove(paramOnPageChangeListener); 
  }
  
  public void removeView(View paramView) {
    if (this.mInLayout) {
      removeViewInLayout(paramView);
      return;
    } 
    super.removeView(paramView);
  }
  
  public void setAdapter(@Nullable PagerAdapter paramPagerAdapter) {
    PagerAdapter pagerAdapter1 = this.b;
    byte b = 0;
    if (pagerAdapter1 != null) {
      this.b.setViewPagerObserver(null);
      this.b.startUpdate(this);
      for (byte b1 = 0; b1 < this.mItems.size(); b1++) {
        ItemInfo itemInfo = this.mItems.get(b1);
        this.b.destroyItem(this, itemInfo.b, itemInfo.a);
      } 
      this.b.finishUpdate(this);
      this.mItems.clear();
      removeNonDecorViews();
      this.c = 0;
      scrollTo(0, 0);
    } 
    PagerAdapter pagerAdapter2 = this.b;
    this.b = paramPagerAdapter;
    this.mExpectedAdapterCount = 0;
    if (this.b != null) {
      if (this.mObserver == null)
        this.mObserver = new PagerObserver(this); 
      this.b.setViewPagerObserver(this.mObserver);
      this.mPopulatePending = false;
      boolean bool = this.mFirstLayout;
      this.mFirstLayout = true;
      this.mExpectedAdapterCount = this.b.getCount();
      if (this.mRestoredCurItem >= 0) {
        this.b.restoreState(this.mRestoredAdapterState, this.mRestoredClassLoader);
        a(this.mRestoredCurItem, false, true);
        this.mRestoredCurItem = -1;
        this.mRestoredAdapterState = null;
        this.mRestoredClassLoader = null;
      } else if (!bool) {
        c();
      } else {
        requestLayout();
      } 
    } 
    if (this.mAdapterChangeListeners != null && !this.mAdapterChangeListeners.isEmpty()) {
      int i = this.mAdapterChangeListeners.size();
      while (b < i) {
        ((OnAdapterChangeListener)this.mAdapterChangeListeners.get(b)).onAdapterChanged(this, pagerAdapter2, paramPagerAdapter);
        b++;
      } 
    } 
  }
  
  public void setCurrentItem(int paramInt) {
    this.mPopulatePending = false;
    a(paramInt, true ^ this.mFirstLayout, false);
  }
  
  public void setCurrentItem(int paramInt, boolean paramBoolean) {
    this.mPopulatePending = false;
    a(paramInt, paramBoolean, false);
  }
  
  public void setOffscreenPageLimit(int paramInt) {
    if (paramInt < 1) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Requested offscreen page limit ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" too small; defaulting to ");
      stringBuilder.append(1);
      Log.w("ViewPager", stringBuilder.toString());
      paramInt = 1;
    } 
    if (paramInt != this.mOffscreenPageLimit) {
      this.mOffscreenPageLimit = paramInt;
      c();
    } 
  }
  
  @Deprecated
  public void setOnPageChangeListener(OnPageChangeListener paramOnPageChangeListener) {
    this.mOnPageChangeListener = paramOnPageChangeListener;
  }
  
  public void setPageMargin(int paramInt) {
    int i = this.mPageMargin;
    this.mPageMargin = paramInt;
    int j = getWidth();
    recomputeScrollPosition(j, j, paramInt, i);
    requestLayout();
  }
  
  public void setPageMarginDrawable(@DrawableRes int paramInt) {
    setPageMarginDrawable(ContextCompat.getDrawable(getContext(), paramInt));
  }
  
  public void setPageMarginDrawable(@Nullable Drawable paramDrawable) {
    boolean bool;
    this.mMarginDrawable = paramDrawable;
    if (paramDrawable != null)
      refreshDrawableState(); 
    if (paramDrawable == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    invalidate();
  }
  
  public void setPageTransformer(boolean paramBoolean, @Nullable PageTransformer paramPageTransformer) {
    setPageTransformer(paramBoolean, paramPageTransformer, 2);
  }
  
  public void setPageTransformer(boolean paramBoolean, @Nullable PageTransformer paramPageTransformer, int paramInt) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    byte b = 1;
    if (paramPageTransformer != null) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    if (this.mPageTransformer != null) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    if (bool1 != bool2) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    this.mPageTransformer = paramPageTransformer;
    setChildrenDrawingOrderEnabled(bool1);
    if (bool1) {
      if (paramBoolean)
        b = 2; 
      this.mDrawingOrder = b;
      this.mPageTransformerLayerType = paramInt;
    } else {
      this.mDrawingOrder = 0;
    } 
    if (bool3)
      c(); 
  }
  
  void setScrollState(int paramInt) {
    if (this.mScrollState == paramInt)
      return; 
    this.mScrollState = paramInt;
    if (this.mPageTransformer != null) {
      boolean bool;
      if (paramInt != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      enableLayers(bool);
    } 
    dispatchOnScrollStateChanged(paramInt);
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mMarginDrawable);
  }
  
  @Inherited
  @Retention(RetentionPolicy.RUNTIME)
  @Target({ElementType.TYPE})
  public static @interface DecorView {}
  
  static class ItemInfo {
    Object a;
    
    int b;
    
    boolean c;
    
    float d;
    
    float e;
  }
  
  public static class LayoutParams extends ViewGroup.LayoutParams {
    float a = 0.0F;
    
    boolean b;
    
    int c;
    
    int d;
    
    public int gravity;
    
    public boolean isDecor;
    
    public LayoutParams() {
      super(-1, -1);
    }
    
    public LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ViewPager.a);
      this.gravity = typedArray.getInteger(0, 48);
      typedArray.recycle();
    }
  }
  
  class MyAccessibilityDelegate extends AccessibilityDelegateCompat {
    MyAccessibilityDelegate(ViewPager this$0) {}
    
    private boolean canScroll() {
      return (this.b.b != null && this.b.b.getCount() > 1);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(ViewPager.class.getName());
      param1AccessibilityEvent.setScrollable(canScroll());
      if (param1AccessibilityEvent.getEventType() == 4096 && this.b.b != null) {
        param1AccessibilityEvent.setItemCount(this.b.b.getCount());
        param1AccessibilityEvent.setFromIndex(this.b.c);
        param1AccessibilityEvent.setToIndex(this.b.c);
      } 
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      param1AccessibilityNodeInfoCompat.setClassName(ViewPager.class.getName());
      param1AccessibilityNodeInfoCompat.setScrollable(canScroll());
      if (this.b.canScrollHorizontally(1))
        param1AccessibilityNodeInfoCompat.addAction(4096); 
      if (this.b.canScrollHorizontally(-1))
        param1AccessibilityNodeInfoCompat.addAction(8192); 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        if (this.b.canScrollHorizontally(-1)) {
          this.b.setCurrentItem(this.b.c - 1);
          return true;
        } 
        return false;
      } 
      if (this.b.canScrollHorizontally(1)) {
        this.b.setCurrentItem(1 + this.b.c);
        return true;
      } 
      return false;
    }
  }
  
  public static interface OnAdapterChangeListener {
    void onAdapterChanged(@NonNull ViewPager param1ViewPager, @Nullable PagerAdapter param1PagerAdapter1, @Nullable PagerAdapter param1PagerAdapter2);
  }
  
  public static interface OnPageChangeListener {
    void onPageScrollStateChanged(int param1Int);
    
    void onPageScrolled(int param1Int1, float param1Float, int param1Int2);
    
    void onPageSelected(int param1Int);
  }
  
  public static interface PageTransformer {
    void transformPage(@NonNull View param1View, float param1Float);
  }
  
  private class PagerObserver extends DataSetObserver {
    PagerObserver(ViewPager this$0) {}
    
    public void onChanged() {
      this.a.b();
    }
    
    public void onInvalidated() {
      this.a.b();
    }
  }
  
  public static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public ViewPager.SavedState createFromParcel(Parcel param2Parcel) {
          return new ViewPager.SavedState(param2Parcel, null);
        }
        
        public ViewPager.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
          return new ViewPager.SavedState(param2Parcel, param2ClassLoader);
        }
        
        public ViewPager.SavedState[] newArray(int param2Int) {
          return new ViewPager.SavedState[param2Int];
        }
      };
    
    int a;
    
    Parcelable b;
    
    ClassLoader c;
    
    SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      if (param1ClassLoader == null)
        param1ClassLoader = getClass().getClassLoader(); 
      this.a = param1Parcel.readInt();
      this.b = param1Parcel.readParcelable(param1ClassLoader);
      this.c = param1ClassLoader;
    }
    
    public SavedState(@NonNull Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("FragmentPager.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" position=");
      stringBuilder.append(this.a);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.a);
      param1Parcel.writeParcelable(this.b, param1Int);
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
    public ViewPager.SavedState createFromParcel(Parcel param1Parcel) {
      return new ViewPager.SavedState(param1Parcel, null);
    }
    
    public ViewPager.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new ViewPager.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public ViewPager.SavedState[] newArray(int param1Int) {
      return new ViewPager.SavedState[param1Int];
    }
  }
  
  public static class SimpleOnPageChangeListener implements OnPageChangeListener {
    public void onPageScrollStateChanged(int param1Int) {}
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {}
    
    public void onPageSelected(int param1Int) {}
  }
  
  static class ViewPositionComparator implements Comparator<View> {
    public int compare(View param1View1, View param1View2) {
      ViewPager.LayoutParams layoutParams1 = (ViewPager.LayoutParams)param1View1.getLayoutParams();
      ViewPager.LayoutParams layoutParams2 = (ViewPager.LayoutParams)param1View2.getLayoutParams();
      return (layoutParams1.isDecor != layoutParams2.isDecor) ? (layoutParams1.isDecor ? 1 : -1) : (layoutParams1.c - layoutParams2.c);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\view\ViewPager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */