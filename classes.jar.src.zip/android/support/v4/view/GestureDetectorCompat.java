package android.support.v4.view;

import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Message;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.ViewConfiguration;

public final class GestureDetectorCompat {
  private final GestureDetectorCompatImpl mImpl;
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener) {
    this(paramContext, paramOnGestureListener, null);
  }
  
  public GestureDetectorCompat(Context paramContext, GestureDetector.OnGestureListener paramOnGestureListener, Handler paramHandler) {
    if (Build.VERSION.SDK_INT > 17) {
      this.mImpl = new GestureDetectorCompatImplJellybeanMr2(paramContext, paramOnGestureListener, paramHandler);
      return;
    } 
    this.mImpl = new GestureDetectorCompatImplBase(paramContext, paramOnGestureListener, paramHandler);
  }
  
  public boolean isLongpressEnabled() {
    return this.mImpl.isLongpressEnabled();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    return this.mImpl.onTouchEvent(paramMotionEvent);
  }
  
  public void setIsLongpressEnabled(boolean paramBoolean) {
    this.mImpl.setIsLongpressEnabled(paramBoolean);
  }
  
  public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener paramOnDoubleTapListener) {
    this.mImpl.setOnDoubleTapListener(paramOnDoubleTapListener);
  }
  
  static interface GestureDetectorCompatImpl {
    boolean isLongpressEnabled();
    
    boolean onTouchEvent(MotionEvent param1MotionEvent);
    
    void setIsLongpressEnabled(boolean param1Boolean);
    
    void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener);
  }
  
  static class GestureDetectorCompatImplBase implements GestureDetectorCompatImpl {
    private static final int DOUBLE_TAP_TIMEOUT = ViewConfiguration.getDoubleTapTimeout();
    
    private static final int LONGPRESS_TIMEOUT = ViewConfiguration.getLongPressTimeout();
    
    private static final int LONG_PRESS = 2;
    
    private static final int SHOW_PRESS = 1;
    
    private static final int TAP = 3;
    
    private static final int TAP_TIMEOUT = ViewConfiguration.getTapTimeout();
    
    final GestureDetector.OnGestureListener a;
    
    GestureDetector.OnDoubleTapListener b;
    
    boolean c;
    
    boolean d;
    
    MotionEvent e;
    
    private boolean mAlwaysInBiggerTapRegion;
    
    private boolean mAlwaysInTapRegion;
    
    private int mDoubleTapSlopSquare;
    
    private float mDownFocusX;
    
    private float mDownFocusY;
    
    private final Handler mHandler;
    
    private boolean mInLongPress;
    
    private boolean mIsDoubleTapping;
    
    private boolean mIsLongpressEnabled;
    
    private float mLastFocusX;
    
    private float mLastFocusY;
    
    private int mMaximumFlingVelocity;
    
    private int mMinimumFlingVelocity;
    
    private MotionEvent mPreviousUpEvent;
    
    private int mTouchSlopSquare;
    
    private VelocityTracker mVelocityTracker;
    
    static {
    
    }
    
    GestureDetectorCompatImplBase(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      if (param1Handler != null) {
        this.mHandler = new GestureHandler(this, param1Handler);
      } else {
        this.mHandler = new GestureHandler(this);
      } 
      this.a = param1OnGestureListener;
      if (param1OnGestureListener instanceof GestureDetector.OnDoubleTapListener)
        setOnDoubleTapListener((GestureDetector.OnDoubleTapListener)param1OnGestureListener); 
      init(param1Context);
    }
    
    private void cancel() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
      this.mIsDoubleTapping = false;
      this.c = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      this.d = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void cancelTaps() {
      this.mHandler.removeMessages(1);
      this.mHandler.removeMessages(2);
      this.mHandler.removeMessages(3);
      this.mIsDoubleTapping = false;
      this.mAlwaysInTapRegion = false;
      this.mAlwaysInBiggerTapRegion = false;
      this.d = false;
      if (this.mInLongPress)
        this.mInLongPress = false; 
    }
    
    private void init(Context param1Context) {
      if (param1Context != null) {
        if (this.a != null) {
          this.mIsLongpressEnabled = true;
          ViewConfiguration viewConfiguration = ViewConfiguration.get(param1Context);
          int i = viewConfiguration.getScaledTouchSlop();
          int j = viewConfiguration.getScaledDoubleTapSlop();
          this.mMinimumFlingVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
          this.mMaximumFlingVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
          this.mTouchSlopSquare = i * i;
          this.mDoubleTapSlopSquare = j * j;
          return;
        } 
        throw new IllegalArgumentException("OnGestureListener must not be null");
      } 
      throw new IllegalArgumentException("Context must not be null");
    }
    
    private boolean isConsideredDoubleTap(MotionEvent param1MotionEvent1, MotionEvent param1MotionEvent2, MotionEvent param1MotionEvent3) {
      if (!this.mAlwaysInBiggerTapRegion)
        return false; 
      if (param1MotionEvent3.getEventTime() - param1MotionEvent2.getEventTime() > DOUBLE_TAP_TIMEOUT)
        return false; 
      int i = (int)param1MotionEvent1.getX() - (int)param1MotionEvent3.getX();
      int j = (int)param1MotionEvent1.getY() - (int)param1MotionEvent3.getY();
      int k = i * i + j * j;
      int m = this.mDoubleTapSlopSquare;
      boolean bool = false;
      if (k < m)
        bool = true; 
      return bool;
    }
    
    void a() {
      this.mHandler.removeMessages(3);
      this.d = false;
      this.mInLongPress = true;
      this.a.onLongPress(this.e);
    }
    
    public boolean isLongpressEnabled() {
      return this.mIsLongpressEnabled;
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      // Byte code:
      //   0: aload_1
      //   1: invokevirtual getAction : ()I
      //   4: istore_2
      //   5: aload_0
      //   6: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   9: ifnonnull -> 19
      //   12: aload_0
      //   13: invokestatic obtain : ()Landroid/view/VelocityTracker;
      //   16: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   19: aload_0
      //   20: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   23: aload_1
      //   24: invokevirtual addMovement : (Landroid/view/MotionEvent;)V
      //   27: iload_2
      //   28: sipush #255
      //   31: iand
      //   32: istore_3
      //   33: iload_3
      //   34: bipush #6
      //   36: if_icmpne -> 45
      //   39: iconst_1
      //   40: istore #4
      //   42: goto -> 48
      //   45: iconst_0
      //   46: istore #4
      //   48: iload #4
      //   50: ifeq -> 62
      //   53: aload_1
      //   54: invokevirtual getActionIndex : ()I
      //   57: istore #5
      //   59: goto -> 65
      //   62: iconst_m1
      //   63: istore #5
      //   65: aload_1
      //   66: invokevirtual getPointerCount : ()I
      //   69: istore #6
      //   71: iconst_0
      //   72: istore #7
      //   74: fconst_0
      //   75: fstore #8
      //   77: fconst_0
      //   78: fstore #9
      //   80: iload #7
      //   82: iload #6
      //   84: if_icmpge -> 125
      //   87: iload #5
      //   89: iload #7
      //   91: if_icmpne -> 97
      //   94: goto -> 119
      //   97: fload #8
      //   99: aload_1
      //   100: iload #7
      //   102: invokevirtual getX : (I)F
      //   105: fadd
      //   106: fstore #8
      //   108: fload #9
      //   110: aload_1
      //   111: iload #7
      //   113: invokevirtual getY : (I)F
      //   116: fadd
      //   117: fstore #9
      //   119: iinc #7, 1
      //   122: goto -> 80
      //   125: iload #4
      //   127: ifeq -> 139
      //   130: iload #6
      //   132: iconst_1
      //   133: isub
      //   134: istore #10
      //   136: goto -> 143
      //   139: iload #6
      //   141: istore #10
      //   143: iload #10
      //   145: i2f
      //   146: fstore #11
      //   148: fload #8
      //   150: fload #11
      //   152: fdiv
      //   153: fstore #12
      //   155: fload #9
      //   157: fload #11
      //   159: fdiv
      //   160: fstore #13
      //   162: iload_3
      //   163: tableswitch default -> 204, 0 -> 913, 1 -> 635, 2 -> 393, 3 -> 387, 4 -> 204, 5 -> 357, 6 -> 206
      //   204: iconst_0
      //   205: ireturn
      //   206: aload_0
      //   207: fload #12
      //   209: putfield mLastFocusX : F
      //   212: aload_0
      //   213: fload #12
      //   215: putfield mDownFocusX : F
      //   218: aload_0
      //   219: fload #13
      //   221: putfield mLastFocusY : F
      //   224: aload_0
      //   225: fload #13
      //   227: putfield mDownFocusY : F
      //   230: aload_0
      //   231: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   234: sipush #1000
      //   237: aload_0
      //   238: getfield mMaximumFlingVelocity : I
      //   241: i2f
      //   242: invokevirtual computeCurrentVelocity : (IF)V
      //   245: aload_1
      //   246: invokevirtual getActionIndex : ()I
      //   249: istore #35
      //   251: aload_1
      //   252: iload #35
      //   254: invokevirtual getPointerId : (I)I
      //   257: istore #36
      //   259: aload_0
      //   260: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   263: iload #36
      //   265: invokevirtual getXVelocity : (I)F
      //   268: fstore #37
      //   270: aload_0
      //   271: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   274: iload #36
      //   276: invokevirtual getYVelocity : (I)F
      //   279: fstore #38
      //   281: iconst_0
      //   282: istore #39
      //   284: iconst_0
      //   285: istore #16
      //   287: iload #39
      //   289: iload #6
      //   291: if_icmpge -> 1178
      //   294: iload #39
      //   296: iload #35
      //   298: if_icmpne -> 304
      //   301: goto -> 351
      //   304: aload_1
      //   305: iload #39
      //   307: invokevirtual getPointerId : (I)I
      //   310: istore #40
      //   312: fload #37
      //   314: aload_0
      //   315: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   318: iload #40
      //   320: invokevirtual getXVelocity : (I)F
      //   323: fmul
      //   324: fload #38
      //   326: aload_0
      //   327: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   330: iload #40
      //   332: invokevirtual getYVelocity : (I)F
      //   335: fmul
      //   336: fadd
      //   337: fconst_0
      //   338: fcmpg
      //   339: ifge -> 351
      //   342: aload_0
      //   343: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   346: invokevirtual clear : ()V
      //   349: iconst_0
      //   350: ireturn
      //   351: iinc #39, 1
      //   354: goto -> 284
      //   357: aload_0
      //   358: fload #12
      //   360: putfield mLastFocusX : F
      //   363: aload_0
      //   364: fload #12
      //   366: putfield mDownFocusX : F
      //   369: aload_0
      //   370: fload #13
      //   372: putfield mLastFocusY : F
      //   375: aload_0
      //   376: fload #13
      //   378: putfield mDownFocusY : F
      //   381: aload_0
      //   382: invokespecial cancelTaps : ()V
      //   385: iconst_0
      //   386: ireturn
      //   387: aload_0
      //   388: invokespecial cancel : ()V
      //   391: iconst_0
      //   392: ireturn
      //   393: aload_0
      //   394: getfield mInLongPress : Z
      //   397: ifeq -> 402
      //   400: iconst_0
      //   401: ireturn
      //   402: aload_0
      //   403: getfield mLastFocusX : F
      //   406: fload #12
      //   408: fsub
      //   409: fstore #28
      //   411: aload_0
      //   412: getfield mLastFocusY : F
      //   415: fload #13
      //   417: fsub
      //   418: fstore #29
      //   420: aload_0
      //   421: getfield mIsDoubleTapping : Z
      //   424: ifeq -> 440
      //   427: iconst_0
      //   428: aload_0
      //   429: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   432: aload_1
      //   433: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   438: ior
      //   439: ireturn
      //   440: aload_0
      //   441: getfield mAlwaysInTapRegion : Z
      //   444: ifeq -> 573
      //   447: fload #12
      //   449: aload_0
      //   450: getfield mDownFocusX : F
      //   453: fsub
      //   454: f2i
      //   455: istore #32
      //   457: fload #13
      //   459: aload_0
      //   460: getfield mDownFocusY : F
      //   463: fsub
      //   464: f2i
      //   465: istore #33
      //   467: iload #32
      //   469: iload #32
      //   471: imul
      //   472: iload #33
      //   474: iload #33
      //   476: imul
      //   477: iadd
      //   478: istore #34
      //   480: iload #34
      //   482: aload_0
      //   483: getfield mTouchSlopSquare : I
      //   486: if_icmple -> 553
      //   489: aload_0
      //   490: getfield a : Landroid/view/GestureDetector$OnGestureListener;
      //   493: aload_0
      //   494: getfield e : Landroid/view/MotionEvent;
      //   497: aload_1
      //   498: fload #28
      //   500: fload #29
      //   502: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   507: istore #25
      //   509: aload_0
      //   510: fload #12
      //   512: putfield mLastFocusX : F
      //   515: aload_0
      //   516: fload #13
      //   518: putfield mLastFocusY : F
      //   521: aload_0
      //   522: iconst_0
      //   523: putfield mAlwaysInTapRegion : Z
      //   526: aload_0
      //   527: getfield mHandler : Landroid/os/Handler;
      //   530: iconst_3
      //   531: invokevirtual removeMessages : (I)V
      //   534: aload_0
      //   535: getfield mHandler : Landroid/os/Handler;
      //   538: iconst_1
      //   539: invokevirtual removeMessages : (I)V
      //   542: aload_0
      //   543: getfield mHandler : Landroid/os/Handler;
      //   546: iconst_2
      //   547: invokevirtual removeMessages : (I)V
      //   550: goto -> 556
      //   553: iconst_0
      //   554: istore #25
      //   556: iload #34
      //   558: aload_0
      //   559: getfield mTouchSlopSquare : I
      //   562: if_icmple -> 910
      //   565: aload_0
      //   566: iconst_0
      //   567: putfield mAlwaysInBiggerTapRegion : Z
      //   570: goto -> 910
      //   573: fload #28
      //   575: invokestatic abs : (F)F
      //   578: fconst_1
      //   579: fcmpl
      //   580: ifge -> 600
      //   583: fload #29
      //   585: invokestatic abs : (F)F
      //   588: fconst_1
      //   589: fcmpl
      //   590: istore #31
      //   592: iconst_0
      //   593: istore #16
      //   595: iload #31
      //   597: iflt -> 1178
      //   600: aload_0
      //   601: getfield a : Landroid/view/GestureDetector$OnGestureListener;
      //   604: aload_0
      //   605: getfield e : Landroid/view/MotionEvent;
      //   608: aload_1
      //   609: fload #28
      //   611: fload #29
      //   613: invokeinterface onScroll : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   618: istore #30
      //   620: aload_0
      //   621: fload #12
      //   623: putfield mLastFocusX : F
      //   626: aload_0
      //   627: fload #13
      //   629: putfield mLastFocusY : F
      //   632: iload #30
      //   634: ireturn
      //   635: aload_0
      //   636: iconst_0
      //   637: putfield c : Z
      //   640: aload_1
      //   641: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   644: astore #20
      //   646: aload_0
      //   647: getfield mIsDoubleTapping : Z
      //   650: ifeq -> 670
      //   653: iconst_0
      //   654: aload_0
      //   655: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   658: aload_1
      //   659: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   664: ior
      //   665: istore #25
      //   667: goto -> 845
      //   670: aload_0
      //   671: getfield mInLongPress : Z
      //   674: ifeq -> 693
      //   677: aload_0
      //   678: getfield mHandler : Landroid/os/Handler;
      //   681: iconst_3
      //   682: invokevirtual removeMessages : (I)V
      //   685: aload_0
      //   686: iconst_0
      //   687: putfield mInLongPress : Z
      //   690: goto -> 819
      //   693: aload_0
      //   694: getfield mAlwaysInTapRegion : Z
      //   697: ifeq -> 744
      //   700: aload_0
      //   701: getfield a : Landroid/view/GestureDetector$OnGestureListener;
      //   704: aload_1
      //   705: invokeinterface onSingleTapUp : (Landroid/view/MotionEvent;)Z
      //   710: istore #26
      //   712: aload_0
      //   713: getfield d : Z
      //   716: ifeq -> 737
      //   719: aload_0
      //   720: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   723: ifnull -> 737
      //   726: aload_0
      //   727: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   730: aload_1
      //   731: invokeinterface onSingleTapConfirmed : (Landroid/view/MotionEvent;)Z
      //   736: pop
      //   737: iload #26
      //   739: istore #25
      //   741: goto -> 845
      //   744: aload_0
      //   745: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   748: astore #21
      //   750: aload_1
      //   751: iconst_0
      //   752: invokevirtual getPointerId : (I)I
      //   755: istore #22
      //   757: aload #21
      //   759: sipush #1000
      //   762: aload_0
      //   763: getfield mMaximumFlingVelocity : I
      //   766: i2f
      //   767: invokevirtual computeCurrentVelocity : (IF)V
      //   770: aload #21
      //   772: iload #22
      //   774: invokevirtual getYVelocity : (I)F
      //   777: fstore #23
      //   779: aload #21
      //   781: iload #22
      //   783: invokevirtual getXVelocity : (I)F
      //   786: fstore #24
      //   788: fload #23
      //   790: invokestatic abs : (F)F
      //   793: aload_0
      //   794: getfield mMinimumFlingVelocity : I
      //   797: i2f
      //   798: fcmpl
      //   799: ifgt -> 825
      //   802: fload #24
      //   804: invokestatic abs : (F)F
      //   807: aload_0
      //   808: getfield mMinimumFlingVelocity : I
      //   811: i2f
      //   812: fcmpl
      //   813: ifle -> 819
      //   816: goto -> 825
      //   819: iconst_0
      //   820: istore #25
      //   822: goto -> 845
      //   825: aload_0
      //   826: getfield a : Landroid/view/GestureDetector$OnGestureListener;
      //   829: aload_0
      //   830: getfield e : Landroid/view/MotionEvent;
      //   833: aload_1
      //   834: fload #24
      //   836: fload #23
      //   838: invokeinterface onFling : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;FF)Z
      //   843: istore #25
      //   845: aload_0
      //   846: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   849: ifnull -> 859
      //   852: aload_0
      //   853: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   856: invokevirtual recycle : ()V
      //   859: aload_0
      //   860: aload #20
      //   862: putfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   865: aload_0
      //   866: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   869: ifnull -> 884
      //   872: aload_0
      //   873: getfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   876: invokevirtual recycle : ()V
      //   879: aload_0
      //   880: aconst_null
      //   881: putfield mVelocityTracker : Landroid/view/VelocityTracker;
      //   884: aload_0
      //   885: iconst_0
      //   886: putfield mIsDoubleTapping : Z
      //   889: aload_0
      //   890: iconst_0
      //   891: putfield d : Z
      //   894: aload_0
      //   895: getfield mHandler : Landroid/os/Handler;
      //   898: iconst_1
      //   899: invokevirtual removeMessages : (I)V
      //   902: aload_0
      //   903: getfield mHandler : Landroid/os/Handler;
      //   906: iconst_2
      //   907: invokevirtual removeMessages : (I)V
      //   910: iload #25
      //   912: ireturn
      //   913: aload_0
      //   914: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   917: ifnull -> 1027
      //   920: aload_0
      //   921: getfield mHandler : Landroid/os/Handler;
      //   924: iconst_3
      //   925: invokevirtual hasMessages : (I)Z
      //   928: istore #18
      //   930: iload #18
      //   932: ifeq -> 943
      //   935: aload_0
      //   936: getfield mHandler : Landroid/os/Handler;
      //   939: iconst_3
      //   940: invokevirtual removeMessages : (I)V
      //   943: aload_0
      //   944: getfield e : Landroid/view/MotionEvent;
      //   947: ifnull -> 1014
      //   950: aload_0
      //   951: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   954: ifnull -> 1014
      //   957: iload #18
      //   959: ifeq -> 1014
      //   962: aload_0
      //   963: aload_0
      //   964: getfield e : Landroid/view/MotionEvent;
      //   967: aload_0
      //   968: getfield mPreviousUpEvent : Landroid/view/MotionEvent;
      //   971: aload_1
      //   972: invokespecial isConsideredDoubleTap : (Landroid/view/MotionEvent;Landroid/view/MotionEvent;Landroid/view/MotionEvent;)Z
      //   975: ifeq -> 1014
      //   978: aload_0
      //   979: iconst_1
      //   980: putfield mIsDoubleTapping : Z
      //   983: iconst_0
      //   984: aload_0
      //   985: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   988: aload_0
      //   989: getfield e : Landroid/view/MotionEvent;
      //   992: invokeinterface onDoubleTap : (Landroid/view/MotionEvent;)Z
      //   997: ior
      //   998: aload_0
      //   999: getfield b : Landroid/view/GestureDetector$OnDoubleTapListener;
      //   1002: aload_1
      //   1003: invokeinterface onDoubleTapEvent : (Landroid/view/MotionEvent;)Z
      //   1008: ior
      //   1009: istore #14
      //   1011: goto -> 1030
      //   1014: aload_0
      //   1015: getfield mHandler : Landroid/os/Handler;
      //   1018: iconst_3
      //   1019: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.DOUBLE_TAP_TIMEOUT : I
      //   1022: i2l
      //   1023: invokevirtual sendEmptyMessageDelayed : (IJ)Z
      //   1026: pop
      //   1027: iconst_0
      //   1028: istore #14
      //   1030: aload_0
      //   1031: fload #12
      //   1033: putfield mLastFocusX : F
      //   1036: aload_0
      //   1037: fload #12
      //   1039: putfield mDownFocusX : F
      //   1042: aload_0
      //   1043: fload #13
      //   1045: putfield mLastFocusY : F
      //   1048: aload_0
      //   1049: fload #13
      //   1051: putfield mDownFocusY : F
      //   1054: aload_0
      //   1055: getfield e : Landroid/view/MotionEvent;
      //   1058: ifnull -> 1068
      //   1061: aload_0
      //   1062: getfield e : Landroid/view/MotionEvent;
      //   1065: invokevirtual recycle : ()V
      //   1068: aload_0
      //   1069: aload_1
      //   1070: invokestatic obtain : (Landroid/view/MotionEvent;)Landroid/view/MotionEvent;
      //   1073: putfield e : Landroid/view/MotionEvent;
      //   1076: aload_0
      //   1077: iconst_1
      //   1078: putfield mAlwaysInTapRegion : Z
      //   1081: aload_0
      //   1082: iconst_1
      //   1083: putfield mAlwaysInBiggerTapRegion : Z
      //   1086: aload_0
      //   1087: iconst_1
      //   1088: putfield c : Z
      //   1091: aload_0
      //   1092: iconst_0
      //   1093: putfield mInLongPress : Z
      //   1096: aload_0
      //   1097: iconst_0
      //   1098: putfield d : Z
      //   1101: aload_0
      //   1102: getfield mIsLongpressEnabled : Z
      //   1105: ifeq -> 1142
      //   1108: aload_0
      //   1109: getfield mHandler : Landroid/os/Handler;
      //   1112: iconst_2
      //   1113: invokevirtual removeMessages : (I)V
      //   1116: aload_0
      //   1117: getfield mHandler : Landroid/os/Handler;
      //   1120: iconst_2
      //   1121: aload_0
      //   1122: getfield e : Landroid/view/MotionEvent;
      //   1125: invokevirtual getDownTime : ()J
      //   1128: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   1131: i2l
      //   1132: ladd
      //   1133: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.LONGPRESS_TIMEOUT : I
      //   1136: i2l
      //   1137: ladd
      //   1138: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   1141: pop
      //   1142: aload_0
      //   1143: getfield mHandler : Landroid/os/Handler;
      //   1146: iconst_1
      //   1147: aload_0
      //   1148: getfield e : Landroid/view/MotionEvent;
      //   1151: invokevirtual getDownTime : ()J
      //   1154: getstatic android/support/v4/view/GestureDetectorCompat$GestureDetectorCompatImplBase.TAP_TIMEOUT : I
      //   1157: i2l
      //   1158: ladd
      //   1159: invokevirtual sendEmptyMessageAtTime : (IJ)Z
      //   1162: pop
      //   1163: iload #14
      //   1165: aload_0
      //   1166: getfield a : Landroid/view/GestureDetector$OnGestureListener;
      //   1169: aload_1
      //   1170: invokeinterface onDown : (Landroid/view/MotionEvent;)Z
      //   1175: ior
      //   1176: istore #16
      //   1178: iload #16
      //   1180: ireturn
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mIsLongpressEnabled = param1Boolean;
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.b = param1OnDoubleTapListener;
    }
    
    private class GestureHandler extends Handler {
      GestureHandler(GestureDetectorCompat.GestureDetectorCompatImplBase this$0) {}
      
      GestureHandler(GestureDetectorCompat.GestureDetectorCompatImplBase this$0, Handler param2Handler) {
        super(param2Handler.getLooper());
      }
      
      public void handleMessage(Message param2Message) {
        StringBuilder stringBuilder;
        switch (param2Message.what) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown message ");
            stringBuilder.append(param2Message);
            throw new RuntimeException(stringBuilder.toString());
          case 3:
            if (this.a.b != null) {
              if (!this.a.c) {
                this.a.b.onSingleTapConfirmed(this.a.e);
                return;
              } 
              this.a.d = true;
              return;
            } 
            return;
          case 2:
            this.a.a();
            return;
          case 1:
            break;
        } 
        this.a.a.onShowPress(this.a.e);
      }
    }
  }
  
  private class GestureHandler extends Handler {
    GestureHandler(GestureDetectorCompat this$0) {}
    
    GestureHandler(GestureDetectorCompat this$0, Handler param1Handler) {
      super(param1Handler.getLooper());
    }
    
    public void handleMessage(Message param1Message) {
      StringBuilder stringBuilder;
      switch (param1Message.what) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown message ");
          stringBuilder.append(param1Message);
          throw new RuntimeException(stringBuilder.toString());
        case 3:
          if (this.a.b != null) {
            if (!this.a.c) {
              this.a.b.onSingleTapConfirmed(this.a.e);
              return;
            } 
            this.a.d = true;
            return;
          } 
          return;
        case 2:
          this.a.a();
          return;
        case 1:
          break;
      } 
      this.a.a.onShowPress(this.a.e);
    }
  }
  
  static class GestureDetectorCompatImplJellybeanMr2 implements GestureDetectorCompatImpl {
    private final GestureDetector mDetector;
    
    GestureDetectorCompatImplJellybeanMr2(Context param1Context, GestureDetector.OnGestureListener param1OnGestureListener, Handler param1Handler) {
      this.mDetector = new GestureDetector(param1Context, param1OnGestureListener, param1Handler);
    }
    
    public boolean isLongpressEnabled() {
      return this.mDetector.isLongpressEnabled();
    }
    
    public boolean onTouchEvent(MotionEvent param1MotionEvent) {
      return this.mDetector.onTouchEvent(param1MotionEvent);
    }
    
    public void setIsLongpressEnabled(boolean param1Boolean) {
      this.mDetector.setIsLongpressEnabled(param1Boolean);
    }
    
    public void setOnDoubleTapListener(GestureDetector.OnDoubleTapListener param1OnDoubleTapListener) {
      this.mDetector.setOnDoubleTapListener(param1OnDoubleTapListener);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\view\GestureDetectorCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */