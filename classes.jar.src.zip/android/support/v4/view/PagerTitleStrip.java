package android.support.v4.view;

import android.content.Context;
import android.content.res.TypedArray;
import android.database.DataSetObserver;
import android.graphics.drawable.Drawable;
import android.support.annotation.ColorInt;
import android.support.annotation.FloatRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.widget.TextViewCompat;
import android.text.TextUtils;
import android.text.method.SingleLineTransformationMethod;
import android.text.method.TransformationMethod;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;
import java.lang.ref.WeakReference;
import java.util.Locale;

@DecorView
public class PagerTitleStrip extends ViewGroup {
  private static final int[] ATTRS = new int[] { 16842804, 16842901, 16842904, 16842927 };
  
  private static final float SIDE_ALPHA = 0.6F;
  
  private static final int[] TEXT_ATTRS = new int[] { 16843660 };
  
  private static final int TEXT_SPACING = 16;
  
  ViewPager a;
  
  TextView b;
  
  TextView c;
  
  TextView d;
  
  float e = -1.0F;
  
  int f;
  
  private int mGravity;
  
  private int mLastKnownCurrentPage = -1;
  
  private int mNonPrimaryAlpha;
  
  private final PageListener mPageListener = new PageListener(this);
  
  private int mScaledTextSpacing;
  
  private boolean mUpdatingPositions;
  
  private boolean mUpdatingText;
  
  private WeakReference<PagerAdapter> mWatchingAdapter;
  
  public PagerTitleStrip(@NonNull Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public PagerTitleStrip(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    TextView textView1 = new TextView(paramContext);
    this.b = textView1;
    addView((View)textView1);
    TextView textView2 = new TextView(paramContext);
    this.c = textView2;
    addView((View)textView2);
    TextView textView3 = new TextView(paramContext);
    this.d = textView3;
    addView((View)textView3);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, ATTRS);
    int i = typedArray.getResourceId(0, 0);
    if (i != 0) {
      TextViewCompat.setTextAppearance(this.b, i);
      TextViewCompat.setTextAppearance(this.c, i);
      TextViewCompat.setTextAppearance(this.d, i);
    } 
    int j = typedArray.getDimensionPixelSize(1, 0);
    if (j != 0)
      setTextSize(0, j); 
    if (typedArray.hasValue(2)) {
      int k = typedArray.getColor(2, 0);
      this.b.setTextColor(k);
      this.c.setTextColor(k);
      this.d.setTextColor(k);
    } 
    this.mGravity = typedArray.getInteger(3, 80);
    typedArray.recycle();
    this.f = this.c.getTextColors().getDefaultColor();
    setNonPrimaryAlpha(0.6F);
    this.b.setEllipsize(TextUtils.TruncateAt.END);
    this.c.setEllipsize(TextUtils.TruncateAt.END);
    this.d.setEllipsize(TextUtils.TruncateAt.END);
    boolean bool = false;
    if (i != 0) {
      TypedArray typedArray1 = paramContext.obtainStyledAttributes(i, TEXT_ATTRS);
      bool = typedArray1.getBoolean(0, false);
      typedArray1.recycle();
    } 
    if (bool) {
      setSingleLineAllCaps(this.b);
      setSingleLineAllCaps(this.c);
      setSingleLineAllCaps(this.d);
    } else {
      this.b.setSingleLine();
      this.c.setSingleLine();
      this.d.setSingleLine();
    } 
    this.mScaledTextSpacing = (int)(16.0F * (paramContext.getResources().getDisplayMetrics()).density);
  }
  
  private static void setSingleLineAllCaps(TextView paramTextView) {
    paramTextView.setTransformationMethod((TransformationMethod)new SingleLineAllCapsTransform(paramTextView.getContext()));
  }
  
  void a(int paramInt, float paramFloat, boolean paramBoolean) {
    int i23;
    int i24;
    int i25;
    if (paramInt != this.mLastKnownCurrentPage) {
      a(paramInt, this.a.getAdapter());
    } else if (!paramBoolean && paramFloat == this.e) {
      return;
    } 
    this.mUpdatingPositions = true;
    int i = this.b.getMeasuredWidth();
    int j = this.c.getMeasuredWidth();
    int k = this.d.getMeasuredWidth();
    int m = j / 2;
    int n = getWidth();
    int i1 = getHeight();
    int i2 = getPaddingLeft();
    int i3 = getPaddingRight();
    int i4 = getPaddingTop();
    int i5 = getPaddingBottom();
    int i6 = i2 + m;
    int i7 = i3 + m;
    int i8 = n - i6 - i7;
    float f = 0.5F + paramFloat;
    if (f > 1.0F)
      f--; 
    int i9 = n - i7 - (int)(f * i8) - m;
    int i10 = j + i9;
    int i11 = this.b.getBaseline();
    int i12 = this.c.getBaseline();
    int i13 = this.d.getBaseline();
    int i14 = Math.max(Math.max(i11, i12), i13);
    int i15 = i14 - i11;
    int i16 = i14 - i12;
    int i17 = i14 - i13;
    int i18 = i15 + this.b.getMeasuredHeight();
    int i19 = i16 + this.c.getMeasuredHeight();
    int i20 = i17 + this.d.getMeasuredHeight();
    int i21 = Math.max(Math.max(i18, i19), i20);
    int i22 = 0x70 & this.mGravity;
    if (i22 != 16) {
      if (i22 != 80) {
        i23 = i15 + i4;
        i24 = i16 + i4;
        i25 = i4 + i17;
      } else {
        int i28 = i1 - i5 - i21;
        i23 = i15 + i28;
        i24 = i16 + i28;
        i25 = i28 + i17;
      } 
    } else {
      int i28 = (i1 - i4 - i5 - i21) / 2;
      i23 = i15 + i28;
      i24 = i16 + i28;
      i25 = i28 + i17;
    } 
    this.c.layout(i9, i24, i10, i24 + this.c.getMeasuredHeight());
    int i26 = Math.min(i2, i9 - this.mScaledTextSpacing - i);
    this.b.layout(i26, i23, i + i26, i23 + this.b.getMeasuredHeight());
    int i27 = Math.max(n - i3 - k, i10 + this.mScaledTextSpacing);
    this.d.layout(i27, i25, i27 + k, i25 + this.d.getMeasuredHeight());
    this.e = paramFloat;
    this.mUpdatingPositions = false;
  }
  
  void a(int paramInt, PagerAdapter paramPagerAdapter) {
    byte b;
    CharSequence charSequence1;
    CharSequence charSequence2;
    if (paramPagerAdapter != null) {
      b = paramPagerAdapter.getCount();
    } else {
      b = 0;
    } 
    this.mUpdatingText = true;
    if (paramInt >= 1 && paramPagerAdapter != null) {
      charSequence1 = paramPagerAdapter.getPageTitle(paramInt - 1);
    } else {
      charSequence1 = null;
    } 
    this.b.setText(charSequence1);
    TextView textView = this.c;
    if (paramPagerAdapter != null && paramInt < b) {
      charSequence2 = paramPagerAdapter.getPageTitle(paramInt);
    } else {
      charSequence2 = null;
    } 
    textView.setText(charSequence2);
    int i = paramInt + 1;
    CharSequence charSequence3 = null;
    if (i < b) {
      charSequence3 = null;
      if (paramPagerAdapter != null)
        charSequence3 = paramPagerAdapter.getPageTitle(i); 
    } 
    this.d.setText(charSequence3);
    int j = View.MeasureSpec.makeMeasureSpec(Math.max(0, (int)(0.8F * (getWidth() - getPaddingLeft() - getPaddingRight()))), -2147483648);
    int k = View.MeasureSpec.makeMeasureSpec(Math.max(0, getHeight() - getPaddingTop() - getPaddingBottom()), -2147483648);
    this.b.measure(j, k);
    this.c.measure(j, k);
    this.d.measure(j, k);
    this.mLastKnownCurrentPage = paramInt;
    if (!this.mUpdatingPositions)
      a(paramInt, this.e, false); 
    this.mUpdatingText = false;
  }
  
  void a(PagerAdapter paramPagerAdapter1, PagerAdapter paramPagerAdapter2) {
    if (paramPagerAdapter1 != null) {
      paramPagerAdapter1.unregisterDataSetObserver(this.mPageListener);
      this.mWatchingAdapter = null;
    } 
    if (paramPagerAdapter2 != null) {
      paramPagerAdapter2.registerDataSetObserver(this.mPageListener);
      this.mWatchingAdapter = new WeakReference<PagerAdapter>(paramPagerAdapter2);
    } 
    if (this.a != null) {
      this.mLastKnownCurrentPage = -1;
      this.e = -1.0F;
      a(this.a.getCurrentItem(), paramPagerAdapter2);
      requestLayout();
    } 
  }
  
  int getMinHeight() {
    Drawable drawable = getBackground();
    return (drawable != null) ? drawable.getIntrinsicHeight() : 0;
  }
  
  public int getTextSpacing() {
    return this.mScaledTextSpacing;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    ViewParent viewParent = getParent();
    if (viewParent instanceof ViewPager) {
      PagerAdapter pagerAdapter2;
      ViewPager viewPager = (ViewPager)viewParent;
      PagerAdapter pagerAdapter1 = viewPager.getAdapter();
      viewPager.a(this.mPageListener);
      viewPager.addOnAdapterChangeListener(this.mPageListener);
      this.a = viewPager;
      if (this.mWatchingAdapter != null) {
        pagerAdapter2 = this.mWatchingAdapter.get();
      } else {
        pagerAdapter2 = null;
      } 
      a(pagerAdapter2, pagerAdapter1);
      return;
    } 
    throw new IllegalStateException("PagerTitleStrip must be a direct child of a ViewPager.");
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    if (this.a != null) {
      a(this.a.getAdapter(), (PagerAdapter)null);
      this.a.a((ViewPager.OnPageChangeListener)null);
      this.a.removeOnAdapterChangeListener(this.mPageListener);
      this.a = null;
    } 
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    if (this.a != null) {
      int i = this.e cmp 0.0F;
      float f = 0.0F;
      if (i >= 0)
        f = this.e; 
      a(this.mLastKnownCurrentPage, f, true);
    } 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    if (View.MeasureSpec.getMode(paramInt1) == 1073741824) {
      int n;
      int i = getPaddingTop() + getPaddingBottom();
      int j = getChildMeasureSpec(paramInt2, i, -2);
      int k = View.MeasureSpec.getSize(paramInt1);
      int m = getChildMeasureSpec(paramInt1, (int)(0.2F * k), -2);
      this.b.measure(m, j);
      this.c.measure(m, j);
      this.d.measure(m, j);
      if (View.MeasureSpec.getMode(paramInt2) == 1073741824) {
        n = View.MeasureSpec.getSize(paramInt2);
      } else {
        int i1 = this.c.getMeasuredHeight();
        n = Math.max(getMinHeight(), i1 + i);
      } 
      setMeasuredDimension(k, View.resolveSizeAndState(n, paramInt2, this.c.getMeasuredState() << 16));
      return;
    } 
    throw new IllegalStateException("Must measure with an exact width");
  }
  
  public void requestLayout() {
    if (!this.mUpdatingText)
      super.requestLayout(); 
  }
  
  public void setGravity(int paramInt) {
    this.mGravity = paramInt;
    requestLayout();
  }
  
  public void setNonPrimaryAlpha(@FloatRange(from = 0.0D, to = 1.0D) float paramFloat) {
    this.mNonPrimaryAlpha = 0xFF & (int)(paramFloat * 255.0F);
    int i = this.mNonPrimaryAlpha << 24 | 0xFFFFFF & this.f;
    this.b.setTextColor(i);
    this.d.setTextColor(i);
  }
  
  public void setTextColor(@ColorInt int paramInt) {
    this.f = paramInt;
    this.c.setTextColor(paramInt);
    int i = this.mNonPrimaryAlpha << 24 | 0xFFFFFF & this.f;
    this.b.setTextColor(i);
    this.d.setTextColor(i);
  }
  
  public void setTextSize(int paramInt, float paramFloat) {
    this.b.setTextSize(paramInt, paramFloat);
    this.c.setTextSize(paramInt, paramFloat);
    this.d.setTextSize(paramInt, paramFloat);
  }
  
  public void setTextSpacing(int paramInt) {
    this.mScaledTextSpacing = paramInt;
    requestLayout();
  }
  
  private class PageListener extends DataSetObserver implements ViewPager.OnAdapterChangeListener, ViewPager.OnPageChangeListener {
    private int mScrollState;
    
    PageListener(PagerTitleStrip this$0) {}
    
    public void onAdapterChanged(ViewPager param1ViewPager, PagerAdapter param1PagerAdapter1, PagerAdapter param1PagerAdapter2) {
      this.a.a(param1PagerAdapter1, param1PagerAdapter2);
    }
    
    public void onChanged() {
      this.a.a(this.a.a.getCurrentItem(), this.a.a.getAdapter());
      int i = this.a.e cmp 0.0F;
      float f = 0.0F;
      if (i >= 0)
        f = this.a.e; 
      this.a.a(this.a.a.getCurrentItem(), f, true);
    }
    
    public void onPageScrollStateChanged(int param1Int) {
      this.mScrollState = param1Int;
    }
    
    public void onPageScrolled(int param1Int1, float param1Float, int param1Int2) {
      if (param1Float > 0.5F)
        param1Int1++; 
      this.a.a(param1Int1, param1Float, false);
    }
    
    public void onPageSelected(int param1Int) {
      if (this.mScrollState == 0) {
        this.a.a(this.a.a.getCurrentItem(), this.a.a.getAdapter());
        int i = this.a.e cmp 0.0F;
        float f = 0.0F;
        if (i >= 0)
          f = this.a.e; 
        this.a.a(this.a.a.getCurrentItem(), f, true);
      } 
    }
  }
  
  private static class SingleLineAllCapsTransform extends SingleLineTransformationMethod {
    private Locale mLocale;
    
    SingleLineAllCapsTransform(Context param1Context) {
      this.mLocale = (param1Context.getResources().getConfiguration()).locale;
    }
    
    public CharSequence getTransformation(CharSequence param1CharSequence, View param1View) {
      CharSequence charSequence = super.getTransformation(param1CharSequence, param1View);
      return (charSequence != null) ? charSequence.toString().toUpperCase(this.mLocale) : null;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\view\PagerTitleStrip.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */