package android.support.v4.view;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.support.annotation.LayoutRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.UiThread;
import android.support.v4.util.Pools;
import android.util.AttributeSet;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import java.util.concurrent.ArrayBlockingQueue;

public final class AsyncLayoutInflater {
  private static final String TAG = "AsyncLayoutInflater";
  
  LayoutInflater a;
  
  Handler b;
  
  InflateThread c;
  
  private Handler.Callback mHandlerCallback = new Handler.Callback(this) {
      public boolean handleMessage(Message param1Message) {
        AsyncLayoutInflater.InflateRequest inflateRequest = (AsyncLayoutInflater.InflateRequest)param1Message.obj;
        if (inflateRequest.d == null)
          inflateRequest.d = this.a.a.inflate(inflateRequest.c, inflateRequest.b, false); 
        inflateRequest.e.onInflateFinished(inflateRequest.d, inflateRequest.c, inflateRequest.b);
        this.a.c.releaseRequest(inflateRequest);
        return true;
      }
    };
  
  public AsyncLayoutInflater(@NonNull Context paramContext) {
    this.a = new BasicInflater(paramContext);
    this.b = new Handler(this.mHandlerCallback);
    this.c = InflateThread.getInstance();
  }
  
  @UiThread
  public void inflate(@LayoutRes int paramInt, @Nullable ViewGroup paramViewGroup, @NonNull OnInflateFinishedListener paramOnInflateFinishedListener) {
    if (paramOnInflateFinishedListener != null) {
      InflateRequest inflateRequest = this.c.obtainRequest();
      inflateRequest.a = this;
      inflateRequest.c = paramInt;
      inflateRequest.b = paramViewGroup;
      inflateRequest.e = paramOnInflateFinishedListener;
      this.c.enqueue(inflateRequest);
      return;
    } 
    throw new NullPointerException("callback argument may not be null!");
  }
  
  private static class BasicInflater extends LayoutInflater {
    private static final String[] sClassPrefixList = new String[] { "android.widget.", "android.webkit.", "android.app." };
    
    BasicInflater(Context param1Context) {
      super(param1Context);
    }
    
    public LayoutInflater cloneInContext(Context param1Context) {
      return new BasicInflater(param1Context);
    }
    
    protected View onCreateView(String param1String, AttributeSet param1AttributeSet) {
      for (String str : sClassPrefixList) {
        View view = createView(param1String, str, param1AttributeSet);
        if (view != null)
          return view; 
      } 
      return super.onCreateView(param1String, param1AttributeSet);
    }
  }
  
  private static class InflateRequest {
    AsyncLayoutInflater a;
    
    ViewGroup b;
    
    int c;
    
    View d;
    
    AsyncLayoutInflater.OnInflateFinishedListener e;
  }
  
  private static class InflateThread extends Thread {
    private static final InflateThread sInstance = new InflateThread();
    
    private ArrayBlockingQueue<AsyncLayoutInflater.InflateRequest> mQueue = new ArrayBlockingQueue<AsyncLayoutInflater.InflateRequest>(10);
    
    private Pools.SynchronizedPool<AsyncLayoutInflater.InflateRequest> mRequestPool = new Pools.SynchronizedPool(10);
    
    static {
      sInstance.start();
    }
    
    public static InflateThread getInstance() {
      return sInstance;
    }
    
    public void enqueue(AsyncLayoutInflater.InflateRequest param1InflateRequest) {
      try {
        this.mQueue.put(param1InflateRequest);
        return;
      } catch (InterruptedException interruptedException) {
        throw new RuntimeException("Failed to enqueue async inflate request", interruptedException);
      } 
    }
    
    public AsyncLayoutInflater.InflateRequest obtainRequest() {
      AsyncLayoutInflater.InflateRequest inflateRequest = (AsyncLayoutInflater.InflateRequest)this.mRequestPool.acquire();
      if (inflateRequest == null)
        inflateRequest = new AsyncLayoutInflater.InflateRequest(); 
      return inflateRequest;
    }
    
    public void releaseRequest(AsyncLayoutInflater.InflateRequest param1InflateRequest) {
      param1InflateRequest.e = null;
      param1InflateRequest.a = null;
      param1InflateRequest.b = null;
      param1InflateRequest.c = 0;
      param1InflateRequest.d = null;
      this.mRequestPool.release(param1InflateRequest);
    }
    
    public void run() {
      while (true)
        runInner(); 
    }
    
    public void runInner() {
      try {
        AsyncLayoutInflater.InflateRequest inflateRequest = this.mQueue.take();
        try {
          inflateRequest.d = inflateRequest.a.a.inflate(inflateRequest.c, inflateRequest.b, false);
        } catch (RuntimeException runtimeException) {
          Log.w("AsyncLayoutInflater", "Failed to inflate resource in the background! Retrying on the UI thread", runtimeException);
        } 
        Message.obtain(inflateRequest.a.b, 0, inflateRequest).sendToTarget();
        return;
      } catch (InterruptedException interruptedException) {
        Log.w("AsyncLayoutInflater", interruptedException);
        return;
      } 
    }
  }
  
  public static interface OnInflateFinishedListener {
    void onInflateFinished(@NonNull View param1View, @LayoutRes int param1Int, @Nullable ViewGroup param1ViewGroup);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\view\AsyncLayoutInflater.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */