package android.support.v4.os;

import android.os.Build;
import android.os.LocaleList;
import android.support.annotation.IntRange;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.Size;
import java.util.Locale;

public final class LocaleListCompat {
  static final LocaleListInterface a;
  
  private static final LocaleListCompat sEmptyLocaleList = new LocaleListCompat();
  
  static {
    if (Build.VERSION.SDK_INT >= 24) {
      a = new LocaleListCompatApi24Impl();
      return;
    } 
    a = new LocaleListCompatBaseImpl();
  }
  
  public static LocaleListCompat create(@NonNull Locale... paramVarArgs) {
    LocaleListCompat localeListCompat = new LocaleListCompat();
    localeListCompat.setLocaleListArray(paramVarArgs);
    return localeListCompat;
  }
  
  @NonNull
  public static LocaleListCompat forLanguageTags(@Nullable String paramString) {
    if (paramString == null || paramString.isEmpty())
      return getEmptyLocaleList(); 
    String[] arrayOfString = paramString.split(",");
    Locale[] arrayOfLocale = new Locale[arrayOfString.length];
    for (byte b = 0; b < arrayOfLocale.length; b++) {
      Locale locale;
      if (Build.VERSION.SDK_INT >= 21) {
        locale = Locale.forLanguageTag(arrayOfString[b]);
      } else {
        locale = LocaleHelper.a(arrayOfString[b]);
      } 
      arrayOfLocale[b] = locale;
    } 
    LocaleListCompat localeListCompat = new LocaleListCompat();
    localeListCompat.setLocaleListArray(arrayOfLocale);
    return localeListCompat;
  }
  
  @NonNull
  @Size(min = 1L)
  public static LocaleListCompat getAdjustedDefault() {
    if (Build.VERSION.SDK_INT >= 24)
      return wrap(LocaleList.getAdjustedDefault()); 
    Locale[] arrayOfLocale = new Locale[1];
    arrayOfLocale[0] = Locale.getDefault();
    return create(arrayOfLocale);
  }
  
  @NonNull
  @Size(min = 1L)
  public static LocaleListCompat getDefault() {
    if (Build.VERSION.SDK_INT >= 24)
      return wrap(LocaleList.getDefault()); 
    Locale[] arrayOfLocale = new Locale[1];
    arrayOfLocale[0] = Locale.getDefault();
    return create(arrayOfLocale);
  }
  
  @NonNull
  public static LocaleListCompat getEmptyLocaleList() {
    return sEmptyLocaleList;
  }
  
  @RequiresApi(24)
  private void setLocaleList(LocaleList paramLocaleList) {
    int i = paramLocaleList.size();
    if (i > 0) {
      Locale[] arrayOfLocale = new Locale[i];
      for (byte b = 0; b < i; b++)
        arrayOfLocale[b] = paramLocaleList.get(b); 
      a.setLocaleList(arrayOfLocale);
    } 
  }
  
  private void setLocaleListArray(Locale... paramVarArgs) {
    a.setLocaleList(paramVarArgs);
  }
  
  @RequiresApi(24)
  public static LocaleListCompat wrap(Object paramObject) {
    LocaleListCompat localeListCompat = new LocaleListCompat();
    if (paramObject instanceof LocaleList)
      localeListCompat.setLocaleList((LocaleList)paramObject); 
    return localeListCompat;
  }
  
  public boolean equals(Object paramObject) {
    return a.equals(paramObject);
  }
  
  public Locale get(int paramInt) {
    return a.get(paramInt);
  }
  
  public Locale getFirstMatch(String[] paramArrayOfString) {
    return a.getFirstMatch(paramArrayOfString);
  }
  
  public int hashCode() {
    return a.hashCode();
  }
  
  @IntRange(from = -1L)
  public int indexOf(Locale paramLocale) {
    return a.indexOf(paramLocale);
  }
  
  public boolean isEmpty() {
    return a.isEmpty();
  }
  
  @IntRange(from = 0L)
  public int size() {
    return a.size();
  }
  
  @NonNull
  public String toLanguageTags() {
    return a.toLanguageTags();
  }
  
  public String toString() {
    return a.toString();
  }
  
  @Nullable
  public Object unwrap() {
    return a.getLocaleList();
  }
  
  @RequiresApi(24)
  static class LocaleListCompatApi24Impl implements LocaleListInterface {
    private LocaleList mLocaleList = new LocaleList(new Locale[0]);
    
    public boolean equals(Object param1Object) {
      return this.mLocaleList.equals(((LocaleListCompat)param1Object).unwrap());
    }
    
    public Locale get(int param1Int) {
      return this.mLocaleList.get(param1Int);
    }
    
    @Nullable
    public Locale getFirstMatch(String[] param1ArrayOfString) {
      return (this.mLocaleList != null) ? this.mLocaleList.getFirstMatch(param1ArrayOfString) : null;
    }
    
    public Object getLocaleList() {
      return this.mLocaleList;
    }
    
    public int hashCode() {
      return this.mLocaleList.hashCode();
    }
    
    @IntRange(from = -1L)
    public int indexOf(Locale param1Locale) {
      return this.mLocaleList.indexOf(param1Locale);
    }
    
    public boolean isEmpty() {
      return this.mLocaleList.isEmpty();
    }
    
    public void setLocaleList(@NonNull Locale... param1VarArgs) {
      this.mLocaleList = new LocaleList(param1VarArgs);
    }
    
    @IntRange(from = 0L)
    public int size() {
      return this.mLocaleList.size();
    }
    
    public String toLanguageTags() {
      return this.mLocaleList.toLanguageTags();
    }
    
    public String toString() {
      return this.mLocaleList.toString();
    }
  }
  
  static class LocaleListCompatBaseImpl implements LocaleListInterface {
    private LocaleListHelper mLocaleList = new LocaleListHelper(new Locale[0]);
    
    public boolean equals(Object param1Object) {
      return this.mLocaleList.equals(((LocaleListCompat)param1Object).unwrap());
    }
    
    public Locale get(int param1Int) {
      return this.mLocaleList.get(param1Int);
    }
    
    @Nullable
    public Locale getFirstMatch(String[] param1ArrayOfString) {
      return (this.mLocaleList != null) ? this.mLocaleList.a(param1ArrayOfString) : null;
    }
    
    public Object getLocaleList() {
      return this.mLocaleList;
    }
    
    public int hashCode() {
      return this.mLocaleList.hashCode();
    }
    
    @IntRange(from = -1L)
    public int indexOf(Locale param1Locale) {
      return this.mLocaleList.a(param1Locale);
    }
    
    public boolean isEmpty() {
      return this.mLocaleList.isEmpty();
    }
    
    public void setLocaleList(@NonNull Locale... param1VarArgs) {
      this.mLocaleList = new LocaleListHelper(param1VarArgs);
    }
    
    @IntRange(from = 0L)
    public int size() {
      return this.mLocaleList.a();
    }
    
    public String toLanguageTags() {
      return this.mLocaleList.b();
    }
    
    public String toString() {
      return this.mLocaleList.toString();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\os\LocaleListCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */