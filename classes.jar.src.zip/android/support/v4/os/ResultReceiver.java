package android.support.v4.os;

import android.os.Bundle;
import android.os.Handler;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class ResultReceiver implements Parcelable {
  public static final Parcelable.Creator<ResultReceiver> CREATOR = new Parcelable.Creator<ResultReceiver>() {
      public ResultReceiver createFromParcel(Parcel param1Parcel) {
        return new ResultReceiver(param1Parcel);
      }
      
      public ResultReceiver[] newArray(int param1Int) {
        return new ResultReceiver[param1Int];
      }
    };
  
  final boolean a = true;
  
  final Handler b;
  
  IResultReceiver c;
  
  public ResultReceiver(Handler paramHandler) {
    this.b = paramHandler;
  }
  
  ResultReceiver(Parcel paramParcel) {
    this.b = null;
    this.c = IResultReceiver.Stub.asInterface(paramParcel.readStrongBinder());
  }
  
  public int describeContents() {
    return 0;
  }
  
  protected void onReceiveResult(int paramInt, Bundle paramBundle) {}
  
  public void send(int paramInt, Bundle paramBundle) {
    // Byte code:
    //   0: aload_0
    //   1: getfield a : Z
    //   4: ifeq -> 40
    //   7: aload_0
    //   8: getfield b : Landroid/os/Handler;
    //   11: ifnull -> 33
    //   14: aload_0
    //   15: getfield b : Landroid/os/Handler;
    //   18: new android/support/v4/os/ResultReceiver$MyRunnable
    //   21: dup
    //   22: aload_0
    //   23: iload_1
    //   24: aload_2
    //   25: invokespecial <init> : (Landroid/support/v4/os/ResultReceiver;ILandroid/os/Bundle;)V
    //   28: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   31: pop
    //   32: return
    //   33: aload_0
    //   34: iload_1
    //   35: aload_2
    //   36: invokevirtual onReceiveResult : (ILandroid/os/Bundle;)V
    //   39: return
    //   40: aload_0
    //   41: getfield c : Landroid/support/v4/os/IResultReceiver;
    //   44: ifnull -> 61
    //   47: aload_0
    //   48: getfield c : Landroid/support/v4/os/IResultReceiver;
    //   51: iload_1
    //   52: aload_2
    //   53: invokeinterface send : (ILandroid/os/Bundle;)V
    //   58: goto -> 62
    //   61: pop
    //   62: return
    // Exception table:
    //   from	to	target	type
    //   47	58	61	android/os/RemoteException
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield c : Landroid/support/v4/os/IResultReceiver;
    //   6: ifnonnull -> 21
    //   9: aload_0
    //   10: new android/support/v4/os/ResultReceiver$MyResultReceiver
    //   13: dup
    //   14: aload_0
    //   15: invokespecial <init> : (Landroid/support/v4/os/ResultReceiver;)V
    //   18: putfield c : Landroid/support/v4/os/IResultReceiver;
    //   21: aload_1
    //   22: aload_0
    //   23: getfield c : Landroid/support/v4/os/IResultReceiver;
    //   26: invokeinterface asBinder : ()Landroid/os/IBinder;
    //   31: invokevirtual writeStrongBinder : (Landroid/os/IBinder;)V
    //   34: aload_0
    //   35: monitorexit
    //   36: return
    //   37: astore_3
    //   38: aload_0
    //   39: monitorexit
    //   40: aload_3
    //   41: athrow
    // Exception table:
    //   from	to	target	type
    //   2	21	37	finally
    //   21	36	37	finally
    //   38	40	37	finally
  }
  
  class MyResultReceiver extends IResultReceiver.Stub {
    MyResultReceiver(ResultReceiver this$0) {}
    
    public void send(int param1Int, Bundle param1Bundle) {
      if (this.a.b != null) {
        this.a.b.post(new ResultReceiver.MyRunnable(this.a, param1Int, param1Bundle));
        return;
      } 
      this.a.onReceiveResult(param1Int, param1Bundle);
    }
  }
  
  class MyRunnable implements Runnable {
    final int a;
    
    final Bundle b;
    
    MyRunnable(ResultReceiver this$0, int param1Int, Bundle param1Bundle) {
      this.a = param1Int;
      this.b = param1Bundle;
    }
    
    public void run() {
      this.c.onReceiveResult(this.a, this.b);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\os\ResultReceiver.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */