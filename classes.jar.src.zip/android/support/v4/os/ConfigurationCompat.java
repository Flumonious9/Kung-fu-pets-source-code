package android.support.v4.os;

import android.content.res.Configuration;
import android.os.Build;
import java.util.Locale;

public final class ConfigurationCompat {
  public static LocaleListCompat getLocales(Configuration paramConfiguration) {
    if (Build.VERSION.SDK_INT >= 24)
      return LocaleListCompat.wrap(paramConfiguration.getLocales()); 
    Locale[] arrayOfLocale = new Locale[1];
    arrayOfLocale[0] = paramConfiguration.locale;
    return LocaleListCompat.create(arrayOfLocale);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\os\ConfigurationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */