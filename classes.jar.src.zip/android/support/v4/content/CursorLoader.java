package android.support.v4.content;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.os.CancellationSignal;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.Arrays;

public class CursorLoader extends AsyncTaskLoader<Cursor> {
  final Loader<Cursor>.ForceLoadContentObserver a = new Loader.ForceLoadContentObserver(this);
  
  Uri b;
  
  String[] c;
  
  String d;
  
  String[] e;
  
  String f;
  
  Cursor g;
  
  CancellationSignal h;
  
  public CursorLoader(@NonNull Context paramContext) {
    super(paramContext);
  }
  
  public CursorLoader(@NonNull Context paramContext, @NonNull Uri paramUri, @Nullable String[] paramArrayOfString1, @Nullable String paramString1, @Nullable String[] paramArrayOfString2, @Nullable String paramString2) {
    super(paramContext);
    this.b = paramUri;
    this.c = paramArrayOfString1;
    this.d = paramString1;
    this.e = paramArrayOfString2;
    this.f = paramString2;
  }
  
  public void cancelLoadInBackground() {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial cancelLoadInBackground : ()V
    //   4: aload_0
    //   5: monitorenter
    //   6: aload_0
    //   7: getfield h : Landroid/support/v4/os/CancellationSignal;
    //   10: ifnull -> 20
    //   13: aload_0
    //   14: getfield h : Landroid/support/v4/os/CancellationSignal;
    //   17: invokevirtual cancel : ()V
    //   20: aload_0
    //   21: monitorexit
    //   22: return
    //   23: astore_1
    //   24: aload_0
    //   25: monitorexit
    //   26: aload_1
    //   27: athrow
    // Exception table:
    //   from	to	target	type
    //   6	20	23	finally
    //   20	22	23	finally
    //   24	26	23	finally
  }
  
  public void deliverResult(Cursor paramCursor) {
    if (isReset()) {
      if (paramCursor != null)
        paramCursor.close(); 
      return;
    } 
    Cursor cursor = this.g;
    this.g = paramCursor;
    if (isStarted())
      super.deliverResult(paramCursor); 
    if (cursor != null && cursor != paramCursor && !cursor.isClosed())
      cursor.close(); 
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    super.dump(paramString, paramFileDescriptor, paramPrintWriter, paramArrayOfString);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mUri=");
    paramPrintWriter.println(this.b);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mProjection=");
    paramPrintWriter.println(Arrays.toString((Object[])this.c));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelection=");
    paramPrintWriter.println(this.d);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSelectionArgs=");
    paramPrintWriter.println(Arrays.toString((Object[])this.e));
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mSortOrder=");
    paramPrintWriter.println(this.f);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mCursor=");
    paramPrintWriter.println(this.g);
    paramPrintWriter.print(paramString);
    paramPrintWriter.print("mContentChanged=");
    paramPrintWriter.println(this.mContentChanged);
  }
  
  @Nullable
  public String[] getProjection() {
    return this.c;
  }
  
  @Nullable
  public String getSelection() {
    return this.d;
  }
  
  @Nullable
  public String[] getSelectionArgs() {
    return this.e;
  }
  
  @Nullable
  public String getSortOrder() {
    return this.f;
  }
  
  @NonNull
  public Uri getUri() {
    return this.b;
  }
  
  public Cursor loadInBackground() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: invokevirtual isLoadInBackgroundCanceled : ()Z
    //   6: ifne -> 133
    //   9: aload_0
    //   10: new android/support/v4/os/CancellationSignal
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield h : Landroid/support/v4/os/CancellationSignal;
    //   20: aload_0
    //   21: monitorexit
    //   22: aload_0
    //   23: invokevirtual getContext : ()Landroid/content/Context;
    //   26: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   29: aload_0
    //   30: getfield b : Landroid/net/Uri;
    //   33: aload_0
    //   34: getfield c : [Ljava/lang/String;
    //   37: aload_0
    //   38: getfield d : Ljava/lang/String;
    //   41: aload_0
    //   42: getfield e : [Ljava/lang/String;
    //   45: aload_0
    //   46: getfield f : Ljava/lang/String;
    //   49: aload_0
    //   50: getfield h : Landroid/support/v4/os/CancellationSignal;
    //   53: invokestatic query : (Landroid/content/ContentResolver;Landroid/net/Uri;[Ljava/lang/String;Ljava/lang/String;[Ljava/lang/String;Ljava/lang/String;Landroid/support/v4/os/CancellationSignal;)Landroid/database/Cursor;
    //   56: astore #4
    //   58: aload #4
    //   60: ifnull -> 97
    //   63: aload #4
    //   65: invokeinterface getCount : ()I
    //   70: pop
    //   71: aload #4
    //   73: aload_0
    //   74: getfield a : Landroid/support/v4/content/Loader$ForceLoadContentObserver;
    //   77: invokeinterface registerContentObserver : (Landroid/database/ContentObserver;)V
    //   82: goto -> 97
    //   85: astore #6
    //   87: aload #4
    //   89: invokeinterface close : ()V
    //   94: aload #6
    //   96: athrow
    //   97: aload_0
    //   98: monitorenter
    //   99: aload_0
    //   100: aconst_null
    //   101: putfield h : Landroid/support/v4/os/CancellationSignal;
    //   104: aload_0
    //   105: monitorexit
    //   106: aload #4
    //   108: areturn
    //   109: astore #5
    //   111: aload_0
    //   112: monitorexit
    //   113: aload #5
    //   115: athrow
    //   116: astore_2
    //   117: aload_0
    //   118: monitorenter
    //   119: aload_0
    //   120: aconst_null
    //   121: putfield h : Landroid/support/v4/os/CancellationSignal;
    //   124: aload_0
    //   125: monitorexit
    //   126: aload_2
    //   127: athrow
    //   128: astore_3
    //   129: aload_0
    //   130: monitorexit
    //   131: aload_3
    //   132: athrow
    //   133: new android/support/v4/os/OperationCanceledException
    //   136: dup
    //   137: invokespecial <init> : ()V
    //   140: athrow
    //   141: astore_1
    //   142: aload_0
    //   143: monitorexit
    //   144: aload_1
    //   145: athrow
    // Exception table:
    //   from	to	target	type
    //   2	22	141	finally
    //   22	58	116	finally
    //   63	82	85	java/lang/RuntimeException
    //   63	82	116	finally
    //   87	97	116	finally
    //   99	106	109	finally
    //   111	113	109	finally
    //   119	126	128	finally
    //   129	131	128	finally
    //   133	141	141	finally
    //   142	144	141	finally
  }
  
  public void onCanceled(Cursor paramCursor) {
    if (paramCursor != null && !paramCursor.isClosed())
      paramCursor.close(); 
  }
  
  protected void onReset() {
    super.onReset();
    onStopLoading();
    if (this.g != null && !this.g.isClosed())
      this.g.close(); 
    this.g = null;
  }
  
  protected void onStartLoading() {
    if (this.g != null)
      deliverResult(this.g); 
    if (takeContentChanged() || this.g == null)
      forceLoad(); 
  }
  
  protected void onStopLoading() {
    cancelLoad();
  }
  
  public void setProjection(@Nullable String[] paramArrayOfString) {
    this.c = paramArrayOfString;
  }
  
  public void setSelection(@Nullable String paramString) {
    this.d = paramString;
  }
  
  public void setSelectionArgs(@Nullable String[] paramArrayOfString) {
    this.e = paramArrayOfString;
  }
  
  public void setSortOrder(@Nullable String paramString) {
    this.f = paramString;
  }
  
  public void setUri(@NonNull Uri paramUri) {
    this.b = paramUri;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\content\CursorLoader.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */