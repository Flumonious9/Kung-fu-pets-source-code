package android.support.v4.content;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.support.annotation.NonNull;
import android.util.Log;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Set;

public final class LocalBroadcastManager {
  private static final boolean DEBUG = false;
  
  private static final String TAG = "LocalBroadcastManager";
  
  private static LocalBroadcastManager mInstance;
  
  private static final Object mLock = new Object();
  
  private final HashMap<String, ArrayList<ReceiverRecord>> mActions = new HashMap<String, ArrayList<ReceiverRecord>>();
  
  private final Context mAppContext;
  
  private final Handler mHandler;
  
  private final ArrayList<BroadcastRecord> mPendingBroadcasts = new ArrayList<BroadcastRecord>();
  
  private final HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>> mReceivers = new HashMap<BroadcastReceiver, ArrayList<ReceiverRecord>>();
  
  private LocalBroadcastManager(Context paramContext) {
    this.mAppContext = paramContext;
    this.mHandler = new Handler(this, paramContext.getMainLooper()) {
        public void handleMessage(Message param1Message) {
          if (param1Message.what != 1) {
            super.handleMessage(param1Message);
            return;
          } 
          LocalBroadcastManager.a(this.a);
        }
      };
  }
  
  private void executePendingBroadcasts() {
    while (true) {
      synchronized (this.mReceivers) {
        int i = this.mPendingBroadcasts.size();
        if (i <= 0)
          return; 
        BroadcastRecord[] arrayOfBroadcastRecord = new BroadcastRecord[i];
        this.mPendingBroadcasts.toArray(arrayOfBroadcastRecord);
        this.mPendingBroadcasts.clear();
        for (byte b = 0; b < arrayOfBroadcastRecord.length; b++) {
          BroadcastRecord broadcastRecord = arrayOfBroadcastRecord[b];
          int j = broadcastRecord.b.size();
          for (byte b1 = 0; b1 < j; b1++) {
            ReceiverRecord receiverRecord = broadcastRecord.b.get(b1);
            if (!receiverRecord.d)
              receiverRecord.b.onReceive(this.mAppContext, broadcastRecord.a); 
          } 
        } 
      } 
    } 
  }
  
  @NonNull
  public static LocalBroadcastManager getInstance(@NonNull Context paramContext) {
    synchronized (mLock) {
      if (mInstance == null)
        mInstance = new LocalBroadcastManager(paramContext.getApplicationContext()); 
      return mInstance;
    } 
  }
  
  public void registerReceiver(@NonNull BroadcastReceiver paramBroadcastReceiver, @NonNull IntentFilter paramIntentFilter) {
    synchronized (this.mReceivers) {
      ReceiverRecord receiverRecord = new ReceiverRecord(paramIntentFilter, paramBroadcastReceiver);
      ArrayList<ReceiverRecord> arrayList = this.mReceivers.get(paramBroadcastReceiver);
      if (arrayList == null) {
        arrayList = new ArrayList(1);
        this.mReceivers.put(paramBroadcastReceiver, arrayList);
      } 
      arrayList.add(receiverRecord);
      for (byte b = 0; b < paramIntentFilter.countActions(); b++) {
        String str = paramIntentFilter.getAction(b);
        ArrayList<ReceiverRecord> arrayList1 = this.mActions.get(str);
        if (arrayList1 == null) {
          arrayList1 = new ArrayList(1);
          this.mActions.put(str, arrayList1);
        } 
        arrayList1.add(receiverRecord);
      } 
      return;
    } 
  }
  
  public boolean sendBroadcast(@NonNull Intent paramIntent) {
    String str1;
    String str2;
    Uri uri;
    String str3;
    Set set;
    boolean bool;
    ArrayList<ReceiverRecord> arrayList1;
    synchronized (this.mReceivers) {
      str1 = paramIntent.getAction();
      str2 = paramIntent.resolveTypeIfNeeded(this.mAppContext.getContentResolver());
      uri = paramIntent.getData();
      str3 = paramIntent.getScheme();
      set = paramIntent.getCategories();
      if ((0x8 & paramIntent.getFlags()) != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Resolving type ");
        stringBuilder.append(str2);
        stringBuilder.append(" scheme ");
        stringBuilder.append(str3);
        stringBuilder.append(" of intent ");
        stringBuilder.append(paramIntent);
        Log.v("LocalBroadcastManager", stringBuilder.toString());
      } 
      arrayList1 = this.mActions.get(paramIntent.getAction());
      if (arrayList1 != null) {
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Action list: ");
          stringBuilder.append(arrayList1);
          Log.v("LocalBroadcastManager", stringBuilder.toString());
        } 
      } else {
        return false;
      } 
    } 
    ArrayList<ReceiverRecord> arrayList2 = null;
    int i = 0;
    while (true) {
      ArrayList<ReceiverRecord> arrayList;
      if (i < arrayList1.size()) {
        ReceiverRecord receiverRecord = arrayList1.get(i);
        if (bool) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Matching against filter ");
          stringBuilder.append(receiverRecord.a);
          Log.v("LocalBroadcastManager", stringBuilder.toString());
        } 
        if (receiverRecord.c) {
          if (bool)
            Log.v("LocalBroadcastManager", "  Filter's target already added"); 
        } else {
          IntentFilter intentFilter = receiverRecord.a;
          String str8 = str1;
          String str9 = str2;
          String str6 = str1;
          ArrayList<ReceiverRecord> arrayList6 = arrayList2;
          int k = i;
          ArrayList<ReceiverRecord> arrayList5 = arrayList1;
          String str7 = str2;
          int m = intentFilter.match(str8, str9, str3, uri, set, "LocalBroadcastManager");
          if (m >= 0) {
            if (bool) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("  Filter matched!  match=0x");
              stringBuilder.append(Integer.toHexString(m));
              Log.v("LocalBroadcastManager", stringBuilder.toString());
            } 
            if (arrayList6 == null) {
              arrayList2 = new ArrayList();
            } else {
              arrayList2 = arrayList6;
            } 
            arrayList2.add(receiverRecord);
            receiverRecord.c = true;
          } else {
            if (bool) {
              String str;
              StringBuilder stringBuilder;
              switch (m) {
                default:
                  str = "unknown reason";
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("  Filter did not match: ");
                  stringBuilder.append(str);
                  Log.v("LocalBroadcastManager", stringBuilder.toString());
                  break;
                case -1:
                  str = "type";
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("  Filter did not match: ");
                  stringBuilder.append(str);
                  Log.v("LocalBroadcastManager", stringBuilder.toString());
                  break;
                case -2:
                  str = "data";
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("  Filter did not match: ");
                  stringBuilder.append(str);
                  Log.v("LocalBroadcastManager", stringBuilder.toString());
                  break;
                case -3:
                  str = "action";
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("  Filter did not match: ");
                  stringBuilder.append(str);
                  Log.v("LocalBroadcastManager", stringBuilder.toString());
                  break;
                case -4:
                  str = "category";
                  stringBuilder = new StringBuilder();
                  stringBuilder.append("  Filter did not match: ");
                  stringBuilder.append(str);
                  Log.v("LocalBroadcastManager", stringBuilder.toString());
                  break;
              } 
            } 
            arrayList2 = arrayList6;
          } 
          i = k + 1;
          str1 = str6;
          arrayList1 = arrayList5;
          str2 = str7;
          continue;
        } 
        int j = i;
        ArrayList<ReceiverRecord> arrayList4 = arrayList1;
        String str4 = str1;
        String str5 = str2;
        arrayList = arrayList2;
      } else {
        break;
      } 
      arrayList2 = arrayList;
    } 
    ArrayList<ReceiverRecord> arrayList3 = arrayList2;
    if (arrayList3 != null) {
      byte b;
      for (b = 0; b < arrayList3.size(); b++)
        ((ReceiverRecord)arrayList3.get(b)).c = false; 
      this.mPendingBroadcasts.add(new BroadcastRecord(paramIntent, arrayList3));
      if (!this.mHandler.hasMessages(1))
        this.mHandler.sendEmptyMessage(1); 
      /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
      return true;
    } 
    /* monitor exit ClassFileLocalVariableReferenceExpression{type=ObjectType{java/lang/Object}, name=SYNTHETIC_LOCAL_VARIABLE_2} */
    return false;
  }
  
  public void sendBroadcastSync(@NonNull Intent paramIntent) {
    if (sendBroadcast(paramIntent))
      executePendingBroadcasts(); 
  }
  
  public void unregisterReceiver(@NonNull BroadcastReceiver paramBroadcastReceiver) {
    synchronized (this.mReceivers) {
      ArrayList<ReceiverRecord> arrayList = this.mReceivers.remove(paramBroadcastReceiver);
      if (arrayList == null)
        return; 
      for (int i = arrayList.size() - 1;; i--) {
        if (i >= 0) {
          ReceiverRecord receiverRecord = arrayList.get(i);
          receiverRecord.d = true;
          for (byte b = 0; b < receiverRecord.a.countActions(); b++) {
            String str = receiverRecord.a.getAction(b);
            ArrayList<ReceiverRecord> arrayList1 = this.mActions.get(str);
            if (arrayList1 != null)
              for (int j = arrayList1.size() - 1;; j--) {
                if (j >= 0) {
                  ReceiverRecord receiverRecord1 = arrayList1.get(j);
                  if (receiverRecord1.b == paramBroadcastReceiver) {
                    receiverRecord1.d = true;
                    arrayList1.remove(j);
                  } 
                } else {
                  if (arrayList1.size() <= 0)
                    this.mActions.remove(str); 
                  break;
                } 
              }  
          } 
        } else {
          return;
        } 
      } 
    } 
  }
  
  private static final class BroadcastRecord {
    final Intent a;
    
    final ArrayList<LocalBroadcastManager.ReceiverRecord> b;
    
    BroadcastRecord(Intent param1Intent, ArrayList<LocalBroadcastManager.ReceiverRecord> param1ArrayList) {
      this.a = param1Intent;
      this.b = param1ArrayList;
    }
  }
  
  private static final class ReceiverRecord {
    final IntentFilter a;
    
    final BroadcastReceiver b;
    
    boolean c;
    
    boolean d;
    
    ReceiverRecord(IntentFilter param1IntentFilter, BroadcastReceiver param1BroadcastReceiver) {
      this.a = param1IntentFilter;
      this.b = param1BroadcastReceiver;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder(128);
      stringBuilder.append("Receiver{");
      stringBuilder.append(this.b);
      stringBuilder.append(" filter=");
      stringBuilder.append(this.a);
      if (this.d)
        stringBuilder.append(" DEAD"); 
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\content\LocalBroadcastManager.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */