package android.support.v4.content.pm;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ShortcutInfo;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.VisibleForTesting;
import android.support.v4.graphics.drawable.IconCompat;
import android.text.TextUtils;
import java.util.Arrays;

public class ShortcutInfoCompat {
  private ComponentName mActivity;
  
  private Context mContext;
  
  private CharSequence mDisabledMessage;
  
  private IconCompat mIcon;
  
  private String mId;
  
  private Intent[] mIntents;
  
  private boolean mIsAlwaysBadged;
  
  private CharSequence mLabel;
  
  private CharSequence mLongLabel;
  
  private ShortcutInfoCompat() {}
  
  @VisibleForTesting
  Intent a(Intent paramIntent) {
    // Byte code:
    //   0: aload_1
    //   1: ldc 'android.intent.extra.shortcut.INTENT'
    //   3: aload_0
    //   4: getfield mIntents : [Landroid/content/Intent;
    //   7: iconst_m1
    //   8: aload_0
    //   9: getfield mIntents : [Landroid/content/Intent;
    //   12: arraylength
    //   13: iadd
    //   14: aaload
    //   15: invokevirtual putExtra : (Ljava/lang/String;Landroid/os/Parcelable;)Landroid/content/Intent;
    //   18: ldc 'android.intent.extra.shortcut.NAME'
    //   20: aload_0
    //   21: getfield mLabel : Ljava/lang/CharSequence;
    //   24: invokeinterface toString : ()Ljava/lang/String;
    //   29: invokevirtual putExtra : (Ljava/lang/String;Ljava/lang/String;)Landroid/content/Intent;
    //   32: pop
    //   33: aload_0
    //   34: getfield mIcon : Landroid/support/v4/graphics/drawable/IconCompat;
    //   37: ifnull -> 116
    //   40: aload_0
    //   41: getfield mIsAlwaysBadged : Z
    //   44: istore_3
    //   45: aconst_null
    //   46: astore #4
    //   48: iload_3
    //   49: ifeq -> 106
    //   52: aload_0
    //   53: getfield mContext : Landroid/content/Context;
    //   56: invokevirtual getPackageManager : ()Landroid/content/pm/PackageManager;
    //   59: astore #5
    //   61: aload_0
    //   62: getfield mActivity : Landroid/content/ComponentName;
    //   65: ifnull -> 86
    //   68: aload #5
    //   70: aload_0
    //   71: getfield mActivity : Landroid/content/ComponentName;
    //   74: invokevirtual getActivityIcon : (Landroid/content/ComponentName;)Landroid/graphics/drawable/Drawable;
    //   77: astore #7
    //   79: aload #7
    //   81: astore #4
    //   83: goto -> 87
    //   86: pop
    //   87: aload #4
    //   89: ifnonnull -> 106
    //   92: aload_0
    //   93: getfield mContext : Landroid/content/Context;
    //   96: invokevirtual getApplicationInfo : ()Landroid/content/pm/ApplicationInfo;
    //   99: aload #5
    //   101: invokevirtual loadIcon : (Landroid/content/pm/PackageManager;)Landroid/graphics/drawable/Drawable;
    //   104: astore #4
    //   106: aload_0
    //   107: getfield mIcon : Landroid/support/v4/graphics/drawable/IconCompat;
    //   110: aload_1
    //   111: aload #4
    //   113: invokevirtual addToShortcutIntent : (Landroid/content/Intent;Landroid/graphics/drawable/Drawable;)V
    //   116: aload_1
    //   117: areturn
    // Exception table:
    //   from	to	target	type
    //   68	79	86	android/content/pm/PackageManager$NameNotFoundException
  }
  
  @Nullable
  public ComponentName getActivity() {
    return this.mActivity;
  }
  
  @Nullable
  public CharSequence getDisabledMessage() {
    return this.mDisabledMessage;
  }
  
  @NonNull
  public String getId() {
    return this.mId;
  }
  
  @NonNull
  public Intent getIntent() {
    return this.mIntents[-1 + this.mIntents.length];
  }
  
  @NonNull
  public Intent[] getIntents() {
    return Arrays.<Intent>copyOf(this.mIntents, this.mIntents.length);
  }
  
  @Nullable
  public CharSequence getLongLabel() {
    return this.mLongLabel;
  }
  
  @NonNull
  public CharSequence getShortLabel() {
    return this.mLabel;
  }
  
  @RequiresApi(25)
  public ShortcutInfo toShortcutInfo() {
    ShortcutInfo.Builder builder = (new ShortcutInfo.Builder(this.mContext, this.mId)).setShortLabel(this.mLabel).setIntents(this.mIntents);
    if (this.mIcon != null)
      builder.setIcon(this.mIcon.toIcon()); 
    if (!TextUtils.isEmpty(this.mLongLabel))
      builder.setLongLabel(this.mLongLabel); 
    if (!TextUtils.isEmpty(this.mDisabledMessage))
      builder.setDisabledMessage(this.mDisabledMessage); 
    if (this.mActivity != null)
      builder.setActivity(this.mActivity); 
    return builder.build();
  }
  
  public static class Builder {
    private final ShortcutInfoCompat mInfo = new ShortcutInfoCompat();
    
    public Builder(@NonNull Context param1Context, @NonNull String param1String) {
      ShortcutInfoCompat.a(this.mInfo, param1Context);
      ShortcutInfoCompat.a(this.mInfo, param1String);
    }
    
    @NonNull
    public ShortcutInfoCompat build() {
      if (!TextUtils.isEmpty(ShortcutInfoCompat.a(this.mInfo))) {
        if (ShortcutInfoCompat.b(this.mInfo) != null && (ShortcutInfoCompat.b(this.mInfo)).length != 0)
          return this.mInfo; 
        throw new IllegalArgumentException("Shortcut much have an intent");
      } 
      throw new IllegalArgumentException("Shortcut much have a non-empty label");
    }
    
    @NonNull
    public Builder setActivity(@NonNull ComponentName param1ComponentName) {
      ShortcutInfoCompat.a(this.mInfo, param1ComponentName);
      return this;
    }
    
    public Builder setAlwaysBadged() {
      ShortcutInfoCompat.a(this.mInfo, true);
      return this;
    }
    
    @NonNull
    public Builder setDisabledMessage(@NonNull CharSequence param1CharSequence) {
      ShortcutInfoCompat.c(this.mInfo, param1CharSequence);
      return this;
    }
    
    @NonNull
    public Builder setIcon(IconCompat param1IconCompat) {
      ShortcutInfoCompat.a(this.mInfo, param1IconCompat);
      return this;
    }
    
    @NonNull
    public Builder setIntent(@NonNull Intent param1Intent) {
      return setIntents(new Intent[] { param1Intent });
    }
    
    @NonNull
    public Builder setIntents(@NonNull Intent[] param1ArrayOfIntent) {
      ShortcutInfoCompat.a(this.mInfo, param1ArrayOfIntent);
      return this;
    }
    
    @NonNull
    public Builder setLongLabel(@NonNull CharSequence param1CharSequence) {
      ShortcutInfoCompat.b(this.mInfo, param1CharSequence);
      return this;
    }
    
    @NonNull
    public Builder setShortLabel(@NonNull CharSequence param1CharSequence) {
      ShortcutInfoCompat.a(this.mInfo, param1CharSequence);
      return this;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\content\pm\ShortcutInfoCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */