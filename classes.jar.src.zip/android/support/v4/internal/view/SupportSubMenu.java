package android.support.v4.internal.view;

import android.support.annotation.RestrictTo;
import android.view.SubMenu;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public interface SupportSubMenu extends SupportMenu, SubMenu {}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\internal\view\SupportSubMenu.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */