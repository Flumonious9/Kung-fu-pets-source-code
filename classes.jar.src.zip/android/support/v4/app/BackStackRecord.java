package android.support.v4.app;

import android.support.v4.util.LogWriter;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Modifier;
import java.util.ArrayList;

final class BackStackRecord extends FragmentTransaction implements FragmentManager.BackStackEntry, FragmentManagerImpl.OpGenerator {
  final FragmentManagerImpl a;
  
  ArrayList<Op> b = new ArrayList<Op>();
  
  int c;
  
  int d;
  
  int e;
  
  int f;
  
  int g;
  
  int h;
  
  boolean i;
  
  boolean j = true;
  
  String k;
  
  boolean l;
  
  int m = -1;
  
  int n;
  
  CharSequence o;
  
  int p;
  
  CharSequence q;
  
  ArrayList<String> r;
  
  ArrayList<String> s;
  
  boolean t = false;
  
  ArrayList<Runnable> u;
  
  public BackStackRecord(FragmentManagerImpl paramFragmentManagerImpl) {
    this.a = paramFragmentManagerImpl;
  }
  
  private void doAddOp(int paramInt1, Fragment paramFragment, String paramString, int paramInt2) {
    Class<?> clazz = paramFragment.getClass();
    int i = clazz.getModifiers();
    if (!clazz.isAnonymousClass() && Modifier.isPublic(i) && (!clazz.isMemberClass() || Modifier.isStatic(i))) {
      paramFragment.mFragmentManager = this.a;
      if (paramString != null)
        if (paramFragment.mTag == null || paramString.equals(paramFragment.mTag)) {
          paramFragment.mTag = paramString;
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Can't change tag of fragment ");
          stringBuilder1.append(paramFragment);
          stringBuilder1.append(": was ");
          stringBuilder1.append(paramFragment.mTag);
          stringBuilder1.append(" now ");
          stringBuilder1.append(paramString);
          throw new IllegalStateException(stringBuilder1.toString());
        }  
      if (paramInt1 != 0)
        if (paramInt1 != -1) {
          if (paramFragment.mFragmentId == 0 || paramFragment.mFragmentId == paramInt1) {
            paramFragment.mFragmentId = paramInt1;
            paramFragment.mContainerId = paramInt1;
          } else {
            StringBuilder stringBuilder1 = new StringBuilder();
            stringBuilder1.append("Can't change container ID of fragment ");
            stringBuilder1.append(paramFragment);
            stringBuilder1.append(": was ");
            stringBuilder1.append(paramFragment.mFragmentId);
            stringBuilder1.append(" now ");
            stringBuilder1.append(paramInt1);
            throw new IllegalStateException(stringBuilder1.toString());
          } 
        } else {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Can't add fragment ");
          stringBuilder1.append(paramFragment);
          stringBuilder1.append(" with tag ");
          stringBuilder1.append(paramString);
          stringBuilder1.append(" to container view with no id");
          throw new IllegalArgumentException(stringBuilder1.toString());
        }  
      a(new Op(paramInt2, paramFragment));
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(clazz.getCanonicalName());
    stringBuilder.append(" must be a public static class to be  properly recreated from");
    stringBuilder.append(" instance state.");
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  private static boolean isFragmentPostponed(Op paramOp) {
    Fragment fragment = paramOp.b;
    return (fragment != null && fragment.mAdded && fragment.mView != null && !fragment.mDetached && !fragment.mHidden && fragment.isPostponed());
  }
  
  int a(boolean paramBoolean) {
    if (!this.l) {
      if (FragmentManagerImpl.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Commit: ");
        stringBuilder.append(this);
        Log.v("FragmentManager", stringBuilder.toString());
        PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
        dump("  ", null, printWriter, null);
        printWriter.close();
      } 
      this.l = true;
      if (this.i) {
        this.m = this.a.allocBackStackIndex(this);
      } else {
        this.m = -1;
      } 
      this.a.enqueueAction(this, paramBoolean);
      return this.m;
    } 
    throw new IllegalStateException("commit already called");
  }
  
  Fragment a(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    Fragment fragment = paramFragment;
    for (byte b = 0; b < this.b.size(); b++) {
      Fragment fragment1;
      int i;
      int j;
      Fragment fragment2;
      byte b1;
      boolean bool;
      Op op = this.b.get(b);
      switch (op.a) {
        case 8:
          this.b.add(b, new Op(9, fragment));
          b++;
          fragment = op.b;
          break;
        case 3:
        case 6:
          paramArrayList.remove(op.b);
          if (op.b == fragment) {
            this.b.add(b, new Op(9, op.b));
            b++;
            fragment = null;
          } 
          break;
        case 2:
          fragment1 = op.b;
          i = fragment1.mContainerId;
          j = paramArrayList.size() - 1;
          fragment2 = fragment;
          b1 = b;
          bool = false;
          while (j >= 0) {
            Fragment fragment3 = paramArrayList.get(j);
            if (fragment3.mContainerId == i)
              if (fragment3 == fragment1) {
                bool = true;
              } else {
                if (fragment3 == fragment2) {
                  this.b.add(b1, new Op(9, fragment3));
                  b1++;
                  fragment2 = null;
                } 
                Op op1 = new Op(3, fragment3);
                op1.c = op.c;
                op1.e = op.e;
                op1.d = op.d;
                op1.f = op.f;
                this.b.add(b1, op1);
                paramArrayList.remove(fragment3);
                b1++;
              }  
            j--;
          } 
          if (bool) {
            this.b.remove(b1);
            b1--;
          } else {
            op.a = 1;
            paramArrayList.add(fragment1);
          } 
          b = b1;
          fragment = fragment2;
          break;
        case 1:
        case 7:
          paramArrayList.add(op.b);
          break;
      } 
    } 
    return fragment;
  }
  
  void a() {
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      Op op = this.b.get(b);
      Fragment fragment = op.b;
      if (fragment != null)
        fragment.setNextTransition(this.g, this.h); 
      int j = op.a;
      if (j != 1) {
        StringBuilder stringBuilder;
        switch (j) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown cmd: ");
            stringBuilder.append(op.a);
            throw new IllegalArgumentException(stringBuilder.toString());
          case 9:
            this.a.setPrimaryNavigationFragment(null);
            break;
          case 8:
            this.a.setPrimaryNavigationFragment(fragment);
            break;
          case 7:
            fragment.setNextAnim(op.c);
            this.a.attachFragment(fragment);
            break;
          case 6:
            fragment.setNextAnim(op.d);
            this.a.detachFragment(fragment);
            break;
          case 5:
            fragment.setNextAnim(op.c);
            this.a.showFragment(fragment);
            break;
          case 4:
            fragment.setNextAnim(op.d);
            this.a.hideFragment(fragment);
            break;
          case 3:
            fragment.setNextAnim(op.d);
            this.a.removeFragment(fragment);
            break;
        } 
      } else {
        fragment.setNextAnim(op.c);
        this.a.addFragment(fragment, false);
      } 
      if (!this.t && op.a != 1 && fragment != null)
        this.a.d(fragment); 
    } 
    if (!this.t)
      this.a.a(this.a.l, true); 
  }
  
  void a(int paramInt) {
    if (!this.i)
      return; 
    if (FragmentManagerImpl.a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Bump nesting in ");
      stringBuilder.append(this);
      stringBuilder.append(" by ");
      stringBuilder.append(paramInt);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      Op op = this.b.get(b);
      if (op.b != null) {
        Fragment fragment = op.b;
        fragment.mBackStackNesting = paramInt + fragment.mBackStackNesting;
        if (FragmentManagerImpl.a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Bump nesting of ");
          stringBuilder.append(op.b);
          stringBuilder.append(" to ");
          stringBuilder.append(op.b.mBackStackNesting);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
      } 
    } 
  }
  
  void a(Op paramOp) {
    this.b.add(paramOp);
    paramOp.c = this.c;
    paramOp.d = this.d;
    paramOp.e = this.e;
    paramOp.f = this.f;
  }
  
  boolean a(ArrayList<BackStackRecord> paramArrayList, int paramInt1, int paramInt2) {
    if (paramInt2 == paramInt1)
      return false; 
    int i = this.b.size();
    byte b = 0;
    byte b1 = -1;
    while (b < i) {
      byte b2;
      Op op = this.b.get(b);
      if (op.b != null) {
        b2 = op.b.mContainerId;
      } else {
        b2 = 0;
      } 
      if (b2 && b2 != b1) {
        for (int j = paramInt1; j < paramInt2; j++) {
          BackStackRecord backStackRecord = paramArrayList.get(j);
          int k = backStackRecord.b.size();
          for (byte b3 = 0; b3 < k; b3++) {
            byte b4;
            Op op1 = backStackRecord.b.get(b3);
            if (op1.b != null) {
              b4 = op1.b.mContainerId;
            } else {
              b4 = 0;
            } 
            if (b4 == b2)
              return true; 
          } 
        } 
        b1 = b2;
      } 
      b++;
    } 
    return false;
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment) {
    doAddOp(paramInt, paramFragment, null, 1);
    return this;
  }
  
  public FragmentTransaction add(int paramInt, Fragment paramFragment, String paramString) {
    doAddOp(paramInt, paramFragment, paramString, 1);
    return this;
  }
  
  public FragmentTransaction add(Fragment paramFragment, String paramString) {
    doAddOp(0, paramFragment, paramString, 1);
    return this;
  }
  
  public FragmentTransaction addSharedElement(View paramView, String paramString) {
    if (FragmentTransition.a()) {
      String str = ViewCompat.getTransitionName(paramView);
      if (str != null) {
        if (this.r == null) {
          this.r = new ArrayList<String>();
          this.s = new ArrayList<String>();
        } else {
          if (!this.s.contains(paramString)) {
            if (this.r.contains(str)) {
              StringBuilder stringBuilder1 = new StringBuilder();
              stringBuilder1.append("A shared element with the source name '");
              stringBuilder1.append(str);
              stringBuilder1.append(" has already been added to the transaction.");
              throw new IllegalArgumentException(stringBuilder1.toString());
            } 
            this.r.add(str);
            this.s.add(paramString);
            return this;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("A shared element with the target name '");
          stringBuilder.append(paramString);
          stringBuilder.append("' has already been added to the transaction.");
          throw new IllegalArgumentException(stringBuilder.toString());
        } 
        this.r.add(str);
        this.s.add(paramString);
        return this;
      } 
      throw new IllegalArgumentException("Unique transitionNames are required for all sharedElements");
    } 
    return this;
  }
  
  public FragmentTransaction addToBackStack(String paramString) {
    if (this.j) {
      this.i = true;
      this.k = paramString;
      return this;
    } 
    throw new IllegalStateException("This FragmentTransaction is not allowed to be added to the back stack.");
  }
  
  public FragmentTransaction attach(Fragment paramFragment) {
    a(new Op(7, paramFragment));
    return this;
  }
  
  Fragment b(ArrayList<Fragment> paramArrayList, Fragment paramFragment) {
    byte b = 0;
    while (b < this.b.size()) {
      Op op = this.b.get(b);
      int i = op.a;
      if (i != 1)
        if (i != 3) {
          switch (i) {
            case 9:
              paramFragment = op.b;
              break;
            case 8:
              paramFragment = null;
              break;
            case 6:
              paramArrayList.add(op.b);
              break;
            case 7:
              paramArrayList.remove(op.b);
              break;
          } 
          b++;
        }  
    } 
    return paramFragment;
  }
  
  void b(boolean paramBoolean) {
    for (int i = this.b.size() - 1; i >= 0; i--) {
      Op op = this.b.get(i);
      Fragment fragment = op.b;
      if (fragment != null)
        fragment.setNextTransition(FragmentManagerImpl.reverseTransit(this.g), this.h); 
      int j = op.a;
      if (j != 1) {
        StringBuilder stringBuilder;
        switch (j) {
          default:
            stringBuilder = new StringBuilder();
            stringBuilder.append("Unknown cmd: ");
            stringBuilder.append(op.a);
            throw new IllegalArgumentException(stringBuilder.toString());
          case 9:
            this.a.setPrimaryNavigationFragment(fragment);
            break;
          case 8:
            this.a.setPrimaryNavigationFragment(null);
            break;
          case 7:
            fragment.setNextAnim(op.f);
            this.a.detachFragment(fragment);
            break;
          case 6:
            fragment.setNextAnim(op.e);
            this.a.attachFragment(fragment);
            break;
          case 5:
            fragment.setNextAnim(op.f);
            this.a.hideFragment(fragment);
            break;
          case 4:
            fragment.setNextAnim(op.e);
            this.a.showFragment(fragment);
            break;
          case 3:
            fragment.setNextAnim(op.e);
            this.a.addFragment(fragment, false);
            break;
        } 
      } else {
        fragment.setNextAnim(op.f);
        this.a.removeFragment(fragment);
      } 
      if (!this.t && op.a != 3 && fragment != null)
        this.a.d(fragment); 
    } 
    if (!this.t && paramBoolean)
      this.a.a(this.a.l, true); 
  }
  
  boolean b(int paramInt) {
    int i = this.b.size();
    for (byte b = 0; b < i; b++) {
      int j;
      Op op = this.b.get(b);
      if (op.b != null) {
        j = op.b.mContainerId;
      } else {
        j = 0;
      } 
      if (j && j == paramInt)
        return true; 
    } 
    return false;
  }
  
  public int commit() {
    return a(false);
  }
  
  public int commitAllowingStateLoss() {
    return a(true);
  }
  
  public void commitNow() {
    disallowAddToBackStack();
    this.a.execSingleAction(this, false);
  }
  
  public void commitNowAllowingStateLoss() {
    disallowAddToBackStack();
    this.a.execSingleAction(this, true);
  }
  
  public FragmentTransaction detach(Fragment paramFragment) {
    a(new Op(6, paramFragment));
    return this;
  }
  
  public FragmentTransaction disallowAddToBackStack() {
    if (!this.i) {
      this.j = false;
      return this;
    } 
    throw new IllegalStateException("This transaction is already being added to the back stack");
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    dump(paramString, paramPrintWriter, true);
  }
  
  public void dump(String paramString, PrintWriter paramPrintWriter, boolean paramBoolean) {
    if (paramBoolean) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.print("mName=");
      paramPrintWriter.print(this.k);
      paramPrintWriter.print(" mIndex=");
      paramPrintWriter.print(this.m);
      paramPrintWriter.print(" mCommitted=");
      paramPrintWriter.println(this.l);
      if (this.g != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mTransition=#");
        paramPrintWriter.print(Integer.toHexString(this.g));
        paramPrintWriter.print(" mTransitionStyle=#");
        paramPrintWriter.println(Integer.toHexString(this.h));
      } 
      if (this.c != 0 || this.d != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.c));
        paramPrintWriter.print(" mExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.d));
      } 
      if (this.e != 0 || this.f != 0) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mPopEnterAnim=#");
        paramPrintWriter.print(Integer.toHexString(this.e));
        paramPrintWriter.print(" mPopExitAnim=#");
        paramPrintWriter.println(Integer.toHexString(this.f));
      } 
      if (this.n != 0 || this.o != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.n));
        paramPrintWriter.print(" mBreadCrumbTitleText=");
        paramPrintWriter.println(this.o);
      } 
      if (this.p != 0 || this.q != null) {
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("mBreadCrumbShortTitleRes=#");
        paramPrintWriter.print(Integer.toHexString(this.p));
        paramPrintWriter.print(" mBreadCrumbShortTitleText=");
        paramPrintWriter.println(this.q);
      } 
    } 
    if (!this.b.isEmpty()) {
      paramPrintWriter.print(paramString);
      paramPrintWriter.println("Operations:");
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramString);
      stringBuilder.append("    ");
      stringBuilder.toString();
      int i = this.b.size();
      for (byte b = 0; b < i; b++) {
        String str;
        StringBuilder stringBuilder1;
        Op op = this.b.get(b);
        switch (op.a) {
          default:
            stringBuilder1 = new StringBuilder();
            stringBuilder1.append("cmd=");
            stringBuilder1.append(op.a);
            str = stringBuilder1.toString();
            break;
          case 9:
            str = "UNSET_PRIMARY_NAV";
            break;
          case 8:
            str = "SET_PRIMARY_NAV";
            break;
          case 7:
            str = "ATTACH";
            break;
          case 6:
            str = "DETACH";
            break;
          case 5:
            str = "SHOW";
            break;
          case 4:
            str = "HIDE";
            break;
          case 3:
            str = "REMOVE";
            break;
          case 2:
            str = "REPLACE";
            break;
          case 1:
            str = "ADD";
            break;
          case 0:
            str = "NULL";
            break;
        } 
        paramPrintWriter.print(paramString);
        paramPrintWriter.print("  Op #");
        paramPrintWriter.print(b);
        paramPrintWriter.print(": ");
        paramPrintWriter.print(str);
        paramPrintWriter.print(" ");
        paramPrintWriter.println(op.b);
        if (paramBoolean) {
          if (op.c != 0 || op.d != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("enterAnim=#");
            paramPrintWriter.print(Integer.toHexString(op.c));
            paramPrintWriter.print(" exitAnim=#");
            paramPrintWriter.println(Integer.toHexString(op.d));
          } 
          if (op.e != 0 || op.f != 0) {
            paramPrintWriter.print(paramString);
            paramPrintWriter.print("popEnterAnim=#");
            paramPrintWriter.print(Integer.toHexString(op.e));
            paramPrintWriter.print(" popExitAnim=#");
            paramPrintWriter.println(Integer.toHexString(op.f));
          } 
        } 
      } 
    } 
  }
  
  public boolean generateOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (FragmentManagerImpl.a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Run: ");
      stringBuilder.append(this);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    paramArrayList.add(this);
    paramArrayList1.add(Boolean.valueOf(false));
    if (this.i)
      this.a.a(this); 
    return true;
  }
  
  public CharSequence getBreadCrumbShortTitle() {
    return (this.p != 0) ? this.a.m.getContext().getText(this.p) : this.q;
  }
  
  public int getBreadCrumbShortTitleRes() {
    return this.p;
  }
  
  public CharSequence getBreadCrumbTitle() {
    return (this.n != 0) ? this.a.m.getContext().getText(this.n) : this.o;
  }
  
  public int getBreadCrumbTitleRes() {
    return this.n;
  }
  
  public int getId() {
    return this.m;
  }
  
  public String getName() {
    return this.k;
  }
  
  public int getTransition() {
    return this.g;
  }
  
  public int getTransitionStyle() {
    return this.h;
  }
  
  public FragmentTransaction hide(Fragment paramFragment) {
    a(new Op(4, paramFragment));
    return this;
  }
  
  public boolean isAddToBackStackAllowed() {
    return this.j;
  }
  
  public boolean isEmpty() {
    return this.b.isEmpty();
  }
  
  boolean isPostponed() {
    for (byte b = 0; b < this.b.size(); b++) {
      if (isFragmentPostponed(this.b.get(b)))
        return true; 
    } 
    return false;
  }
  
  public FragmentTransaction remove(Fragment paramFragment) {
    a(new Op(3, paramFragment));
    return this;
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment) {
    return replace(paramInt, paramFragment, null);
  }
  
  public FragmentTransaction replace(int paramInt, Fragment paramFragment, String paramString) {
    if (paramInt != 0) {
      doAddOp(paramInt, paramFragment, paramString, 2);
      return this;
    } 
    throw new IllegalArgumentException("Must use non-zero containerViewId");
  }
  
  public FragmentTransaction runOnCommit(Runnable paramRunnable) {
    if (paramRunnable != null) {
      disallowAddToBackStack();
      if (this.u == null)
        this.u = new ArrayList<Runnable>(); 
      this.u.add(paramRunnable);
      return this;
    } 
    throw new IllegalArgumentException("runnable cannot be null");
  }
  
  public void runOnCommitRunnables() {
    if (this.u != null) {
      byte b = 0;
      int i = this.u.size();
      while (b < i) {
        ((Runnable)this.u.get(b)).run();
        b++;
      } 
      this.u = null;
    } 
  }
  
  public FragmentTransaction setAllowOptimization(boolean paramBoolean) {
    return setReorderingAllowed(paramBoolean);
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(int paramInt) {
    this.p = paramInt;
    this.q = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbShortTitle(CharSequence paramCharSequence) {
    this.p = 0;
    this.q = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(int paramInt) {
    this.n = paramInt;
    this.o = null;
    return this;
  }
  
  public FragmentTransaction setBreadCrumbTitle(CharSequence paramCharSequence) {
    this.n = 0;
    this.o = paramCharSequence;
    return this;
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2) {
    return setCustomAnimations(paramInt1, paramInt2, 0, 0);
  }
  
  public FragmentTransaction setCustomAnimations(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.c = paramInt1;
    this.d = paramInt2;
    this.e = paramInt3;
    this.f = paramInt4;
    return this;
  }
  
  void setOnStartPostponedListener(Fragment.OnStartEnterTransitionListener paramOnStartEnterTransitionListener) {
    for (byte b = 0; b < this.b.size(); b++) {
      Op op = this.b.get(b);
      if (isFragmentPostponed(op))
        op.b.setOnStartEnterTransitionListener(paramOnStartEnterTransitionListener); 
    } 
  }
  
  public FragmentTransaction setPrimaryNavigationFragment(Fragment paramFragment) {
    a(new Op(8, paramFragment));
    return this;
  }
  
  public FragmentTransaction setReorderingAllowed(boolean paramBoolean) {
    this.t = paramBoolean;
    return this;
  }
  
  public FragmentTransaction setTransition(int paramInt) {
    this.g = paramInt;
    return this;
  }
  
  public FragmentTransaction setTransitionStyle(int paramInt) {
    this.h = paramInt;
    return this;
  }
  
  public FragmentTransaction show(Fragment paramFragment) {
    a(new Op(5, paramFragment));
    return this;
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("BackStackEntry{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    if (this.m >= 0) {
      stringBuilder.append(" #");
      stringBuilder.append(this.m);
    } 
    if (this.k != null) {
      stringBuilder.append(" ");
      stringBuilder.append(this.k);
    } 
    stringBuilder.append("}");
    return stringBuilder.toString();
  }
  
  static final class Op {
    int a;
    
    Fragment b;
    
    int c;
    
    int d;
    
    int e;
    
    int f;
    
    Op() {}
    
    Op(int param1Int, Fragment param1Fragment) {
      this.a = param1Int;
      this.b = param1Fragment;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\BackStackRecord.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */