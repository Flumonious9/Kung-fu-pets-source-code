package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Context;
import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.drawable.Drawable;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.annotation.ColorInt;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.compat.R;
import android.support.v4.text.BidiFormatter;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.TextAppearanceSpan;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

public class NotificationCompat {
  public static final int BADGE_ICON_LARGE = 2;
  
  public static final int BADGE_ICON_NONE = 0;
  
  public static final int BADGE_ICON_SMALL = 1;
  
  public static final String CATEGORY_ALARM = "alarm";
  
  public static final String CATEGORY_CALL = "call";
  
  public static final String CATEGORY_EMAIL = "email";
  
  public static final String CATEGORY_ERROR = "err";
  
  public static final String CATEGORY_EVENT = "event";
  
  public static final String CATEGORY_MESSAGE = "msg";
  
  public static final String CATEGORY_PROGRESS = "progress";
  
  public static final String CATEGORY_PROMO = "promo";
  
  public static final String CATEGORY_RECOMMENDATION = "recommendation";
  
  public static final String CATEGORY_REMINDER = "reminder";
  
  public static final String CATEGORY_SERVICE = "service";
  
  public static final String CATEGORY_SOCIAL = "social";
  
  public static final String CATEGORY_STATUS = "status";
  
  public static final String CATEGORY_SYSTEM = "sys";
  
  public static final String CATEGORY_TRANSPORT = "transport";
  
  @ColorInt
  public static final int COLOR_DEFAULT = 0;
  
  public static final int DEFAULT_ALL = -1;
  
  public static final int DEFAULT_LIGHTS = 4;
  
  public static final int DEFAULT_SOUND = 1;
  
  public static final int DEFAULT_VIBRATE = 2;
  
  public static final String EXTRA_AUDIO_CONTENTS_URI = "android.audioContents";
  
  public static final String EXTRA_BACKGROUND_IMAGE_URI = "android.backgroundImageUri";
  
  public static final String EXTRA_BIG_TEXT = "android.bigText";
  
  public static final String EXTRA_COMPACT_ACTIONS = "android.compactActions";
  
  public static final String EXTRA_CONVERSATION_TITLE = "android.conversationTitle";
  
  public static final String EXTRA_INFO_TEXT = "android.infoText";
  
  public static final String EXTRA_LARGE_ICON = "android.largeIcon";
  
  public static final String EXTRA_LARGE_ICON_BIG = "android.largeIcon.big";
  
  public static final String EXTRA_MEDIA_SESSION = "android.mediaSession";
  
  public static final String EXTRA_MESSAGES = "android.messages";
  
  public static final String EXTRA_PEOPLE = "android.people";
  
  public static final String EXTRA_PICTURE = "android.picture";
  
  public static final String EXTRA_PROGRESS = "android.progress";
  
  public static final String EXTRA_PROGRESS_INDETERMINATE = "android.progressIndeterminate";
  
  public static final String EXTRA_PROGRESS_MAX = "android.progressMax";
  
  public static final String EXTRA_REMOTE_INPUT_HISTORY = "android.remoteInputHistory";
  
  public static final String EXTRA_SELF_DISPLAY_NAME = "android.selfDisplayName";
  
  public static final String EXTRA_SHOW_CHRONOMETER = "android.showChronometer";
  
  public static final String EXTRA_SHOW_WHEN = "android.showWhen";
  
  public static final String EXTRA_SMALL_ICON = "android.icon";
  
  public static final String EXTRA_SUB_TEXT = "android.subText";
  
  public static final String EXTRA_SUMMARY_TEXT = "android.summaryText";
  
  public static final String EXTRA_TEMPLATE = "android.template";
  
  public static final String EXTRA_TEXT = "android.text";
  
  public static final String EXTRA_TEXT_LINES = "android.textLines";
  
  public static final String EXTRA_TITLE = "android.title";
  
  public static final String EXTRA_TITLE_BIG = "android.title.big";
  
  public static final int FLAG_AUTO_CANCEL = 16;
  
  public static final int FLAG_FOREGROUND_SERVICE = 64;
  
  public static final int FLAG_GROUP_SUMMARY = 512;
  
  @Deprecated
  public static final int FLAG_HIGH_PRIORITY = 128;
  
  public static final int FLAG_INSISTENT = 4;
  
  public static final int FLAG_LOCAL_ONLY = 256;
  
  public static final int FLAG_NO_CLEAR = 32;
  
  public static final int FLAG_ONGOING_EVENT = 2;
  
  public static final int FLAG_ONLY_ALERT_ONCE = 8;
  
  public static final int FLAG_SHOW_LIGHTS = 1;
  
  public static final int GROUP_ALERT_ALL = 0;
  
  public static final int GROUP_ALERT_CHILDREN = 2;
  
  public static final int GROUP_ALERT_SUMMARY = 1;
  
  public static final int PRIORITY_DEFAULT = 0;
  
  public static final int PRIORITY_HIGH = 1;
  
  public static final int PRIORITY_LOW = -1;
  
  public static final int PRIORITY_MAX = 2;
  
  public static final int PRIORITY_MIN = -2;
  
  public static final int STREAM_DEFAULT = -1;
  
  public static final int VISIBILITY_PRIVATE = 0;
  
  public static final int VISIBILITY_PUBLIC = 1;
  
  public static final int VISIBILITY_SECRET = -1;
  
  @RequiresApi(20)
  static Action a(Notification.Action paramAction) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getRemoteInputs : ()[Landroid/app/RemoteInput;
    //   4: astore_1
    //   5: aload_1
    //   6: ifnonnull -> 14
    //   9: aconst_null
    //   10: astore_2
    //   11: goto -> 88
    //   14: aload_1
    //   15: arraylength
    //   16: anewarray android/support/v4/app/RemoteInput
    //   19: astore #7
    //   21: iconst_0
    //   22: istore #8
    //   24: iload #8
    //   26: aload_1
    //   27: arraylength
    //   28: if_icmpge -> 85
    //   31: aload_1
    //   32: iload #8
    //   34: aaload
    //   35: astore #9
    //   37: new android/support/v4/app/RemoteInput
    //   40: dup
    //   41: aload #9
    //   43: invokevirtual getResultKey : ()Ljava/lang/String;
    //   46: aload #9
    //   48: invokevirtual getLabel : ()Ljava/lang/CharSequence;
    //   51: aload #9
    //   53: invokevirtual getChoices : ()[Ljava/lang/CharSequence;
    //   56: aload #9
    //   58: invokevirtual getAllowFreeFormInput : ()Z
    //   61: aload #9
    //   63: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   66: aconst_null
    //   67: invokespecial <init> : (Ljava/lang/String;Ljava/lang/CharSequence;[Ljava/lang/CharSequence;ZLandroid/os/Bundle;Ljava/util/Set;)V
    //   70: astore #10
    //   72: aload #7
    //   74: iload #8
    //   76: aload #10
    //   78: aastore
    //   79: iinc #8, 1
    //   82: goto -> 24
    //   85: aload #7
    //   87: astore_2
    //   88: getstatic android/os/Build$VERSION.SDK_INT : I
    //   91: bipush #24
    //   93: if_icmplt -> 131
    //   96: aload_0
    //   97: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   100: ldc 'android.support.allowGeneratedReplies'
    //   102: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   105: ifne -> 122
    //   108: aload_0
    //   109: invokevirtual getAllowGeneratedReplies : ()Z
    //   112: istore #6
    //   114: iconst_0
    //   115: istore #5
    //   117: iload #6
    //   119: ifeq -> 125
    //   122: iconst_1
    //   123: istore #5
    //   125: iload #5
    //   127: istore_3
    //   128: goto -> 141
    //   131: aload_0
    //   132: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   135: ldc 'android.support.allowGeneratedReplies'
    //   137: invokevirtual getBoolean : (Ljava/lang/String;)Z
    //   140: istore_3
    //   141: new android/support/v4/app/NotificationCompat$Action
    //   144: dup
    //   145: aload_0
    //   146: getfield icon : I
    //   149: aload_0
    //   150: getfield title : Ljava/lang/CharSequence;
    //   153: aload_0
    //   154: getfield actionIntent : Landroid/app/PendingIntent;
    //   157: aload_0
    //   158: invokevirtual getExtras : ()Landroid/os/Bundle;
    //   161: aload_2
    //   162: aconst_null
    //   163: iload_3
    //   164: invokespecial <init> : (ILjava/lang/CharSequence;Landroid/app/PendingIntent;Landroid/os/Bundle;[Landroid/support/v4/app/RemoteInput;[Landroid/support/v4/app/RemoteInput;Z)V
    //   167: astore #4
    //   169: aload #4
    //   171: areturn
  }
  
  static Notification[] a(Bundle paramBundle, String paramString) {
    Parcelable[] arrayOfParcelable = paramBundle.getParcelableArray(paramString);
    if (arrayOfParcelable instanceof Notification[] || arrayOfParcelable == null)
      return (Notification[])arrayOfParcelable; 
    Notification[] arrayOfNotification = new Notification[arrayOfParcelable.length];
    for (byte b = 0; b < arrayOfParcelable.length; b++)
      arrayOfNotification[b] = (Notification)arrayOfParcelable[b]; 
    paramBundle.putParcelableArray(paramString, (Parcelable[])arrayOfNotification);
    return arrayOfNotification;
  }
  
  public static Action getAction(Notification paramNotification, int paramInt) {
    if (Build.VERSION.SDK_INT >= 20)
      return a(paramNotification.actions[paramInt]); 
    if (Build.VERSION.SDK_INT >= 19) {
      Notification.Action action = paramNotification.actions[paramInt];
      SparseArray sparseArray = paramNotification.extras.getSparseParcelableArray("android.support.actionExtras");
      Bundle bundle = null;
      if (sparseArray != null)
        bundle = (Bundle)sparseArray.get(paramInt); 
      return NotificationCompatJellybean.readAction(action.icon, action.title, action.actionIntent, bundle);
    } 
    return (Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getAction(paramNotification, paramInt) : null;
  }
  
  public static int getActionCount(Notification paramNotification) {
    if (Build.VERSION.SDK_INT >= 19) {
      Notification.Action[] arrayOfAction = paramNotification.actions;
      int i = 0;
      if (arrayOfAction != null)
        i = paramNotification.actions.length; 
      return i;
    } 
    return (Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getActionCount(paramNotification) : 0;
  }
  
  public static int getBadgeIconType(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? paramNotification.getBadgeIconType() : 0;
  }
  
  public static String getCategory(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 21) ? paramNotification.category : null;
  }
  
  public static String getChannelId(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? paramNotification.getChannelId() : null;
  }
  
  public static Bundle getExtras(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 19) ? paramNotification.extras : ((Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getExtras(paramNotification) : null);
  }
  
  public static String getGroup(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 20) ? paramNotification.getGroup() : ((Build.VERSION.SDK_INT >= 19) ? paramNotification.extras.getString("android.support.groupKey") : ((Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getExtras(paramNotification).getString("android.support.groupKey") : null));
  }
  
  public static int getGroupAlertBehavior(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? paramNotification.getGroupAlertBehavior() : 0;
  }
  
  public static boolean getLocalOnly(Notification paramNotification) {
    if (Build.VERSION.SDK_INT >= 20) {
      int i = 0x100 & paramNotification.flags;
      boolean bool = false;
      if (i != 0)
        bool = true; 
      return bool;
    } 
    return (Build.VERSION.SDK_INT >= 19) ? paramNotification.extras.getBoolean("android.support.localOnly") : ((Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getExtras(paramNotification).getBoolean("android.support.localOnly") : false);
  }
  
  public static String getShortcutId(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? paramNotification.getShortcutId() : null;
  }
  
  public static String getSortKey(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 20) ? paramNotification.getSortKey() : ((Build.VERSION.SDK_INT >= 19) ? paramNotification.extras.getString("android.support.sortKey") : ((Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getExtras(paramNotification).getString("android.support.sortKey") : null));
  }
  
  public static long getTimeoutAfter(Notification paramNotification) {
    return (Build.VERSION.SDK_INT >= 26) ? paramNotification.getTimeoutAfter() : 0L;
  }
  
  public static boolean isGroupSummary(Notification paramNotification) {
    if (Build.VERSION.SDK_INT >= 20) {
      int i = 0x200 & paramNotification.flags;
      boolean bool = false;
      if (i != 0)
        bool = true; 
      return bool;
    } 
    return (Build.VERSION.SDK_INT >= 19) ? paramNotification.extras.getBoolean("android.support.isGroupSummary") : ((Build.VERSION.SDK_INT >= 16) ? NotificationCompatJellybean.getExtras(paramNotification).getBoolean("android.support.isGroupSummary") : false);
  }
  
  public static class Action {
    final Bundle a;
    
    public PendingIntent actionIntent;
    
    public int icon;
    
    private boolean mAllowGeneratedReplies;
    
    private final RemoteInput[] mDataOnlyRemoteInputs;
    
    private final RemoteInput[] mRemoteInputs;
    
    public CharSequence title;
    
    public Action(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1Int, param1CharSequence, param1PendingIntent, new Bundle(), null, null, true);
    }
    
    Action(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, RemoteInput[] param1ArrayOfRemoteInput1, RemoteInput[] param1ArrayOfRemoteInput2, boolean param1Boolean) {
      this.icon = param1Int;
      this.title = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      this.actionIntent = param1PendingIntent;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      this.a = param1Bundle;
      this.mRemoteInputs = param1ArrayOfRemoteInput1;
      this.mDataOnlyRemoteInputs = param1ArrayOfRemoteInput2;
      this.mAllowGeneratedReplies = param1Boolean;
    }
    
    public PendingIntent getActionIntent() {
      return this.actionIntent;
    }
    
    public boolean getAllowGeneratedReplies() {
      return this.mAllowGeneratedReplies;
    }
    
    public RemoteInput[] getDataOnlyRemoteInputs() {
      return this.mDataOnlyRemoteInputs;
    }
    
    public Bundle getExtras() {
      return this.a;
    }
    
    public int getIcon() {
      return this.icon;
    }
    
    public RemoteInput[] getRemoteInputs() {
      return this.mRemoteInputs;
    }
    
    public CharSequence getTitle() {
      return this.title;
    }
    
    public static final class Builder {
      private boolean mAllowGeneratedReplies;
      
      private final Bundle mExtras;
      
      private final int mIcon;
      
      private final PendingIntent mIntent;
      
      private ArrayList<RemoteInput> mRemoteInputs;
      
      private final CharSequence mTitle;
      
      public Builder(int param2Int, CharSequence param2CharSequence, PendingIntent param2PendingIntent) {
        this(param2Int, param2CharSequence, param2PendingIntent, new Bundle(), null, true);
      }
      
      private Builder(int param2Int, CharSequence param2CharSequence, PendingIntent param2PendingIntent, Bundle param2Bundle, RemoteInput[] param2ArrayOfRemoteInput, boolean param2Boolean) {
        ArrayList<RemoteInput> arrayList;
        this.mAllowGeneratedReplies = true;
        this.mIcon = param2Int;
        this.mTitle = NotificationCompat.Builder.limitCharSequenceLength(param2CharSequence);
        this.mIntent = param2PendingIntent;
        this.mExtras = param2Bundle;
        if (param2ArrayOfRemoteInput == null) {
          arrayList = null;
        } else {
          arrayList = new ArrayList(Arrays.asList((Object[])param2ArrayOfRemoteInput));
        } 
        this.mRemoteInputs = arrayList;
        this.mAllowGeneratedReplies = param2Boolean;
      }
      
      public Builder(NotificationCompat.Action param2Action) {
        this(param2Action.icon, param2Action.title, param2Action.actionIntent, new Bundle(param2Action.a), param2Action.getRemoteInputs(), param2Action.getAllowGeneratedReplies());
      }
      
      public Builder addExtras(Bundle param2Bundle) {
        if (param2Bundle != null)
          this.mExtras.putAll(param2Bundle); 
        return this;
      }
      
      public Builder addRemoteInput(RemoteInput param2RemoteInput) {
        if (this.mRemoteInputs == null)
          this.mRemoteInputs = new ArrayList<RemoteInput>(); 
        this.mRemoteInputs.add(param2RemoteInput);
        return this;
      }
      
      public NotificationCompat.Action build() {
        RemoteInput[] arrayOfRemoteInput1;
        ArrayList<RemoteInput> arrayList1 = new ArrayList();
        ArrayList<RemoteInput> arrayList2 = new ArrayList();
        if (this.mRemoteInputs != null)
          for (RemoteInput remoteInput : this.mRemoteInputs) {
            if (remoteInput.isDataOnly()) {
              arrayList1.add(remoteInput);
              continue;
            } 
            arrayList2.add(remoteInput);
          }  
        if (arrayList1.isEmpty()) {
          arrayOfRemoteInput1 = null;
        } else {
          arrayOfRemoteInput1 = arrayList1.<RemoteInput>toArray(new RemoteInput[arrayList1.size()]);
        } 
        boolean bool = arrayList2.isEmpty();
        RemoteInput[] arrayOfRemoteInput2 = null;
        if (!bool)
          arrayOfRemoteInput2 = arrayList2.<RemoteInput>toArray(new RemoteInput[arrayList2.size()]); 
        RemoteInput[] arrayOfRemoteInput3 = arrayOfRemoteInput2;
        return new NotificationCompat.Action(this.mIcon, this.mTitle, this.mIntent, this.mExtras, arrayOfRemoteInput3, arrayOfRemoteInput1, this.mAllowGeneratedReplies);
      }
      
      public Builder extend(NotificationCompat.Action.Extender param2Extender) {
        param2Extender.extend(this);
        return this;
      }
      
      public Bundle getExtras() {
        return this.mExtras;
      }
      
      public Builder setAllowGeneratedReplies(boolean param2Boolean) {
        this.mAllowGeneratedReplies = param2Boolean;
        return this;
      }
    }
    
    public static interface Extender {
      NotificationCompat.Action.Builder extend(NotificationCompat.Action.Builder param2Builder);
    }
    
    public static final class WearableExtender implements Extender {
      private static final int DEFAULT_FLAGS = 1;
      
      private static final String EXTRA_WEARABLE_EXTENSIONS = "android.wearable.EXTENSIONS";
      
      private static final int FLAG_AVAILABLE_OFFLINE = 1;
      
      private static final int FLAG_HINT_DISPLAY_INLINE = 4;
      
      private static final int FLAG_HINT_LAUNCHES_ACTIVITY = 2;
      
      private static final String KEY_CANCEL_LABEL = "cancelLabel";
      
      private static final String KEY_CONFIRM_LABEL = "confirmLabel";
      
      private static final String KEY_FLAGS = "flags";
      
      private static final String KEY_IN_PROGRESS_LABEL = "inProgressLabel";
      
      private CharSequence mCancelLabel;
      
      private CharSequence mConfirmLabel;
      
      private int mFlags = 1;
      
      private CharSequence mInProgressLabel;
      
      public WearableExtender() {}
      
      public WearableExtender(NotificationCompat.Action param2Action) {
        Bundle bundle = param2Action.getExtras().getBundle("android.wearable.EXTENSIONS");
        if (bundle != null) {
          this.mFlags = bundle.getInt("flags", 1);
          this.mInProgressLabel = bundle.getCharSequence("inProgressLabel");
          this.mConfirmLabel = bundle.getCharSequence("confirmLabel");
          this.mCancelLabel = bundle.getCharSequence("cancelLabel");
        } 
      }
      
      private void setFlag(int param2Int, boolean param2Boolean) {
        if (param2Boolean) {
          this.mFlags = param2Int | this.mFlags;
          return;
        } 
        this.mFlags &= param2Int ^ 0xFFFFFFFF;
      }
      
      public WearableExtender clone() {
        WearableExtender wearableExtender = new WearableExtender();
        wearableExtender.mFlags = this.mFlags;
        wearableExtender.mInProgressLabel = this.mInProgressLabel;
        wearableExtender.mConfirmLabel = this.mConfirmLabel;
        wearableExtender.mCancelLabel = this.mCancelLabel;
        return wearableExtender;
      }
      
      public NotificationCompat.Action.Builder extend(NotificationCompat.Action.Builder param2Builder) {
        Bundle bundle = new Bundle();
        if (this.mFlags != 1)
          bundle.putInt("flags", this.mFlags); 
        if (this.mInProgressLabel != null)
          bundle.putCharSequence("inProgressLabel", this.mInProgressLabel); 
        if (this.mConfirmLabel != null)
          bundle.putCharSequence("confirmLabel", this.mConfirmLabel); 
        if (this.mCancelLabel != null)
          bundle.putCharSequence("cancelLabel", this.mCancelLabel); 
        param2Builder.getExtras().putBundle("android.wearable.EXTENSIONS", bundle);
        return param2Builder;
      }
      
      public CharSequence getCancelLabel() {
        return this.mCancelLabel;
      }
      
      public CharSequence getConfirmLabel() {
        return this.mConfirmLabel;
      }
      
      public boolean getHintDisplayActionInline() {
        return ((0x4 & this.mFlags) != 0);
      }
      
      public boolean getHintLaunchesActivity() {
        return ((0x2 & this.mFlags) != 0);
      }
      
      public CharSequence getInProgressLabel() {
        return this.mInProgressLabel;
      }
      
      public boolean isAvailableOffline() {
        return ((0x1 & this.mFlags) != 0);
      }
      
      public WearableExtender setAvailableOffline(boolean param2Boolean) {
        setFlag(1, param2Boolean);
        return this;
      }
      
      public WearableExtender setCancelLabel(CharSequence param2CharSequence) {
        this.mCancelLabel = param2CharSequence;
        return this;
      }
      
      public WearableExtender setConfirmLabel(CharSequence param2CharSequence) {
        this.mConfirmLabel = param2CharSequence;
        return this;
      }
      
      public WearableExtender setHintDisplayActionInline(boolean param2Boolean) {
        setFlag(4, param2Boolean);
        return this;
      }
      
      public WearableExtender setHintLaunchesActivity(boolean param2Boolean) {
        setFlag(2, param2Boolean);
        return this;
      }
      
      public WearableExtender setInProgressLabel(CharSequence param2CharSequence) {
        this.mInProgressLabel = param2CharSequence;
        return this;
      }
    }
  }
  
  public static final class Builder {
    private boolean mAllowGeneratedReplies;
    
    private final Bundle mExtras;
    
    private final int mIcon;
    
    private final PendingIntent mIntent;
    
    private ArrayList<RemoteInput> mRemoteInputs;
    
    private final CharSequence mTitle;
    
    public Builder(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this(param1Int, param1CharSequence, param1PendingIntent, new Bundle(), null, true);
    }
    
    private Builder(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent, Bundle param1Bundle, RemoteInput[] param1ArrayOfRemoteInput, boolean param1Boolean) {
      ArrayList<RemoteInput> arrayList;
      this.mAllowGeneratedReplies = true;
      this.mIcon = param1Int;
      this.mTitle = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      this.mIntent = param1PendingIntent;
      this.mExtras = param1Bundle;
      if (param1ArrayOfRemoteInput == null) {
        arrayList = null;
      } else {
        arrayList = new ArrayList(Arrays.asList((Object[])param1ArrayOfRemoteInput));
      } 
      this.mRemoteInputs = arrayList;
      this.mAllowGeneratedReplies = param1Boolean;
    }
    
    public Builder(NotificationCompat.Action param1Action) {
      this(param1Action.icon, param1Action.title, param1Action.actionIntent, new Bundle(param1Action.a), param1Action.getRemoteInputs(), param1Action.getAllowGeneratedReplies());
    }
    
    public Builder addExtras(Bundle param1Bundle) {
      if (param1Bundle != null)
        this.mExtras.putAll(param1Bundle); 
      return this;
    }
    
    public Builder addRemoteInput(RemoteInput param1RemoteInput) {
      if (this.mRemoteInputs == null)
        this.mRemoteInputs = new ArrayList<RemoteInput>(); 
      this.mRemoteInputs.add(param1RemoteInput);
      return this;
    }
    
    public NotificationCompat.Action build() {
      RemoteInput[] arrayOfRemoteInput1;
      ArrayList<RemoteInput> arrayList1 = new ArrayList();
      ArrayList<RemoteInput> arrayList2 = new ArrayList();
      if (this.mRemoteInputs != null)
        for (RemoteInput remoteInput : this.mRemoteInputs) {
          if (remoteInput.isDataOnly()) {
            arrayList1.add(remoteInput);
            continue;
          } 
          arrayList2.add(remoteInput);
        }  
      if (arrayList1.isEmpty()) {
        arrayOfRemoteInput1 = null;
      } else {
        arrayOfRemoteInput1 = arrayList1.<RemoteInput>toArray(new RemoteInput[arrayList1.size()]);
      } 
      boolean bool = arrayList2.isEmpty();
      RemoteInput[] arrayOfRemoteInput2 = null;
      if (!bool)
        arrayOfRemoteInput2 = arrayList2.<RemoteInput>toArray(new RemoteInput[arrayList2.size()]); 
      RemoteInput[] arrayOfRemoteInput3 = arrayOfRemoteInput2;
      return new NotificationCompat.Action(this.mIcon, this.mTitle, this.mIntent, this.mExtras, arrayOfRemoteInput3, arrayOfRemoteInput1, this.mAllowGeneratedReplies);
    }
    
    public Builder extend(NotificationCompat.Action.Extender param1Extender) {
      param1Extender.extend(this);
      return this;
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public Builder setAllowGeneratedReplies(boolean param1Boolean) {
      this.mAllowGeneratedReplies = param1Boolean;
      return this;
    }
  }
  
  public static interface Extender {
    NotificationCompat.Action.Builder extend(NotificationCompat.Action.Builder param1Builder);
  }
  
  public static final class WearableExtender implements Action.Extender {
    private static final int DEFAULT_FLAGS = 1;
    
    private static final String EXTRA_WEARABLE_EXTENSIONS = "android.wearable.EXTENSIONS";
    
    private static final int FLAG_AVAILABLE_OFFLINE = 1;
    
    private static final int FLAG_HINT_DISPLAY_INLINE = 4;
    
    private static final int FLAG_HINT_LAUNCHES_ACTIVITY = 2;
    
    private static final String KEY_CANCEL_LABEL = "cancelLabel";
    
    private static final String KEY_CONFIRM_LABEL = "confirmLabel";
    
    private static final String KEY_FLAGS = "flags";
    
    private static final String KEY_IN_PROGRESS_LABEL = "inProgressLabel";
    
    private CharSequence mCancelLabel;
    
    private CharSequence mConfirmLabel;
    
    private int mFlags = 1;
    
    private CharSequence mInProgressLabel;
    
    public WearableExtender() {}
    
    public WearableExtender(NotificationCompat.Action param1Action) {
      Bundle bundle = param1Action.getExtras().getBundle("android.wearable.EXTENSIONS");
      if (bundle != null) {
        this.mFlags = bundle.getInt("flags", 1);
        this.mInProgressLabel = bundle.getCharSequence("inProgressLabel");
        this.mConfirmLabel = bundle.getCharSequence("confirmLabel");
        this.mCancelLabel = bundle.getCharSequence("cancelLabel");
      } 
    }
    
    private void setFlag(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        this.mFlags = param1Int | this.mFlags;
        return;
      } 
      this.mFlags &= param1Int ^ 0xFFFFFFFF;
    }
    
    public WearableExtender clone() {
      WearableExtender wearableExtender = new WearableExtender();
      wearableExtender.mFlags = this.mFlags;
      wearableExtender.mInProgressLabel = this.mInProgressLabel;
      wearableExtender.mConfirmLabel = this.mConfirmLabel;
      wearableExtender.mCancelLabel = this.mCancelLabel;
      return wearableExtender;
    }
    
    public NotificationCompat.Action.Builder extend(NotificationCompat.Action.Builder param1Builder) {
      Bundle bundle = new Bundle();
      if (this.mFlags != 1)
        bundle.putInt("flags", this.mFlags); 
      if (this.mInProgressLabel != null)
        bundle.putCharSequence("inProgressLabel", this.mInProgressLabel); 
      if (this.mConfirmLabel != null)
        bundle.putCharSequence("confirmLabel", this.mConfirmLabel); 
      if (this.mCancelLabel != null)
        bundle.putCharSequence("cancelLabel", this.mCancelLabel); 
      param1Builder.getExtras().putBundle("android.wearable.EXTENSIONS", bundle);
      return param1Builder;
    }
    
    public CharSequence getCancelLabel() {
      return this.mCancelLabel;
    }
    
    public CharSequence getConfirmLabel() {
      return this.mConfirmLabel;
    }
    
    public boolean getHintDisplayActionInline() {
      return ((0x4 & this.mFlags) != 0);
    }
    
    public boolean getHintLaunchesActivity() {
      return ((0x2 & this.mFlags) != 0);
    }
    
    public CharSequence getInProgressLabel() {
      return this.mInProgressLabel;
    }
    
    public boolean isAvailableOffline() {
      return ((0x1 & this.mFlags) != 0);
    }
    
    public WearableExtender setAvailableOffline(boolean param1Boolean) {
      setFlag(1, param1Boolean);
      return this;
    }
    
    public WearableExtender setCancelLabel(CharSequence param1CharSequence) {
      this.mCancelLabel = param1CharSequence;
      return this;
    }
    
    public WearableExtender setConfirmLabel(CharSequence param1CharSequence) {
      this.mConfirmLabel = param1CharSequence;
      return this;
    }
    
    public WearableExtender setHintDisplayActionInline(boolean param1Boolean) {
      setFlag(4, param1Boolean);
      return this;
    }
    
    public WearableExtender setHintLaunchesActivity(boolean param1Boolean) {
      setFlag(2, param1Boolean);
      return this;
    }
    
    public WearableExtender setInProgressLabel(CharSequence param1CharSequence) {
      this.mInProgressLabel = param1CharSequence;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface BadgeIconType {}
  
  public static class BigPictureStyle extends Style {
    private Bitmap mBigLargeIcon;
    
    private boolean mBigLargeIconSet;
    
    private Bitmap mPicture;
    
    public BigPictureStyle() {}
    
    public BigPictureStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 16) {
        Notification.BigPictureStyle bigPictureStyle = (new Notification.BigPictureStyle(param1NotificationBuilderWithBuilderAccessor.getBuilder())).setBigContentTitle(this.d).bigPicture(this.mPicture);
        if (this.mBigLargeIconSet)
          bigPictureStyle.bigLargeIcon(this.mBigLargeIcon); 
        if (this.f)
          bigPictureStyle.setSummaryText(this.e); 
      } 
    }
    
    public BigPictureStyle bigLargeIcon(Bitmap param1Bitmap) {
      this.mBigLargeIcon = param1Bitmap;
      this.mBigLargeIconSet = true;
      return this;
    }
    
    public BigPictureStyle bigPicture(Bitmap param1Bitmap) {
      this.mPicture = param1Bitmap;
      return this;
    }
    
    public BigPictureStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.d = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public BigPictureStyle setSummaryText(CharSequence param1CharSequence) {
      this.e = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      this.f = true;
      return this;
    }
  }
  
  public static class BigTextStyle extends Style {
    private CharSequence mBigText;
    
    public BigTextStyle() {}
    
    public BigTextStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 16) {
        Notification.BigTextStyle bigTextStyle = (new Notification.BigTextStyle(param1NotificationBuilderWithBuilderAccessor.getBuilder())).setBigContentTitle(this.d).bigText(this.mBigText);
        if (this.f)
          bigTextStyle.setSummaryText(this.e); 
      } 
    }
    
    public BigTextStyle bigText(CharSequence param1CharSequence) {
      this.mBigText = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public BigTextStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.d = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public BigTextStyle setSummaryText(CharSequence param1CharSequence) {
      this.e = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      this.f = true;
      return this;
    }
  }
  
  public static class Builder {
    private static final int MAX_CHARSEQUENCE_LENGTH = 5120;
    
    int A = 0;
    
    Notification B;
    
    RemoteViews C;
    
    RemoteViews D;
    
    RemoteViews E;
    
    String F;
    
    int G = 0;
    
    String H;
    
    long I;
    
    int J = 0;
    
    Notification K = new Notification();
    
    CharSequence a;
    
    CharSequence b;
    
    PendingIntent c;
    
    PendingIntent d;
    
    RemoteViews e;
    
    Bitmap f;
    
    CharSequence g;
    
    int h;
    
    int i;
    
    boolean j = true;
    
    boolean k;
    
    NotificationCompat.Style l;
    
    CharSequence m;
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public ArrayList<NotificationCompat.Action> mActions = new ArrayList<NotificationCompat.Action>();
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Context mContext;
    
    @Deprecated
    public ArrayList<String> mPeople;
    
    CharSequence[] n;
    
    int o;
    
    int p;
    
    boolean q;
    
    String r;
    
    boolean s;
    
    String t;
    
    boolean u = false;
    
    boolean v;
    
    boolean w;
    
    String x;
    
    Bundle y;
    
    int z = 0;
    
    @Deprecated
    public Builder(Context param1Context) {
      this(param1Context, null);
    }
    
    public Builder(@NonNull Context param1Context, @NonNull String param1String) {
      this.mContext = param1Context;
      this.F = param1String;
      this.K.when = System.currentTimeMillis();
      this.K.audioStreamType = -1;
      this.i = 0;
      this.mPeople = new ArrayList<String>();
    }
    
    protected static CharSequence limitCharSequenceLength(CharSequence param1CharSequence) {
      if (param1CharSequence == null)
        return param1CharSequence; 
      if (param1CharSequence.length() > 5120)
        param1CharSequence = param1CharSequence.subSequence(0, 5120); 
      return param1CharSequence;
    }
    
    private void setFlag(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        Notification notification1 = this.K;
        notification1.flags = param1Int | notification1.flags;
        return;
      } 
      Notification notification = this.K;
      notification.flags &= param1Int ^ 0xFFFFFFFF;
    }
    
    public Builder addAction(int param1Int, CharSequence param1CharSequence, PendingIntent param1PendingIntent) {
      this.mActions.add(new NotificationCompat.Action(param1Int, param1CharSequence, param1PendingIntent));
      return this;
    }
    
    public Builder addAction(NotificationCompat.Action param1Action) {
      this.mActions.add(param1Action);
      return this;
    }
    
    public Builder addExtras(Bundle param1Bundle) {
      if (param1Bundle != null) {
        if (this.y == null) {
          this.y = new Bundle(param1Bundle);
          return this;
        } 
        this.y.putAll(param1Bundle);
      } 
      return this;
    }
    
    public Builder addPerson(String param1String) {
      this.mPeople.add(param1String);
      return this;
    }
    
    public Notification build() {
      return (new NotificationCompatBuilder(this)).build();
    }
    
    public Builder extend(NotificationCompat.Extender param1Extender) {
      param1Extender.extend(this);
      return this;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews getBigContentView() {
      return this.D;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public int getColor() {
      return this.z;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews getContentView() {
      return this.C;
    }
    
    public Bundle getExtras() {
      if (this.y == null)
        this.y = new Bundle(); 
      return this.y;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews getHeadsUpContentView() {
      return this.E;
    }
    
    @Deprecated
    public Notification getNotification() {
      return build();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public int getPriority() {
      return this.i;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public long getWhenIfShowing() {
      return this.j ? this.K.when : 0L;
    }
    
    public Builder setAutoCancel(boolean param1Boolean) {
      setFlag(16, param1Boolean);
      return this;
    }
    
    public Builder setBadgeIconType(int param1Int) {
      this.G = param1Int;
      return this;
    }
    
    public Builder setCategory(String param1String) {
      this.x = param1String;
      return this;
    }
    
    public Builder setChannelId(@NonNull String param1String) {
      this.F = param1String;
      return this;
    }
    
    public Builder setColor(@ColorInt int param1Int) {
      this.z = param1Int;
      return this;
    }
    
    public Builder setColorized(boolean param1Boolean) {
      this.v = param1Boolean;
      this.w = true;
      return this;
    }
    
    public Builder setContent(RemoteViews param1RemoteViews) {
      this.K.contentView = param1RemoteViews;
      return this;
    }
    
    public Builder setContentInfo(CharSequence param1CharSequence) {
      this.g = limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public Builder setContentIntent(PendingIntent param1PendingIntent) {
      this.c = param1PendingIntent;
      return this;
    }
    
    public Builder setContentText(CharSequence param1CharSequence) {
      this.b = limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public Builder setContentTitle(CharSequence param1CharSequence) {
      this.a = limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public Builder setCustomBigContentView(RemoteViews param1RemoteViews) {
      this.D = param1RemoteViews;
      return this;
    }
    
    public Builder setCustomContentView(RemoteViews param1RemoteViews) {
      this.C = param1RemoteViews;
      return this;
    }
    
    public Builder setCustomHeadsUpContentView(RemoteViews param1RemoteViews) {
      this.E = param1RemoteViews;
      return this;
    }
    
    public Builder setDefaults(int param1Int) {
      this.K.defaults = param1Int;
      if ((param1Int & 0x4) != 0) {
        Notification notification = this.K;
        notification.flags = 0x1 | notification.flags;
      } 
      return this;
    }
    
    public Builder setDeleteIntent(PendingIntent param1PendingIntent) {
      this.K.deleteIntent = param1PendingIntent;
      return this;
    }
    
    public Builder setExtras(Bundle param1Bundle) {
      this.y = param1Bundle;
      return this;
    }
    
    public Builder setFullScreenIntent(PendingIntent param1PendingIntent, boolean param1Boolean) {
      this.d = param1PendingIntent;
      setFlag(128, param1Boolean);
      return this;
    }
    
    public Builder setGroup(String param1String) {
      this.r = param1String;
      return this;
    }
    
    public Builder setGroupAlertBehavior(int param1Int) {
      this.J = param1Int;
      return this;
    }
    
    public Builder setGroupSummary(boolean param1Boolean) {
      this.s = param1Boolean;
      return this;
    }
    
    public Builder setLargeIcon(Bitmap param1Bitmap) {
      this.f = param1Bitmap;
      return this;
    }
    
    public Builder setLights(@ColorInt int param1Int1, int param1Int2, int param1Int3) {
      boolean bool;
      this.K.ledARGB = param1Int1;
      this.K.ledOnMS = param1Int2;
      this.K.ledOffMS = param1Int3;
      if (this.K.ledOnMS != 0 && this.K.ledOffMS != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.K.flags = bool | 0xFFFFFFFE & this.K.flags;
      return this;
    }
    
    public Builder setLocalOnly(boolean param1Boolean) {
      this.u = param1Boolean;
      return this;
    }
    
    public Builder setNumber(int param1Int) {
      this.h = param1Int;
      return this;
    }
    
    public Builder setOngoing(boolean param1Boolean) {
      setFlag(2, param1Boolean);
      return this;
    }
    
    public Builder setOnlyAlertOnce(boolean param1Boolean) {
      setFlag(8, param1Boolean);
      return this;
    }
    
    public Builder setPriority(int param1Int) {
      this.i = param1Int;
      return this;
    }
    
    public Builder setProgress(int param1Int1, int param1Int2, boolean param1Boolean) {
      this.o = param1Int1;
      this.p = param1Int2;
      this.q = param1Boolean;
      return this;
    }
    
    public Builder setPublicVersion(Notification param1Notification) {
      this.B = param1Notification;
      return this;
    }
    
    public Builder setRemoteInputHistory(CharSequence[] param1ArrayOfCharSequence) {
      this.n = param1ArrayOfCharSequence;
      return this;
    }
    
    public Builder setShortcutId(String param1String) {
      this.H = param1String;
      return this;
    }
    
    public Builder setShowWhen(boolean param1Boolean) {
      this.j = param1Boolean;
      return this;
    }
    
    public Builder setSmallIcon(int param1Int) {
      this.K.icon = param1Int;
      return this;
    }
    
    public Builder setSmallIcon(int param1Int1, int param1Int2) {
      this.K.icon = param1Int1;
      this.K.iconLevel = param1Int2;
      return this;
    }
    
    public Builder setSortKey(String param1String) {
      this.t = param1String;
      return this;
    }
    
    public Builder setSound(Uri param1Uri) {
      this.K.sound = param1Uri;
      this.K.audioStreamType = -1;
      if (Build.VERSION.SDK_INT >= 21)
        this.K.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setUsage(5).build(); 
      return this;
    }
    
    public Builder setSound(Uri param1Uri, int param1Int) {
      this.K.sound = param1Uri;
      this.K.audioStreamType = param1Int;
      if (Build.VERSION.SDK_INT >= 21)
        this.K.audioAttributes = (new AudioAttributes.Builder()).setContentType(4).setLegacyStreamType(param1Int).build(); 
      return this;
    }
    
    public Builder setStyle(NotificationCompat.Style param1Style) {
      if (this.l != param1Style) {
        this.l = param1Style;
        if (this.l != null)
          this.l.setBuilder(this); 
      } 
      return this;
    }
    
    public Builder setSubText(CharSequence param1CharSequence) {
      this.m = limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public Builder setTicker(CharSequence param1CharSequence) {
      this.K.tickerText = limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public Builder setTicker(CharSequence param1CharSequence, RemoteViews param1RemoteViews) {
      this.K.tickerText = limitCharSequenceLength(param1CharSequence);
      this.e = param1RemoteViews;
      return this;
    }
    
    public Builder setTimeoutAfter(long param1Long) {
      this.I = param1Long;
      return this;
    }
    
    public Builder setUsesChronometer(boolean param1Boolean) {
      this.k = param1Boolean;
      return this;
    }
    
    public Builder setVibrate(long[] param1ArrayOflong) {
      this.K.vibrate = param1ArrayOflong;
      return this;
    }
    
    public Builder setVisibility(int param1Int) {
      this.A = param1Int;
      return this;
    }
    
    public Builder setWhen(long param1Long) {
      this.K.when = param1Long;
      return this;
    }
  }
  
  public static final class CarExtender implements Extender {
    private static final String EXTRA_CAR_EXTENDER = "android.car.EXTENSIONS";
    
    private static final String EXTRA_COLOR = "app_color";
    
    private static final String EXTRA_CONVERSATION = "car_conversation";
    
    private static final String EXTRA_LARGE_ICON = "large_icon";
    
    private static final String KEY_AUTHOR = "author";
    
    private static final String KEY_MESSAGES = "messages";
    
    private static final String KEY_ON_READ = "on_read";
    
    private static final String KEY_ON_REPLY = "on_reply";
    
    private static final String KEY_PARTICIPANTS = "participants";
    
    private static final String KEY_REMOTE_INPUT = "remote_input";
    
    private static final String KEY_TEXT = "text";
    
    private static final String KEY_TIMESTAMP = "timestamp";
    
    private int mColor;
    
    private Bitmap mLargeIcon;
    
    private UnreadConversation mUnreadConversation;
    
    public CarExtender() {
      this.mColor = 0;
    }
    
    public CarExtender(Notification param1Notification) {
      Bundle bundle;
      this.mColor = 0;
      if (Build.VERSION.SDK_INT < 21)
        return; 
      if (NotificationCompat.getExtras(param1Notification) == null) {
        bundle = null;
      } else {
        bundle = NotificationCompat.getExtras(param1Notification).getBundle("android.car.EXTENSIONS");
      } 
      if (bundle != null) {
        this.mLargeIcon = (Bitmap)bundle.getParcelable("large_icon");
        this.mColor = bundle.getInt("app_color", 0);
        this.mUnreadConversation = getUnreadConversationFromBundle(bundle.getBundle("car_conversation"));
      } 
    }
    
    @RequiresApi(21)
    private static Bundle getBundleForUnreadConversation(@NonNull UnreadConversation param1UnreadConversation) {
      String str;
      Bundle bundle = new Bundle();
      String[] arrayOfString = param1UnreadConversation.getParticipants();
      byte b = 0;
      if (arrayOfString != null && (param1UnreadConversation.getParticipants()).length > 1) {
        str = param1UnreadConversation.getParticipants()[0];
      } else {
        str = null;
      } 
      Parcelable[] arrayOfParcelable = new Parcelable[(param1UnreadConversation.getMessages()).length];
      while (b < arrayOfParcelable.length) {
        Bundle bundle1 = new Bundle();
        bundle1.putString("text", param1UnreadConversation.getMessages()[b]);
        bundle1.putString("author", str);
        arrayOfParcelable[b] = (Parcelable)bundle1;
        b++;
      } 
      bundle.putParcelableArray("messages", arrayOfParcelable);
      RemoteInput remoteInput = param1UnreadConversation.getRemoteInput();
      if (remoteInput != null)
        bundle.putParcelable("remote_input", (Parcelable)(new RemoteInput.Builder(remoteInput.getResultKey())).setLabel(remoteInput.getLabel()).setChoices(remoteInput.getChoices()).setAllowFreeFormInput(remoteInput.getAllowFreeFormInput()).addExtras(remoteInput.getExtras()).build()); 
      bundle.putParcelable("on_reply", (Parcelable)param1UnreadConversation.getReplyPendingIntent());
      bundle.putParcelable("on_read", (Parcelable)param1UnreadConversation.getReadPendingIntent());
      bundle.putStringArray("participants", param1UnreadConversation.getParticipants());
      bundle.putLong("timestamp", param1UnreadConversation.getLatestTimestamp());
      return bundle;
    }
    
    @RequiresApi(21)
    private static UnreadConversation getUnreadConversationFromBundle(@Nullable Bundle param1Bundle) {
      String[] arrayOfString1;
      if (param1Bundle == null)
        return null; 
      Parcelable[] arrayOfParcelable = param1Bundle.getParcelableArray("messages");
      if (arrayOfParcelable != null) {
        boolean bool;
        String[] arrayOfString = new String[arrayOfParcelable.length];
        byte b = 0;
        while (true) {
          if (b < arrayOfString.length) {
            if (!(arrayOfParcelable[b] instanceof Bundle)) {
              boolean bool1 = false;
              break;
            } 
            arrayOfString[b] = ((Bundle)arrayOfParcelable[b]).getString("text");
            if (arrayOfString[b] == null) {
              boolean bool1 = false;
              break;
            } 
            b++;
            continue;
          } 
          bool = true;
          break;
        } 
        if (bool) {
          arrayOfString1 = arrayOfString;
        } else {
          return null;
        } 
      } else {
        arrayOfString1 = null;
      } 
      PendingIntent pendingIntent1 = (PendingIntent)param1Bundle.getParcelable("on_read");
      PendingIntent pendingIntent2 = (PendingIntent)param1Bundle.getParcelable("on_reply");
      RemoteInput remoteInput = (RemoteInput)param1Bundle.getParcelable("remote_input");
      String[] arrayOfString2 = param1Bundle.getStringArray("participants");
      if (arrayOfString2 != null) {
        if (arrayOfString2.length != 1)
          return null; 
        RemoteInput remoteInput1 = null;
        if (remoteInput != null) {
          String str = remoteInput.getResultKey();
          CharSequence charSequence = remoteInput.getLabel();
          CharSequence[] arrayOfCharSequence = remoteInput.getChoices();
          boolean bool = remoteInput.getAllowFreeFormInput();
          Bundle bundle = remoteInput.getExtras();
          remoteInput1 = new RemoteInput(str, charSequence, arrayOfCharSequence, bool, bundle, null);
        } 
        RemoteInput remoteInput2 = remoteInput1;
        return new UnreadConversation(arrayOfString1, remoteInput2, pendingIntent2, pendingIntent1, arrayOfString2, param1Bundle.getLong("timestamp"));
      } 
      return null;
    }
    
    public NotificationCompat.Builder extend(NotificationCompat.Builder param1Builder) {
      if (Build.VERSION.SDK_INT < 21)
        return param1Builder; 
      Bundle bundle = new Bundle();
      if (this.mLargeIcon != null)
        bundle.putParcelable("large_icon", (Parcelable)this.mLargeIcon); 
      if (this.mColor != 0)
        bundle.putInt("app_color", this.mColor); 
      if (this.mUnreadConversation != null)
        bundle.putBundle("car_conversation", getBundleForUnreadConversation(this.mUnreadConversation)); 
      param1Builder.getExtras().putBundle("android.car.EXTENSIONS", bundle);
      return param1Builder;
    }
    
    @ColorInt
    public int getColor() {
      return this.mColor;
    }
    
    public Bitmap getLargeIcon() {
      return this.mLargeIcon;
    }
    
    public UnreadConversation getUnreadConversation() {
      return this.mUnreadConversation;
    }
    
    public CarExtender setColor(@ColorInt int param1Int) {
      this.mColor = param1Int;
      return this;
    }
    
    public CarExtender setLargeIcon(Bitmap param1Bitmap) {
      this.mLargeIcon = param1Bitmap;
      return this;
    }
    
    public CarExtender setUnreadConversation(UnreadConversation param1UnreadConversation) {
      this.mUnreadConversation = param1UnreadConversation;
      return this;
    }
    
    public static class UnreadConversation {
      private final long mLatestTimestamp;
      
      private final String[] mMessages;
      
      private final String[] mParticipants;
      
      private final PendingIntent mReadPendingIntent;
      
      private final RemoteInput mRemoteInput;
      
      private final PendingIntent mReplyPendingIntent;
      
      UnreadConversation(String[] param2ArrayOfString1, RemoteInput param2RemoteInput, PendingIntent param2PendingIntent1, PendingIntent param2PendingIntent2, String[] param2ArrayOfString2, long param2Long) {
        this.mMessages = param2ArrayOfString1;
        this.mRemoteInput = param2RemoteInput;
        this.mReadPendingIntent = param2PendingIntent2;
        this.mReplyPendingIntent = param2PendingIntent1;
        this.mParticipants = param2ArrayOfString2;
        this.mLatestTimestamp = param2Long;
      }
      
      public long getLatestTimestamp() {
        return this.mLatestTimestamp;
      }
      
      public String[] getMessages() {
        return this.mMessages;
      }
      
      public String getParticipant() {
        return (this.mParticipants.length > 0) ? this.mParticipants[0] : null;
      }
      
      public String[] getParticipants() {
        return this.mParticipants;
      }
      
      public PendingIntent getReadPendingIntent() {
        return this.mReadPendingIntent;
      }
      
      public RemoteInput getRemoteInput() {
        return this.mRemoteInput;
      }
      
      public PendingIntent getReplyPendingIntent() {
        return this.mReplyPendingIntent;
      }
      
      public static class Builder {
        private long mLatestTimestamp;
        
        private final List<String> mMessages = new ArrayList<String>();
        
        private final String mParticipant;
        
        private PendingIntent mReadPendingIntent;
        
        private RemoteInput mRemoteInput;
        
        private PendingIntent mReplyPendingIntent;
        
        public Builder(String param3String) {
          this.mParticipant = param3String;
        }
        
        public Builder addMessage(String param3String) {
          this.mMessages.add(param3String);
          return this;
        }
        
        public NotificationCompat.CarExtender.UnreadConversation build() {
          String[] arrayOfString1 = this.mMessages.<String>toArray(new String[this.mMessages.size()]);
          String[] arrayOfString2 = new String[1];
          arrayOfString2[0] = this.mParticipant;
          return new NotificationCompat.CarExtender.UnreadConversation(arrayOfString1, this.mRemoteInput, this.mReplyPendingIntent, this.mReadPendingIntent, arrayOfString2, this.mLatestTimestamp);
        }
        
        public Builder setLatestTimestamp(long param3Long) {
          this.mLatestTimestamp = param3Long;
          return this;
        }
        
        public Builder setReadPendingIntent(PendingIntent param3PendingIntent) {
          this.mReadPendingIntent = param3PendingIntent;
          return this;
        }
        
        public Builder setReplyAction(PendingIntent param3PendingIntent, RemoteInput param3RemoteInput) {
          this.mRemoteInput = param3RemoteInput;
          this.mReplyPendingIntent = param3PendingIntent;
          return this;
        }
      }
    }
    
    public static class Builder {
      private long mLatestTimestamp;
      
      private final List<String> mMessages = new ArrayList<String>();
      
      private final String mParticipant;
      
      private PendingIntent mReadPendingIntent;
      
      private RemoteInput mRemoteInput;
      
      private PendingIntent mReplyPendingIntent;
      
      public Builder(String param2String) {
        this.mParticipant = param2String;
      }
      
      public Builder addMessage(String param2String) {
        this.mMessages.add(param2String);
        return this;
      }
      
      public NotificationCompat.CarExtender.UnreadConversation build() {
        String[] arrayOfString1 = this.mMessages.<String>toArray(new String[this.mMessages.size()]);
        String[] arrayOfString2 = new String[1];
        arrayOfString2[0] = this.mParticipant;
        return new NotificationCompat.CarExtender.UnreadConversation(arrayOfString1, this.mRemoteInput, this.mReplyPendingIntent, this.mReadPendingIntent, arrayOfString2, this.mLatestTimestamp);
      }
      
      public Builder setLatestTimestamp(long param2Long) {
        this.mLatestTimestamp = param2Long;
        return this;
      }
      
      public Builder setReadPendingIntent(PendingIntent param2PendingIntent) {
        this.mReadPendingIntent = param2PendingIntent;
        return this;
      }
      
      public Builder setReplyAction(PendingIntent param2PendingIntent, RemoteInput param2RemoteInput) {
        this.mRemoteInput = param2RemoteInput;
        this.mReplyPendingIntent = param2PendingIntent;
        return this;
      }
    }
  }
  
  public static class UnreadConversation {
    private final long mLatestTimestamp;
    
    private final String[] mMessages;
    
    private final String[] mParticipants;
    
    private final PendingIntent mReadPendingIntent;
    
    private final RemoteInput mRemoteInput;
    
    private final PendingIntent mReplyPendingIntent;
    
    UnreadConversation(String[] param1ArrayOfString1, RemoteInput param1RemoteInput, PendingIntent param1PendingIntent1, PendingIntent param1PendingIntent2, String[] param1ArrayOfString2, long param1Long) {
      this.mMessages = param1ArrayOfString1;
      this.mRemoteInput = param1RemoteInput;
      this.mReadPendingIntent = param1PendingIntent2;
      this.mReplyPendingIntent = param1PendingIntent1;
      this.mParticipants = param1ArrayOfString2;
      this.mLatestTimestamp = param1Long;
    }
    
    public long getLatestTimestamp() {
      return this.mLatestTimestamp;
    }
    
    public String[] getMessages() {
      return this.mMessages;
    }
    
    public String getParticipant() {
      return (this.mParticipants.length > 0) ? this.mParticipants[0] : null;
    }
    
    public String[] getParticipants() {
      return this.mParticipants;
    }
    
    public PendingIntent getReadPendingIntent() {
      return this.mReadPendingIntent;
    }
    
    public RemoteInput getRemoteInput() {
      return this.mRemoteInput;
    }
    
    public PendingIntent getReplyPendingIntent() {
      return this.mReplyPendingIntent;
    }
    
    public static class Builder {
      private long mLatestTimestamp;
      
      private final List<String> mMessages = new ArrayList<String>();
      
      private final String mParticipant;
      
      private PendingIntent mReadPendingIntent;
      
      private RemoteInput mRemoteInput;
      
      private PendingIntent mReplyPendingIntent;
      
      public Builder(String param3String) {
        this.mParticipant = param3String;
      }
      
      public Builder addMessage(String param3String) {
        this.mMessages.add(param3String);
        return this;
      }
      
      public NotificationCompat.CarExtender.UnreadConversation build() {
        String[] arrayOfString1 = this.mMessages.<String>toArray(new String[this.mMessages.size()]);
        String[] arrayOfString2 = new String[1];
        arrayOfString2[0] = this.mParticipant;
        return new NotificationCompat.CarExtender.UnreadConversation(arrayOfString1, this.mRemoteInput, this.mReplyPendingIntent, this.mReadPendingIntent, arrayOfString2, this.mLatestTimestamp);
      }
      
      public Builder setLatestTimestamp(long param3Long) {
        this.mLatestTimestamp = param3Long;
        return this;
      }
      
      public Builder setReadPendingIntent(PendingIntent param3PendingIntent) {
        this.mReadPendingIntent = param3PendingIntent;
        return this;
      }
      
      public Builder setReplyAction(PendingIntent param3PendingIntent, RemoteInput param3RemoteInput) {
        this.mRemoteInput = param3RemoteInput;
        this.mReplyPendingIntent = param3PendingIntent;
        return this;
      }
    }
  }
  
  public static class Builder {
    private long mLatestTimestamp;
    
    private final List<String> mMessages = new ArrayList<String>();
    
    private final String mParticipant;
    
    private PendingIntent mReadPendingIntent;
    
    private RemoteInput mRemoteInput;
    
    private PendingIntent mReplyPendingIntent;
    
    public Builder(String param1String) {
      this.mParticipant = param1String;
    }
    
    public Builder addMessage(String param1String) {
      this.mMessages.add(param1String);
      return this;
    }
    
    public NotificationCompat.CarExtender.UnreadConversation build() {
      String[] arrayOfString1 = this.mMessages.<String>toArray(new String[this.mMessages.size()]);
      String[] arrayOfString2 = new String[1];
      arrayOfString2[0] = this.mParticipant;
      return new NotificationCompat.CarExtender.UnreadConversation(arrayOfString1, this.mRemoteInput, this.mReplyPendingIntent, this.mReadPendingIntent, arrayOfString2, this.mLatestTimestamp);
    }
    
    public Builder setLatestTimestamp(long param1Long) {
      this.mLatestTimestamp = param1Long;
      return this;
    }
    
    public Builder setReadPendingIntent(PendingIntent param1PendingIntent) {
      this.mReadPendingIntent = param1PendingIntent;
      return this;
    }
    
    public Builder setReplyAction(PendingIntent param1PendingIntent, RemoteInput param1RemoteInput) {
      this.mRemoteInput = param1RemoteInput;
      this.mReplyPendingIntent = param1PendingIntent;
      return this;
    }
  }
  
  public static class DecoratedCustomViewStyle extends Style {
    private static final int MAX_ACTION_BUTTONS = 3;
    
    private RemoteViews createRemoteViews(RemoteViews param1RemoteViews, boolean param1Boolean) {
      // Byte code:
      //   0: getstatic android/support/compat/R$layout.notification_template_custom_big : I
      //   3: istore_3
      //   4: iconst_1
      //   5: istore #4
      //   7: aload_0
      //   8: iload #4
      //   10: iload_3
      //   11: iconst_0
      //   12: invokevirtual applyStandardTemplate : (ZIZ)Landroid/widget/RemoteViews;
      //   15: astore #5
      //   17: aload #5
      //   19: getstatic android/support/compat/R$id.actions : I
      //   22: invokevirtual removeAllViews : (I)V
      //   25: iload_2
      //   26: ifeq -> 107
      //   29: aload_0
      //   30: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   33: getfield mActions : Ljava/util/ArrayList;
      //   36: ifnull -> 107
      //   39: aload_0
      //   40: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   43: getfield mActions : Ljava/util/ArrayList;
      //   46: invokevirtual size : ()I
      //   49: iconst_3
      //   50: invokestatic min : (II)I
      //   53: istore #7
      //   55: iload #7
      //   57: ifle -> 107
      //   60: iconst_0
      //   61: istore #8
      //   63: iload #8
      //   65: iload #7
      //   67: if_icmpge -> 110
      //   70: aload_0
      //   71: aload_0
      //   72: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   75: getfield mActions : Ljava/util/ArrayList;
      //   78: iload #8
      //   80: invokevirtual get : (I)Ljava/lang/Object;
      //   83: checkcast android/support/v4/app/NotificationCompat$Action
      //   86: invokespecial generateActionButton : (Landroid/support/v4/app/NotificationCompat$Action;)Landroid/widget/RemoteViews;
      //   89: astore #9
      //   91: aload #5
      //   93: getstatic android/support/compat/R$id.actions : I
      //   96: aload #9
      //   98: invokevirtual addView : (ILandroid/widget/RemoteViews;)V
      //   101: iinc #8, 1
      //   104: goto -> 63
      //   107: iconst_0
      //   108: istore #4
      //   110: iload #4
      //   112: ifeq -> 121
      //   115: iconst_0
      //   116: istore #6
      //   118: goto -> 125
      //   121: bipush #8
      //   123: istore #6
      //   125: aload #5
      //   127: getstatic android/support/compat/R$id.actions : I
      //   130: iload #6
      //   132: invokevirtual setViewVisibility : (II)V
      //   135: aload #5
      //   137: getstatic android/support/compat/R$id.action_divider : I
      //   140: iload #6
      //   142: invokevirtual setViewVisibility : (II)V
      //   145: aload_0
      //   146: aload #5
      //   148: aload_1
      //   149: invokevirtual buildIntoRemoteViews : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   152: aload #5
      //   154: areturn
    }
    
    private RemoteViews generateActionButton(NotificationCompat.Action param1Action) {
      boolean bool;
      int i;
      if (param1Action.actionIntent == null) {
        bool = true;
      } else {
        bool = false;
      } 
      String str = this.mBuilder.mContext.getPackageName();
      if (bool) {
        i = R.layout.notification_action_tombstone;
      } else {
        i = R.layout.notification_action;
      } 
      RemoteViews remoteViews = new RemoteViews(str, i);
      remoteViews.setImageViewBitmap(R.id.action_image, createColoredBitmap(param1Action.getIcon(), this.mBuilder.mContext.getResources().getColor(R.color.notification_action_color_filter)));
      remoteViews.setTextViewText(R.id.action_text, param1Action.title);
      if (!bool)
        remoteViews.setOnClickPendingIntent(R.id.action_container, param1Action.actionIntent); 
      if (Build.VERSION.SDK_INT >= 15)
        remoteViews.setContentDescription(R.id.action_container, param1Action.title); 
      return remoteViews;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 24)
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setStyle((Notification.Style)new Notification.DecoratedCustomViewStyle()); 
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews = this.mBuilder.getBigContentView();
      if (remoteViews == null)
        remoteViews = this.mBuilder.getContentView(); 
      return (remoteViews == null) ? null : createRemoteViews(remoteViews, true);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return (Build.VERSION.SDK_INT >= 24) ? null : ((this.mBuilder.getContentView() == null) ? null : createRemoteViews(this.mBuilder.getContentView(), false));
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeHeadsUpContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      RemoteViews remoteViews2;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      RemoteViews remoteViews1 = this.mBuilder.getHeadsUpContentView();
      if (remoteViews1 != null) {
        remoteViews2 = remoteViews1;
      } else {
        remoteViews2 = this.mBuilder.getContentView();
      } 
      return (remoteViews1 == null) ? null : createRemoteViews(remoteViews2, true);
    }
  }
  
  public static interface Extender {
    NotificationCompat.Builder extend(NotificationCompat.Builder param1Builder);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface GroupAlertBehavior {}
  
  public static class InboxStyle extends Style {
    private ArrayList<CharSequence> mTexts = new ArrayList<CharSequence>();
    
    public InboxStyle() {}
    
    public InboxStyle(NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    public InboxStyle addLine(CharSequence param1CharSequence) {
      this.mTexts.add(NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence));
      return this;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 16) {
        Notification.InboxStyle inboxStyle = (new Notification.InboxStyle(param1NotificationBuilderWithBuilderAccessor.getBuilder())).setBigContentTitle(this.d);
        if (this.f)
          inboxStyle.setSummaryText(this.e); 
        Iterator<CharSequence> iterator = this.mTexts.iterator();
        while (iterator.hasNext())
          inboxStyle.addLine(iterator.next()); 
      } 
    }
    
    public InboxStyle setBigContentTitle(CharSequence param1CharSequence) {
      this.d = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      return this;
    }
    
    public InboxStyle setSummaryText(CharSequence param1CharSequence) {
      this.e = NotificationCompat.Builder.limitCharSequenceLength(param1CharSequence);
      this.f = true;
      return this;
    }
  }
  
  public static class MessagingStyle extends Style {
    public static final int MAXIMUM_RETAINED_MESSAGES = 25;
    
    CharSequence a;
    
    CharSequence b;
    
    List<Message> c = new ArrayList<Message>();
    
    MessagingStyle() {}
    
    public MessagingStyle(@NonNull CharSequence param1CharSequence) {
      this.a = param1CharSequence;
    }
    
    public static MessagingStyle extractMessagingStyleFromNotification(Notification param1Notification) {
      Bundle bundle = NotificationCompat.getExtras(param1Notification);
      MessagingStyle messagingStyle = null;
      if (bundle != null && !bundle.containsKey("android.selfDisplayName"))
        return null; 
      try {
        MessagingStyle messagingStyle1 = new MessagingStyle();
        messagingStyle1.restoreFromCompatExtras(bundle);
        messagingStyle = messagingStyle1;
      } catch (ClassCastException classCastException) {}
      return messagingStyle;
    }
    
    @Nullable
    private Message findLatestIncomingMessage() {
      for (int i = -1 + this.c.size(); i >= 0; i--) {
        Message message = this.c.get(i);
        if (!TextUtils.isEmpty(message.getSender()))
          return message; 
      } 
      return !this.c.isEmpty() ? this.c.get(-1 + this.c.size()) : null;
    }
    
    private boolean hasMessagesWithoutSender() {
      for (int i = this.c.size() - 1; i >= 0; i--) {
        if (((Message)this.c.get(i)).getSender() == null)
          return true; 
      } 
      return false;
    }
    
    @NonNull
    private TextAppearanceSpan makeFontColorSpan(int param1Int) {
      return new TextAppearanceSpan(null, 0, 0, ColorStateList.valueOf(param1Int), null);
    }
    
    private CharSequence makeMessageLine(Message param1Message) {
      boolean bool;
      int i;
      CharSequence charSequence3;
      BidiFormatter bidiFormatter = BidiFormatter.getInstance();
      SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
      if (Build.VERSION.SDK_INT >= 21) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        i = -16777216;
      } else {
        i = -1;
      } 
      CharSequence charSequence1 = param1Message.getSender();
      if (TextUtils.isEmpty(param1Message.getSender())) {
        if (this.a == null) {
          charSequence1 = "";
        } else {
          charSequence1 = this.a;
        } 
        if (bool && this.mBuilder.getColor() != 0)
          i = this.mBuilder.getColor(); 
      } 
      CharSequence charSequence2 = bidiFormatter.unicodeWrap(charSequence1);
      spannableStringBuilder.append(charSequence2);
      spannableStringBuilder.setSpan(makeFontColorSpan(i), spannableStringBuilder.length() - charSequence2.length(), spannableStringBuilder.length(), 33);
      if (param1Message.getText() == null) {
        charSequence3 = "";
      } else {
        charSequence3 = param1Message.getText();
      } 
      spannableStringBuilder.append("  ").append(bidiFormatter.unicodeWrap(charSequence3));
      return (CharSequence)spannableStringBuilder;
    }
    
    public void addCompatExtras(Bundle param1Bundle) {
      super.addCompatExtras(param1Bundle);
      if (this.a != null)
        param1Bundle.putCharSequence("android.selfDisplayName", this.a); 
      if (this.b != null)
        param1Bundle.putCharSequence("android.conversationTitle", this.b); 
      if (!this.c.isEmpty())
        param1Bundle.putParcelableArray("android.messages", (Parcelable[])Message.a(this.c)); 
    }
    
    public MessagingStyle addMessage(Message param1Message) {
      this.c.add(param1Message);
      if (this.c.size() > 25)
        this.c.remove(0); 
      return this;
    }
    
    public MessagingStyle addMessage(CharSequence param1CharSequence1, long param1Long, CharSequence param1CharSequence2) {
      this.c.add(new Message(param1CharSequence1, param1Long, param1CharSequence2));
      if (this.c.size() > 25)
        this.c.remove(0); 
      return this;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 24) {
        Notification.MessagingStyle messagingStyle = (new Notification.MessagingStyle(this.a)).setConversationTitle(this.b);
        for (Message message1 : this.c) {
          Notification.MessagingStyle.Message message2 = new Notification.MessagingStyle.Message(message1.getText(), message1.getTimestamp(), message1.getSender());
          if (message1.getDataMimeType() != null)
            message2.setData(message1.getDataMimeType(), message1.getDataUri()); 
          messagingStyle.addMessage(message2);
        } 
        messagingStyle.setBuilder(param1NotificationBuilderWithBuilderAccessor.getBuilder());
        return;
      } 
      Message message = findLatestIncomingMessage();
      if (this.b != null) {
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setContentTitle(this.b);
      } else if (message != null) {
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setContentTitle(message.getSender());
      } 
      if (message != null) {
        CharSequence charSequence;
        Notification.Builder builder = param1NotificationBuilderWithBuilderAccessor.getBuilder();
        if (this.b != null) {
          charSequence = makeMessageLine(message);
        } else {
          charSequence = message.getText();
        } 
        builder.setContentText(charSequence);
      } 
      if (Build.VERSION.SDK_INT >= 16) {
        boolean bool;
        SpannableStringBuilder spannableStringBuilder = new SpannableStringBuilder();
        if (this.b != null || hasMessagesWithoutSender()) {
          bool = true;
        } else {
          bool = false;
        } 
        for (int i = this.c.size() - 1; i >= 0; i--) {
          CharSequence charSequence;
          Message message1 = this.c.get(i);
          if (bool) {
            charSequence = makeMessageLine(message1);
          } else {
            charSequence = message1.getText();
          } 
          if (i != this.c.size() - 1)
            spannableStringBuilder.insert(0, "\n"); 
          spannableStringBuilder.insert(0, charSequence);
        } 
        (new Notification.BigTextStyle(param1NotificationBuilderWithBuilderAccessor.getBuilder())).setBigContentTitle(null).bigText((CharSequence)spannableStringBuilder);
      } 
    }
    
    public CharSequence getConversationTitle() {
      return this.b;
    }
    
    public List<Message> getMessages() {
      return this.c;
    }
    
    public CharSequence getUserDisplayName() {
      return this.a;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    protected void restoreFromCompatExtras(Bundle param1Bundle) {
      this.c.clear();
      this.a = param1Bundle.getString("android.selfDisplayName");
      this.b = param1Bundle.getString("android.conversationTitle");
      Parcelable[] arrayOfParcelable = param1Bundle.getParcelableArray("android.messages");
      if (arrayOfParcelable != null)
        this.c = Message.a(arrayOfParcelable); 
    }
    
    public MessagingStyle setConversationTitle(CharSequence param1CharSequence) {
      this.b = param1CharSequence;
      return this;
    }
    
    public static final class Message {
      private String mDataMimeType;
      
      private Uri mDataUri;
      
      private Bundle mExtras = new Bundle();
      
      private final CharSequence mSender;
      
      private final CharSequence mText;
      
      private final long mTimestamp;
      
      public Message(CharSequence param2CharSequence1, long param2Long, CharSequence param2CharSequence2) {
        this.mText = param2CharSequence1;
        this.mTimestamp = param2Long;
        this.mSender = param2CharSequence2;
      }
      
      static Message a(Bundle param2Bundle) {
        try {
          if (param2Bundle.containsKey("text")) {
            if (!param2Bundle.containsKey("time"))
              return null; 
            Message message = new Message(param2Bundle.getCharSequence("text"), param2Bundle.getLong("time"), param2Bundle.getCharSequence("sender"));
            if (param2Bundle.containsKey("type") && param2Bundle.containsKey("uri"))
              message.setData(param2Bundle.getString("type"), (Uri)param2Bundle.getParcelable("uri")); 
            if (param2Bundle.containsKey("extras"))
              message.getExtras().putAll(param2Bundle.getBundle("extras")); 
            return message;
          } 
          return null;
        } catch (ClassCastException classCastException) {
          return null;
        } 
      }
      
      static List<Message> a(Parcelable[] param2ArrayOfParcelable) {
        ArrayList<Message> arrayList = new ArrayList(param2ArrayOfParcelable.length);
        for (byte b = 0; b < param2ArrayOfParcelable.length; b++) {
          if (param2ArrayOfParcelable[b] instanceof Bundle) {
            Message message = a((Bundle)param2ArrayOfParcelable[b]);
            if (message != null)
              arrayList.add(message); 
          } 
        } 
        return arrayList;
      }
      
      static Bundle[] a(List<Message> param2List) {
        Bundle[] arrayOfBundle = new Bundle[param2List.size()];
        int i = param2List.size();
        for (byte b = 0; b < i; b++)
          arrayOfBundle[b] = ((Message)param2List.get(b)).toBundle(); 
        return arrayOfBundle;
      }
      
      private Bundle toBundle() {
        Bundle bundle = new Bundle();
        if (this.mText != null)
          bundle.putCharSequence("text", this.mText); 
        bundle.putLong("time", this.mTimestamp);
        if (this.mSender != null)
          bundle.putCharSequence("sender", this.mSender); 
        if (this.mDataMimeType != null)
          bundle.putString("type", this.mDataMimeType); 
        if (this.mDataUri != null)
          bundle.putParcelable("uri", (Parcelable)this.mDataUri); 
        if (this.mExtras != null)
          bundle.putBundle("extras", this.mExtras); 
        return bundle;
      }
      
      public String getDataMimeType() {
        return this.mDataMimeType;
      }
      
      public Uri getDataUri() {
        return this.mDataUri;
      }
      
      public Bundle getExtras() {
        return this.mExtras;
      }
      
      public CharSequence getSender() {
        return this.mSender;
      }
      
      public CharSequence getText() {
        return this.mText;
      }
      
      public long getTimestamp() {
        return this.mTimestamp;
      }
      
      public Message setData(String param2String, Uri param2Uri) {
        this.mDataMimeType = param2String;
        this.mDataUri = param2Uri;
        return this;
      }
    }
  }
  
  public static final class Message {
    private String mDataMimeType;
    
    private Uri mDataUri;
    
    private Bundle mExtras = new Bundle();
    
    private final CharSequence mSender;
    
    private final CharSequence mText;
    
    private final long mTimestamp;
    
    public Message(CharSequence param1CharSequence1, long param1Long, CharSequence param1CharSequence2) {
      this.mText = param1CharSequence1;
      this.mTimestamp = param1Long;
      this.mSender = param1CharSequence2;
    }
    
    static Message a(Bundle param1Bundle) {
      try {
        if (param1Bundle.containsKey("text")) {
          if (!param1Bundle.containsKey("time"))
            return null; 
          Message message = new Message(param1Bundle.getCharSequence("text"), param1Bundle.getLong("time"), param1Bundle.getCharSequence("sender"));
          if (param1Bundle.containsKey("type") && param1Bundle.containsKey("uri"))
            message.setData(param1Bundle.getString("type"), (Uri)param1Bundle.getParcelable("uri")); 
          if (param1Bundle.containsKey("extras"))
            message.getExtras().putAll(param1Bundle.getBundle("extras")); 
          return message;
        } 
        return null;
      } catch (ClassCastException classCastException) {
        return null;
      } 
    }
    
    static List<Message> a(Parcelable[] param1ArrayOfParcelable) {
      ArrayList<Message> arrayList = new ArrayList(param1ArrayOfParcelable.length);
      for (byte b = 0; b < param1ArrayOfParcelable.length; b++) {
        if (param1ArrayOfParcelable[b] instanceof Bundle) {
          Message message = a((Bundle)param1ArrayOfParcelable[b]);
          if (message != null)
            arrayList.add(message); 
        } 
      } 
      return arrayList;
    }
    
    static Bundle[] a(List<Message> param1List) {
      Bundle[] arrayOfBundle = new Bundle[param1List.size()];
      int i = param1List.size();
      for (byte b = 0; b < i; b++)
        arrayOfBundle[b] = ((Message)param1List.get(b)).toBundle(); 
      return arrayOfBundle;
    }
    
    private Bundle toBundle() {
      Bundle bundle = new Bundle();
      if (this.mText != null)
        bundle.putCharSequence("text", this.mText); 
      bundle.putLong("time", this.mTimestamp);
      if (this.mSender != null)
        bundle.putCharSequence("sender", this.mSender); 
      if (this.mDataMimeType != null)
        bundle.putString("type", this.mDataMimeType); 
      if (this.mDataUri != null)
        bundle.putParcelable("uri", (Parcelable)this.mDataUri); 
      if (this.mExtras != null)
        bundle.putBundle("extras", this.mExtras); 
      return bundle;
    }
    
    public String getDataMimeType() {
      return this.mDataMimeType;
    }
    
    public Uri getDataUri() {
      return this.mDataUri;
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public CharSequence getSender() {
      return this.mSender;
    }
    
    public CharSequence getText() {
      return this.mText;
    }
    
    public long getTimestamp() {
      return this.mTimestamp;
    }
    
    public Message setData(String param1String, Uri param1Uri) {
      this.mDataMimeType = param1String;
      this.mDataUri = param1Uri;
      return this;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface NotificationVisibility {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface StreamType {}
  
  public static abstract class Style {
    CharSequence d;
    
    CharSequence e;
    
    boolean f = false;
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    protected NotificationCompat.Builder mBuilder;
    
    private int calculateTopPadding() {
      Resources resources = this.mBuilder.mContext.getResources();
      int i = resources.getDimensionPixelSize(R.dimen.notification_top_pad);
      int j = resources.getDimensionPixelSize(R.dimen.notification_top_pad_large_text);
      float f = (constrain((resources.getConfiguration()).fontScale, 1.0F, 1.3F) - 1.0F) / 0.29999995F;
      return Math.round((1.0F - f) * i + f * j);
    }
    
    private static float constrain(float param1Float1, float param1Float2, float param1Float3) {
      if (param1Float1 < param1Float2)
        return param1Float2; 
      if (param1Float1 > param1Float3)
        param1Float1 = param1Float3; 
      return param1Float1;
    }
    
    private Bitmap createColoredBitmap(int param1Int1, int param1Int2, int param1Int3) {
      int i;
      Drawable drawable = this.mBuilder.mContext.getResources().getDrawable(param1Int1);
      if (param1Int3 == 0) {
        i = drawable.getIntrinsicWidth();
      } else {
        i = param1Int3;
      } 
      if (param1Int3 == 0)
        param1Int3 = drawable.getIntrinsicHeight(); 
      Bitmap bitmap = Bitmap.createBitmap(i, param1Int3, Bitmap.Config.ARGB_8888);
      drawable.setBounds(0, 0, i, param1Int3);
      if (param1Int2 != 0)
        drawable.mutate().setColorFilter((ColorFilter)new PorterDuffColorFilter(param1Int2, PorterDuff.Mode.SRC_IN)); 
      drawable.draw(new Canvas(bitmap));
      return bitmap;
    }
    
    private Bitmap createIconWithBackground(int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      int i = R.drawable.notification_icon_background;
      if (param1Int4 == 0)
        param1Int4 = 0; 
      Bitmap bitmap = createColoredBitmap(i, param1Int4, param1Int2);
      Canvas canvas = new Canvas(bitmap);
      Drawable drawable = this.mBuilder.mContext.getResources().getDrawable(param1Int1).mutate();
      drawable.setFilterBitmap(true);
      int j = (param1Int2 - param1Int3) / 2;
      int k = param1Int3 + j;
      drawable.setBounds(j, j, k, k);
      drawable.setColorFilter((ColorFilter)new PorterDuffColorFilter(-1, PorterDuff.Mode.SRC_ATOP));
      drawable.draw(canvas);
      return bitmap;
    }
    
    private void hideNormalContent(RemoteViews param1RemoteViews) {
      param1RemoteViews.setViewVisibility(R.id.title, 8);
      param1RemoteViews.setViewVisibility(R.id.text2, 8);
      param1RemoteViews.setViewVisibility(R.id.text, 8);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void addCompatExtras(Bundle param1Bundle) {}
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {}
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews applyStandardTemplate(boolean param1Boolean1, int param1Int, boolean param1Boolean2) {
      // Byte code:
      //   0: aload_0
      //   1: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   4: getfield mContext : Landroid/content/Context;
      //   7: invokevirtual getResources : ()Landroid/content/res/Resources;
      //   10: astore #4
      //   12: new android/widget/RemoteViews
      //   15: dup
      //   16: aload_0
      //   17: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   20: getfield mContext : Landroid/content/Context;
      //   23: invokevirtual getPackageName : ()Ljava/lang/String;
      //   26: iload_2
      //   27: invokespecial <init> : (Ljava/lang/String;I)V
      //   30: astore #5
      //   32: aload_0
      //   33: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   36: invokevirtual getPriority : ()I
      //   39: iconst_m1
      //   40: if_icmpge -> 49
      //   43: iconst_1
      //   44: istore #6
      //   46: goto -> 52
      //   49: iconst_0
      //   50: istore #6
      //   52: getstatic android/os/Build$VERSION.SDK_INT : I
      //   55: bipush #16
      //   57: if_icmplt -> 128
      //   60: getstatic android/os/Build$VERSION.SDK_INT : I
      //   63: bipush #21
      //   65: if_icmpge -> 128
      //   68: iload #6
      //   70: ifeq -> 102
      //   73: aload #5
      //   75: getstatic android/support/compat/R$id.notification_background : I
      //   78: ldc 'setBackgroundResource'
      //   80: getstatic android/support/compat/R$drawable.notification_bg_low : I
      //   83: invokevirtual setInt : (ILjava/lang/String;I)V
      //   86: aload #5
      //   88: getstatic android/support/compat/R$id.icon : I
      //   91: ldc 'setBackgroundResource'
      //   93: getstatic android/support/compat/R$drawable.notification_template_icon_low_bg : I
      //   96: invokevirtual setInt : (ILjava/lang/String;I)V
      //   99: goto -> 128
      //   102: aload #5
      //   104: getstatic android/support/compat/R$id.notification_background : I
      //   107: ldc 'setBackgroundResource'
      //   109: getstatic android/support/compat/R$drawable.notification_bg : I
      //   112: invokevirtual setInt : (ILjava/lang/String;I)V
      //   115: aload #5
      //   117: getstatic android/support/compat/R$id.icon : I
      //   120: ldc 'setBackgroundResource'
      //   122: getstatic android/support/compat/R$drawable.notification_template_icon_bg : I
      //   125: invokevirtual setInt : (ILjava/lang/String;I)V
      //   128: aload_0
      //   129: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   132: getfield f : Landroid/graphics/Bitmap;
      //   135: ifnull -> 308
      //   138: getstatic android/os/Build$VERSION.SDK_INT : I
      //   141: bipush #16
      //   143: if_icmplt -> 173
      //   146: aload #5
      //   148: getstatic android/support/compat/R$id.icon : I
      //   151: iconst_0
      //   152: invokevirtual setViewVisibility : (II)V
      //   155: aload #5
      //   157: getstatic android/support/compat/R$id.icon : I
      //   160: aload_0
      //   161: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   164: getfield f : Landroid/graphics/Bitmap;
      //   167: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
      //   170: goto -> 183
      //   173: aload #5
      //   175: getstatic android/support/compat/R$id.icon : I
      //   178: bipush #8
      //   180: invokevirtual setViewVisibility : (II)V
      //   183: iload_1
      //   184: ifeq -> 434
      //   187: aload_0
      //   188: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   191: getfield K : Landroid/app/Notification;
      //   194: getfield icon : I
      //   197: ifeq -> 434
      //   200: aload #4
      //   202: getstatic android/support/compat/R$dimen.notification_right_icon_size : I
      //   205: invokevirtual getDimensionPixelSize : (I)I
      //   208: istore #20
      //   210: iload #20
      //   212: iconst_2
      //   213: aload #4
      //   215: getstatic android/support/compat/R$dimen.notification_small_icon_background_padding : I
      //   218: invokevirtual getDimensionPixelSize : (I)I
      //   221: imul
      //   222: isub
      //   223: istore #21
      //   225: getstatic android/os/Build$VERSION.SDK_INT : I
      //   228: bipush #21
      //   230: if_icmplt -> 273
      //   233: aload_0
      //   234: aload_0
      //   235: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   238: getfield K : Landroid/app/Notification;
      //   241: getfield icon : I
      //   244: iload #20
      //   246: iload #21
      //   248: aload_0
      //   249: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   252: invokevirtual getColor : ()I
      //   255: invokespecial createIconWithBackground : (IIII)Landroid/graphics/Bitmap;
      //   258: astore #22
      //   260: aload #5
      //   262: getstatic android/support/compat/R$id.right_icon : I
      //   265: aload #22
      //   267: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
      //   270: goto -> 296
      //   273: aload #5
      //   275: getstatic android/support/compat/R$id.right_icon : I
      //   278: aload_0
      //   279: aload_0
      //   280: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   283: getfield K : Landroid/app/Notification;
      //   286: getfield icon : I
      //   289: iconst_m1
      //   290: invokevirtual createColoredBitmap : (II)Landroid/graphics/Bitmap;
      //   293: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
      //   296: aload #5
      //   298: getstatic android/support/compat/R$id.right_icon : I
      //   301: iconst_0
      //   302: invokevirtual setViewVisibility : (II)V
      //   305: goto -> 434
      //   308: iload_1
      //   309: ifeq -> 434
      //   312: aload_0
      //   313: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   316: getfield K : Landroid/app/Notification;
      //   319: getfield icon : I
      //   322: ifeq -> 434
      //   325: aload #5
      //   327: getstatic android/support/compat/R$id.icon : I
      //   330: iconst_0
      //   331: invokevirtual setViewVisibility : (II)V
      //   334: getstatic android/os/Build$VERSION.SDK_INT : I
      //   337: bipush #21
      //   339: if_icmplt -> 411
      //   342: aload #4
      //   344: getstatic android/support/compat/R$dimen.notification_large_icon_width : I
      //   347: invokevirtual getDimensionPixelSize : (I)I
      //   350: aload #4
      //   352: getstatic android/support/compat/R$dimen.notification_big_circle_margin : I
      //   355: invokevirtual getDimensionPixelSize : (I)I
      //   358: isub
      //   359: istore #17
      //   361: aload #4
      //   363: getstatic android/support/compat/R$dimen.notification_small_icon_size_as_large : I
      //   366: invokevirtual getDimensionPixelSize : (I)I
      //   369: istore #18
      //   371: aload_0
      //   372: aload_0
      //   373: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   376: getfield K : Landroid/app/Notification;
      //   379: getfield icon : I
      //   382: iload #17
      //   384: iload #18
      //   386: aload_0
      //   387: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   390: invokevirtual getColor : ()I
      //   393: invokespecial createIconWithBackground : (IIII)Landroid/graphics/Bitmap;
      //   396: astore #19
      //   398: aload #5
      //   400: getstatic android/support/compat/R$id.icon : I
      //   403: aload #19
      //   405: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
      //   408: goto -> 434
      //   411: aload #5
      //   413: getstatic android/support/compat/R$id.icon : I
      //   416: aload_0
      //   417: aload_0
      //   418: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   421: getfield K : Landroid/app/Notification;
      //   424: getfield icon : I
      //   427: iconst_m1
      //   428: invokevirtual createColoredBitmap : (II)Landroid/graphics/Bitmap;
      //   431: invokevirtual setImageViewBitmap : (ILandroid/graphics/Bitmap;)V
      //   434: aload_0
      //   435: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   438: getfield a : Ljava/lang/CharSequence;
      //   441: ifnull -> 459
      //   444: aload #5
      //   446: getstatic android/support/compat/R$id.title : I
      //   449: aload_0
      //   450: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   453: getfield a : Ljava/lang/CharSequence;
      //   456: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   459: aload_0
      //   460: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   463: getfield b : Ljava/lang/CharSequence;
      //   466: ifnull -> 490
      //   469: aload #5
      //   471: getstatic android/support/compat/R$id.text : I
      //   474: aload_0
      //   475: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   478: getfield b : Ljava/lang/CharSequence;
      //   481: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   484: iconst_1
      //   485: istore #7
      //   487: goto -> 493
      //   490: iconst_0
      //   491: istore #7
      //   493: getstatic android/os/Build$VERSION.SDK_INT : I
      //   496: bipush #21
      //   498: if_icmpge -> 517
      //   501: aload_0
      //   502: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   505: getfield f : Landroid/graphics/Bitmap;
      //   508: ifnull -> 517
      //   511: iconst_1
      //   512: istore #8
      //   514: goto -> 520
      //   517: iconst_0
      //   518: istore #8
      //   520: aload_0
      //   521: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   524: getfield g : Ljava/lang/CharSequence;
      //   527: ifnull -> 563
      //   530: aload #5
      //   532: getstatic android/support/compat/R$id.info : I
      //   535: aload_0
      //   536: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   539: getfield g : Ljava/lang/CharSequence;
      //   542: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   545: aload #5
      //   547: getstatic android/support/compat/R$id.info : I
      //   550: iconst_0
      //   551: invokevirtual setViewVisibility : (II)V
      //   554: iconst_1
      //   555: istore #7
      //   557: iconst_1
      //   558: istore #8
      //   560: goto -> 662
      //   563: aload_0
      //   564: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   567: getfield h : I
      //   570: ifle -> 652
      //   573: aload #4
      //   575: getstatic android/support/compat/R$integer.status_bar_notification_info_maxnum : I
      //   578: invokevirtual getInteger : (I)I
      //   581: istore #15
      //   583: aload_0
      //   584: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   587: getfield h : I
      //   590: iload #15
      //   592: if_icmple -> 614
      //   595: aload #5
      //   597: getstatic android/support/compat/R$id.info : I
      //   600: aload #4
      //   602: getstatic android/support/compat/R$string.status_bar_notification_info_overflow : I
      //   605: invokevirtual getString : (I)Ljava/lang/String;
      //   608: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   611: goto -> 640
      //   614: invokestatic getIntegerInstance : ()Ljava/text/NumberFormat;
      //   617: astore #16
      //   619: aload #5
      //   621: getstatic android/support/compat/R$id.info : I
      //   624: aload #16
      //   626: aload_0
      //   627: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   630: getfield h : I
      //   633: i2l
      //   634: invokevirtual format : (J)Ljava/lang/String;
      //   637: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   640: aload #5
      //   642: getstatic android/support/compat/R$id.info : I
      //   645: iconst_0
      //   646: invokevirtual setViewVisibility : (II)V
      //   649: goto -> 554
      //   652: aload #5
      //   654: getstatic android/support/compat/R$id.info : I
      //   657: bipush #8
      //   659: invokevirtual setViewVisibility : (II)V
      //   662: aload_0
      //   663: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   666: getfield m : Ljava/lang/CharSequence;
      //   669: ifnull -> 745
      //   672: getstatic android/os/Build$VERSION.SDK_INT : I
      //   675: bipush #16
      //   677: if_icmplt -> 745
      //   680: aload #5
      //   682: getstatic android/support/compat/R$id.text : I
      //   685: aload_0
      //   686: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   689: getfield m : Ljava/lang/CharSequence;
      //   692: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   695: aload_0
      //   696: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   699: getfield b : Ljava/lang/CharSequence;
      //   702: ifnull -> 735
      //   705: aload #5
      //   707: getstatic android/support/compat/R$id.text2 : I
      //   710: aload_0
      //   711: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   714: getfield b : Ljava/lang/CharSequence;
      //   717: invokevirtual setTextViewText : (ILjava/lang/CharSequence;)V
      //   720: aload #5
      //   722: getstatic android/support/compat/R$id.text2 : I
      //   725: iconst_0
      //   726: invokevirtual setViewVisibility : (II)V
      //   729: iconst_1
      //   730: istore #9
      //   732: goto -> 748
      //   735: aload #5
      //   737: getstatic android/support/compat/R$id.text2 : I
      //   740: bipush #8
      //   742: invokevirtual setViewVisibility : (II)V
      //   745: iconst_0
      //   746: istore #9
      //   748: iload #9
      //   750: ifeq -> 799
      //   753: getstatic android/os/Build$VERSION.SDK_INT : I
      //   756: bipush #16
      //   758: if_icmplt -> 799
      //   761: iload_3
      //   762: ifeq -> 787
      //   765: aload #4
      //   767: getstatic android/support/compat/R$dimen.notification_subtext_size : I
      //   770: invokevirtual getDimensionPixelSize : (I)I
      //   773: i2f
      //   774: fstore #14
      //   776: aload #5
      //   778: getstatic android/support/compat/R$id.text : I
      //   781: iconst_0
      //   782: fload #14
      //   784: invokevirtual setTextViewTextSize : (IIF)V
      //   787: aload #5
      //   789: getstatic android/support/compat/R$id.line1 : I
      //   792: iconst_0
      //   793: iconst_0
      //   794: iconst_0
      //   795: iconst_0
      //   796: invokevirtual setViewPadding : (IIIII)V
      //   799: aload_0
      //   800: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   803: invokevirtual getWhenIfShowing : ()J
      //   806: lconst_0
      //   807: lcmp
      //   808: ifeq -> 909
      //   811: aload_0
      //   812: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   815: getfield k : Z
      //   818: ifeq -> 879
      //   821: getstatic android/os/Build$VERSION.SDK_INT : I
      //   824: bipush #16
      //   826: if_icmplt -> 879
      //   829: aload #5
      //   831: getstatic android/support/compat/R$id.chronometer : I
      //   834: iconst_0
      //   835: invokevirtual setViewVisibility : (II)V
      //   838: aload #5
      //   840: getstatic android/support/compat/R$id.chronometer : I
      //   843: ldc_w 'setBase'
      //   846: aload_0
      //   847: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   850: invokevirtual getWhenIfShowing : ()J
      //   853: invokestatic elapsedRealtime : ()J
      //   856: invokestatic currentTimeMillis : ()J
      //   859: lsub
      //   860: ladd
      //   861: invokevirtual setLong : (ILjava/lang/String;J)V
      //   864: aload #5
      //   866: getstatic android/support/compat/R$id.chronometer : I
      //   869: ldc_w 'setStarted'
      //   872: iconst_1
      //   873: invokevirtual setBoolean : (ILjava/lang/String;Z)V
      //   876: goto -> 906
      //   879: aload #5
      //   881: getstatic android/support/compat/R$id.time : I
      //   884: iconst_0
      //   885: invokevirtual setViewVisibility : (II)V
      //   888: aload #5
      //   890: getstatic android/support/compat/R$id.time : I
      //   893: ldc_w 'setTime'
      //   896: aload_0
      //   897: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   900: invokevirtual getWhenIfShowing : ()J
      //   903: invokevirtual setLong : (ILjava/lang/String;J)V
      //   906: iconst_1
      //   907: istore #8
      //   909: getstatic android/support/compat/R$id.right_side : I
      //   912: istore #10
      //   914: iload #8
      //   916: ifeq -> 925
      //   919: iconst_0
      //   920: istore #11
      //   922: goto -> 929
      //   925: bipush #8
      //   927: istore #11
      //   929: aload #5
      //   931: iload #10
      //   933: iload #11
      //   935: invokevirtual setViewVisibility : (II)V
      //   938: getstatic android/support/compat/R$id.line3 : I
      //   941: istore #12
      //   943: iload #7
      //   945: ifeq -> 954
      //   948: iconst_0
      //   949: istore #13
      //   951: goto -> 958
      //   954: bipush #8
      //   956: istore #13
      //   958: aload #5
      //   960: iload #12
      //   962: iload #13
      //   964: invokevirtual setViewVisibility : (II)V
      //   967: aload #5
      //   969: areturn
    }
    
    public Notification build() {
      return (this.mBuilder != null) ? this.mBuilder.build() : null;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void buildIntoRemoteViews(RemoteViews param1RemoteViews1, RemoteViews param1RemoteViews2) {
      hideNormalContent(param1RemoteViews1);
      param1RemoteViews1.removeAllViews(R.id.notification_main_column);
      param1RemoteViews1.addView(R.id.notification_main_column, param1RemoteViews2.clone());
      param1RemoteViews1.setViewVisibility(R.id.notification_main_column, 0);
      if (Build.VERSION.SDK_INT >= 21)
        param1RemoteViews1.setViewPadding(R.id.notification_main_column_container, 0, calculateTopPadding(), 0, 0); 
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Bitmap createColoredBitmap(int param1Int1, int param1Int2) {
      return createColoredBitmap(param1Int1, param1Int2, 0);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return null;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return null;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeHeadsUpContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return null;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    protected void restoreFromCompatExtras(Bundle param1Bundle) {}
    
    public void setBuilder(NotificationCompat.Builder param1Builder) {
      if (this.mBuilder != param1Builder) {
        this.mBuilder = param1Builder;
        if (this.mBuilder != null)
          this.mBuilder.setStyle(this); 
      } 
    }
  }
  
  public static final class WearableExtender implements Extender {
    private static final int DEFAULT_CONTENT_ICON_GRAVITY = 8388613;
    
    private static final int DEFAULT_FLAGS = 1;
    
    private static final int DEFAULT_GRAVITY = 80;
    
    private static final String EXTRA_WEARABLE_EXTENSIONS = "android.wearable.EXTENSIONS";
    
    private static final int FLAG_BIG_PICTURE_AMBIENT = 32;
    
    private static final int FLAG_CONTENT_INTENT_AVAILABLE_OFFLINE = 1;
    
    private static final int FLAG_HINT_AVOID_BACKGROUND_CLIPPING = 16;
    
    private static final int FLAG_HINT_CONTENT_INTENT_LAUNCHES_ACTIVITY = 64;
    
    private static final int FLAG_HINT_HIDE_ICON = 2;
    
    private static final int FLAG_HINT_SHOW_BACKGROUND_ONLY = 4;
    
    private static final int FLAG_START_SCROLL_BOTTOM = 8;
    
    private static final String KEY_ACTIONS = "actions";
    
    private static final String KEY_BACKGROUND = "background";
    
    private static final String KEY_BRIDGE_TAG = "bridgeTag";
    
    private static final String KEY_CONTENT_ACTION_INDEX = "contentActionIndex";
    
    private static final String KEY_CONTENT_ICON = "contentIcon";
    
    private static final String KEY_CONTENT_ICON_GRAVITY = "contentIconGravity";
    
    private static final String KEY_CUSTOM_CONTENT_HEIGHT = "customContentHeight";
    
    private static final String KEY_CUSTOM_SIZE_PRESET = "customSizePreset";
    
    private static final String KEY_DISMISSAL_ID = "dismissalId";
    
    private static final String KEY_DISPLAY_INTENT = "displayIntent";
    
    private static final String KEY_FLAGS = "flags";
    
    private static final String KEY_GRAVITY = "gravity";
    
    private static final String KEY_HINT_SCREEN_TIMEOUT = "hintScreenTimeout";
    
    private static final String KEY_PAGES = "pages";
    
    public static final int SCREEN_TIMEOUT_LONG = -1;
    
    public static final int SCREEN_TIMEOUT_SHORT = 0;
    
    public static final int SIZE_DEFAULT = 0;
    
    public static final int SIZE_FULL_SCREEN = 5;
    
    public static final int SIZE_LARGE = 4;
    
    public static final int SIZE_MEDIUM = 3;
    
    public static final int SIZE_SMALL = 2;
    
    public static final int SIZE_XSMALL = 1;
    
    public static final int UNSET_ACTION_INDEX = -1;
    
    private ArrayList<NotificationCompat.Action> mActions;
    
    private Bitmap mBackground;
    
    private String mBridgeTag;
    
    private int mContentActionIndex;
    
    private int mContentIcon;
    
    private int mContentIconGravity;
    
    private int mCustomContentHeight;
    
    private int mCustomSizePreset;
    
    private String mDismissalId;
    
    private PendingIntent mDisplayIntent;
    
    private int mFlags;
    
    private int mGravity;
    
    private int mHintScreenTimeout;
    
    private ArrayList<Notification> mPages;
    
    public WearableExtender() {
      this.mActions = new ArrayList<NotificationCompat.Action>();
      this.mFlags = 1;
      this.mPages = new ArrayList<Notification>();
      this.mContentIconGravity = 8388613;
      this.mContentActionIndex = -1;
      this.mCustomSizePreset = 0;
      this.mGravity = 80;
    }
    
    public WearableExtender(Notification param1Notification) {
      Bundle bundle2;
      this.mActions = new ArrayList<NotificationCompat.Action>();
      this.mFlags = 1;
      this.mPages = new ArrayList<Notification>();
      this.mContentIconGravity = 8388613;
      this.mContentActionIndex = -1;
      this.mCustomSizePreset = 0;
      this.mGravity = 80;
      Bundle bundle1 = NotificationCompat.getExtras(param1Notification);
      if (bundle1 != null) {
        bundle2 = bundle1.getBundle("android.wearable.EXTENSIONS");
      } else {
        bundle2 = null;
      } 
      if (bundle2 != null) {
        ArrayList<Notification.Action> arrayList = bundle2.getParcelableArrayList("actions");
        if (Build.VERSION.SDK_INT >= 16 && arrayList != null) {
          NotificationCompat.Action[] arrayOfAction = new NotificationCompat.Action[arrayList.size()];
          for (byte b = 0; b < arrayOfAction.length; b++) {
            if (Build.VERSION.SDK_INT >= 20) {
              arrayOfAction[b] = NotificationCompat.a(arrayList.get(b));
            } else if (Build.VERSION.SDK_INT >= 16) {
              arrayOfAction[b] = NotificationCompatJellybean.a((Bundle)arrayList.get(b));
            } 
          } 
          Collections.addAll(this.mActions, arrayOfAction);
        } 
        this.mFlags = bundle2.getInt("flags", 1);
        this.mDisplayIntent = (PendingIntent)bundle2.getParcelable("displayIntent");
        Notification[] arrayOfNotification = NotificationCompat.a(bundle2, "pages");
        if (arrayOfNotification != null)
          Collections.addAll(this.mPages, arrayOfNotification); 
        this.mBackground = (Bitmap)bundle2.getParcelable("background");
        this.mContentIcon = bundle2.getInt("contentIcon");
        this.mContentIconGravity = bundle2.getInt("contentIconGravity", 8388613);
        this.mContentActionIndex = bundle2.getInt("contentActionIndex", -1);
        this.mCustomSizePreset = bundle2.getInt("customSizePreset", 0);
        this.mCustomContentHeight = bundle2.getInt("customContentHeight");
        this.mGravity = bundle2.getInt("gravity", 80);
        this.mHintScreenTimeout = bundle2.getInt("hintScreenTimeout");
        this.mDismissalId = bundle2.getString("dismissalId");
        this.mBridgeTag = bundle2.getString("bridgeTag");
      } 
    }
    
    @RequiresApi(20)
    private static Notification.Action getActionFromActionCompat(NotificationCompat.Action param1Action) {
      Bundle bundle;
      Notification.Action.Builder builder = new Notification.Action.Builder(param1Action.getIcon(), param1Action.getTitle(), param1Action.getActionIntent());
      if (param1Action.getExtras() != null) {
        bundle = new Bundle(param1Action.getExtras());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", param1Action.getAllowGeneratedReplies());
      if (Build.VERSION.SDK_INT >= 24)
        builder.setAllowGeneratedReplies(param1Action.getAllowGeneratedReplies()); 
      builder.addExtras(bundle);
      RemoteInput[] arrayOfRemoteInput = param1Action.getRemoteInputs();
      if (arrayOfRemoteInput != null) {
        RemoteInput[] arrayOfRemoteInput1 = RemoteInput.a(arrayOfRemoteInput);
        int i = arrayOfRemoteInput1.length;
        for (byte b = 0; b < i; b++)
          builder.addRemoteInput(arrayOfRemoteInput1[b]); 
      } 
      return builder.build();
    }
    
    private void setFlag(int param1Int, boolean param1Boolean) {
      if (param1Boolean) {
        this.mFlags = param1Int | this.mFlags;
        return;
      } 
      this.mFlags &= param1Int ^ 0xFFFFFFFF;
    }
    
    public WearableExtender addAction(NotificationCompat.Action param1Action) {
      this.mActions.add(param1Action);
      return this;
    }
    
    public WearableExtender addActions(List<NotificationCompat.Action> param1List) {
      this.mActions.addAll(param1List);
      return this;
    }
    
    public WearableExtender addPage(Notification param1Notification) {
      this.mPages.add(param1Notification);
      return this;
    }
    
    public WearableExtender addPages(List<Notification> param1List) {
      this.mPages.addAll(param1List);
      return this;
    }
    
    public WearableExtender clearActions() {
      this.mActions.clear();
      return this;
    }
    
    public WearableExtender clearPages() {
      this.mPages.clear();
      return this;
    }
    
    public WearableExtender clone() {
      WearableExtender wearableExtender = new WearableExtender();
      wearableExtender.mActions = new ArrayList<NotificationCompat.Action>(this.mActions);
      wearableExtender.mFlags = this.mFlags;
      wearableExtender.mDisplayIntent = this.mDisplayIntent;
      wearableExtender.mPages = new ArrayList<Notification>(this.mPages);
      wearableExtender.mBackground = this.mBackground;
      wearableExtender.mContentIcon = this.mContentIcon;
      wearableExtender.mContentIconGravity = this.mContentIconGravity;
      wearableExtender.mContentActionIndex = this.mContentActionIndex;
      wearableExtender.mCustomSizePreset = this.mCustomSizePreset;
      wearableExtender.mCustomContentHeight = this.mCustomContentHeight;
      wearableExtender.mGravity = this.mGravity;
      wearableExtender.mHintScreenTimeout = this.mHintScreenTimeout;
      wearableExtender.mDismissalId = this.mDismissalId;
      wearableExtender.mBridgeTag = this.mBridgeTag;
      return wearableExtender;
    }
    
    public NotificationCompat.Builder extend(NotificationCompat.Builder param1Builder) {
      Bundle bundle = new Bundle();
      if (!this.mActions.isEmpty())
        if (Build.VERSION.SDK_INT >= 16) {
          ArrayList<Notification.Action> arrayList = new ArrayList(this.mActions.size());
          for (NotificationCompat.Action action : this.mActions) {
            if (Build.VERSION.SDK_INT >= 20) {
              arrayList.add(getActionFromActionCompat(action));
              continue;
            } 
            if (Build.VERSION.SDK_INT >= 16)
              arrayList.add(NotificationCompatJellybean.a(action)); 
          } 
          bundle.putParcelableArrayList("actions", arrayList);
        } else {
          bundle.putParcelableArrayList("actions", null);
        }  
      if (this.mFlags != 1)
        bundle.putInt("flags", this.mFlags); 
      if (this.mDisplayIntent != null)
        bundle.putParcelable("displayIntent", (Parcelable)this.mDisplayIntent); 
      if (!this.mPages.isEmpty())
        bundle.putParcelableArray("pages", (Parcelable[])this.mPages.toArray((Object[])new Notification[this.mPages.size()])); 
      if (this.mBackground != null)
        bundle.putParcelable("background", (Parcelable)this.mBackground); 
      if (this.mContentIcon != 0)
        bundle.putInt("contentIcon", this.mContentIcon); 
      if (this.mContentIconGravity != 8388613)
        bundle.putInt("contentIconGravity", this.mContentIconGravity); 
      if (this.mContentActionIndex != -1)
        bundle.putInt("contentActionIndex", this.mContentActionIndex); 
      if (this.mCustomSizePreset != 0)
        bundle.putInt("customSizePreset", this.mCustomSizePreset); 
      if (this.mCustomContentHeight != 0)
        bundle.putInt("customContentHeight", this.mCustomContentHeight); 
      if (this.mGravity != 80)
        bundle.putInt("gravity", this.mGravity); 
      if (this.mHintScreenTimeout != 0)
        bundle.putInt("hintScreenTimeout", this.mHintScreenTimeout); 
      if (this.mDismissalId != null)
        bundle.putString("dismissalId", this.mDismissalId); 
      if (this.mBridgeTag != null)
        bundle.putString("bridgeTag", this.mBridgeTag); 
      param1Builder.getExtras().putBundle("android.wearable.EXTENSIONS", bundle);
      return param1Builder;
    }
    
    public List<NotificationCompat.Action> getActions() {
      return this.mActions;
    }
    
    public Bitmap getBackground() {
      return this.mBackground;
    }
    
    public String getBridgeTag() {
      return this.mBridgeTag;
    }
    
    public int getContentAction() {
      return this.mContentActionIndex;
    }
    
    public int getContentIcon() {
      return this.mContentIcon;
    }
    
    public int getContentIconGravity() {
      return this.mContentIconGravity;
    }
    
    public boolean getContentIntentAvailableOffline() {
      return ((0x1 & this.mFlags) != 0);
    }
    
    public int getCustomContentHeight() {
      return this.mCustomContentHeight;
    }
    
    public int getCustomSizePreset() {
      return this.mCustomSizePreset;
    }
    
    public String getDismissalId() {
      return this.mDismissalId;
    }
    
    public PendingIntent getDisplayIntent() {
      return this.mDisplayIntent;
    }
    
    public int getGravity() {
      return this.mGravity;
    }
    
    public boolean getHintAmbientBigPicture() {
      return ((0x20 & this.mFlags) != 0);
    }
    
    public boolean getHintAvoidBackgroundClipping() {
      return ((0x10 & this.mFlags) != 0);
    }
    
    public boolean getHintContentIntentLaunchesActivity() {
      return ((0x40 & this.mFlags) != 0);
    }
    
    public boolean getHintHideIcon() {
      return ((0x2 & this.mFlags) != 0);
    }
    
    public int getHintScreenTimeout() {
      return this.mHintScreenTimeout;
    }
    
    public boolean getHintShowBackgroundOnly() {
      return ((0x4 & this.mFlags) != 0);
    }
    
    public List<Notification> getPages() {
      return this.mPages;
    }
    
    public boolean getStartScrollBottom() {
      return ((0x8 & this.mFlags) != 0);
    }
    
    public WearableExtender setBackground(Bitmap param1Bitmap) {
      this.mBackground = param1Bitmap;
      return this;
    }
    
    public WearableExtender setBridgeTag(String param1String) {
      this.mBridgeTag = param1String;
      return this;
    }
    
    public WearableExtender setContentAction(int param1Int) {
      this.mContentActionIndex = param1Int;
      return this;
    }
    
    public WearableExtender setContentIcon(int param1Int) {
      this.mContentIcon = param1Int;
      return this;
    }
    
    public WearableExtender setContentIconGravity(int param1Int) {
      this.mContentIconGravity = param1Int;
      return this;
    }
    
    public WearableExtender setContentIntentAvailableOffline(boolean param1Boolean) {
      setFlag(1, param1Boolean);
      return this;
    }
    
    public WearableExtender setCustomContentHeight(int param1Int) {
      this.mCustomContentHeight = param1Int;
      return this;
    }
    
    public WearableExtender setCustomSizePreset(int param1Int) {
      this.mCustomSizePreset = param1Int;
      return this;
    }
    
    public WearableExtender setDismissalId(String param1String) {
      this.mDismissalId = param1String;
      return this;
    }
    
    public WearableExtender setDisplayIntent(PendingIntent param1PendingIntent) {
      this.mDisplayIntent = param1PendingIntent;
      return this;
    }
    
    public WearableExtender setGravity(int param1Int) {
      this.mGravity = param1Int;
      return this;
    }
    
    public WearableExtender setHintAmbientBigPicture(boolean param1Boolean) {
      setFlag(32, param1Boolean);
      return this;
    }
    
    public WearableExtender setHintAvoidBackgroundClipping(boolean param1Boolean) {
      setFlag(16, param1Boolean);
      return this;
    }
    
    public WearableExtender setHintContentIntentLaunchesActivity(boolean param1Boolean) {
      setFlag(64, param1Boolean);
      return this;
    }
    
    public WearableExtender setHintHideIcon(boolean param1Boolean) {
      setFlag(2, param1Boolean);
      return this;
    }
    
    public WearableExtender setHintScreenTimeout(int param1Int) {
      this.mHintScreenTimeout = param1Int;
      return this;
    }
    
    public WearableExtender setHintShowBackgroundOnly(boolean param1Boolean) {
      setFlag(4, param1Boolean);
      return this;
    }
    
    public WearableExtender setStartScrollBottom(boolean param1Boolean) {
      setFlag(8, param1Boolean);
      return this;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\NotificationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */