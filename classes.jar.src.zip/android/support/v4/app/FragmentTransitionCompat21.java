package android.support.v4.app;

import android.graphics.Rect;
import android.support.annotation.RequiresApi;
import android.transition.Transition;
import android.transition.TransitionManager;
import android.transition.TransitionSet;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.List;

@RequiresApi(21)
class FragmentTransitionCompat21 extends FragmentTransitionImpl {
  private static boolean hasSimpleTarget(Transition paramTransition) {
    return (!isNullOrEmpty(paramTransition.getTargetIds()) || !isNullOrEmpty(paramTransition.getTargetNames()) || !isNullOrEmpty(paramTransition.getTargetTypes()));
  }
  
  public void addTarget(Object paramObject, View paramView) {
    if (paramObject != null)
      ((Transition)paramObject).addTarget(paramView); 
  }
  
  public void addTargets(Object paramObject, ArrayList<View> paramArrayList) {
    Transition transition = (Transition)paramObject;
    if (transition == null)
      return; 
    boolean bool = transition instanceof TransitionSet;
    byte b = 0;
    if (bool) {
      TransitionSet transitionSet = (TransitionSet)transition;
      int i = transitionSet.getTransitionCount();
      while (b < i) {
        addTargets(transitionSet.getTransitionAt(b), paramArrayList);
        b++;
      } 
    } else if (!hasSimpleTarget(transition) && isNullOrEmpty(transition.getTargets())) {
      int i = paramArrayList.size();
      while (b < i) {
        transition.addTarget(paramArrayList.get(b));
        b++;
      } 
    } 
  }
  
  public void beginDelayedTransition(ViewGroup paramViewGroup, Object paramObject) {
    TransitionManager.beginDelayedTransition(paramViewGroup, (Transition)paramObject);
  }
  
  public boolean canHandle(Object paramObject) {
    return paramObject instanceof Transition;
  }
  
  public Object cloneTransition(Object paramObject) {
    return (paramObject != null) ? ((Transition)paramObject).clone() : null;
  }
  
  public Object mergeTransitionsInSequence(Object paramObject1, Object paramObject2, Object paramObject3) {
    TransitionSet transitionSet;
    Transition transition1 = (Transition)paramObject1;
    Transition transition2 = (Transition)paramObject2;
    Transition transition3 = (Transition)paramObject3;
    if (transition1 != null && transition2 != null) {
      transitionSet = (new TransitionSet()).addTransition(transition1).addTransition(transition2).setOrdering(1);
    } else if (transitionSet == null) {
      if (transition2 != null) {
        Transition transition = transition2;
      } else {
        transitionSet = null;
      } 
    } 
    if (transition3 != null) {
      TransitionSet transitionSet1 = new TransitionSet();
      if (transitionSet != null)
        transitionSet1.addTransition((Transition)transitionSet); 
      transitionSet1.addTransition(transition3);
      return transitionSet1;
    } 
    return transitionSet;
  }
  
  public Object mergeTransitionsTogether(Object paramObject1, Object paramObject2, Object paramObject3) {
    TransitionSet transitionSet = new TransitionSet();
    if (paramObject1 != null)
      transitionSet.addTransition((Transition)paramObject1); 
    if (paramObject2 != null)
      transitionSet.addTransition((Transition)paramObject2); 
    if (paramObject3 != null)
      transitionSet.addTransition((Transition)paramObject3); 
    return transitionSet;
  }
  
  public void removeTarget(Object paramObject, View paramView) {
    if (paramObject != null)
      ((Transition)paramObject).removeTarget(paramView); 
  }
  
  public void replaceTargets(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2) {
    Transition transition = (Transition)paramObject;
    boolean bool = transition instanceof TransitionSet;
    byte b = 0;
    if (bool) {
      TransitionSet transitionSet = (TransitionSet)transition;
      int i = transitionSet.getTransitionCount();
      while (b < i) {
        replaceTargets(transitionSet.getTransitionAt(b), paramArrayList1, paramArrayList2);
        b++;
      } 
    } else if (!hasSimpleTarget(transition)) {
      List list = transition.getTargets();
      if (list != null && list.size() == paramArrayList1.size() && list.containsAll(paramArrayList1)) {
        int i;
        if (paramArrayList2 == null) {
          i = 0;
          b = 0;
        } else {
          i = paramArrayList2.size();
        } 
        while (b < i) {
          transition.addTarget(paramArrayList2.get(b));
          b++;
        } 
        for (int j = -1 + paramArrayList1.size(); j >= 0; j--)
          transition.removeTarget(paramArrayList1.get(j)); 
      } 
    } 
  }
  
  public void scheduleHideFragmentView(Object paramObject, View paramView, ArrayList<View> paramArrayList) {
    ((Transition)paramObject).addListener(new Transition.TransitionListener(this, paramView, paramArrayList) {
          public void onTransitionCancel(Transition param1Transition) {}
          
          public void onTransitionEnd(Transition param1Transition) {
            param1Transition.removeListener(this);
            this.a.setVisibility(8);
            int i = this.b.size();
            for (byte b = 0; b < i; b++)
              ((View)this.b.get(b)).setVisibility(0); 
          }
          
          public void onTransitionPause(Transition param1Transition) {}
          
          public void onTransitionResume(Transition param1Transition) {}
          
          public void onTransitionStart(Transition param1Transition) {}
        });
  }
  
  public void scheduleRemoveTargets(Object paramObject1, Object paramObject2, ArrayList<View> paramArrayList1, Object paramObject3, ArrayList<View> paramArrayList2, Object paramObject4, ArrayList<View> paramArrayList3) {
    Transition transition = (Transition)paramObject1;
    Transition.TransitionListener transitionListener = new Transition.TransitionListener(this, paramObject2, paramArrayList1, paramObject3, paramArrayList2, paramObject4, paramArrayList3) {
        public void onTransitionCancel(Transition param1Transition) {}
        
        public void onTransitionEnd(Transition param1Transition) {}
        
        public void onTransitionPause(Transition param1Transition) {}
        
        public void onTransitionResume(Transition param1Transition) {}
        
        public void onTransitionStart(Transition param1Transition) {
          if (this.a != null)
            this.g.replaceTargets(this.a, this.b, (ArrayList<View>)null); 
          if (this.c != null)
            this.g.replaceTargets(this.c, this.d, (ArrayList<View>)null); 
          if (this.e != null)
            this.g.replaceTargets(this.e, this.f, (ArrayList<View>)null); 
        }
      };
    transition.addListener(transitionListener);
  }
  
  public void setEpicenter(Object paramObject, Rect paramRect) {
    if (paramObject != null)
      ((Transition)paramObject).setEpicenterCallback(new Transition.EpicenterCallback(this, paramRect) {
            public Rect onGetEpicenter(Transition param1Transition) {
              return (this.a == null || this.a.isEmpty()) ? null : this.a;
            }
          }); 
  }
  
  public void setEpicenter(Object paramObject, View paramView) {
    if (paramView != null) {
      Transition transition = (Transition)paramObject;
      Rect rect = new Rect();
      getBoundsOnScreen(paramView, rect);
      transition.setEpicenterCallback(new Transition.EpicenterCallback(this, rect) {
            public Rect onGetEpicenter(Transition param1Transition) {
              return this.a;
            }
          });
    } 
  }
  
  public void setSharedElementTargets(Object paramObject, View paramView, ArrayList<View> paramArrayList) {
    TransitionSet transitionSet = (TransitionSet)paramObject;
    List<View> list = transitionSet.getTargets();
    list.clear();
    int i = paramArrayList.size();
    for (byte b = 0; b < i; b++)
      bfsAddViewChildren(list, paramArrayList.get(b)); 
    list.add(paramView);
    paramArrayList.add(paramView);
    addTargets(transitionSet, paramArrayList);
  }
  
  public void swapSharedElementTargets(Object paramObject, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2) {
    TransitionSet transitionSet = (TransitionSet)paramObject;
    if (transitionSet != null) {
      transitionSet.getTargets().clear();
      transitionSet.getTargets().addAll(paramArrayList2);
      replaceTargets(transitionSet, paramArrayList1, paramArrayList2);
    } 
  }
  
  public Object wrapTransitionInSet(Object paramObject) {
    if (paramObject == null)
      return null; 
    TransitionSet transitionSet = new TransitionSet();
    transitionSet.addTransition((Transition)paramObject);
    return transitionSet;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\FragmentTransitionCompat21.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */