package android.support.v4.app;

import android.arch.lifecycle.ViewModelStore;
import android.content.Context;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

final class FragmentState implements Parcelable {
  public static final Parcelable.Creator<FragmentState> CREATOR = new Parcelable.Creator<FragmentState>() {
      public FragmentState createFromParcel(Parcel param1Parcel) {
        return new FragmentState(param1Parcel);
      }
      
      public FragmentState[] newArray(int param1Int) {
        return new FragmentState[param1Int];
      }
    };
  
  final String a;
  
  final int b;
  
  final boolean c;
  
  final int d;
  
  final int e;
  
  final String f;
  
  final boolean g;
  
  final boolean h;
  
  final Bundle i;
  
  final boolean j;
  
  Bundle k;
  
  Fragment l;
  
  FragmentState(Parcel paramParcel) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    this.a = paramParcel.readString();
    this.b = paramParcel.readInt();
    if (paramParcel.readInt() != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    this.c = bool1;
    this.d = paramParcel.readInt();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readString();
    if (paramParcel.readInt() != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    this.g = bool2;
    if (paramParcel.readInt() != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    this.h = bool3;
    this.i = paramParcel.readBundle();
    int i = paramParcel.readInt();
    boolean bool4 = false;
    if (i != 0)
      bool4 = true; 
    this.j = bool4;
    this.k = paramParcel.readBundle();
  }
  
  FragmentState(Fragment paramFragment) {
    this.a = paramFragment.getClass().getName();
    this.b = paramFragment.mIndex;
    this.c = paramFragment.mFromLayout;
    this.d = paramFragment.mFragmentId;
    this.e = paramFragment.mContainerId;
    this.f = paramFragment.mTag;
    this.g = paramFragment.mRetainInstance;
    this.h = paramFragment.mDetached;
    this.i = paramFragment.mArguments;
    this.j = paramFragment.mHidden;
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Fragment instantiate(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment, FragmentManagerNonConfig paramFragmentManagerNonConfig, ViewModelStore paramViewModelStore) {
    if (this.l == null) {
      Context context = paramFragmentHostCallback.getContext();
      if (this.i != null)
        this.i.setClassLoader(context.getClassLoader()); 
      if (paramFragmentContainer != null) {
        this.l = paramFragmentContainer.instantiate(context, this.a, this.i);
      } else {
        this.l = Fragment.instantiate(context, this.a, this.i);
      } 
      if (this.k != null) {
        this.k.setClassLoader(context.getClassLoader());
        this.l.mSavedFragmentState = this.k;
      } 
      this.l.setIndex(this.b, paramFragment);
      this.l.mFromLayout = this.c;
      this.l.mRestored = true;
      this.l.mFragmentId = this.d;
      this.l.mContainerId = this.e;
      this.l.mTag = this.f;
      this.l.mRetainInstance = this.g;
      this.l.mDetached = this.h;
      this.l.mHidden = this.j;
      this.l.mFragmentManager = paramFragmentHostCallback.d;
      if (FragmentManagerImpl.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiated fragment ");
        stringBuilder.append(this.l);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
    } 
    this.l.mChildNonConfig = paramFragmentManagerNonConfig;
    this.l.mViewModelStore = paramViewModelStore;
    return this.l;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeString(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeInt(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeString(this.f);
    paramParcel.writeInt(this.g);
    paramParcel.writeInt(this.h);
    paramParcel.writeBundle(this.i);
    paramParcel.writeInt(this.j);
    paramParcel.writeBundle(this.k);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\FragmentState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */