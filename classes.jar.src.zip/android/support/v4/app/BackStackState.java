package android.support.v4.app;

import android.os.Parcel;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import java.util.ArrayList;

final class BackStackState implements Parcelable {
  public static final Parcelable.Creator<BackStackState> CREATOR = new Parcelable.Creator<BackStackState>() {
      public BackStackState createFromParcel(Parcel param1Parcel) {
        return new BackStackState(param1Parcel);
      }
      
      public BackStackState[] newArray(int param1Int) {
        return new BackStackState[param1Int];
      }
    };
  
  final int[] a;
  
  final int b;
  
  final int c;
  
  final String d;
  
  final int e;
  
  final int f;
  
  final CharSequence g;
  
  final int h;
  
  final CharSequence i;
  
  final ArrayList<String> j;
  
  final ArrayList<String> k;
  
  final boolean l;
  
  public BackStackState(Parcel paramParcel) {
    boolean bool;
    this.a = paramParcel.createIntArray();
    this.b = paramParcel.readInt();
    this.c = paramParcel.readInt();
    this.d = paramParcel.readString();
    this.e = paramParcel.readInt();
    this.f = paramParcel.readInt();
    this.g = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.h = paramParcel.readInt();
    this.i = (CharSequence)TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(paramParcel);
    this.j = paramParcel.createStringArrayList();
    this.k = paramParcel.createStringArrayList();
    if (paramParcel.readInt() != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    this.l = bool;
  }
  
  public BackStackState(BackStackRecord paramBackStackRecord) {
    int i = paramBackStackRecord.b.size();
    this.a = new int[i * 6];
    if (paramBackStackRecord.i) {
      byte b = 0;
      int j;
      for (j = 0; b < i; j = i3) {
        byte b1;
        BackStackRecord.Op op = paramBackStackRecord.b.get(b);
        int[] arrayOfInt1 = this.a;
        int k = j + 1;
        arrayOfInt1[j] = op.a;
        int[] arrayOfInt2 = this.a;
        int m = k + 1;
        if (op.b != null) {
          b1 = op.b.mIndex;
        } else {
          b1 = -1;
        } 
        arrayOfInt2[k] = b1;
        int[] arrayOfInt3 = this.a;
        int n = m + 1;
        arrayOfInt3[m] = op.c;
        int[] arrayOfInt4 = this.a;
        int i1 = n + 1;
        arrayOfInt4[n] = op.d;
        int[] arrayOfInt5 = this.a;
        int i2 = i1 + 1;
        arrayOfInt5[i1] = op.e;
        int[] arrayOfInt6 = this.a;
        int i3 = i2 + 1;
        arrayOfInt6[i2] = op.f;
        b++;
      } 
      this.b = paramBackStackRecord.g;
      this.c = paramBackStackRecord.h;
      this.d = paramBackStackRecord.k;
      this.e = paramBackStackRecord.m;
      this.f = paramBackStackRecord.n;
      this.g = paramBackStackRecord.o;
      this.h = paramBackStackRecord.p;
      this.i = paramBackStackRecord.q;
      this.j = paramBackStackRecord.r;
      this.k = paramBackStackRecord.s;
      this.l = paramBackStackRecord.t;
      return;
    } 
    throw new IllegalStateException("Not on back stack");
  }
  
  public int describeContents() {
    return 0;
  }
  
  public BackStackRecord instantiate(FragmentManagerImpl paramFragmentManagerImpl) {
    BackStackRecord backStackRecord = new BackStackRecord(paramFragmentManagerImpl);
    int i = 0;
    byte b = 0;
    while (i < this.a.length) {
      BackStackRecord.Op op = new BackStackRecord.Op();
      int[] arrayOfInt1 = this.a;
      int j = i + 1;
      op.a = arrayOfInt1[i];
      if (FragmentManagerImpl.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Instantiate ");
        stringBuilder.append(backStackRecord);
        stringBuilder.append(" op #");
        stringBuilder.append(b);
        stringBuilder.append(" base fragment #");
        stringBuilder.append(this.a[j]);
        Log.v("FragmentManager", stringBuilder.toString());
      } 
      int[] arrayOfInt2 = this.a;
      int k = j + 1;
      int m = arrayOfInt2[j];
      if (m >= 0) {
        op.b = (Fragment)paramFragmentManagerImpl.f.get(m);
      } else {
        op.b = null;
      } 
      int[] arrayOfInt3 = this.a;
      int n = k + 1;
      op.c = arrayOfInt3[k];
      int[] arrayOfInt4 = this.a;
      int i1 = n + 1;
      op.d = arrayOfInt4[n];
      int[] arrayOfInt5 = this.a;
      int i2 = i1 + 1;
      op.e = arrayOfInt5[i1];
      int[] arrayOfInt6 = this.a;
      int i3 = i2 + 1;
      op.f = arrayOfInt6[i2];
      backStackRecord.c = op.c;
      backStackRecord.d = op.d;
      backStackRecord.e = op.e;
      backStackRecord.f = op.f;
      backStackRecord.a(op);
      b++;
      i = i3;
    } 
    backStackRecord.g = this.b;
    backStackRecord.h = this.c;
    backStackRecord.k = this.d;
    backStackRecord.m = this.e;
    backStackRecord.i = true;
    backStackRecord.n = this.f;
    backStackRecord.o = this.g;
    backStackRecord.p = this.h;
    backStackRecord.q = this.i;
    backStackRecord.r = this.j;
    backStackRecord.s = this.k;
    backStackRecord.t = this.l;
    backStackRecord.a(1);
    return backStackRecord;
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeIntArray(this.a);
    paramParcel.writeInt(this.b);
    paramParcel.writeInt(this.c);
    paramParcel.writeString(this.d);
    paramParcel.writeInt(this.e);
    paramParcel.writeInt(this.f);
    TextUtils.writeToParcel(this.g, paramParcel, 0);
    paramParcel.writeInt(this.h);
    TextUtils.writeToParcel(this.i, paramParcel, 0);
    paramParcel.writeStringList(this.j);
    paramParcel.writeStringList(this.k);
    paramParcel.writeInt(this.l);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\BackStackState.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */