package android.support.v4.app;

import android.graphics.Rect;
import android.os.Build;
import android.support.v4.util.ArrayMap;
import android.support.v4.view.ViewCompat;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;

class FragmentTransition {
  private static final int[] INVERSE_OPS = new int[] { 0, 3, 0, 1, 5, 4, 7, 6, 9, 8 };
  
  private static final FragmentTransitionImpl PLATFORM_IMPL;
  
  private static final FragmentTransitionImpl SUPPORT_IMPL = resolveSupportImpl();
  
  static void a(FragmentManagerImpl paramFragmentManagerImpl, ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, boolean paramBoolean) {
    if (paramFragmentManagerImpl.l < 1)
      return; 
    SparseArray<FragmentContainerTransition> sparseArray = new SparseArray();
    for (int i = paramInt1; i < paramInt2; i++) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue()) {
        calculatePopFragments(backStackRecord, sparseArray, paramBoolean);
      } else {
        calculateFragments(backStackRecord, sparseArray, paramBoolean);
      } 
    } 
    if (sparseArray.size() != 0) {
      View view = new View(paramFragmentManagerImpl.m.getContext());
      int j = sparseArray.size();
      for (byte b = 0; b < j; b++) {
        int k = sparseArray.keyAt(b);
        ArrayMap<String, String> arrayMap = calculateNameOverrides(k, paramArrayList, paramArrayList1, paramInt1, paramInt2);
        FragmentContainerTransition fragmentContainerTransition = (FragmentContainerTransition)sparseArray.valueAt(b);
        if (paramBoolean) {
          configureTransitionsReordered(paramFragmentManagerImpl, k, fragmentContainerTransition, view, arrayMap);
        } else {
          configureTransitionsOrdered(paramFragmentManagerImpl, k, fragmentContainerTransition, view, arrayMap);
        } 
      } 
    } 
  }
  
  static boolean a() {
    return (PLATFORM_IMPL != null || SUPPORT_IMPL != null);
  }
  
  private static void addSharedElementsWithMatchingNames(ArrayList<View> paramArrayList, ArrayMap<String, View> paramArrayMap, Collection<String> paramCollection) {
    for (int i = -1 + paramArrayMap.size(); i >= 0; i--) {
      View view = (View)paramArrayMap.valueAt(i);
      if (paramCollection.contains(ViewCompat.getTransitionName(view)))
        paramArrayList.add(view); 
    } 
  }
  
  private static void addToFirstInLastOut(BackStackRecord paramBackStackRecord, BackStackRecord.Op paramOp, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean1, boolean paramBoolean2) {
    // Byte code:
    //   0: aload_1
    //   1: getfield b : Landroid/support/v4/app/Fragment;
    //   4: astore #5
    //   6: aload #5
    //   8: ifnonnull -> 12
    //   11: return
    //   12: aload #5
    //   14: getfield mContainerId : I
    //   17: istore #6
    //   19: iload #6
    //   21: ifne -> 25
    //   24: return
    //   25: iload_3
    //   26: ifeq -> 42
    //   29: getstatic android/support/v4/app/FragmentTransition.INVERSE_OPS : [I
    //   32: aload_1
    //   33: getfield a : I
    //   36: iaload
    //   37: istore #7
    //   39: goto -> 48
    //   42: aload_1
    //   43: getfield a : I
    //   46: istore #7
    //   48: iconst_0
    //   49: istore #8
    //   51: iload #7
    //   53: iconst_1
    //   54: if_icmpeq -> 286
    //   57: iload #7
    //   59: tableswitch default -> 92, 3 -> 197, 4 -> 146, 5 -> 104, 6 -> 197, 7 -> 286
    //   92: iconst_0
    //   93: istore #10
    //   95: iconst_0
    //   96: istore #11
    //   98: iconst_0
    //   99: istore #12
    //   101: goto -> 336
    //   104: iload #4
    //   106: ifeq -> 136
    //   109: aload #5
    //   111: getfield mHiddenChanged : Z
    //   114: ifeq -> 323
    //   117: aload #5
    //   119: getfield mHidden : Z
    //   122: ifne -> 323
    //   125: aload #5
    //   127: getfield mAdded : Z
    //   130: ifeq -> 323
    //   133: goto -> 317
    //   136: aload #5
    //   138: getfield mHidden : Z
    //   141: istore #9
    //   143: goto -> 326
    //   146: iload #4
    //   148: ifeq -> 178
    //   151: aload #5
    //   153: getfield mHiddenChanged : Z
    //   156: ifeq -> 245
    //   159: aload #5
    //   161: getfield mAdded : Z
    //   164: ifeq -> 245
    //   167: aload #5
    //   169: getfield mHidden : Z
    //   172: ifeq -> 245
    //   175: goto -> 239
    //   178: aload #5
    //   180: getfield mAdded : Z
    //   183: ifeq -> 245
    //   186: aload #5
    //   188: getfield mHidden : Z
    //   191: ifne -> 245
    //   194: goto -> 175
    //   197: iload #4
    //   199: ifeq -> 251
    //   202: aload #5
    //   204: getfield mAdded : Z
    //   207: ifne -> 245
    //   210: aload #5
    //   212: getfield mView : Landroid/view/View;
    //   215: ifnull -> 245
    //   218: aload #5
    //   220: getfield mView : Landroid/view/View;
    //   223: invokevirtual getVisibility : ()I
    //   226: ifne -> 245
    //   229: aload #5
    //   231: getfield mPostponedAlpha : F
    //   234: fconst_0
    //   235: fcmpl
    //   236: iflt -> 245
    //   239: iconst_1
    //   240: istore #16
    //   242: goto -> 270
    //   245: iconst_0
    //   246: istore #16
    //   248: goto -> 270
    //   251: aload #5
    //   253: getfield mAdded : Z
    //   256: ifeq -> 245
    //   259: aload #5
    //   261: getfield mHidden : Z
    //   264: ifne -> 245
    //   267: goto -> 239
    //   270: iload #16
    //   272: istore #12
    //   274: iconst_1
    //   275: istore #11
    //   277: iconst_0
    //   278: istore #10
    //   280: iconst_0
    //   281: istore #8
    //   283: goto -> 336
    //   286: iload #4
    //   288: ifeq -> 301
    //   291: aload #5
    //   293: getfield mIsNewlyAdded : Z
    //   296: istore #9
    //   298: goto -> 326
    //   301: aload #5
    //   303: getfield mAdded : Z
    //   306: ifne -> 323
    //   309: aload #5
    //   311: getfield mHidden : Z
    //   314: ifne -> 323
    //   317: iconst_1
    //   318: istore #9
    //   320: goto -> 326
    //   323: iconst_0
    //   324: istore #9
    //   326: iload #9
    //   328: istore #8
    //   330: iconst_1
    //   331: istore #10
    //   333: goto -> 95
    //   336: aload_2
    //   337: iload #6
    //   339: invokevirtual get : (I)Ljava/lang/Object;
    //   342: checkcast android/support/v4/app/FragmentTransition$FragmentContainerTransition
    //   345: astore #13
    //   347: iload #8
    //   349: ifeq -> 381
    //   352: aload #13
    //   354: aload_2
    //   355: iload #6
    //   357: invokestatic ensureContainer : (Landroid/support/v4/app/FragmentTransition$FragmentContainerTransition;Landroid/util/SparseArray;I)Landroid/support/v4/app/FragmentTransition$FragmentContainerTransition;
    //   360: astore #13
    //   362: aload #13
    //   364: aload #5
    //   366: putfield lastIn : Landroid/support/v4/app/Fragment;
    //   369: aload #13
    //   371: iload_3
    //   372: putfield lastInIsPop : Z
    //   375: aload #13
    //   377: aload_0
    //   378: putfield lastInTransaction : Landroid/support/v4/app/BackStackRecord;
    //   381: aload #13
    //   383: astore #14
    //   385: iload #4
    //   387: ifne -> 465
    //   390: iload #10
    //   392: ifeq -> 465
    //   395: aload #14
    //   397: ifnull -> 416
    //   400: aload #14
    //   402: getfield firstOut : Landroid/support/v4/app/Fragment;
    //   405: aload #5
    //   407: if_acmpne -> 416
    //   410: aload #14
    //   412: aconst_null
    //   413: putfield firstOut : Landroid/support/v4/app/Fragment;
    //   416: aload_0
    //   417: getfield a : Landroid/support/v4/app/FragmentManagerImpl;
    //   420: astore #15
    //   422: aload #5
    //   424: getfield mState : I
    //   427: iconst_1
    //   428: if_icmpge -> 465
    //   431: aload #15
    //   433: getfield l : I
    //   436: iconst_1
    //   437: if_icmplt -> 465
    //   440: aload_0
    //   441: getfield t : Z
    //   444: ifne -> 465
    //   447: aload #15
    //   449: aload #5
    //   451: invokevirtual e : (Landroid/support/v4/app/Fragment;)V
    //   454: aload #15
    //   456: aload #5
    //   458: iconst_1
    //   459: iconst_0
    //   460: iconst_0
    //   461: iconst_0
    //   462: invokevirtual a : (Landroid/support/v4/app/Fragment;IIIZ)V
    //   465: iload #12
    //   467: ifeq -> 512
    //   470: aload #14
    //   472: ifnull -> 483
    //   475: aload #14
    //   477: getfield firstOut : Landroid/support/v4/app/Fragment;
    //   480: ifnonnull -> 512
    //   483: aload #14
    //   485: aload_2
    //   486: iload #6
    //   488: invokestatic ensureContainer : (Landroid/support/v4/app/FragmentTransition$FragmentContainerTransition;Landroid/util/SparseArray;I)Landroid/support/v4/app/FragmentTransition$FragmentContainerTransition;
    //   491: astore #14
    //   493: aload #14
    //   495: aload #5
    //   497: putfield firstOut : Landroid/support/v4/app/Fragment;
    //   500: aload #14
    //   502: iload_3
    //   503: putfield firstOutIsPop : Z
    //   506: aload #14
    //   508: aload_0
    //   509: putfield firstOutTransaction : Landroid/support/v4/app/BackStackRecord;
    //   512: iload #4
    //   514: ifne -> 543
    //   517: iload #11
    //   519: ifeq -> 543
    //   522: aload #14
    //   524: ifnull -> 543
    //   527: aload #14
    //   529: getfield lastIn : Landroid/support/v4/app/Fragment;
    //   532: aload #5
    //   534: if_acmpne -> 543
    //   537: aload #14
    //   539: aconst_null
    //   540: putfield lastIn : Landroid/support/v4/app/Fragment;
    //   543: return
  }
  
  public static void calculateFragments(BackStackRecord paramBackStackRecord, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean) {
    int i = paramBackStackRecord.b.size();
    for (byte b = 0; b < i; b++)
      addToFirstInLastOut(paramBackStackRecord, paramBackStackRecord.b.get(b), paramSparseArray, false, paramBoolean); 
  }
  
  private static ArrayMap<String, String> calculateNameOverrides(int paramInt1, ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt2, int paramInt3) {
    ArrayMap<String, String> arrayMap = new ArrayMap();
    for (int i = paramInt3 - 1; i >= paramInt2; i--) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (backStackRecord.b(paramInt1)) {
        boolean bool = ((Boolean)paramArrayList1.get(i)).booleanValue();
        if (backStackRecord.r != null) {
          ArrayList<String> arrayList1;
          ArrayList<String> arrayList2;
          int j = backStackRecord.r.size();
          if (bool) {
            arrayList1 = backStackRecord.r;
            arrayList2 = backStackRecord.s;
          } else {
            ArrayList<String> arrayList = backStackRecord.r;
            arrayList1 = backStackRecord.s;
            arrayList2 = arrayList;
          } 
          for (byte b = 0; b < j; b++) {
            String str1 = arrayList2.get(b);
            String str2 = arrayList1.get(b);
            String str3 = (String)arrayMap.remove(str2);
            if (str3 != null) {
              arrayMap.put(str1, str3);
            } else {
              arrayMap.put(str1, str2);
            } 
          } 
        } 
      } 
    } 
    return arrayMap;
  }
  
  public static void calculatePopFragments(BackStackRecord paramBackStackRecord, SparseArray<FragmentContainerTransition> paramSparseArray, boolean paramBoolean) {
    if (!paramBackStackRecord.a.n.onHasView())
      return; 
    for (int i = paramBackStackRecord.b.size() - 1; i >= 0; i--)
      addToFirstInLastOut(paramBackStackRecord, paramBackStackRecord.b.get(i), paramSparseArray, true, paramBoolean); 
  }
  
  private static void callSharedElementStartEnd(Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean1, ArrayMap<String, View> paramArrayMap, boolean paramBoolean2) {
    SharedElementCallback sharedElementCallback;
    if (paramBoolean1) {
      sharedElementCallback = paramFragment2.getEnterTransitionCallback();
    } else {
      sharedElementCallback = paramFragment1.getEnterTransitionCallback();
    } 
    if (sharedElementCallback != null) {
      int i;
      ArrayList<Object> arrayList1 = new ArrayList();
      ArrayList<Object> arrayList2 = new ArrayList();
      byte b = 0;
      if (paramArrayMap == null) {
        b = 0;
        i = 0;
      } else {
        i = paramArrayMap.size();
      } 
      while (b < i) {
        arrayList2.add(paramArrayMap.keyAt(b));
        arrayList1.add(paramArrayMap.valueAt(b));
        b++;
      } 
      if (paramBoolean2) {
        sharedElementCallback.onSharedElementStart(arrayList2, arrayList1, null);
        return;
      } 
      sharedElementCallback.onSharedElementEnd(arrayList2, arrayList1, null);
    } 
  }
  
  private static boolean canHandleAll(FragmentTransitionImpl paramFragmentTransitionImpl, List<Object> paramList) {
    int i = paramList.size();
    for (byte b = 0; b < i; b++) {
      if (!paramFragmentTransitionImpl.canHandle(paramList.get(b)))
        return false; 
    } 
    return true;
  }
  
  private static ArrayMap<String, View> captureInSharedElements(FragmentTransitionImpl paramFragmentTransitionImpl, ArrayMap<String, String> paramArrayMap, Object paramObject, FragmentContainerTransition paramFragmentContainerTransition) {
    SharedElementCallback sharedElementCallback;
    ArrayList<String> arrayList;
    Fragment fragment = paramFragmentContainerTransition.lastIn;
    View view = fragment.getView();
    if (paramArrayMap.isEmpty() || paramObject == null || view == null) {
      paramArrayMap.clear();
      return null;
    } 
    ArrayMap<String, View> arrayMap = new ArrayMap();
    paramFragmentTransitionImpl.a((Map<String, View>)arrayMap, view);
    BackStackRecord backStackRecord = paramFragmentContainerTransition.lastInTransaction;
    if (paramFragmentContainerTransition.lastInIsPop) {
      sharedElementCallback = fragment.getExitTransitionCallback();
      arrayList = backStackRecord.r;
    } else {
      sharedElementCallback = fragment.getEnterTransitionCallback();
      arrayList = backStackRecord.s;
    } 
    if (arrayList != null) {
      arrayMap.retainAll(arrayList);
      arrayMap.retainAll(paramArrayMap.values());
    } 
    if (sharedElementCallback != null) {
      sharedElementCallback.onMapSharedElements(arrayList, (Map<String, View>)arrayMap);
      for (int i = -1 + arrayList.size(); i >= 0; i--) {
        String str = arrayList.get(i);
        View view1 = (View)arrayMap.get(str);
        if (view1 == null) {
          String str1 = findKeyForValue(paramArrayMap, str);
          if (str1 != null)
            paramArrayMap.remove(str1); 
        } else if (!str.equals(ViewCompat.getTransitionName(view1))) {
          String str1 = findKeyForValue(paramArrayMap, str);
          if (str1 != null)
            paramArrayMap.put(str1, ViewCompat.getTransitionName(view1)); 
        } 
      } 
    } else {
      retainValues(paramArrayMap, arrayMap);
    } 
    return arrayMap;
  }
  
  private static ArrayMap<String, View> captureOutSharedElements(FragmentTransitionImpl paramFragmentTransitionImpl, ArrayMap<String, String> paramArrayMap, Object paramObject, FragmentContainerTransition paramFragmentContainerTransition) {
    SharedElementCallback sharedElementCallback;
    ArrayList<String> arrayList;
    if (paramArrayMap.isEmpty() || paramObject == null) {
      paramArrayMap.clear();
      return null;
    } 
    Fragment fragment = paramFragmentContainerTransition.firstOut;
    ArrayMap<String, View> arrayMap = new ArrayMap();
    paramFragmentTransitionImpl.a((Map<String, View>)arrayMap, fragment.getView());
    BackStackRecord backStackRecord = paramFragmentContainerTransition.firstOutTransaction;
    if (paramFragmentContainerTransition.firstOutIsPop) {
      sharedElementCallback = fragment.getEnterTransitionCallback();
      arrayList = backStackRecord.s;
    } else {
      sharedElementCallback = fragment.getExitTransitionCallback();
      arrayList = backStackRecord.r;
    } 
    arrayMap.retainAll(arrayList);
    if (sharedElementCallback != null) {
      sharedElementCallback.onMapSharedElements(arrayList, (Map<String, View>)arrayMap);
      for (int i = -1 + arrayList.size(); i >= 0; i--) {
        String str = arrayList.get(i);
        View view = (View)arrayMap.get(str);
        if (view == null) {
          paramArrayMap.remove(str);
        } else if (!str.equals(ViewCompat.getTransitionName(view))) {
          String str1 = (String)paramArrayMap.remove(str);
          paramArrayMap.put(ViewCompat.getTransitionName(view), str1);
        } 
      } 
    } else {
      paramArrayMap.retainAll(arrayMap.keySet());
    } 
    return arrayMap;
  }
  
  private static FragmentTransitionImpl chooseImpl(Fragment paramFragment1, Fragment paramFragment2) {
    ArrayList<Object> arrayList = new ArrayList();
    if (paramFragment1 != null) {
      Object object1 = paramFragment1.getExitTransition();
      if (object1 != null)
        arrayList.add(object1); 
      Object object2 = paramFragment1.getReturnTransition();
      if (object2 != null)
        arrayList.add(object2); 
      Object object3 = paramFragment1.getSharedElementReturnTransition();
      if (object3 != null)
        arrayList.add(object3); 
    } 
    if (paramFragment2 != null) {
      Object object1 = paramFragment2.getEnterTransition();
      if (object1 != null)
        arrayList.add(object1); 
      Object object2 = paramFragment2.getReenterTransition();
      if (object2 != null)
        arrayList.add(object2); 
      Object object3 = paramFragment2.getSharedElementEnterTransition();
      if (object3 != null)
        arrayList.add(object3); 
    } 
    if (arrayList.isEmpty())
      return null; 
    if (PLATFORM_IMPL != null && canHandleAll(PLATFORM_IMPL, arrayList))
      return PLATFORM_IMPL; 
    if (SUPPORT_IMPL != null && canHandleAll(SUPPORT_IMPL, arrayList))
      return SUPPORT_IMPL; 
    if (PLATFORM_IMPL == null && SUPPORT_IMPL == null)
      return null; 
    throw new IllegalArgumentException("Invalid Transition types");
  }
  
  private static ArrayList<View> configureEnteringExitingViews(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList, View paramView) {
    ArrayList arrayList;
    if (paramObject != null) {
      arrayList = new ArrayList();
      View view = paramFragment.getView();
      if (view != null)
        paramFragmentTransitionImpl.a(arrayList, view); 
      if (paramArrayList != null)
        arrayList.removeAll(paramArrayList); 
      if (!arrayList.isEmpty()) {
        arrayList.add(paramView);
        paramFragmentTransitionImpl.addTargets(paramObject, arrayList);
        return arrayList;
      } 
    } else {
      arrayList = null;
    } 
    return arrayList;
  }
  
  private static Object configureSharedElementsOrdered(FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, View paramView, ArrayMap<String, String> paramArrayMap, FragmentContainerTransition paramFragmentContainerTransition, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramFragmentContainerTransition.lastIn;
    Fragment fragment2 = paramFragmentContainerTransition.firstOut;
    if (fragment1 != null) {
      Object object1;
      ArrayMap<String, String> arrayMap;
      Object object2;
      Rect rect;
      if (fragment2 == null)
        return null; 
      boolean bool = paramFragmentContainerTransition.lastInIsPop;
      if (paramArrayMap.isEmpty()) {
        arrayMap = paramArrayMap;
        object1 = null;
      } else {
        object1 = getSharedElementTransition(paramFragmentTransitionImpl, fragment1, fragment2, bool);
        arrayMap = paramArrayMap;
      } 
      ArrayMap<String, View> arrayMap1 = captureOutSharedElements(paramFragmentTransitionImpl, arrayMap, object1, paramFragmentContainerTransition);
      if (paramArrayMap.isEmpty()) {
        object2 = null;
      } else {
        paramArrayList1.addAll(arrayMap1.values());
        object2 = object1;
      } 
      if (paramObject1 == null && paramObject2 == null && object2 == null)
        return null; 
      callSharedElementStartEnd(fragment1, fragment2, bool, arrayMap1, true);
      if (object2 != null) {
        rect = new Rect();
        paramFragmentTransitionImpl.setSharedElementTargets(object2, paramView, paramArrayList1);
        boolean bool1 = paramFragmentContainerTransition.firstOutIsPop;
        BackStackRecord backStackRecord = paramFragmentContainerTransition.firstOutTransaction;
        setOutEpicenter(paramFragmentTransitionImpl, object2, paramObject2, arrayMap1, bool1, backStackRecord);
        if (paramObject1 != null)
          paramFragmentTransitionImpl.setEpicenter(paramObject1, rect); 
      } else {
        rect = null;
      } 
      Runnable runnable = new Runnable(paramFragmentTransitionImpl, paramArrayMap, object2, paramFragmentContainerTransition, paramArrayList2, paramView, fragment1, fragment2, bool, paramArrayList1, paramObject1, rect) {
          public void run() {
            ArrayMap arrayMap = FragmentTransition.a(this.a, this.b, this.c, this.d);
            if (arrayMap != null) {
              this.e.addAll(arrayMap.values());
              this.e.add(this.f);
            } 
            FragmentTransition.a(this.g, this.h, this.i, arrayMap, false);
            if (this.c != null) {
              this.a.swapSharedElementTargets(this.c, this.j, this.e);
              View view = FragmentTransition.a(arrayMap, this.d, this.k, this.i);
              if (view != null)
                this.a.getBoundsOnScreen(view, this.l); 
            } 
          }
        };
      OneShotPreDrawListener.add((View)paramViewGroup, runnable);
      return object2;
    } 
    return null;
  }
  
  private static Object configureSharedElementsReordered(FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, View paramView, ArrayMap<String, String> paramArrayMap, FragmentContainerTransition paramFragmentContainerTransition, ArrayList<View> paramArrayList1, ArrayList<View> paramArrayList2, Object paramObject1, Object paramObject2) {
    Fragment fragment1 = paramFragmentContainerTransition.lastIn;
    Fragment fragment2 = paramFragmentContainerTransition.firstOut;
    if (fragment1 != null)
      fragment1.getView().setVisibility(0); 
    if (fragment1 != null) {
      Object object1;
      Object object2;
      View view;
      Rect rect;
      if (fragment2 == null)
        return null; 
      boolean bool = paramFragmentContainerTransition.lastInIsPop;
      if (paramArrayMap.isEmpty()) {
        object1 = null;
      } else {
        object1 = getSharedElementTransition(paramFragmentTransitionImpl, fragment1, fragment2, bool);
      } 
      ArrayMap<String, View> arrayMap1 = captureOutSharedElements(paramFragmentTransitionImpl, paramArrayMap, object1, paramFragmentContainerTransition);
      ArrayMap<String, View> arrayMap2 = captureInSharedElements(paramFragmentTransitionImpl, paramArrayMap, object1, paramFragmentContainerTransition);
      if (paramArrayMap.isEmpty()) {
        if (arrayMap1 != null)
          arrayMap1.clear(); 
        if (arrayMap2 != null)
          arrayMap2.clear(); 
        object2 = null;
      } else {
        addSharedElementsWithMatchingNames(paramArrayList1, arrayMap1, paramArrayMap.keySet());
        addSharedElementsWithMatchingNames(paramArrayList2, arrayMap2, paramArrayMap.values());
        object2 = object1;
      } 
      if (paramObject1 == null && paramObject2 == null && object2 == null)
        return null; 
      callSharedElementStartEnd(fragment1, fragment2, bool, arrayMap1, true);
      if (object2 != null) {
        paramArrayList2.add(paramView);
        paramFragmentTransitionImpl.setSharedElementTargets(object2, paramView, paramArrayList1);
        boolean bool1 = paramFragmentContainerTransition.firstOutIsPop;
        BackStackRecord backStackRecord = paramFragmentContainerTransition.firstOutTransaction;
        setOutEpicenter(paramFragmentTransitionImpl, object2, paramObject2, arrayMap1, bool1, backStackRecord);
        Rect rect1 = new Rect();
        View view1 = getInEpicenterView(arrayMap2, paramFragmentContainerTransition, paramObject1, bool);
        if (view1 != null)
          paramFragmentTransitionImpl.setEpicenter(paramObject1, rect1); 
        rect = rect1;
        view = view1;
      } else {
        view = null;
        rect = null;
      } 
      Runnable runnable = new Runnable(fragment1, fragment2, bool, arrayMap2, view, paramFragmentTransitionImpl, rect) {
          public void run() {
            FragmentTransition.a(this.a, this.b, this.c, this.d, false);
            if (this.e != null)
              this.f.getBoundsOnScreen(this.e, this.g); 
          }
        };
      OneShotPreDrawListener.add((View)paramViewGroup, runnable);
      return object2;
    } 
    return null;
  }
  
  private static void configureTransitionsOrdered(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, FragmentContainerTransition paramFragmentContainerTransition, View paramView, ArrayMap<String, String> paramArrayMap) {
    ViewGroup viewGroup;
    Object object4;
    Object object5;
    if (paramFragmentManagerImpl.n.onHasView()) {
      viewGroup = (ViewGroup)paramFragmentManagerImpl.n.onFindViewById(paramInt);
    } else {
      viewGroup = null;
    } 
    if (viewGroup == null)
      return; 
    Fragment fragment1 = paramFragmentContainerTransition.lastIn;
    Fragment fragment2 = paramFragmentContainerTransition.firstOut;
    FragmentTransitionImpl fragmentTransitionImpl = chooseImpl(fragment2, fragment1);
    if (fragmentTransitionImpl == null)
      return; 
    boolean bool1 = paramFragmentContainerTransition.lastInIsPop;
    boolean bool2 = paramFragmentContainerTransition.firstOutIsPop;
    Object object1 = getEnterTransition(fragmentTransitionImpl, fragment1, bool1);
    Object object2 = getExitTransition(fragmentTransitionImpl, fragment2, bool2);
    ArrayList<View> arrayList1 = new ArrayList();
    ArrayList<View> arrayList2 = new ArrayList();
    Object object3 = configureSharedElementsOrdered(fragmentTransitionImpl, viewGroup, paramView, paramArrayMap, paramFragmentContainerTransition, arrayList1, arrayList2, object1, object2);
    if (object1 == null && object3 == null) {
      object4 = object2;
      if (object4 == null)
        return; 
    } else {
      object4 = object2;
    } 
    ArrayList<View> arrayList3 = configureEnteringExitingViews(fragmentTransitionImpl, object4, fragment2, arrayList1, paramView);
    if (arrayList3 == null || arrayList3.isEmpty()) {
      object5 = null;
    } else {
      object5 = object4;
    } 
    fragmentTransitionImpl.addTarget(object1, paramView);
    boolean bool3 = paramFragmentContainerTransition.lastInIsPop;
    Object object6 = mergeTransitions(fragmentTransitionImpl, object1, object5, object3, fragment1, bool3);
    if (object6 != null) {
      ArrayList<View> arrayList = new ArrayList();
      fragmentTransitionImpl.scheduleRemoveTargets(object6, object1, arrayList, object5, arrayList3, object3, arrayList2);
      scheduleTargetChange(fragmentTransitionImpl, viewGroup, fragment1, paramView, arrayList2, object1, arrayList, object5, arrayList3);
      fragmentTransitionImpl.a((View)viewGroup, arrayList2, (Map<String, String>)paramArrayMap);
      fragmentTransitionImpl.beginDelayedTransition(viewGroup, object6);
      fragmentTransitionImpl.a(viewGroup, arrayList2, (Map<String, String>)paramArrayMap);
    } 
  }
  
  private static void configureTransitionsReordered(FragmentManagerImpl paramFragmentManagerImpl, int paramInt, FragmentContainerTransition paramFragmentContainerTransition, View paramView, ArrayMap<String, String> paramArrayMap) {
    ViewGroup viewGroup1;
    Object object4;
    if (paramFragmentManagerImpl.n.onHasView()) {
      viewGroup1 = (ViewGroup)paramFragmentManagerImpl.n.onFindViewById(paramInt);
    } else {
      viewGroup1 = null;
    } 
    ViewGroup viewGroup2 = viewGroup1;
    if (viewGroup2 == null)
      return; 
    Fragment fragment1 = paramFragmentContainerTransition.lastIn;
    Fragment fragment2 = paramFragmentContainerTransition.firstOut;
    FragmentTransitionImpl fragmentTransitionImpl = chooseImpl(fragment2, fragment1);
    if (fragmentTransitionImpl == null)
      return; 
    boolean bool1 = paramFragmentContainerTransition.lastInIsPop;
    boolean bool2 = paramFragmentContainerTransition.firstOutIsPop;
    ArrayList<View> arrayList1 = new ArrayList();
    ArrayList<View> arrayList2 = new ArrayList();
    Object object1 = getEnterTransition(fragmentTransitionImpl, fragment1, bool1);
    Object object2 = getExitTransition(fragmentTransitionImpl, fragment2, bool2);
    Object object3 = configureSharedElementsReordered(fragmentTransitionImpl, viewGroup2, paramView, paramArrayMap, paramFragmentContainerTransition, arrayList2, arrayList1, object1, object2);
    if (object1 == null && object3 == null) {
      object4 = object2;
      if (object4 == null)
        return; 
    } else {
      object4 = object2;
    } 
    ArrayList<View> arrayList3 = configureEnteringExitingViews(fragmentTransitionImpl, object4, fragment2, arrayList2, paramView);
    ArrayList<View> arrayList4 = configureEnteringExitingViews(fragmentTransitionImpl, object1, fragment1, arrayList1, paramView);
    setViewVisibility(arrayList4, 4);
    Object object5 = mergeTransitions(fragmentTransitionImpl, object1, object4, object3, fragment1, bool1);
    if (object5 != null) {
      replaceHide(fragmentTransitionImpl, object4, fragment2, arrayList3);
      ArrayList<String> arrayList = fragmentTransitionImpl.a(arrayList1);
      fragmentTransitionImpl.scheduleRemoveTargets(object5, object1, arrayList4, object4, arrayList3, object3, arrayList1);
      fragmentTransitionImpl.beginDelayedTransition(viewGroup2, object5);
      fragmentTransitionImpl.a((View)viewGroup2, arrayList2, arrayList1, arrayList, (Map<String, String>)paramArrayMap);
      setViewVisibility(arrayList4, 0);
      fragmentTransitionImpl.swapSharedElementTargets(object3, arrayList2, arrayList1);
    } 
  }
  
  private static FragmentContainerTransition ensureContainer(FragmentContainerTransition paramFragmentContainerTransition, SparseArray<FragmentContainerTransition> paramSparseArray, int paramInt) {
    if (paramFragmentContainerTransition == null) {
      paramFragmentContainerTransition = new FragmentContainerTransition();
      paramSparseArray.put(paramInt, paramFragmentContainerTransition);
    } 
    return paramFragmentContainerTransition;
  }
  
  private static String findKeyForValue(ArrayMap<String, String> paramArrayMap, String paramString) {
    int i = paramArrayMap.size();
    for (byte b = 0; b < i; b++) {
      if (paramString.equals(paramArrayMap.valueAt(b)))
        return (String)paramArrayMap.keyAt(b); 
    } 
    return null;
  }
  
  private static Object getEnterTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.getReenterTransition();
    } else {
      object = paramFragment.getEnterTransition();
    } 
    return paramFragmentTransitionImpl.cloneTransition(object);
  }
  
  private static Object getExitTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment, boolean paramBoolean) {
    Object object;
    if (paramFragment == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment.getReturnTransition();
    } else {
      object = paramFragment.getExitTransition();
    } 
    return paramFragmentTransitionImpl.cloneTransition(object);
  }
  
  private static View getInEpicenterView(ArrayMap<String, View> paramArrayMap, FragmentContainerTransition paramFragmentContainerTransition, Object paramObject, boolean paramBoolean) {
    BackStackRecord backStackRecord = paramFragmentContainerTransition.lastInTransaction;
    if (paramObject != null && paramArrayMap != null && backStackRecord.r != null && !backStackRecord.r.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = backStackRecord.r.get(0);
      } else {
        str = backStackRecord.s.get(0);
      } 
      return (View)paramArrayMap.get(str);
    } 
    return null;
  }
  
  private static Object getSharedElementTransition(FragmentTransitionImpl paramFragmentTransitionImpl, Fragment paramFragment1, Fragment paramFragment2, boolean paramBoolean) {
    Object object;
    if (paramFragment1 == null || paramFragment2 == null)
      return null; 
    if (paramBoolean) {
      object = paramFragment2.getSharedElementReturnTransition();
    } else {
      object = paramFragment1.getSharedElementEnterTransition();
    } 
    return paramFragmentTransitionImpl.wrapTransitionInSet(paramFragmentTransitionImpl.cloneTransition(object));
  }
  
  private static Object mergeTransitions(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject1, Object paramObject2, Object paramObject3, Fragment paramFragment, boolean paramBoolean) {
    boolean bool;
    if (paramObject1 != null && paramObject2 != null && paramFragment != null) {
      if (paramBoolean) {
        bool = paramFragment.getAllowReturnTransitionOverlap();
      } else {
        bool = paramFragment.getAllowEnterTransitionOverlap();
      } 
    } else {
      bool = true;
    } 
    return bool ? paramFragmentTransitionImpl.mergeTransitionsTogether(paramObject2, paramObject1, paramObject3) : paramFragmentTransitionImpl.mergeTransitionsInSequence(paramObject2, paramObject1, paramObject3);
  }
  
  private static void replaceHide(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject, Fragment paramFragment, ArrayList<View> paramArrayList) {
    if (paramFragment != null && paramObject != null && paramFragment.mAdded && paramFragment.mHidden && paramFragment.mHiddenChanged) {
      paramFragment.setHideReplaced(true);
      paramFragmentTransitionImpl.scheduleHideFragmentView(paramObject, paramFragment.getView(), paramArrayList);
      OneShotPreDrawListener.add((View)paramFragment.mContainer, new Runnable(paramArrayList) {
            public void run() {
              FragmentTransition.a(this.a, 4);
            }
          });
    } 
  }
  
  private static FragmentTransitionImpl resolveSupportImpl() {
    try {
      return Class.forName("android.support.transition.FragmentTransitionSupport").getDeclaredConstructor(new Class[0]).newInstance(new Object[0]);
    } catch (Exception exception) {
      return null;
    } 
  }
  
  private static void retainValues(ArrayMap<String, String> paramArrayMap, ArrayMap<String, View> paramArrayMap1) {
    for (int i = -1 + paramArrayMap.size(); i >= 0; i--) {
      if (!paramArrayMap1.containsKey(paramArrayMap.valueAt(i)))
        paramArrayMap.removeAt(i); 
    } 
  }
  
  private static void scheduleTargetChange(FragmentTransitionImpl paramFragmentTransitionImpl, ViewGroup paramViewGroup, Fragment paramFragment, View paramView, ArrayList<View> paramArrayList1, Object paramObject1, ArrayList<View> paramArrayList2, Object paramObject2, ArrayList<View> paramArrayList3) {
    Runnable runnable = new Runnable(paramObject1, paramFragmentTransitionImpl, paramView, paramFragment, paramArrayList1, paramArrayList2, paramArrayList3, paramObject2) {
        public void run() {
          if (this.a != null) {
            this.b.removeTarget(this.a, this.c);
            ArrayList arrayList = FragmentTransition.a(this.b, this.a, this.d, this.e, this.c);
            this.f.addAll(arrayList);
          } 
          if (this.g != null) {
            if (this.h != null) {
              ArrayList<View> arrayList = new ArrayList();
              arrayList.add(this.c);
              this.b.replaceTargets(this.h, this.g, arrayList);
            } 
            this.g.clear();
            this.g.add(this.c);
          } 
        }
      };
    OneShotPreDrawListener.add((View)paramViewGroup, runnable);
  }
  
  private static void setOutEpicenter(FragmentTransitionImpl paramFragmentTransitionImpl, Object paramObject1, Object paramObject2, ArrayMap<String, View> paramArrayMap, boolean paramBoolean, BackStackRecord paramBackStackRecord) {
    if (paramBackStackRecord.r != null && !paramBackStackRecord.r.isEmpty()) {
      String str;
      if (paramBoolean) {
        str = paramBackStackRecord.s.get(0);
      } else {
        str = paramBackStackRecord.r.get(0);
      } 
      View view = (View)paramArrayMap.get(str);
      paramFragmentTransitionImpl.setEpicenter(paramObject1, view);
      if (paramObject2 != null)
        paramFragmentTransitionImpl.setEpicenter(paramObject2, view); 
    } 
  }
  
  private static void setViewVisibility(ArrayList<View> paramArrayList, int paramInt) {
    if (paramArrayList == null)
      return; 
    for (int i = -1 + paramArrayList.size(); i >= 0; i--)
      ((View)paramArrayList.get(i)).setVisibility(paramInt); 
  }
  
  static {
    FragmentTransitionImpl fragmentTransitionImpl;
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 21) {
      fragmentTransitionImpl = new FragmentTransitionCompat21();
    } else {
      fragmentTransitionImpl = null;
    } 
    PLATFORM_IMPL = fragmentTransitionImpl;
  }
  
  static class FragmentContainerTransition {
    public Fragment firstOut;
    
    public boolean firstOutIsPop;
    
    public BackStackRecord firstOutTransaction;
    
    public Fragment lastIn;
    
    public boolean lastInIsPop;
    
    public BackStackRecord lastInTransaction;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\FragmentTransition.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */