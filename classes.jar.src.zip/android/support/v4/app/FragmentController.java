package android.support.v4.app;

import android.content.Context;
import android.content.res.Configuration;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.util.SimpleArrayMap;
import android.util.AttributeSet;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public class FragmentController {
  private final FragmentHostCallback<?> mHost;
  
  private FragmentController(FragmentHostCallback<?> paramFragmentHostCallback) {
    this.mHost = paramFragmentHostCallback;
  }
  
  public static FragmentController createController(FragmentHostCallback<?> paramFragmentHostCallback) {
    return new FragmentController(paramFragmentHostCallback);
  }
  
  public void attachHost(Fragment paramFragment) {
    this.mHost.d.attachController(this.mHost, this.mHost, paramFragment);
  }
  
  public void dispatchActivityCreated() {
    this.mHost.d.dispatchActivityCreated();
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    this.mHost.d.dispatchConfigurationChanged(paramConfiguration);
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    return this.mHost.d.dispatchContextItemSelected(paramMenuItem);
  }
  
  public void dispatchCreate() {
    this.mHost.d.dispatchCreate();
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    return this.mHost.d.dispatchCreateOptionsMenu(paramMenu, paramMenuInflater);
  }
  
  public void dispatchDestroy() {
    this.mHost.d.dispatchDestroy();
  }
  
  public void dispatchDestroyView() {
    this.mHost.d.dispatchDestroyView();
  }
  
  public void dispatchLowMemory() {
    this.mHost.d.dispatchLowMemory();
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    this.mHost.d.dispatchMultiWindowModeChanged(paramBoolean);
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    return this.mHost.d.dispatchOptionsItemSelected(paramMenuItem);
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    this.mHost.d.dispatchOptionsMenuClosed(paramMenu);
  }
  
  public void dispatchPause() {
    this.mHost.d.dispatchPause();
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    this.mHost.d.dispatchPictureInPictureModeChanged(paramBoolean);
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    return this.mHost.d.dispatchPrepareOptionsMenu(paramMenu);
  }
  
  public void dispatchReallyStop() {
    this.mHost.d.dispatchReallyStop();
  }
  
  public void dispatchResume() {
    this.mHost.d.dispatchResume();
  }
  
  public void dispatchStart() {
    this.mHost.d.dispatchStart();
  }
  
  public void dispatchStop() {
    this.mHost.d.dispatchStop();
  }
  
  @Deprecated
  public void doLoaderDestroy() {}
  
  @Deprecated
  public void doLoaderRetain() {}
  
  @Deprecated
  public void doLoaderStart() {}
  
  @Deprecated
  public void doLoaderStop(boolean paramBoolean) {}
  
  @Deprecated
  public void dumpLoaders(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public boolean execPendingActions() {
    return this.mHost.d.execPendingActions();
  }
  
  @Nullable
  public Fragment findFragmentByWho(String paramString) {
    return this.mHost.d.findFragmentByWho(paramString);
  }
  
  public List<Fragment> getActiveFragments(List<Fragment> paramList) {
    return this.mHost.d.getActiveFragments();
  }
  
  public int getActiveFragmentsCount() {
    return this.mHost.d.getActiveFragmentCount();
  }
  
  public FragmentManager getSupportFragmentManager() {
    return this.mHost.getFragmentManagerImpl();
  }
  
  @Deprecated
  public LoaderManager getSupportLoaderManager() {
    return null;
  }
  
  public void noteStateNotSaved() {
    this.mHost.d.noteStateNotSaved();
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return this.mHost.d.onCreateView(paramView, paramString, paramContext, paramAttributeSet);
  }
  
  @Deprecated
  public void reportLoaderStart() {}
  
  public void restoreAllState(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    this.mHost.d.a(paramParcelable, paramFragmentManagerNonConfig);
  }
  
  @Deprecated
  public void restoreAllState(Parcelable paramParcelable, List<Fragment> paramList) {
    this.mHost.d.a(paramParcelable, new FragmentManagerNonConfig(paramList, null, null));
  }
  
  @Deprecated
  public void restoreLoaderNonConfig(SimpleArrayMap<String, LoaderManager> paramSimpleArrayMap) {}
  
  @Deprecated
  public SimpleArrayMap<String, LoaderManager> retainLoaderNonConfig() {
    return null;
  }
  
  public FragmentManagerNonConfig retainNestedNonConfig() {
    return this.mHost.d.d();
  }
  
  @Deprecated
  public List<Fragment> retainNonConfig() {
    FragmentManagerNonConfig fragmentManagerNonConfig = this.mHost.d.d();
    return (fragmentManagerNonConfig != null) ? fragmentManagerNonConfig.getFragments() : null;
  }
  
  public Parcelable saveAllState() {
    return this.mHost.d.f();
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\FragmentController.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */