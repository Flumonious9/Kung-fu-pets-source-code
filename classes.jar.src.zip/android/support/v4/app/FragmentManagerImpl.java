package android.support.v4.app;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.AnimatorSet;
import android.animation.PropertyValuesHolder;
import android.animation.ValueAnimator;
import android.arch.lifecycle.ViewModelStore;
import android.content.Context;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.os.Build;
import android.os.Bundle;
import android.os.Looper;
import android.os.Parcelable;
import android.support.annotation.CallSuper;
import android.support.annotation.NonNull;
import android.support.v4.util.ArraySet;
import android.support.v4.util.DebugUtils;
import android.support.v4.util.LogWriter;
import android.support.v4.util.Pair;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.ScaleAnimation;
import android.view.animation.Transformation;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.io.Writer;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

final class FragmentManagerImpl extends FragmentManager implements LayoutInflater.Factory2 {
  public static final int ANIM_STYLE_CLOSE_ENTER = 3;
  
  public static final int ANIM_STYLE_CLOSE_EXIT = 4;
  
  public static final int ANIM_STYLE_FADE_ENTER = 5;
  
  public static final int ANIM_STYLE_FADE_EXIT = 6;
  
  public static final int ANIM_STYLE_OPEN_ENTER = 1;
  
  public static final int ANIM_STYLE_OPEN_EXIT = 2;
  
  static final Interpolator E = (Interpolator)new DecelerateInterpolator(2.5F);
  
  static final Interpolator F = (Interpolator)new DecelerateInterpolator(1.5F);
  
  static final Interpolator G = (Interpolator)new AccelerateInterpolator(2.5F);
  
  static final Interpolator H = (Interpolator)new AccelerateInterpolator(1.5F);
  
  static boolean a = false;
  
  static Field q;
  
  SparseArray<Parcelable> A = null;
  
  ArrayList<StartEnterTransitionListener> B;
  
  FragmentManagerNonConfig C;
  
  Runnable D = new Runnable(this) {
      public void run() {
        this.a.execPendingActions();
      }
    };
  
  ArrayList<OpGenerator> b;
  
  boolean c;
  
  int d = 0;
  
  final ArrayList<Fragment> e = new ArrayList<Fragment>();
  
  SparseArray<Fragment> f;
  
  ArrayList<BackStackRecord> g;
  
  ArrayList<Fragment> h;
  
  ArrayList<BackStackRecord> i;
  
  ArrayList<Integer> j;
  
  ArrayList<FragmentManager.OnBackStackChangedListener> k;
  
  int l = 0;
  
  FragmentHostCallback m;
  
  private final CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>> mLifecycleCallbacks = new CopyOnWriteArrayList<Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean>>();
  
  FragmentContainer n;
  
  Fragment o;
  
  Fragment p;
  
  boolean r;
  
  boolean s;
  
  boolean t;
  
  String u;
  
  boolean v;
  
  ArrayList<BackStackRecord> w;
  
  ArrayList<Boolean> x;
  
  ArrayList<Fragment> y;
  
  Bundle z = null;
  
  static AnimationOrAnimator a(Context paramContext, float paramFloat1, float paramFloat2) {
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat1, paramFloat2);
    alphaAnimation.setInterpolator(F);
    alphaAnimation.setDuration(220L);
    return new AnimationOrAnimator((Animation)alphaAnimation);
  }
  
  static AnimationOrAnimator a(Context paramContext, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    AnimationSet animationSet = new AnimationSet(false);
    ScaleAnimation scaleAnimation = new ScaleAnimation(paramFloat1, paramFloat2, paramFloat1, paramFloat2, 1, 0.5F, 1, 0.5F);
    scaleAnimation.setInterpolator(E);
    scaleAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)scaleAnimation);
    AlphaAnimation alphaAnimation = new AlphaAnimation(paramFloat3, paramFloat4);
    alphaAnimation.setInterpolator(F);
    alphaAnimation.setDuration(220L);
    animationSet.addAnimation((Animation)alphaAnimation);
    return new AnimationOrAnimator((Animation)animationSet);
  }
  
  static boolean a(Animator paramAnimator) {
    if (paramAnimator == null)
      return false; 
    if (paramAnimator instanceof ValueAnimator) {
      PropertyValuesHolder[] arrayOfPropertyValuesHolder = ((ValueAnimator)paramAnimator).getValues();
      for (byte b = 0; b < arrayOfPropertyValuesHolder.length; b++) {
        if ("alpha".equals(arrayOfPropertyValuesHolder[b].getPropertyName()))
          return true; 
      } 
    } else if (paramAnimator instanceof AnimatorSet) {
      ArrayList<Animator> arrayList = ((AnimatorSet)paramAnimator).getChildAnimations();
      for (byte b = 0; b < arrayList.size(); b++) {
        if (a(arrayList.get(b)))
          return true; 
      } 
    } 
    return false;
  }
  
  static boolean a(AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramAnimationOrAnimator.animation instanceof AlphaAnimation)
      return true; 
    if (paramAnimationOrAnimator.animation instanceof AnimationSet) {
      List list = ((AnimationSet)paramAnimationOrAnimator.animation).getAnimations();
      for (byte b = 0; b < list.size(); b++) {
        if (list.get(b) instanceof AlphaAnimation)
          return true; 
      } 
      return false;
    } 
    return a(paramAnimationOrAnimator.animator);
  }
  
  static boolean a(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramView != null) {
      if (paramAnimationOrAnimator == null)
        return false; 
      int i = Build.VERSION.SDK_INT;
      boolean bool = false;
      if (i >= 19) {
        int j = paramView.getLayerType();
        bool = false;
        if (j == 0) {
          boolean bool1 = ViewCompat.hasOverlappingRendering(paramView);
          bool = false;
          if (bool1) {
            boolean bool2 = a(paramAnimationOrAnimator);
            bool = false;
            if (bool2)
              bool = true; 
          } 
        } 
      } 
      return bool;
    } 
    return false;
  }
  
  private void addAddedFragments(ArraySet<Fragment> paramArraySet) {
    if (this.l < 1)
      return; 
    int i = Math.min(this.l, 4);
    int j = this.e.size();
    for (byte b = 0; b < j; b++) {
      Fragment fragment = this.e.get(b);
      if (fragment.mState < i) {
        a(fragment, i, fragment.getNextAnim(), fragment.getNextTransition(), false);
        if (fragment.mView != null && !fragment.mHidden && fragment.mIsNewlyAdded)
          paramArraySet.add(fragment); 
      } 
    } 
  }
  
  private void animateRemoveFragment(@NonNull Fragment paramFragment, @NonNull AnimationOrAnimator paramAnimationOrAnimator, int paramInt) {
    View view = paramFragment.mView;
    ViewGroup viewGroup = paramFragment.mContainer;
    viewGroup.startViewTransition(view);
    paramFragment.setStateAfterAnimating(paramInt);
    if (paramAnimationOrAnimator.animation != null) {
      EndViewTransitionAnimator endViewTransitionAnimator = new EndViewTransitionAnimator(paramAnimationOrAnimator.animation, viewGroup, view);
      paramFragment.setAnimatingAway(paramFragment.mView);
      endViewTransitionAnimator.setAnimationListener(new AnimationListenerWrapper(this, getAnimationListener((Animation)endViewTransitionAnimator), viewGroup, paramFragment) {
            public void onAnimationEnd(Animation param1Animation) {
              super.onAnimationEnd(param1Animation);
              this.a.post(new Runnable(this) {
                    public void run() {
                      if (this.a.b.getAnimatingAway() != null) {
                        this.a.b.setAnimatingAway(null);
                        this.a.c.a(this.a.b, this.a.b.getStateAfterAnimating(), 0, 0, false);
                      } 
                    }
                  });
            }
          });
      setHWLayerAnimListenerIfAlpha(view, paramAnimationOrAnimator);
      paramFragment.mView.startAnimation((Animation)endViewTransitionAnimator);
      return;
    } 
    Animator animator = paramAnimationOrAnimator.animator;
    paramFragment.setAnimator(paramAnimationOrAnimator.animator);
    animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter(this, viewGroup, view, paramFragment) {
          public void onAnimationEnd(Animator param1Animator) {
            this.a.endViewTransition(this.b);
            Animator animator = this.c.getAnimator();
            this.c.setAnimator(null);
            if (animator != null && this.a.indexOfChild(this.b) < 0)
              this.d.a(this.c, this.c.getStateAfterAnimating(), 0, 0, false); 
          }
        });
    animator.setTarget(paramFragment.mView);
    setHWLayerAnimListenerIfAlpha(paramFragment.mView, paramAnimationOrAnimator);
    animator.start();
  }
  
  private void burpActive() {
    if (this.f != null)
      for (int i = -1 + this.f.size(); i >= 0; i--) {
        if (this.f.valueAt(i) == null)
          this.f.delete(this.f.keyAt(i)); 
      }  
  }
  
  private void checkStateLoss() {
    if (!this.s) {
      if (this.u == null)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Can not perform this action inside of ");
      stringBuilder.append(this.u);
      throw new IllegalStateException(stringBuilder.toString());
    } 
    throw new IllegalStateException("Can not perform this action after onSaveInstanceState");
  }
  
  private void cleanupExec() {
    this.c = false;
    this.x.clear();
    this.w.clear();
  }
  
  private void completeExecute(BackStackRecord paramBackStackRecord, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
    if (paramBoolean1) {
      paramBackStackRecord.b(paramBoolean3);
    } else {
      paramBackStackRecord.a();
    } 
    ArrayList<BackStackRecord> arrayList = new ArrayList(1);
    ArrayList<Boolean> arrayList1 = new ArrayList(1);
    arrayList.add(paramBackStackRecord);
    arrayList1.add(Boolean.valueOf(paramBoolean1));
    if (paramBoolean2)
      FragmentTransition.a(this, arrayList, arrayList1, 0, 1, true); 
    if (paramBoolean3)
      a(this.l, true); 
    if (this.f != null) {
      int i = this.f.size();
      for (byte b = 0; b < i; b++) {
        Fragment fragment = (Fragment)this.f.valueAt(b);
        if (fragment != null && fragment.mView != null && fragment.mIsNewlyAdded && paramBackStackRecord.b(fragment.mContainerId)) {
          if (fragment.mPostponedAlpha > 0.0F)
            fragment.mView.setAlpha(fragment.mPostponedAlpha); 
          if (paramBoolean3) {
            fragment.mPostponedAlpha = 0.0F;
          } else {
            fragment.mPostponedAlpha = -1.0F;
            fragment.mIsNewlyAdded = false;
          } 
        } 
      } 
    } 
  }
  
  private void dispatchStateChange(int paramInt) {
    try {
      this.c = true;
      a(paramInt, false);
      this.c = false;
      return;
    } finally {
      this.c = false;
    } 
  }
  
  private void endAnimatingAwayFragments() {
    int i;
    SparseArray<Fragment> sparseArray = this.f;
    byte b = 0;
    if (sparseArray == null) {
      i = 0;
      b = 0;
    } else {
      i = this.f.size();
    } 
    while (b < i) {
      Fragment fragment = (Fragment)this.f.valueAt(b);
      if (fragment != null)
        if (fragment.getAnimatingAway() != null) {
          int j = fragment.getStateAfterAnimating();
          View view = fragment.getAnimatingAway();
          Animation animation = view.getAnimation();
          if (animation != null) {
            animation.cancel();
            view.clearAnimation();
          } 
          fragment.setAnimatingAway(null);
          a(fragment, j, 0, 0, false);
        } else if (fragment.getAnimator() != null) {
          fragment.getAnimator().end();
        }  
      b++;
    } 
  }
  
  private void ensureExecReady(boolean paramBoolean) {
    if (!this.c) {
      if (this.m != null) {
        if (Looper.myLooper() == this.m.getHandler().getLooper()) {
          if (!paramBoolean)
            checkStateLoss(); 
          if (this.w == null) {
            this.w = new ArrayList<BackStackRecord>();
            this.x = new ArrayList<Boolean>();
          } 
          this.c = true;
          try {
            executePostponedTransaction(null, null);
            return;
          } finally {
            this.c = false;
          } 
        } 
        throw new IllegalStateException("Must be called from main thread of fragment host");
      } 
      throw new IllegalStateException("Fragment host has been destroyed");
    } 
    throw new IllegalStateException("FragmentManager is already executing transactions");
  }
  
  private static void executeOps(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    while (paramInt1 < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(paramInt1);
      boolean bool = ((Boolean)paramArrayList1.get(paramInt1)).booleanValue();
      boolean bool1 = true;
      if (bool) {
        backStackRecord.a(-1);
        if (paramInt1 != paramInt2 - 1)
          bool1 = false; 
        backStackRecord.b(bool1);
      } else {
        backStackRecord.a(bool1);
        backStackRecord.a();
      } 
      paramInt1++;
    } 
  }
  
  private void executeOpsTogether(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2) {
    int k;
    int i = paramInt1;
    boolean bool = ((BackStackRecord)paramArrayList.get(i)).t;
    if (this.y == null) {
      this.y = new ArrayList<Fragment>();
    } else {
      this.y.clear();
    } 
    this.y.addAll(this.e);
    Fragment fragment = getPrimaryNavigationFragment();
    int j = i;
    boolean bool1 = false;
    while (j < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(j);
      if (!((Boolean)paramArrayList1.get(j)).booleanValue()) {
        fragment = backStackRecord.a(this.y, fragment);
      } else {
        fragment = backStackRecord.b(this.y, fragment);
      } 
      if (bool1 || backStackRecord.i) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      j++;
    } 
    this.y.clear();
    if (!bool)
      FragmentTransition.a(this, paramArrayList, paramArrayList1, paramInt1, paramInt2, false); 
    executeOps(paramArrayList, paramArrayList1, paramInt1, paramInt2);
    if (bool) {
      ArraySet<Fragment> arraySet = new ArraySet();
      addAddedFragments(arraySet);
      int m = postponePostponableTransactions(paramArrayList, paramArrayList1, paramInt1, paramInt2, arraySet);
      makeRemovedFragmentsInvisible(arraySet);
      k = m;
    } else {
      k = paramInt2;
    } 
    if (k != i && bool) {
      FragmentTransition.a(this, paramArrayList, paramArrayList1, paramInt1, k, true);
      a(this.l, true);
    } 
    while (i < paramInt2) {
      BackStackRecord backStackRecord = paramArrayList.get(i);
      if (((Boolean)paramArrayList1.get(i)).booleanValue() && backStackRecord.m >= 0) {
        freeBackStackIndex(backStackRecord.m);
        backStackRecord.m = -1;
      } 
      backStackRecord.runOnCommitRunnables();
      i++;
    } 
    if (bool1)
      c(); 
  }
  
  private void executePostponedTransaction(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    int i;
    if (this.B == null) {
      i = 0;
    } else {
      i = this.B.size();
    } 
    int j = i;
    for (byte b = 0; b < j; b++) {
      StartEnterTransitionListener startEnterTransitionListener = this.B.get(b);
      if (paramArrayList != null && !StartEnterTransitionListener.a(startEnterTransitionListener)) {
        int k = paramArrayList.indexOf(StartEnterTransitionListener.b(startEnterTransitionListener));
        if (k != -1 && ((Boolean)paramArrayList1.get(k)).booleanValue()) {
          startEnterTransitionListener.cancelTransaction();
          continue;
        } 
      } 
      if (startEnterTransitionListener.isReady() || (paramArrayList != null && StartEnterTransitionListener.b(startEnterTransitionListener).a(paramArrayList, 0, paramArrayList.size()))) {
        this.B.remove(b);
        b--;
        j--;
        if (paramArrayList != null && !StartEnterTransitionListener.a(startEnterTransitionListener)) {
          int k = paramArrayList.indexOf(StartEnterTransitionListener.b(startEnterTransitionListener));
          if (k != -1 && ((Boolean)paramArrayList1.get(k)).booleanValue()) {
            startEnterTransitionListener.cancelTransaction();
            continue;
          } 
        } 
        startEnterTransitionListener.completeTransaction();
      } 
      continue;
    } 
  }
  
  private Fragment findFragmentUnder(Fragment paramFragment) {
    ViewGroup viewGroup = paramFragment.mContainer;
    View view = paramFragment.mView;
    if (viewGroup != null) {
      if (view == null)
        return null; 
      for (int i = -1 + this.e.indexOf(paramFragment); i >= 0; i--) {
        Fragment fragment = this.e.get(i);
        if (fragment.mContainer == viewGroup && fragment.mView != null)
          return fragment; 
      } 
      return null;
    } 
    return null;
  }
  
  private void forcePostponedTransactions() {
    if (this.B != null)
      while (!this.B.isEmpty())
        ((StartEnterTransitionListener)this.B.remove(0)).completeTransaction();  
  }
  
  private boolean generateOpsForPendingActions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield b : Ljava/util/ArrayList;
    //   6: astore #4
    //   8: iconst_0
    //   9: istore #5
    //   11: aload #4
    //   13: ifnull -> 104
    //   16: aload_0
    //   17: getfield b : Ljava/util/ArrayList;
    //   20: invokevirtual size : ()I
    //   23: ifne -> 29
    //   26: goto -> 104
    //   29: aload_0
    //   30: getfield b : Ljava/util/ArrayList;
    //   33: invokevirtual size : ()I
    //   36: istore #6
    //   38: iconst_0
    //   39: istore #7
    //   41: iload #5
    //   43: iload #6
    //   45: if_icmpge -> 78
    //   48: iload #7
    //   50: aload_0
    //   51: getfield b : Ljava/util/ArrayList;
    //   54: iload #5
    //   56: invokevirtual get : (I)Ljava/lang/Object;
    //   59: checkcast android/support/v4/app/FragmentManagerImpl$OpGenerator
    //   62: aload_1
    //   63: aload_2
    //   64: invokeinterface generateOps : (Ljava/util/ArrayList;Ljava/util/ArrayList;)Z
    //   69: ior
    //   70: istore #7
    //   72: iinc #5, 1
    //   75: goto -> 41
    //   78: aload_0
    //   79: getfield b : Ljava/util/ArrayList;
    //   82: invokevirtual clear : ()V
    //   85: aload_0
    //   86: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   89: invokevirtual getHandler : ()Landroid/os/Handler;
    //   92: aload_0
    //   93: getfield D : Ljava/lang/Runnable;
    //   96: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   99: aload_0
    //   100: monitorexit
    //   101: iload #7
    //   103: ireturn
    //   104: aload_0
    //   105: monitorexit
    //   106: iconst_0
    //   107: ireturn
    //   108: astore_3
    //   109: aload_0
    //   110: monitorexit
    //   111: aload_3
    //   112: athrow
    // Exception table:
    //   from	to	target	type
    //   2	8	108	finally
    //   16	26	108	finally
    //   29	38	108	finally
    //   48	72	108	finally
    //   78	101	108	finally
    //   104	106	108	finally
    //   109	111	108	finally
  }
  
  private static Animation.AnimationListener getAnimationListener(Animation paramAnimation) {
    try {
      if (q == null) {
        q = Animation.class.getDeclaredField("mListener");
        q.setAccessible(true);
      } 
      return (Animation.AnimationListener)q.get(paramAnimation);
    } catch (NoSuchFieldException noSuchFieldException) {
      Log.e("FragmentManager", "No field with the name mListener is found in Animation class", noSuchFieldException);
    } catch (IllegalAccessException illegalAccessException) {
      Log.e("FragmentManager", "Cannot access Animation's mListener field", illegalAccessException);
    } 
    return null;
  }
  
  private void makeRemovedFragmentsInvisible(ArraySet<Fragment> paramArraySet) {
    int i = paramArraySet.size();
    for (byte b = 0; b < i; b++) {
      Fragment fragment = (Fragment)paramArraySet.valueAt(b);
      if (!fragment.mAdded) {
        View view = fragment.getView();
        fragment.mPostponedAlpha = view.getAlpha();
        view.setAlpha(0.0F);
      } 
    } 
  }
  
  private boolean popBackStackImmediate(String paramString, int paramInt1, int paramInt2) {
    execPendingActions();
    ensureExecReady(true);
    if (this.p != null && paramInt1 < 0 && paramString == null) {
      FragmentManager fragmentManager = this.p.peekChildFragmentManager();
      if (fragmentManager != null && fragmentManager.popBackStackImmediate())
        return true; 
    } 
    boolean bool = a(this.w, this.x, paramString, paramInt1, paramInt2);
    if (bool) {
      this.c = true;
      try {
        removeRedundantOperationsAndExecute(this.w, this.x);
      } finally {
        cleanupExec();
      } 
    } 
    b();
    burpActive();
    return bool;
  }
  
  private int postponePostponableTransactions(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, int paramInt1, int paramInt2, ArraySet<Fragment> paramArraySet) {
    int i = paramInt2 - 1;
    int j = paramInt2;
    while (i >= paramInt1) {
      boolean bool1;
      BackStackRecord backStackRecord = paramArrayList.get(i);
      boolean bool = ((Boolean)paramArrayList1.get(i)).booleanValue();
      if (backStackRecord.isPostponed() && !backStackRecord.a(paramArrayList, i + 1, paramInt2)) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if (bool1) {
        if (this.B == null)
          this.B = new ArrayList<StartEnterTransitionListener>(); 
        StartEnterTransitionListener startEnterTransitionListener = new StartEnterTransitionListener(backStackRecord, bool);
        this.B.add(startEnterTransitionListener);
        backStackRecord.setOnStartPostponedListener(startEnterTransitionListener);
        if (bool) {
          backStackRecord.a();
        } else {
          backStackRecord.b(false);
        } 
        if (i != --j) {
          paramArrayList.remove(i);
          paramArrayList.add(j, backStackRecord);
        } 
        addAddedFragments(paramArraySet);
      } 
      i--;
    } 
    return j;
  }
  
  private void removeRedundantOperationsAndExecute(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1) {
    if (paramArrayList != null) {
      if (paramArrayList.isEmpty())
        return; 
      if (paramArrayList1 != null && paramArrayList.size() == paramArrayList1.size()) {
        executePostponedTransaction(paramArrayList, paramArrayList1);
        int i = paramArrayList.size();
        int j = 0;
        int k = 0;
        while (j < i) {
          if (!((BackStackRecord)paramArrayList.get(j)).t) {
            if (k != j)
              executeOpsTogether(paramArrayList, paramArrayList1, k, j); 
            k = j + 1;
            if (((Boolean)paramArrayList1.get(j)).booleanValue())
              while (k < i && ((Boolean)paramArrayList1.get(k)).booleanValue() && !((BackStackRecord)paramArrayList.get(k)).t)
                k++;  
            executeOpsTogether(paramArrayList, paramArrayList1, j, k);
            j = k - 1;
          } 
          j++;
        } 
        if (k != i)
          executeOpsTogether(paramArrayList, paramArrayList1, k, i); 
        return;
      } 
      throw new IllegalStateException("Internal error with the back stack records");
    } 
  }
  
  public static int reverseTransit(int paramInt) {
    char c = ' ';
    if (paramInt != 4097) {
      if (paramInt != 4099)
        return (paramInt != c) ? 0 : 4097; 
      c = 'ဃ';
    } 
    return c;
  }
  
  private void scheduleCommit() {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield B : Ljava/util/ArrayList;
    //   6: ifnull -> 97
    //   9: aload_0
    //   10: getfield B : Ljava/util/ArrayList;
    //   13: invokevirtual isEmpty : ()Z
    //   16: ifne -> 97
    //   19: iconst_1
    //   20: istore_2
    //   21: goto -> 24
    //   24: aload_0
    //   25: getfield b : Ljava/util/ArrayList;
    //   28: astore_3
    //   29: iconst_0
    //   30: istore #4
    //   32: aload_3
    //   33: ifnull -> 102
    //   36: aload_0
    //   37: getfield b : Ljava/util/ArrayList;
    //   40: invokevirtual size : ()I
    //   43: istore #5
    //   45: iconst_0
    //   46: istore #4
    //   48: iload #5
    //   50: iconst_1
    //   51: if_icmpne -> 102
    //   54: iconst_1
    //   55: istore #4
    //   57: goto -> 102
    //   60: aload_0
    //   61: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   64: invokevirtual getHandler : ()Landroid/os/Handler;
    //   67: aload_0
    //   68: getfield D : Ljava/lang/Runnable;
    //   71: invokevirtual removeCallbacks : (Ljava/lang/Runnable;)V
    //   74: aload_0
    //   75: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   78: invokevirtual getHandler : ()Landroid/os/Handler;
    //   81: aload_0
    //   82: getfield D : Ljava/lang/Runnable;
    //   85: invokevirtual post : (Ljava/lang/Runnable;)Z
    //   88: pop
    //   89: aload_0
    //   90: monitorexit
    //   91: return
    //   92: astore_1
    //   93: aload_0
    //   94: monitorexit
    //   95: aload_1
    //   96: athrow
    //   97: iconst_0
    //   98: istore_2
    //   99: goto -> 24
    //   102: iload_2
    //   103: ifne -> 60
    //   106: iload #4
    //   108: ifeq -> 89
    //   111: goto -> 60
    // Exception table:
    //   from	to	target	type
    //   2	19	92	finally
    //   24	29	92	finally
    //   36	45	92	finally
    //   60	89	92	finally
    //   89	91	92	finally
    //   93	95	92	finally
  }
  
  private static void setHWLayerAnimListenerIfAlpha(View paramView, AnimationOrAnimator paramAnimationOrAnimator) {
    if (paramView != null) {
      if (paramAnimationOrAnimator == null)
        return; 
      if (a(paramView, paramAnimationOrAnimator)) {
        if (paramAnimationOrAnimator.animator != null) {
          paramAnimationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorOnHWLayerIfNeededListener(paramView));
          return;
        } 
        Animation.AnimationListener animationListener = getAnimationListener(paramAnimationOrAnimator.animation);
        paramView.setLayerType(2, null);
        paramAnimationOrAnimator.animation.setAnimationListener(new AnimateOnHWLayerIfNeededListener(paramView, animationListener));
      } 
      return;
    } 
  }
  
  private static void setRetaining(FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    if (paramFragmentManagerNonConfig == null)
      return; 
    List<Fragment> list = paramFragmentManagerNonConfig.getFragments();
    if (list != null) {
      Iterator<Fragment> iterator = list.iterator();
      while (iterator.hasNext())
        ((Fragment)iterator.next()).mRetaining = true; 
    } 
    List<FragmentManagerNonConfig> list1 = paramFragmentManagerNonConfig.getChildNonConfigs();
    if (list1 != null) {
      Iterator<FragmentManagerNonConfig> iterator = list1.iterator();
      while (iterator.hasNext())
        setRetaining(iterator.next()); 
    } 
  }
  
  private void throwException(RuntimeException paramRuntimeException) {
    Log.e("FragmentManager", paramRuntimeException.getMessage());
    Log.e("FragmentManager", "Activity state:");
    PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
    if (this.m != null) {
      try {
        this.m.onDump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } else {
      try {
        dump("  ", null, printWriter, new String[0]);
      } catch (Exception exception) {
        Log.e("FragmentManager", "Failed dumping state", exception);
      } 
    } 
    throw paramRuntimeException;
  }
  
  public static int transitToStyleIndex(int paramInt, boolean paramBoolean) {
    return (paramInt != 4097) ? ((paramInt != 4099) ? ((paramInt != 8194) ? -1 : (paramBoolean ? 3 : 4)) : (paramBoolean ? 5 : 6)) : (paramBoolean ? 1 : 2);
  }
  
  AnimationOrAnimator a(Fragment paramFragment, int paramInt1, boolean paramBoolean, int paramInt2) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getNextAnim : ()I
    //   4: istore #5
    //   6: aload_1
    //   7: iload_2
    //   8: iload_3
    //   9: iload #5
    //   11: invokevirtual onCreateAnimation : (IZI)Landroid/view/animation/Animation;
    //   14: astore #6
    //   16: aload #6
    //   18: ifnull -> 32
    //   21: new android/support/v4/app/FragmentManagerImpl$AnimationOrAnimator
    //   24: dup
    //   25: aload #6
    //   27: aconst_null
    //   28: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/support/v4/app/FragmentManagerImpl$1;)V
    //   31: areturn
    //   32: aload_1
    //   33: iload_2
    //   34: iload_3
    //   35: iload #5
    //   37: invokevirtual onCreateAnimator : (IZI)Landroid/animation/Animator;
    //   40: astore #7
    //   42: aload #7
    //   44: ifnull -> 58
    //   47: new android/support/v4/app/FragmentManagerImpl$AnimationOrAnimator
    //   50: dup
    //   51: aload #7
    //   53: aconst_null
    //   54: invokespecial <init> : (Landroid/animation/Animator;Landroid/support/v4/app/FragmentManagerImpl$1;)V
    //   57: areturn
    //   58: iload #5
    //   60: ifeq -> 221
    //   63: ldc_w 'anim'
    //   66: aload_0
    //   67: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   70: invokevirtual getContext : ()Landroid/content/Context;
    //   73: invokevirtual getResources : ()Landroid/content/res/Resources;
    //   76: iload #5
    //   78: invokevirtual getResourceTypeName : (I)Ljava/lang/String;
    //   81: invokevirtual equals : (Ljava/lang/Object;)Z
    //   84: istore #9
    //   86: iconst_0
    //   87: istore #10
    //   89: iload #9
    //   91: ifeq -> 142
    //   94: aload_0
    //   95: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   98: invokevirtual getContext : ()Landroid/content/Context;
    //   101: iload #5
    //   103: invokestatic loadAnimation : (Landroid/content/Context;I)Landroid/view/animation/Animation;
    //   106: astore #16
    //   108: iconst_0
    //   109: istore #10
    //   111: aload #16
    //   113: ifnull -> 131
    //   116: new android/support/v4/app/FragmentManagerImpl$AnimationOrAnimator
    //   119: dup
    //   120: aload #16
    //   122: aconst_null
    //   123: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/support/v4/app/FragmentManagerImpl$1;)V
    //   126: astore #17
    //   128: aload #17
    //   130: areturn
    //   131: iconst_1
    //   132: istore #10
    //   134: goto -> 142
    //   137: astore #15
    //   139: aload #15
    //   141: athrow
    //   142: iload #10
    //   144: ifne -> 221
    //   147: aload_0
    //   148: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   151: invokevirtual getContext : ()Landroid/content/Context;
    //   154: iload #5
    //   156: invokestatic loadAnimator : (Landroid/content/Context;I)Landroid/animation/Animator;
    //   159: astore #13
    //   161: aload #13
    //   163: ifnull -> 221
    //   166: new android/support/v4/app/FragmentManagerImpl$AnimationOrAnimator
    //   169: dup
    //   170: aload #13
    //   172: aconst_null
    //   173: invokespecial <init> : (Landroid/animation/Animator;Landroid/support/v4/app/FragmentManagerImpl$1;)V
    //   176: astore #14
    //   178: aload #14
    //   180: areturn
    //   181: astore #11
    //   183: iload #9
    //   185: ifne -> 218
    //   188: aload_0
    //   189: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   192: invokevirtual getContext : ()Landroid/content/Context;
    //   195: iload #5
    //   197: invokestatic loadAnimation : (Landroid/content/Context;I)Landroid/view/animation/Animation;
    //   200: astore #12
    //   202: aload #12
    //   204: ifnull -> 221
    //   207: new android/support/v4/app/FragmentManagerImpl$AnimationOrAnimator
    //   210: dup
    //   211: aload #12
    //   213: aconst_null
    //   214: invokespecial <init> : (Landroid/view/animation/Animation;Landroid/support/v4/app/FragmentManagerImpl$1;)V
    //   217: areturn
    //   218: aload #11
    //   220: athrow
    //   221: iload_2
    //   222: ifne -> 227
    //   225: aconst_null
    //   226: areturn
    //   227: iload_2
    //   228: iload_3
    //   229: invokestatic transitToStyleIndex : (IZ)I
    //   232: istore #8
    //   234: iload #8
    //   236: ifge -> 241
    //   239: aconst_null
    //   240: areturn
    //   241: iload #8
    //   243: tableswitch default -> 280, 1 -> 384, 2 -> 367, 3 -> 350, 4 -> 333, 5 -> 320, 6 -> 307
    //   280: iload #4
    //   282: ifne -> 401
    //   285: aload_0
    //   286: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   289: invokevirtual onHasWindowAnimations : ()Z
    //   292: ifeq -> 401
    //   295: aload_0
    //   296: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   299: invokevirtual onGetWindowAnimations : ()I
    //   302: istore #4
    //   304: goto -> 401
    //   307: aload_0
    //   308: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   311: invokevirtual getContext : ()Landroid/content/Context;
    //   314: fconst_1
    //   315: fconst_0
    //   316: invokestatic a : (Landroid/content/Context;FF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   319: areturn
    //   320: aload_0
    //   321: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   324: invokevirtual getContext : ()Landroid/content/Context;
    //   327: fconst_0
    //   328: fconst_1
    //   329: invokestatic a : (Landroid/content/Context;FF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   332: areturn
    //   333: aload_0
    //   334: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   337: invokevirtual getContext : ()Landroid/content/Context;
    //   340: fconst_1
    //   341: ldc_w 1.075
    //   344: fconst_1
    //   345: fconst_0
    //   346: invokestatic a : (Landroid/content/Context;FFFF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   349: areturn
    //   350: aload_0
    //   351: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   354: invokevirtual getContext : ()Landroid/content/Context;
    //   357: ldc_w 0.975
    //   360: fconst_1
    //   361: fconst_0
    //   362: fconst_1
    //   363: invokestatic a : (Landroid/content/Context;FFFF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   366: areturn
    //   367: aload_0
    //   368: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   371: invokevirtual getContext : ()Landroid/content/Context;
    //   374: fconst_1
    //   375: ldc_w 0.975
    //   378: fconst_1
    //   379: fconst_0
    //   380: invokestatic a : (Landroid/content/Context;FFFF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   383: areturn
    //   384: aload_0
    //   385: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   388: invokevirtual getContext : ()Landroid/content/Context;
    //   391: ldc_w 1.125
    //   394: fconst_1
    //   395: fconst_0
    //   396: fconst_1
    //   397: invokestatic a : (Landroid/content/Context;FFFF)Landroid/support/v4/app/FragmentManagerImpl$AnimationOrAnimator;
    //   400: areturn
    //   401: iload #4
    //   403: ifne -> 408
    //   406: aconst_null
    //   407: areturn
    //   408: aconst_null
    //   409: areturn
    // Exception table:
    //   from	to	target	type
    //   94	108	137	android/content/res/Resources$NotFoundException
    //   94	108	142	java/lang/RuntimeException
    //   116	128	137	android/content/res/Resources$NotFoundException
    //   116	128	142	java/lang/RuntimeException
    //   147	161	181	java/lang/RuntimeException
    //   166	178	181	java/lang/RuntimeException
  }
  
  void a() {
    if (this.f == null)
      return; 
    for (byte b = 0; b < this.f.size(); b++) {
      Fragment fragment = (Fragment)this.f.valueAt(b);
      if (fragment != null)
        performPendingDeferredStart(fragment); 
    } 
  }
  
  void a(int paramInt, boolean paramBoolean) {
    if (this.m != null || paramInt == 0) {
      if (!paramBoolean && paramInt == this.l)
        return; 
      this.l = paramInt;
      if (this.f != null) {
        int i = this.e.size();
        byte b1 = 0;
        boolean bool = false;
        while (b1 < i) {
          Fragment fragment = this.e.get(b1);
          d(fragment);
          if (fragment.mLoaderManager != null)
            bool |= fragment.mLoaderManager.hasRunningLoaders(); 
          b1++;
        } 
        int j = this.f.size();
        for (byte b2 = 0; b2 < j; b2++) {
          Fragment fragment = (Fragment)this.f.valueAt(b2);
          if (fragment != null && (fragment.mRemoving || fragment.mDetached) && !fragment.mIsNewlyAdded) {
            d(fragment);
            if (fragment.mLoaderManager != null)
              bool |= fragment.mLoaderManager.hasRunningLoaders(); 
          } 
        } 
        if (!bool)
          a(); 
        if (this.r && this.m != null && this.l == 5) {
          this.m.onSupportInvalidateOptionsMenu();
          this.r = false;
        } 
      } 
      return;
    } 
    throw new IllegalStateException("No activity");
  }
  
  void a(Parcelable paramParcelable, FragmentManagerNonConfig paramFragmentManagerNonConfig) {
    List<FragmentManagerNonConfig> list;
    List<ViewModelStore> list1;
    if (paramParcelable == null)
      return; 
    FragmentManagerState fragmentManagerState = (FragmentManagerState)paramParcelable;
    if (fragmentManagerState.a == null)
      return; 
    if (paramFragmentManagerNonConfig != null) {
      byte b1;
      List<Fragment> list2 = paramFragmentManagerNonConfig.getFragments();
      list = paramFragmentManagerNonConfig.getChildNonConfigs();
      list1 = paramFragmentManagerNonConfig.getViewModelStores();
      if (list2 != null) {
        b1 = list2.size();
      } else {
        b1 = 0;
      } 
      for (byte b2 = 0; b2 < b1; b2++) {
        Fragment fragment = list2.get(b2);
        if (a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: re-attaching retained ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        byte b3;
        for (b3 = 0; b3 < fragmentManagerState.a.length && (fragmentManagerState.a[b3]).b != fragment.mIndex; b3++);
        if (b3 == fragmentManagerState.a.length) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Could not find active fragment with index ");
          stringBuilder.append(fragment.mIndex);
          throwException(new IllegalStateException(stringBuilder.toString()));
        } 
        FragmentState fragmentState = fragmentManagerState.a[b3];
        fragmentState.l = fragment;
        fragment.mSavedViewState = null;
        fragment.mBackStackNesting = 0;
        fragment.mInLayout = false;
        fragment.mAdded = false;
        fragment.mTarget = null;
        if (fragmentState.k != null) {
          fragmentState.k.setClassLoader(this.m.getContext().getClassLoader());
          fragment.mSavedViewState = fragmentState.k.getSparseParcelableArray("android:view_state");
          fragment.mSavedFragmentState = fragmentState.k;
        } 
      } 
    } else {
      list = null;
      list1 = null;
    } 
    this.f = new SparseArray(fragmentManagerState.a.length);
    for (byte b = 0; b < fragmentManagerState.a.length; b++) {
      FragmentState fragmentState = fragmentManagerState.a[b];
      if (fragmentState != null) {
        FragmentManagerNonConfig fragmentManagerNonConfig;
        ViewModelStore viewModelStore;
        if (list != null && b < list.size()) {
          fragmentManagerNonConfig = list.get(b);
        } else {
          fragmentManagerNonConfig = null;
        } 
        if (list1 != null && b < list1.size()) {
          viewModelStore = list1.get(b);
        } else {
          viewModelStore = null;
        } 
        Fragment fragment = fragmentState.instantiate(this.m, this.n, this.o, fragmentManagerNonConfig, viewModelStore);
        if (a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: active #");
          stringBuilder.append(b);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        this.f.put(fragment.mIndex, fragment);
        fragmentState.l = null;
      } 
    } 
    if (paramFragmentManagerNonConfig != null) {
      byte b1;
      List<Fragment> list2 = paramFragmentManagerNonConfig.getFragments();
      if (list2 != null) {
        b1 = list2.size();
      } else {
        b1 = 0;
      } 
      for (byte b2 = 0; b2 < b1; b2++) {
        Fragment fragment = list2.get(b2);
        if (fragment.mTargetIndex >= 0) {
          fragment.mTarget = (Fragment)this.f.get(fragment.mTargetIndex);
          if (fragment.mTarget == null) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Re-attaching retained fragment ");
            stringBuilder.append(fragment);
            stringBuilder.append(" target no longer exists: ");
            stringBuilder.append(fragment.mTargetIndex);
            Log.w("FragmentManager", stringBuilder.toString());
          } 
        } 
      } 
    } 
    this.e.clear();
    if (fragmentManagerState.b != null) {
      byte b1 = 0;
      while (b1 < fragmentManagerState.b.length) {
        Fragment fragment = (Fragment)this.f.get(fragmentManagerState.b[b1]);
        if (fragment == null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("No instantiated fragment for index #");
          stringBuilder.append(fragmentManagerState.b[b1]);
          throwException(new IllegalStateException(stringBuilder.toString()));
        } 
        fragment.mAdded = true;
        if (a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: added #");
          stringBuilder.append(b1);
          stringBuilder.append(": ");
          stringBuilder.append(fragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        if (!this.e.contains(fragment)) {
          synchronized (this.e) {
            this.e.add(fragment);
            b1++;
          } 
          continue;
        } 
        throw new IllegalStateException("Already added!");
      } 
    } 
    if (fragmentManagerState.c != null) {
      this.g = new ArrayList<BackStackRecord>(fragmentManagerState.c.length);
      for (byte b1 = 0; b1 < fragmentManagerState.c.length; b1++) {
        BackStackRecord backStackRecord = fragmentManagerState.c[b1].instantiate(this);
        if (a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("restoreAllState: back stack #");
          stringBuilder.append(b1);
          stringBuilder.append(" (index ");
          stringBuilder.append(backStackRecord.m);
          stringBuilder.append("): ");
          stringBuilder.append(backStackRecord);
          Log.v("FragmentManager", stringBuilder.toString());
          PrintWriter printWriter = new PrintWriter((Writer)new LogWriter("FragmentManager"));
          backStackRecord.dump("  ", printWriter, false);
          printWriter.close();
        } 
        this.g.add(backStackRecord);
        if (backStackRecord.m >= 0)
          setBackStackIndex(backStackRecord.m, backStackRecord); 
      } 
    } else {
      this.g = null;
    } 
    if (fragmentManagerState.d >= 0)
      this.p = (Fragment)this.f.get(fragmentManagerState.d); 
    this.d = fragmentManagerState.e;
  }
  
  void a(BackStackRecord paramBackStackRecord) {
    if (this.g == null)
      this.g = new ArrayList<BackStackRecord>(); 
    this.g.add(paramBackStackRecord);
  }
  
  void a(Fragment paramFragment) {
    a(paramFragment, this.l, 0, 0, false);
  }
  
  void a(Fragment paramFragment, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
    int j;
    int k;
    boolean bool = paramFragment.mAdded;
    int i = 1;
    if (!bool || paramFragment.mDetached) {
      j = paramInt1;
      if (j > i)
        j = 1; 
    } else {
      j = paramInt1;
    } 
    if (paramFragment.mRemoving && j > paramFragment.mState)
      if (paramFragment.mState == 0 && paramFragment.isInBackStack()) {
        j = 1;
      } else {
        j = paramFragment.mState;
      }  
    if (paramFragment.mDeferStart && paramFragment.mState < 4 && j > 3) {
      k = 3;
    } else {
      k = j;
    } 
    if (paramFragment.mState <= k) {
      if (paramFragment.mFromLayout && !paramFragment.mInLayout)
        return; 
      if (paramFragment.getAnimatingAway() != null || paramFragment.getAnimator() != null) {
        paramFragment.setAnimatingAway(null);
        paramFragment.setAnimator(null);
        a(paramFragment, paramFragment.getStateAfterAnimating(), 0, 0, true);
      } 
      switch (paramFragment.mState) {
        case 0:
          if (k > 0) {
            FragmentManagerImpl fragmentManagerImpl;
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("moveto CREATED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            if (paramFragment.mSavedFragmentState != null) {
              paramFragment.mSavedFragmentState.setClassLoader(this.m.getContext().getClassLoader());
              paramFragment.mSavedViewState = paramFragment.mSavedFragmentState.getSparseParcelableArray("android:view_state");
              paramFragment.mTarget = getFragment(paramFragment.mSavedFragmentState, "android:target_state");
              if (paramFragment.mTarget != null)
                paramFragment.mTargetRequestCode = paramFragment.mSavedFragmentState.getInt("android:target_req_state", 0); 
              paramFragment.mUserVisibleHint = paramFragment.mSavedFragmentState.getBoolean("android:user_visible_hint", i);
              if (!paramFragment.mUserVisibleHint) {
                paramFragment.mDeferStart = i;
                if (k > 3)
                  k = 3; 
              } 
            } 
            paramFragment.mHost = this.m;
            paramFragment.mParentFragment = this.o;
            if (this.o != null) {
              fragmentManagerImpl = this.o.mChildFragmentManager;
            } else {
              fragmentManagerImpl = this.m.getFragmentManagerImpl();
            } 
            paramFragment.mFragmentManager = fragmentManagerImpl;
            if (paramFragment.mTarget != null)
              if (this.f.get(paramFragment.mTarget.mIndex) == paramFragment.mTarget) {
                if (paramFragment.mTarget.mState < i)
                  a(paramFragment.mTarget, 1, 0, 0, true); 
              } else {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Fragment ");
                stringBuilder.append(paramFragment);
                stringBuilder.append(" declared target fragment ");
                stringBuilder.append(paramFragment.mTarget);
                stringBuilder.append(" that does not belong to this FragmentManager!");
                throw new IllegalStateException(stringBuilder.toString());
              }  
            a(paramFragment, this.m.getContext(), false);
            paramFragment.mCalled = false;
            paramFragment.onAttach(this.m.getContext());
            if (paramFragment.mCalled) {
              if (paramFragment.mParentFragment == null) {
                this.m.onAttachFragment(paramFragment);
              } else {
                paramFragment.mParentFragment.onAttachFragment(paramFragment);
              } 
              b(paramFragment, this.m.getContext(), false);
              if (!paramFragment.mIsCreated) {
                a(paramFragment, paramFragment.mSavedFragmentState, false);
                paramFragment.performCreate(paramFragment.mSavedFragmentState);
                b(paramFragment, paramFragment.mSavedFragmentState, false);
              } else {
                paramFragment.restoreChildFragmentState(paramFragment.mSavedFragmentState);
                paramFragment.mState = i;
              } 
              paramFragment.mRetaining = false;
            } else {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Fragment ");
              stringBuilder.append(paramFragment);
              stringBuilder.append(" did not call through to super.onAttach()");
              throw new SuperNotCalledException(stringBuilder.toString());
            } 
          } 
        case 1:
          b(paramFragment);
          if (k > i) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("moveto ACTIVITY_CREATED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            if (!paramFragment.mFromLayout) {
              ViewGroup viewGroup;
              if (paramFragment.mContainerId != 0) {
                if (paramFragment.mContainerId == -1) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Cannot create fragment ");
                  stringBuilder.append(paramFragment);
                  stringBuilder.append(" for a container view with no id");
                  throwException(new IllegalArgumentException(stringBuilder.toString()));
                } 
                viewGroup = (ViewGroup)this.n.onFindViewById(paramFragment.mContainerId);
                if (viewGroup == null && !paramFragment.mRestored) {
                  String str;
                  try {
                    str = paramFragment.getResources().getResourceName(paramFragment.mContainerId);
                  } catch (android.content.res.Resources.NotFoundException notFoundException) {
                    str = "unknown";
                  } 
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("No view found for id 0x");
                  stringBuilder.append(Integer.toHexString(paramFragment.mContainerId));
                  stringBuilder.append(" (");
                  stringBuilder.append(str);
                  stringBuilder.append(") for fragment ");
                  stringBuilder.append(paramFragment);
                  throwException(new IllegalArgumentException(stringBuilder.toString()));
                } 
              } else {
                viewGroup = null;
              } 
              paramFragment.mContainer = viewGroup;
              paramFragment.mView = paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), viewGroup, paramFragment.mSavedFragmentState);
              if (paramFragment.mView != null) {
                paramFragment.mInnerView = paramFragment.mView;
                paramFragment.mView.setSaveFromParentEnabled(false);
                if (viewGroup != null)
                  viewGroup.addView(paramFragment.mView); 
                if (paramFragment.mHidden)
                  paramFragment.mView.setVisibility(8); 
                paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
                a(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
                if (paramFragment.mView.getVisibility() != 0 || paramFragment.mContainer == null)
                  i = 0; 
                paramFragment.mIsNewlyAdded = i;
              } else {
                paramFragment.mInnerView = null;
              } 
            } 
            paramFragment.performActivityCreated(paramFragment.mSavedFragmentState);
            c(paramFragment, paramFragment.mSavedFragmentState, false);
            if (paramFragment.mView != null)
              paramFragment.restoreViewState(paramFragment.mSavedFragmentState); 
            paramFragment.mSavedFragmentState = null;
          } 
        case 2:
          if (k > 2)
            paramFragment.mState = 3; 
        case 3:
          if (k > 3) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("moveto STARTED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            paramFragment.performStart();
            a(paramFragment, false);
          } 
        case 4:
          if (k > 4) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("moveto RESUMED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            paramFragment.performResume();
            b(paramFragment, false);
            paramFragment.mSavedFragmentState = null;
            paramFragment.mSavedViewState = null;
          } 
          break;
      } 
    } else if (paramFragment.mState > k) {
      switch (paramFragment.mState) {
        case 5:
          if (k < 5) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom RESUMED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            paramFragment.performPause();
            c(paramFragment, false);
          } 
        case 4:
          if (k < 4) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom STARTED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            paramFragment.performStop();
            d(paramFragment, false);
          } 
        case 3:
          if (k < 3) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom STOPPED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            paramFragment.performReallyStop();
          } 
        case 2:
          if (k < 2) {
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("movefrom ACTIVITY_CREATED: ");
              stringBuilder.append(paramFragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            if (paramFragment.mView != null && this.m.onShouldSaveFragmentState(paramFragment) && paramFragment.mSavedViewState == null)
              g(paramFragment); 
            paramFragment.performDestroyView();
            e(paramFragment, false);
            if (paramFragment.mView != null && paramFragment.mContainer != null) {
              AnimationOrAnimator animationOrAnimator;
              paramFragment.mContainer.endViewTransition(paramFragment.mView);
              paramFragment.mView.clearAnimation();
              if (this.l > 0 && !this.t && paramFragment.mView.getVisibility() == 0 && paramFragment.mPostponedAlpha >= 0.0F) {
                animationOrAnimator = a(paramFragment, paramInt2, false, paramInt3);
              } else {
                animationOrAnimator = null;
              } 
              paramFragment.mPostponedAlpha = 0.0F;
              if (animationOrAnimator != null)
                animateRemoveFragment(paramFragment, animationOrAnimator, k); 
              paramFragment.mContainer.removeView(paramFragment.mView);
            } 
            paramFragment.mContainer = null;
            paramFragment.mView = null;
            paramFragment.mInnerView = null;
            paramFragment.mInLayout = false;
          } 
        case 1:
          if (k < i) {
            if (this.t)
              if (paramFragment.getAnimatingAway() != null) {
                View view = paramFragment.getAnimatingAway();
                paramFragment.setAnimatingAway(null);
                view.clearAnimation();
              } else if (paramFragment.getAnimator() != null) {
                Animator animator = paramFragment.getAnimator();
                paramFragment.setAnimator(null);
                animator.cancel();
              }  
            if (paramFragment.getAnimatingAway() != null || paramFragment.getAnimator() != null) {
              paramFragment.setStateAfterAnimating(k);
            } else {
              if (a) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("movefrom CREATED: ");
                stringBuilder.append(paramFragment);
                Log.v("FragmentManager", stringBuilder.toString());
              } 
              if (!paramFragment.mRetaining) {
                paramFragment.performDestroy();
                f(paramFragment, false);
              } else {
                paramFragment.mState = 0;
              } 
              paramFragment.performDetach();
              g(paramFragment, false);
              if (!paramBoolean) {
                if (!paramFragment.mRetaining) {
                  f(paramFragment);
                  break;
                } 
                paramFragment.mHost = null;
                paramFragment.mParentFragment = null;
                paramFragment.mFragmentManager = null;
              } 
              break;
            } 
          } else {
            break;
          } 
          if (paramFragment.mState != i) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("moveToState: Fragment state for ");
            stringBuilder.append(paramFragment);
            stringBuilder.append(" not updated inline; ");
            stringBuilder.append("expected state ");
            stringBuilder.append(i);
            stringBuilder.append(" found ");
            stringBuilder.append(paramFragment.mState);
            Log.w("FragmentManager", stringBuilder.toString());
            paramFragment.mState = i;
          } 
          return;
      } 
    } 
    i = k;
    if (paramFragment.mState != i) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("moveToState: Fragment state for ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" not updated inline; ");
      stringBuilder.append("expected state ");
      stringBuilder.append(i);
      stringBuilder.append(" found ");
      stringBuilder.append(paramFragment.mState);
      Log.w("FragmentManager", stringBuilder.toString());
      paramFragment.mState = i;
    } 
  }
  
  void a(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).a(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void a(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).a(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPreCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void a(Fragment paramFragment, View paramView, Bundle paramBundle, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).a(paramFragment, paramView, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewCreated(this, paramFragment, paramView, paramBundle); 
    } 
  }
  
  void a(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).a(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStarted(this, paramFragment); 
    } 
  }
  
  boolean a(ArrayList<BackStackRecord> paramArrayList, ArrayList<Boolean> paramArrayList1, String paramString, int paramInt1, int paramInt2) {
    byte b;
    if (this.g == null)
      return false; 
    if (paramString == null && paramInt1 < 0 && (paramInt2 & 0x1) == 0) {
      int j = this.g.size() - 1;
      if (j < 0)
        return false; 
      paramArrayList.add(this.g.remove(j));
      paramArrayList1.add(Boolean.valueOf(true));
      return true;
    } 
    if (paramString != null || paramInt1 >= 0) {
      for (b = this.g.size() - 1; b >= 0; b--) {
        BackStackRecord backStackRecord = this.g.get(b);
        if ((paramString != null && paramString.equals(backStackRecord.getName())) || (paramInt1 >= 0 && paramInt1 == backStackRecord.m))
          break; 
      } 
      if (b < 0)
        return false; 
      if ((paramInt2 & 0x1) != 0)
        while (--b >= 0) {
          BackStackRecord backStackRecord = this.g.get(b);
          if ((paramString != null && paramString.equals(backStackRecord.getName())) || (paramInt1 >= 0 && paramInt1 == backStackRecord.m))
            b--; 
        }  
    } else {
      b = -1;
    } 
    if (b == this.g.size() - 1)
      return false; 
    for (int i = this.g.size() - 1; i > b; i--) {
      paramArrayList.add(this.g.remove(i));
      paramArrayList1.add(Boolean.valueOf(true));
    } 
    return true;
  }
  
  public void addFragment(Fragment paramFragment, boolean paramBoolean) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("add: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    e(paramFragment);
    if (!paramFragment.mDetached)
      if (!this.e.contains(paramFragment)) {
        synchronized (this.e) {
          this.e.add(paramFragment);
          paramFragment.mAdded = true;
          paramFragment.mRemoving = false;
          if (paramFragment.mView == null)
            paramFragment.mHiddenChanged = false; 
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.r = true; 
          if (paramBoolean) {
            a(paramFragment);
            return;
          } 
        } 
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Fragment already added: ");
        stringBuilder.append(paramFragment);
        throw new IllegalStateException(stringBuilder.toString());
      }  
  }
  
  public void addOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.k == null)
      this.k = new ArrayList<FragmentManager.OnBackStackChangedListener>(); 
    this.k.add(paramOnBackStackChangedListener);
  }
  
  public int allocBackStackIndex(BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield j : Ljava/util/ArrayList;
    //   6: ifnull -> 122
    //   9: aload_0
    //   10: getfield j : Ljava/util/ArrayList;
    //   13: invokevirtual size : ()I
    //   16: ifgt -> 22
    //   19: goto -> 122
    //   22: aload_0
    //   23: getfield j : Ljava/util/ArrayList;
    //   26: iconst_m1
    //   27: aload_0
    //   28: getfield j : Ljava/util/ArrayList;
    //   31: invokevirtual size : ()I
    //   34: iadd
    //   35: invokevirtual remove : (I)Ljava/lang/Object;
    //   38: checkcast java/lang/Integer
    //   41: invokevirtual intValue : ()I
    //   44: istore #11
    //   46: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   49: ifeq -> 106
    //   52: new java/lang/StringBuilder
    //   55: dup
    //   56: invokespecial <init> : ()V
    //   59: astore #12
    //   61: aload #12
    //   63: ldc_w 'Adding back stack index '
    //   66: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   69: pop
    //   70: aload #12
    //   72: iload #11
    //   74: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   77: pop
    //   78: aload #12
    //   80: ldc_w ' with '
    //   83: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   86: pop
    //   87: aload #12
    //   89: aload_1
    //   90: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   93: pop
    //   94: ldc_w 'FragmentManager'
    //   97: aload #12
    //   99: invokevirtual toString : ()Ljava/lang/String;
    //   102: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   105: pop
    //   106: aload_0
    //   107: getfield i : Ljava/util/ArrayList;
    //   110: iload #11
    //   112: aload_1
    //   113: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   116: pop
    //   117: aload_0
    //   118: monitorexit
    //   119: iload #11
    //   121: ireturn
    //   122: aload_0
    //   123: getfield i : Ljava/util/ArrayList;
    //   126: ifnonnull -> 140
    //   129: aload_0
    //   130: new java/util/ArrayList
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: putfield i : Ljava/util/ArrayList;
    //   140: aload_0
    //   141: getfield i : Ljava/util/ArrayList;
    //   144: invokevirtual size : ()I
    //   147: istore_3
    //   148: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   151: ifeq -> 207
    //   154: new java/lang/StringBuilder
    //   157: dup
    //   158: invokespecial <init> : ()V
    //   161: astore #4
    //   163: aload #4
    //   165: ldc_w 'Setting back stack index '
    //   168: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: aload #4
    //   174: iload_3
    //   175: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   178: pop
    //   179: aload #4
    //   181: ldc_w ' to '
    //   184: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   187: pop
    //   188: aload #4
    //   190: aload_1
    //   191: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   194: pop
    //   195: ldc_w 'FragmentManager'
    //   198: aload #4
    //   200: invokevirtual toString : ()Ljava/lang/String;
    //   203: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   206: pop
    //   207: aload_0
    //   208: getfield i : Ljava/util/ArrayList;
    //   211: aload_1
    //   212: invokevirtual add : (Ljava/lang/Object;)Z
    //   215: pop
    //   216: aload_0
    //   217: monitorexit
    //   218: iload_3
    //   219: ireturn
    //   220: astore_2
    //   221: aload_0
    //   222: monitorexit
    //   223: aload_2
    //   224: athrow
    // Exception table:
    //   from	to	target	type
    //   2	19	220	finally
    //   22	106	220	finally
    //   106	119	220	finally
    //   122	140	220	finally
    //   140	207	220	finally
    //   207	218	220	finally
    //   221	223	220	finally
  }
  
  public void attachController(FragmentHostCallback paramFragmentHostCallback, FragmentContainer paramFragmentContainer, Fragment paramFragment) {
    if (this.m == null) {
      this.m = paramFragmentHostCallback;
      this.n = paramFragmentContainer;
      this.o = paramFragment;
      return;
    } 
    throw new IllegalStateException("Already attached");
  }
  
  public void attachFragment(Fragment paramFragment) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("attach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mDetached) {
      paramFragment.mDetached = false;
      if (!paramFragment.mAdded)
        if (!this.e.contains(paramFragment)) {
          if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("add from attach: ");
            stringBuilder.append(paramFragment);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          synchronized (this.e) {
            this.e.add(paramFragment);
            paramFragment.mAdded = true;
            if (paramFragment.mHasMenu && paramFragment.mMenuVisible) {
              this.r = true;
              return;
            } 
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Fragment already added: ");
          stringBuilder.append(paramFragment);
          throw new IllegalStateException(stringBuilder.toString());
        }  
    } 
  }
  
  void b() {
    if (this.v) {
      byte b = 0;
      boolean bool = false;
      while (b < this.f.size()) {
        Fragment fragment = (Fragment)this.f.valueAt(b);
        if (fragment != null && fragment.mLoaderManager != null)
          bool |= fragment.mLoaderManager.hasRunningLoaders(); 
        b++;
      } 
      if (!bool) {
        this.v = false;
        a();
      } 
    } 
  }
  
  void b(Fragment paramFragment) {
    if (paramFragment.mFromLayout && !paramFragment.mPerformedCreateView) {
      paramFragment.mView = paramFragment.performCreateView(paramFragment.performGetLayoutInflater(paramFragment.mSavedFragmentState), null, paramFragment.mSavedFragmentState);
      if (paramFragment.mView != null) {
        paramFragment.mInnerView = paramFragment.mView;
        paramFragment.mView.setSaveFromParentEnabled(false);
        if (paramFragment.mHidden)
          paramFragment.mView.setVisibility(8); 
        paramFragment.onViewCreated(paramFragment.mView, paramFragment.mSavedFragmentState);
        a(paramFragment, paramFragment.mView, paramFragment.mSavedFragmentState, false);
        return;
      } 
      paramFragment.mInnerView = null;
    } 
  }
  
  void b(Fragment paramFragment, Context paramContext, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).b(paramFragment, paramContext, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentAttached(this, paramFragment, paramContext); 
    } 
  }
  
  void b(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).b(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void b(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).b(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentResumed(this, paramFragment); 
    } 
  }
  
  public FragmentTransaction beginTransaction() {
    return new BackStackRecord(this);
  }
  
  void c() {
    if (this.k != null)
      for (byte b = 0; b < this.k.size(); b++)
        ((FragmentManager.OnBackStackChangedListener)this.k.get(b)).onBackStackChanged();  
  }
  
  void c(Fragment paramFragment) {
    if (paramFragment.mView != null) {
      AnimationOrAnimator animationOrAnimator = a(paramFragment, paramFragment.getNextTransition(), true ^ paramFragment.mHidden, paramFragment.getNextTransitionStyle());
      if (animationOrAnimator != null && animationOrAnimator.animator != null) {
        animationOrAnimator.animator.setTarget(paramFragment.mView);
        if (paramFragment.mHidden) {
          if (paramFragment.isHideReplaced()) {
            paramFragment.setHideReplaced(false);
          } else {
            ViewGroup viewGroup = paramFragment.mContainer;
            View view = paramFragment.mView;
            viewGroup.startViewTransition(view);
            animationOrAnimator.animator.addListener((Animator.AnimatorListener)new AnimatorListenerAdapter(this, viewGroup, view, paramFragment) {
                  public void onAnimationEnd(Animator param1Animator) {
                    this.a.endViewTransition(this.b);
                    param1Animator.removeListener((Animator.AnimatorListener)this);
                    if (this.c.mView != null)
                      this.c.mView.setVisibility(8); 
                  }
                });
          } 
        } else {
          paramFragment.mView.setVisibility(0);
        } 
        setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
        animationOrAnimator.animator.start();
      } else {
        boolean bool;
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
          paramFragment.mView.startAnimation(animationOrAnimator.animation);
          animationOrAnimator.animation.start();
        } 
        if (paramFragment.mHidden && !paramFragment.isHideReplaced()) {
          bool = true;
        } else {
          bool = false;
        } 
        paramFragment.mView.setVisibility(bool);
        if (paramFragment.isHideReplaced())
          paramFragment.setHideReplaced(false); 
      } 
    } 
    if (paramFragment.mAdded && paramFragment.mHasMenu && paramFragment.mMenuVisible)
      this.r = true; 
    paramFragment.mHiddenChanged = false;
    paramFragment.onHiddenChanged(paramFragment.mHidden);
  }
  
  void c(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).c(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentActivityCreated(this, paramFragment, paramBundle); 
    } 
  }
  
  void c(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).c(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentPaused(this, paramFragment); 
    } 
  }
  
  FragmentManagerNonConfig d() {
    setRetaining(this.C);
    return this.C;
  }
  
  void d(Fragment paramFragment) {
    if (paramFragment == null)
      return; 
    int i = this.l;
    if (paramFragment.mRemoving)
      if (paramFragment.isInBackStack()) {
        i = Math.min(i, 1);
      } else {
        i = Math.min(i, 0);
      }  
    a(paramFragment, i, paramFragment.getNextTransition(), paramFragment.getNextTransitionStyle(), false);
    if (paramFragment.mView != null) {
      Fragment fragment = findFragmentUnder(paramFragment);
      if (fragment != null) {
        View view = fragment.mView;
        ViewGroup viewGroup = paramFragment.mContainer;
        int j = viewGroup.indexOfChild(view);
        int k = viewGroup.indexOfChild(paramFragment.mView);
        if (k < j) {
          viewGroup.removeViewAt(k);
          viewGroup.addView(paramFragment.mView, j);
        } 
      } 
      if (paramFragment.mIsNewlyAdded && paramFragment.mContainer != null) {
        if (paramFragment.mPostponedAlpha > 0.0F)
          paramFragment.mView.setAlpha(paramFragment.mPostponedAlpha); 
        paramFragment.mPostponedAlpha = 0.0F;
        paramFragment.mIsNewlyAdded = false;
        AnimationOrAnimator animationOrAnimator = a(paramFragment, paramFragment.getNextTransition(), true, paramFragment.getNextTransitionStyle());
        if (animationOrAnimator != null) {
          setHWLayerAnimListenerIfAlpha(paramFragment.mView, animationOrAnimator);
          if (animationOrAnimator.animation != null) {
            paramFragment.mView.startAnimation(animationOrAnimator.animation);
          } else {
            animationOrAnimator.animator.setTarget(paramFragment.mView);
            animationOrAnimator.animator.start();
          } 
        } 
      } 
    } 
    if (paramFragment.mHiddenChanged)
      c(paramFragment); 
  }
  
  void d(Fragment paramFragment, Bundle paramBundle, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).d(paramFragment, paramBundle, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentSaveInstanceState(this, paramFragment, paramBundle); 
    } 
  }
  
  void d(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).d(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentStopped(this, paramFragment); 
    } 
  }
  
  public void detachFragment(Fragment paramFragment) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mDetached) {
      paramFragment.mDetached = true;
      if (paramFragment.mAdded) {
        if (a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("remove from detach: ");
          stringBuilder.append(paramFragment);
          Log.v("FragmentManager", stringBuilder.toString());
        } 
        synchronized (this.e) {
          this.e.remove(paramFragment);
          if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
            this.r = true; 
          paramFragment.mAdded = false;
          return;
        } 
      } 
    } 
  }
  
  public void dispatchActivityCreated() {
    this.s = false;
    dispatchStateChange(2);
  }
  
  public void dispatchConfigurationChanged(Configuration paramConfiguration) {
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = this.e.get(b);
      if (fragment != null)
        fragment.performConfigurationChanged(paramConfiguration); 
    } 
  }
  
  public boolean dispatchContextItemSelected(MenuItem paramMenuItem) {
    if (this.l < 1)
      return false; 
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = this.e.get(b);
      if (fragment != null && fragment.performContextItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchCreate() {
    this.s = false;
    dispatchStateChange(1);
  }
  
  public boolean dispatchCreateOptionsMenu(Menu paramMenu, MenuInflater paramMenuInflater) {
    if (this.l < 1)
      return false; 
    ArrayList<Fragment> arrayList1 = null;
    byte b1 = 0;
    boolean bool = false;
    while (b1 < this.e.size()) {
      Fragment fragment = this.e.get(b1);
      if (fragment != null && fragment.performCreateOptionsMenu(paramMenu, paramMenuInflater)) {
        if (arrayList1 == null)
          arrayList1 = new ArrayList(); 
        arrayList1.add(fragment);
        bool = true;
      } 
      b1++;
    } 
    ArrayList<Fragment> arrayList2 = this.h;
    byte b2 = 0;
    if (arrayList2 != null)
      while (b2 < this.h.size()) {
        Fragment fragment = this.h.get(b2);
        if (arrayList1 == null || !arrayList1.contains(fragment))
          fragment.onDestroyOptionsMenu(); 
        b2++;
      }  
    this.h = arrayList1;
    return bool;
  }
  
  public void dispatchDestroy() {
    this.t = true;
    execPendingActions();
    dispatchStateChange(0);
    this.m = null;
    this.n = null;
    this.o = null;
  }
  
  public void dispatchDestroyView() {
    dispatchStateChange(1);
  }
  
  public void dispatchLowMemory() {
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = this.e.get(b);
      if (fragment != null)
        fragment.performLowMemory(); 
    } 
  }
  
  public void dispatchMultiWindowModeChanged(boolean paramBoolean) {
    for (int i = -1 + this.e.size(); i >= 0; i--) {
      Fragment fragment = this.e.get(i);
      if (fragment != null)
        fragment.performMultiWindowModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchOptionsItemSelected(MenuItem paramMenuItem) {
    if (this.l < 1)
      return false; 
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = this.e.get(b);
      if (fragment != null && fragment.performOptionsItemSelected(paramMenuItem))
        return true; 
    } 
    return false;
  }
  
  public void dispatchOptionsMenuClosed(Menu paramMenu) {
    if (this.l < 1)
      return; 
    for (byte b = 0; b < this.e.size(); b++) {
      Fragment fragment = this.e.get(b);
      if (fragment != null)
        fragment.performOptionsMenuClosed(paramMenu); 
    } 
  }
  
  public void dispatchPause() {
    dispatchStateChange(4);
  }
  
  public void dispatchPictureInPictureModeChanged(boolean paramBoolean) {
    for (int i = -1 + this.e.size(); i >= 0; i--) {
      Fragment fragment = this.e.get(i);
      if (fragment != null)
        fragment.performPictureInPictureModeChanged(paramBoolean); 
    } 
  }
  
  public boolean dispatchPrepareOptionsMenu(Menu paramMenu) {
    int i = this.l;
    byte b = 0;
    if (i < 1)
      return false; 
    boolean bool = false;
    while (b < this.e.size()) {
      Fragment fragment = this.e.get(b);
      if (fragment != null && fragment.performPrepareOptionsMenu(paramMenu))
        bool = true; 
      b++;
    } 
    return bool;
  }
  
  public void dispatchReallyStop() {
    dispatchStateChange(2);
  }
  
  public void dispatchResume() {
    this.s = false;
    dispatchStateChange(5);
  }
  
  public void dispatchStart() {
    this.s = false;
    dispatchStateChange(4);
  }
  
  public void dispatchStop() {
    this.s = true;
    dispatchStateChange(3);
  }
  
  public void dump(String paramString, FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {
    // Byte code:
    //   0: new java/lang/StringBuilder
    //   3: dup
    //   4: invokespecial <init> : ()V
    //   7: astore #5
    //   9: aload #5
    //   11: aload_1
    //   12: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   15: pop
    //   16: aload #5
    //   18: ldc_w '    '
    //   21: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   24: pop
    //   25: aload #5
    //   27: invokevirtual toString : ()Ljava/lang/String;
    //   30: astore #8
    //   32: aload_0
    //   33: getfield f : Landroid/util/SparseArray;
    //   36: astore #9
    //   38: iconst_0
    //   39: istore #10
    //   41: aload #9
    //   43: ifnull -> 167
    //   46: aload_0
    //   47: getfield f : Landroid/util/SparseArray;
    //   50: invokevirtual size : ()I
    //   53: istore #26
    //   55: iload #26
    //   57: ifle -> 167
    //   60: aload_3
    //   61: aload_1
    //   62: invokevirtual print : (Ljava/lang/String;)V
    //   65: aload_3
    //   66: ldc_w 'Active Fragments in '
    //   69: invokevirtual print : (Ljava/lang/String;)V
    //   72: aload_3
    //   73: aload_0
    //   74: invokestatic identityHashCode : (Ljava/lang/Object;)I
    //   77: invokestatic toHexString : (I)Ljava/lang/String;
    //   80: invokevirtual print : (Ljava/lang/String;)V
    //   83: aload_3
    //   84: ldc_w ':'
    //   87: invokevirtual println : (Ljava/lang/String;)V
    //   90: iconst_0
    //   91: istore #27
    //   93: iload #27
    //   95: iload #26
    //   97: if_icmpge -> 167
    //   100: aload_0
    //   101: getfield f : Landroid/util/SparseArray;
    //   104: iload #27
    //   106: invokevirtual valueAt : (I)Ljava/lang/Object;
    //   109: checkcast android/support/v4/app/Fragment
    //   112: astore #28
    //   114: aload_3
    //   115: aload_1
    //   116: invokevirtual print : (Ljava/lang/String;)V
    //   119: aload_3
    //   120: ldc_w '  #'
    //   123: invokevirtual print : (Ljava/lang/String;)V
    //   126: aload_3
    //   127: iload #27
    //   129: invokevirtual print : (I)V
    //   132: aload_3
    //   133: ldc_w ': '
    //   136: invokevirtual print : (Ljava/lang/String;)V
    //   139: aload_3
    //   140: aload #28
    //   142: invokevirtual println : (Ljava/lang/Object;)V
    //   145: aload #28
    //   147: ifnull -> 161
    //   150: aload #28
    //   152: aload #8
    //   154: aload_2
    //   155: aload_3
    //   156: aload #4
    //   158: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   161: iinc #27, 1
    //   164: goto -> 93
    //   167: aload_0
    //   168: getfield e : Ljava/util/ArrayList;
    //   171: invokevirtual size : ()I
    //   174: istore #11
    //   176: iload #11
    //   178: ifle -> 257
    //   181: aload_3
    //   182: aload_1
    //   183: invokevirtual print : (Ljava/lang/String;)V
    //   186: aload_3
    //   187: ldc_w 'Added Fragments:'
    //   190: invokevirtual println : (Ljava/lang/String;)V
    //   193: iconst_0
    //   194: istore #24
    //   196: iload #24
    //   198: iload #11
    //   200: if_icmpge -> 257
    //   203: aload_0
    //   204: getfield e : Ljava/util/ArrayList;
    //   207: iload #24
    //   209: invokevirtual get : (I)Ljava/lang/Object;
    //   212: checkcast android/support/v4/app/Fragment
    //   215: astore #25
    //   217: aload_3
    //   218: aload_1
    //   219: invokevirtual print : (Ljava/lang/String;)V
    //   222: aload_3
    //   223: ldc_w '  #'
    //   226: invokevirtual print : (Ljava/lang/String;)V
    //   229: aload_3
    //   230: iload #24
    //   232: invokevirtual print : (I)V
    //   235: aload_3
    //   236: ldc_w ': '
    //   239: invokevirtual print : (Ljava/lang/String;)V
    //   242: aload_3
    //   243: aload #25
    //   245: invokevirtual toString : ()Ljava/lang/String;
    //   248: invokevirtual println : (Ljava/lang/String;)V
    //   251: iinc #24, 1
    //   254: goto -> 196
    //   257: aload_0
    //   258: getfield h : Ljava/util/ArrayList;
    //   261: ifnull -> 354
    //   264: aload_0
    //   265: getfield h : Ljava/util/ArrayList;
    //   268: invokevirtual size : ()I
    //   271: istore #21
    //   273: iload #21
    //   275: ifle -> 354
    //   278: aload_3
    //   279: aload_1
    //   280: invokevirtual print : (Ljava/lang/String;)V
    //   283: aload_3
    //   284: ldc_w 'Fragments Created Menus:'
    //   287: invokevirtual println : (Ljava/lang/String;)V
    //   290: iconst_0
    //   291: istore #22
    //   293: iload #22
    //   295: iload #21
    //   297: if_icmpge -> 354
    //   300: aload_0
    //   301: getfield h : Ljava/util/ArrayList;
    //   304: iload #22
    //   306: invokevirtual get : (I)Ljava/lang/Object;
    //   309: checkcast android/support/v4/app/Fragment
    //   312: astore #23
    //   314: aload_3
    //   315: aload_1
    //   316: invokevirtual print : (Ljava/lang/String;)V
    //   319: aload_3
    //   320: ldc_w '  #'
    //   323: invokevirtual print : (Ljava/lang/String;)V
    //   326: aload_3
    //   327: iload #22
    //   329: invokevirtual print : (I)V
    //   332: aload_3
    //   333: ldc_w ': '
    //   336: invokevirtual print : (Ljava/lang/String;)V
    //   339: aload_3
    //   340: aload #23
    //   342: invokevirtual toString : ()Ljava/lang/String;
    //   345: invokevirtual println : (Ljava/lang/String;)V
    //   348: iinc #22, 1
    //   351: goto -> 293
    //   354: aload_0
    //   355: getfield g : Ljava/util/ArrayList;
    //   358: ifnull -> 462
    //   361: aload_0
    //   362: getfield g : Ljava/util/ArrayList;
    //   365: invokevirtual size : ()I
    //   368: istore #18
    //   370: iload #18
    //   372: ifle -> 462
    //   375: aload_3
    //   376: aload_1
    //   377: invokevirtual print : (Ljava/lang/String;)V
    //   380: aload_3
    //   381: ldc_w 'Back Stack:'
    //   384: invokevirtual println : (Ljava/lang/String;)V
    //   387: iconst_0
    //   388: istore #19
    //   390: iload #19
    //   392: iload #18
    //   394: if_icmpge -> 462
    //   397: aload_0
    //   398: getfield g : Ljava/util/ArrayList;
    //   401: iload #19
    //   403: invokevirtual get : (I)Ljava/lang/Object;
    //   406: checkcast android/support/v4/app/BackStackRecord
    //   409: astore #20
    //   411: aload_3
    //   412: aload_1
    //   413: invokevirtual print : (Ljava/lang/String;)V
    //   416: aload_3
    //   417: ldc_w '  #'
    //   420: invokevirtual print : (Ljava/lang/String;)V
    //   423: aload_3
    //   424: iload #19
    //   426: invokevirtual print : (I)V
    //   429: aload_3
    //   430: ldc_w ': '
    //   433: invokevirtual print : (Ljava/lang/String;)V
    //   436: aload_3
    //   437: aload #20
    //   439: invokevirtual toString : ()Ljava/lang/String;
    //   442: invokevirtual println : (Ljava/lang/String;)V
    //   445: aload #20
    //   447: aload #8
    //   449: aload_2
    //   450: aload_3
    //   451: aload #4
    //   453: invokevirtual dump : (Ljava/lang/String;Ljava/io/FileDescriptor;Ljava/io/PrintWriter;[Ljava/lang/String;)V
    //   456: iinc #19, 1
    //   459: goto -> 390
    //   462: aload_0
    //   463: monitorenter
    //   464: aload_0
    //   465: getfield i : Ljava/util/ArrayList;
    //   468: ifnull -> 558
    //   471: aload_0
    //   472: getfield i : Ljava/util/ArrayList;
    //   475: invokevirtual size : ()I
    //   478: istore #15
    //   480: iload #15
    //   482: ifle -> 558
    //   485: aload_3
    //   486: aload_1
    //   487: invokevirtual print : (Ljava/lang/String;)V
    //   490: aload_3
    //   491: ldc_w 'Back Stack Indices:'
    //   494: invokevirtual println : (Ljava/lang/String;)V
    //   497: iconst_0
    //   498: istore #16
    //   500: iload #16
    //   502: iload #15
    //   504: if_icmpge -> 558
    //   507: aload_0
    //   508: getfield i : Ljava/util/ArrayList;
    //   511: iload #16
    //   513: invokevirtual get : (I)Ljava/lang/Object;
    //   516: checkcast android/support/v4/app/BackStackRecord
    //   519: astore #17
    //   521: aload_3
    //   522: aload_1
    //   523: invokevirtual print : (Ljava/lang/String;)V
    //   526: aload_3
    //   527: ldc_w '  #'
    //   530: invokevirtual print : (Ljava/lang/String;)V
    //   533: aload_3
    //   534: iload #16
    //   536: invokevirtual print : (I)V
    //   539: aload_3
    //   540: ldc_w ': '
    //   543: invokevirtual print : (Ljava/lang/String;)V
    //   546: aload_3
    //   547: aload #17
    //   549: invokevirtual println : (Ljava/lang/Object;)V
    //   552: iinc #16, 1
    //   555: goto -> 500
    //   558: aload_0
    //   559: getfield j : Ljava/util/ArrayList;
    //   562: ifnull -> 601
    //   565: aload_0
    //   566: getfield j : Ljava/util/ArrayList;
    //   569: invokevirtual size : ()I
    //   572: ifle -> 601
    //   575: aload_3
    //   576: aload_1
    //   577: invokevirtual print : (Ljava/lang/String;)V
    //   580: aload_3
    //   581: ldc_w 'mAvailBackStackIndices: '
    //   584: invokevirtual print : (Ljava/lang/String;)V
    //   587: aload_3
    //   588: aload_0
    //   589: getfield j : Ljava/util/ArrayList;
    //   592: invokevirtual toArray : ()[Ljava/lang/Object;
    //   595: invokestatic toString : ([Ljava/lang/Object;)Ljava/lang/String;
    //   598: invokevirtual println : (Ljava/lang/String;)V
    //   601: aload_0
    //   602: monitorexit
    //   603: aload_0
    //   604: getfield b : Ljava/util/ArrayList;
    //   607: ifnull -> 694
    //   610: aload_0
    //   611: getfield b : Ljava/util/ArrayList;
    //   614: invokevirtual size : ()I
    //   617: istore #13
    //   619: iload #13
    //   621: ifle -> 694
    //   624: aload_3
    //   625: aload_1
    //   626: invokevirtual print : (Ljava/lang/String;)V
    //   629: aload_3
    //   630: ldc_w 'Pending Actions:'
    //   633: invokevirtual println : (Ljava/lang/String;)V
    //   636: iload #10
    //   638: iload #13
    //   640: if_icmpge -> 694
    //   643: aload_0
    //   644: getfield b : Ljava/util/ArrayList;
    //   647: iload #10
    //   649: invokevirtual get : (I)Ljava/lang/Object;
    //   652: checkcast android/support/v4/app/FragmentManagerImpl$OpGenerator
    //   655: astore #14
    //   657: aload_3
    //   658: aload_1
    //   659: invokevirtual print : (Ljava/lang/String;)V
    //   662: aload_3
    //   663: ldc_w '  #'
    //   666: invokevirtual print : (Ljava/lang/String;)V
    //   669: aload_3
    //   670: iload #10
    //   672: invokevirtual print : (I)V
    //   675: aload_3
    //   676: ldc_w ': '
    //   679: invokevirtual print : (Ljava/lang/String;)V
    //   682: aload_3
    //   683: aload #14
    //   685: invokevirtual println : (Ljava/lang/Object;)V
    //   688: iinc #10, 1
    //   691: goto -> 636
    //   694: aload_3
    //   695: aload_1
    //   696: invokevirtual print : (Ljava/lang/String;)V
    //   699: aload_3
    //   700: ldc_w 'FragmentManager misc state:'
    //   703: invokevirtual println : (Ljava/lang/String;)V
    //   706: aload_3
    //   707: aload_1
    //   708: invokevirtual print : (Ljava/lang/String;)V
    //   711: aload_3
    //   712: ldc_w '  mHost='
    //   715: invokevirtual print : (Ljava/lang/String;)V
    //   718: aload_3
    //   719: aload_0
    //   720: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   723: invokevirtual println : (Ljava/lang/Object;)V
    //   726: aload_3
    //   727: aload_1
    //   728: invokevirtual print : (Ljava/lang/String;)V
    //   731: aload_3
    //   732: ldc_w '  mContainer='
    //   735: invokevirtual print : (Ljava/lang/String;)V
    //   738: aload_3
    //   739: aload_0
    //   740: getfield n : Landroid/support/v4/app/FragmentContainer;
    //   743: invokevirtual println : (Ljava/lang/Object;)V
    //   746: aload_0
    //   747: getfield o : Landroid/support/v4/app/Fragment;
    //   750: ifnull -> 773
    //   753: aload_3
    //   754: aload_1
    //   755: invokevirtual print : (Ljava/lang/String;)V
    //   758: aload_3
    //   759: ldc_w '  mParent='
    //   762: invokevirtual print : (Ljava/lang/String;)V
    //   765: aload_3
    //   766: aload_0
    //   767: getfield o : Landroid/support/v4/app/Fragment;
    //   770: invokevirtual println : (Ljava/lang/Object;)V
    //   773: aload_3
    //   774: aload_1
    //   775: invokevirtual print : (Ljava/lang/String;)V
    //   778: aload_3
    //   779: ldc_w '  mCurState='
    //   782: invokevirtual print : (Ljava/lang/String;)V
    //   785: aload_3
    //   786: aload_0
    //   787: getfield l : I
    //   790: invokevirtual print : (I)V
    //   793: aload_3
    //   794: ldc_w ' mStateSaved='
    //   797: invokevirtual print : (Ljava/lang/String;)V
    //   800: aload_3
    //   801: aload_0
    //   802: getfield s : Z
    //   805: invokevirtual print : (Z)V
    //   808: aload_3
    //   809: ldc_w ' mDestroyed='
    //   812: invokevirtual print : (Ljava/lang/String;)V
    //   815: aload_3
    //   816: aload_0
    //   817: getfield t : Z
    //   820: invokevirtual println : (Z)V
    //   823: aload_0
    //   824: getfield r : Z
    //   827: ifeq -> 850
    //   830: aload_3
    //   831: aload_1
    //   832: invokevirtual print : (Ljava/lang/String;)V
    //   835: aload_3
    //   836: ldc_w '  mNeedMenuInvalidate='
    //   839: invokevirtual print : (Ljava/lang/String;)V
    //   842: aload_3
    //   843: aload_0
    //   844: getfield r : Z
    //   847: invokevirtual println : (Z)V
    //   850: aload_0
    //   851: getfield u : Ljava/lang/String;
    //   854: ifnull -> 877
    //   857: aload_3
    //   858: aload_1
    //   859: invokevirtual print : (Ljava/lang/String;)V
    //   862: aload_3
    //   863: ldc_w '  mNoTransactionsBecause='
    //   866: invokevirtual print : (Ljava/lang/String;)V
    //   869: aload_3
    //   870: aload_0
    //   871: getfield u : Ljava/lang/String;
    //   874: invokevirtual println : (Ljava/lang/String;)V
    //   877: return
    //   878: astore #12
    //   880: aload_0
    //   881: monitorexit
    //   882: aload #12
    //   884: athrow
    // Exception table:
    //   from	to	target	type
    //   464	480	878	finally
    //   485	497	878	finally
    //   507	552	878	finally
    //   558	601	878	finally
    //   601	603	878	finally
    //   880	882	878	finally
  }
  
  void e() {
    List list1;
    List list2;
    List list3;
    if (this.f != null) {
      list1 = null;
      list2 = null;
      list3 = null;
      for (byte b = 0; b < this.f.size(); b++) {
        Fragment fragment = (Fragment)this.f.valueAt(b);
        if (fragment != null) {
          FragmentManagerNonConfig fragmentManagerNonConfig;
          if (fragment.mRetainInstance) {
            byte b1;
            if (list1 == null)
              list1 = new ArrayList(); 
            list1.add(fragment);
            if (fragment.mTarget != null) {
              b1 = fragment.mTarget.mIndex;
            } else {
              b1 = -1;
            } 
            fragment.mTargetIndex = b1;
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("retainNonConfig: keeping retained ");
              stringBuilder.append(fragment);
              Log.v("FragmentManager", stringBuilder.toString());
            } 
          } 
          if (fragment.mChildFragmentManager != null) {
            fragment.mChildFragmentManager.e();
            fragmentManagerNonConfig = fragment.mChildFragmentManager.C;
          } else {
            fragmentManagerNonConfig = fragment.mChildNonConfig;
          } 
          if (list2 == null && fragmentManagerNonConfig != null) {
            list2 = new ArrayList(this.f.size());
            for (byte b1 = 0; b1 < b; b1++)
              list2.add(null); 
          } 
          if (list2 != null)
            list2.add(fragmentManagerNonConfig); 
          if (list3 == null && fragment.mViewModelStore != null) {
            list3 = new ArrayList(this.f.size());
            for (byte b1 = 0; b1 < b; b1++)
              list3.add(null); 
          } 
          if (list3 != null)
            list3.add(fragment.mViewModelStore); 
        } 
      } 
    } else {
      list1 = null;
      list2 = null;
      list3 = null;
    } 
    if (list1 == null && list2 == null && list3 == null) {
      this.C = null;
      return;
    } 
    this.C = new FragmentManagerNonConfig(list1, list2, list3);
  }
  
  void e(Fragment paramFragment) {
    if (paramFragment.mIndex >= 0)
      return; 
    int i = this.d;
    this.d = i + 1;
    paramFragment.setIndex(i, this.o);
    if (this.f == null)
      this.f = new SparseArray(); 
    this.f.put(paramFragment.mIndex, paramFragment);
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Allocated fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
  }
  
  void e(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).e(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentViewDestroyed(this, paramFragment); 
    } 
  }
  
  public void enqueueAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    // Byte code:
    //   0: iload_2
    //   1: ifne -> 8
    //   4: aload_0
    //   5: invokespecial checkStateLoss : ()V
    //   8: aload_0
    //   9: monitorenter
    //   10: aload_0
    //   11: getfield t : Z
    //   14: ifne -> 61
    //   17: aload_0
    //   18: getfield m : Landroid/support/v4/app/FragmentHostCallback;
    //   21: ifnonnull -> 27
    //   24: goto -> 61
    //   27: aload_0
    //   28: getfield b : Ljava/util/ArrayList;
    //   31: ifnonnull -> 45
    //   34: aload_0
    //   35: new java/util/ArrayList
    //   38: dup
    //   39: invokespecial <init> : ()V
    //   42: putfield b : Ljava/util/ArrayList;
    //   45: aload_0
    //   46: getfield b : Ljava/util/ArrayList;
    //   49: aload_1
    //   50: invokevirtual add : (Ljava/lang/Object;)Z
    //   53: pop
    //   54: aload_0
    //   55: invokespecial scheduleCommit : ()V
    //   58: aload_0
    //   59: monitorexit
    //   60: return
    //   61: iload_2
    //   62: ifeq -> 68
    //   65: aload_0
    //   66: monitorexit
    //   67: return
    //   68: new java/lang/IllegalStateException
    //   71: dup
    //   72: ldc_w 'Activity has been destroyed'
    //   75: invokespecial <init> : (Ljava/lang/String;)V
    //   78: athrow
    //   79: astore_3
    //   80: aload_0
    //   81: monitorexit
    //   82: aload_3
    //   83: athrow
    // Exception table:
    //   from	to	target	type
    //   10	24	79	finally
    //   27	45	79	finally
    //   45	60	79	finally
    //   65	67	79	finally
    //   68	79	79	finally
    //   80	82	79	finally
  }
  
  public boolean execPendingActions() {
    ensureExecReady(true);
    boolean bool = false;
    while (generateOpsForPendingActions(this.w, this.x)) {
      this.c = true;
      try {
        removeRedundantOperationsAndExecute(this.w, this.x);
        cleanupExec();
      } finally {
        cleanupExec();
      } 
    } 
    b();
    burpActive();
    return bool;
  }
  
  public void execSingleAction(OpGenerator paramOpGenerator, boolean paramBoolean) {
    if (paramBoolean && (this.m == null || this.t))
      return; 
    ensureExecReady(paramBoolean);
    if (paramOpGenerator.generateOps(this.w, this.x)) {
      this.c = true;
      try {
        removeRedundantOperationsAndExecute(this.w, this.x);
      } finally {
        cleanupExec();
      } 
    } 
    b();
    burpActive();
  }
  
  public boolean executePendingTransactions() {
    boolean bool = execPendingActions();
    forcePostponedTransactions();
    return bool;
  }
  
  Parcelable f() {
    forcePostponedTransactions();
    endAnimatingAwayFragments();
    execPendingActions();
    this.s = true;
    this.C = null;
    if (this.f != null) {
      int[] arrayOfInt;
      if (this.f.size() <= 0)
        return null; 
      int i = this.f.size();
      FragmentState[] arrayOfFragmentState = new FragmentState[i];
      byte b1 = 0;
      byte b2 = 0;
      boolean bool = false;
      while (b2 < i) {
        Fragment fragment = (Fragment)this.f.valueAt(b2);
        if (fragment != null) {
          if (fragment.mIndex < 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failure saving state: active ");
            stringBuilder.append(fragment);
            stringBuilder.append(" has cleared index: ");
            stringBuilder.append(fragment.mIndex);
            throwException(new IllegalStateException(stringBuilder.toString()));
          } 
          FragmentState fragmentState = new FragmentState(fragment);
          arrayOfFragmentState[b2] = fragmentState;
          if (fragment.mState > 0 && fragmentState.k == null) {
            fragmentState.k = h(fragment);
            if (fragment.mTarget != null) {
              if (fragment.mTarget.mIndex < 0) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Failure saving state: ");
                stringBuilder.append(fragment);
                stringBuilder.append(" has target not in fragment manager: ");
                stringBuilder.append(fragment.mTarget);
                throwException(new IllegalStateException(stringBuilder.toString()));
              } 
              if (fragmentState.k == null)
                fragmentState.k = new Bundle(); 
              putFragment(fragmentState.k, "android:target_state", fragment.mTarget);
              if (fragment.mTargetRequestCode != 0)
                fragmentState.k.putInt("android:target_req_state", fragment.mTargetRequestCode); 
            } 
          } else {
            fragmentState.k = fragment.mSavedFragmentState;
          } 
          if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Saved state of ");
            stringBuilder.append(fragment);
            stringBuilder.append(": ");
            stringBuilder.append(fragmentState.k);
            Log.v("FragmentManager", stringBuilder.toString());
          } 
          bool = true;
        } 
        b2++;
      } 
      if (!bool) {
        if (a)
          Log.v("FragmentManager", "saveAllState: no fragments!"); 
        return null;
      } 
      int j = this.e.size();
      if (j > 0) {
        arrayOfInt = new int[j];
        for (byte b = 0; b < j; b++) {
          arrayOfInt[b] = ((Fragment)this.e.get(b)).mIndex;
          if (arrayOfInt[b] < 0) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Failure saving state: active ");
            stringBuilder.append(this.e.get(b));
            stringBuilder.append(" has cleared index: ");
            stringBuilder.append(arrayOfInt[b]);
            throwException(new IllegalStateException(stringBuilder.toString()));
          } 
          if (a) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("saveAllState: adding fragment #");
            stringBuilder.append(b);
            stringBuilder.append(": ");
            stringBuilder.append(this.e.get(b));
            Log.v("FragmentManager", stringBuilder.toString());
          } 
        } 
      } else {
        arrayOfInt = null;
      } 
      ArrayList<BackStackRecord> arrayList = this.g;
      BackStackState[] arrayOfBackStackState = null;
      if (arrayList != null) {
        int k = this.g.size();
        arrayOfBackStackState = null;
        if (k > 0) {
          arrayOfBackStackState = new BackStackState[k];
          while (b1 < k) {
            arrayOfBackStackState[b1] = new BackStackState(this.g.get(b1));
            if (a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("saveAllState: adding back stack #");
              stringBuilder.append(b1);
              stringBuilder.append(": ");
              stringBuilder.append(this.g.get(b1));
              Log.v("FragmentManager", stringBuilder.toString());
            } 
            b1++;
          } 
        } 
      } 
      FragmentManagerState fragmentManagerState = new FragmentManagerState();
      fragmentManagerState.a = arrayOfFragmentState;
      fragmentManagerState.b = arrayOfInt;
      fragmentManagerState.c = arrayOfBackStackState;
      if (this.p != null)
        fragmentManagerState.d = this.p.mIndex; 
      fragmentManagerState.e = this.d;
      e();
      return fragmentManagerState;
    } 
    return null;
  }
  
  void f(Fragment paramFragment) {
    if (paramFragment.mIndex < 0)
      return; 
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Freeing fragment index ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    this.f.put(paramFragment.mIndex, null);
    paramFragment.initState();
  }
  
  void f(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).f(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDestroyed(this, paramFragment); 
    } 
  }
  
  public Fragment findFragmentById(int paramInt) {
    for (int i = -1 + this.e.size(); i >= 0; i--) {
      Fragment fragment = this.e.get(i);
      if (fragment != null && fragment.mFragmentId == paramInt)
        return fragment; 
    } 
    if (this.f != null)
      for (int j = -1 + this.f.size(); j >= 0; j--) {
        Fragment fragment = (Fragment)this.f.valueAt(j);
        if (fragment != null && fragment.mFragmentId == paramInt)
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByTag(String paramString) {
    if (paramString != null)
      for (int i = -1 + this.e.size(); i >= 0; i--) {
        Fragment fragment = this.e.get(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    if (this.f != null && paramString != null)
      for (int i = -1 + this.f.size(); i >= 0; i--) {
        Fragment fragment = (Fragment)this.f.valueAt(i);
        if (fragment != null && paramString.equals(fragment.mTag))
          return fragment; 
      }  
    return null;
  }
  
  public Fragment findFragmentByWho(String paramString) {
    if (this.f != null && paramString != null)
      for (int i = -1 + this.f.size(); i >= 0; i--) {
        Fragment fragment = (Fragment)this.f.valueAt(i);
        if (fragment != null) {
          Fragment fragment1 = fragment.findFragmentByWho(paramString);
          if (fragment1 != null)
            return fragment1; 
        } 
      }  
    return null;
  }
  
  public void freeBackStackIndex(int paramInt) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Ljava/util/ArrayList;
    //   6: iload_1
    //   7: aconst_null
    //   8: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   11: pop
    //   12: aload_0
    //   13: getfield j : Ljava/util/ArrayList;
    //   16: ifnonnull -> 30
    //   19: aload_0
    //   20: new java/util/ArrayList
    //   23: dup
    //   24: invokespecial <init> : ()V
    //   27: putfield j : Ljava/util/ArrayList;
    //   30: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   33: ifeq -> 73
    //   36: new java/lang/StringBuilder
    //   39: dup
    //   40: invokespecial <init> : ()V
    //   43: astore #4
    //   45: aload #4
    //   47: ldc_w 'Freeing back stack index '
    //   50: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   53: pop
    //   54: aload #4
    //   56: iload_1
    //   57: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   60: pop
    //   61: ldc_w 'FragmentManager'
    //   64: aload #4
    //   66: invokevirtual toString : ()Ljava/lang/String;
    //   69: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   72: pop
    //   73: aload_0
    //   74: getfield j : Ljava/util/ArrayList;
    //   77: iload_1
    //   78: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   81: invokevirtual add : (Ljava/lang/Object;)Z
    //   84: pop
    //   85: aload_0
    //   86: monitorexit
    //   87: return
    //   88: astore_2
    //   89: aload_0
    //   90: monitorexit
    //   91: aload_2
    //   92: athrow
    // Exception table:
    //   from	to	target	type
    //   2	30	88	finally
    //   30	73	88	finally
    //   73	87	88	finally
    //   89	91	88	finally
  }
  
  void g(Fragment paramFragment) {
    if (paramFragment.mInnerView == null)
      return; 
    if (this.A == null) {
      this.A = new SparseArray();
    } else {
      this.A.clear();
    } 
    paramFragment.mInnerView.saveHierarchyState(this.A);
    if (this.A.size() > 0) {
      paramFragment.mSavedViewState = this.A;
      this.A = null;
    } 
  }
  
  void g(Fragment paramFragment, boolean paramBoolean) {
    if (this.o != null) {
      FragmentManager fragmentManager = this.o.getFragmentManager();
      if (fragmentManager instanceof FragmentManagerImpl)
        ((FragmentManagerImpl)fragmentManager).g(paramFragment, true); 
    } 
    for (Pair<FragmentManager.FragmentLifecycleCallbacks, Boolean> pair : this.mLifecycleCallbacks) {
      if (!paramBoolean || ((Boolean)pair.second).booleanValue())
        ((FragmentManager.FragmentLifecycleCallbacks)pair.first).onFragmentDetached(this, paramFragment); 
    } 
  }
  
  int getActiveFragmentCount() {
    return (this.f == null) ? 0 : this.f.size();
  }
  
  List<Fragment> getActiveFragments() {
    if (this.f == null)
      return null; 
    int i = this.f.size();
    ArrayList<Object> arrayList = new ArrayList(i);
    for (byte b = 0; b < i; b++)
      arrayList.add(this.f.valueAt(b)); 
    return arrayList;
  }
  
  public FragmentManager.BackStackEntry getBackStackEntryAt(int paramInt) {
    return this.g.get(paramInt);
  }
  
  public int getBackStackEntryCount() {
    return (this.g != null) ? this.g.size() : 0;
  }
  
  public Fragment getFragment(Bundle paramBundle, String paramString) {
    int i = paramBundle.getInt(paramString, -1);
    if (i == -1)
      return null; 
    Fragment fragment = (Fragment)this.f.get(i);
    if (fragment == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment no longer exists for key ");
      stringBuilder.append(paramString);
      stringBuilder.append(": index ");
      stringBuilder.append(i);
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    return fragment;
  }
  
  public List<Fragment> getFragments() {
    if (this.e.isEmpty())
      return Collections.EMPTY_LIST; 
    synchronized (this.e) {
      return (List)this.e.clone();
    } 
  }
  
  LayoutInflater.Factory2 getLayoutInflaterFactory() {
    return this;
  }
  
  public Fragment getPrimaryNavigationFragment() {
    return this.p;
  }
  
  Bundle h(Fragment paramFragment) {
    Bundle bundle;
    if (this.z == null)
      this.z = new Bundle(); 
    paramFragment.performSaveInstanceState(this.z);
    d(paramFragment, this.z, false);
    if (!this.z.isEmpty()) {
      bundle = this.z;
      this.z = null;
    } else {
      bundle = null;
    } 
    if (paramFragment.mView != null)
      g(paramFragment); 
    if (paramFragment.mSavedViewState != null) {
      if (bundle == null)
        bundle = new Bundle(); 
      bundle.putSparseParcelableArray("android:view_state", paramFragment.mSavedViewState);
    } 
    if (!paramFragment.mUserVisibleHint) {
      if (bundle == null)
        bundle = new Bundle(); 
      bundle.putBoolean("android:user_visible_hint", paramFragment.mUserVisibleHint);
    } 
    return bundle;
  }
  
  public void hideFragment(Fragment paramFragment) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("hide: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (!paramFragment.mHidden) {
      paramFragment.mHidden = true;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public boolean isDestroyed() {
    return this.t;
  }
  
  boolean isStateAtLeast(int paramInt) {
    return (this.l >= paramInt);
  }
  
  public boolean isStateSaved() {
    return this.s;
  }
  
  public void noteStateNotSaved() {
    this.C = null;
    byte b = 0;
    this.s = false;
    int i = this.e.size();
    while (b < i) {
      Fragment fragment = this.e.get(b);
      if (fragment != null)
        fragment.noteStateNotSaved(); 
      b++;
    } 
  }
  
  public View onCreateView(View paramView, String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    if (!"fragment".equals(paramString))
      return null; 
    String str1 = paramAttributeSet.getAttributeValue(null, "class");
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, FragmentTag.Fragment);
    if (str1 == null)
      str1 = typedArray.getString(0); 
    String str2 = str1;
    int i = typedArray.getResourceId(1, -1);
    String str3 = typedArray.getString(2);
    typedArray.recycle();
    if (!Fragment.isSupportFragmentClass(this.m.getContext(), str2))
      return null; 
    int j = 0;
    if (paramView != null)
      j = paramView.getId(); 
    if (j != -1 || i != -1 || str3 != null) {
      Fragment fragment1;
      Fragment fragment2;
      if (i != -1) {
        fragment1 = findFragmentById(i);
      } else {
        fragment1 = null;
      } 
      if (fragment1 == null && str3 != null)
        fragment1 = findFragmentByTag(str3); 
      if (fragment1 == null && j != -1)
        fragment1 = findFragmentById(j); 
      if (a) {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append("onCreateView: id=0x");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(" fname=");
        stringBuilder2.append(str2);
        stringBuilder2.append(" existing=");
        stringBuilder2.append(fragment1);
        Log.v("FragmentManager", stringBuilder2.toString());
      } 
      if (fragment1 == null) {
        int k;
        Fragment fragment = this.n.instantiate(paramContext, str2, null);
        fragment.mFromLayout = true;
        if (i != 0) {
          k = i;
        } else {
          k = j;
        } 
        fragment.mFragmentId = k;
        fragment.mContainerId = j;
        fragment.mTag = str3;
        fragment.mInLayout = true;
        fragment.mFragmentManager = this;
        fragment.mHost = this.m;
        fragment.onInflate(this.m.getContext(), paramAttributeSet, fragment.mSavedFragmentState);
        addFragment(fragment, true);
        fragment2 = fragment;
      } else if (!fragment1.mInLayout) {
        fragment1.mInLayout = true;
        fragment1.mHost = this.m;
        if (!fragment1.mRetaining)
          fragment1.onInflate(this.m.getContext(), paramAttributeSet, fragment1.mSavedFragmentState); 
        fragment2 = fragment1;
      } else {
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(paramAttributeSet.getPositionDescription());
        stringBuilder2.append(": Duplicate id 0x");
        stringBuilder2.append(Integer.toHexString(i));
        stringBuilder2.append(", tag ");
        stringBuilder2.append(str3);
        stringBuilder2.append(", or parent id 0x");
        stringBuilder2.append(Integer.toHexString(j));
        stringBuilder2.append(" with another fragment for ");
        stringBuilder2.append(str2);
        throw new IllegalArgumentException(stringBuilder2.toString());
      } 
      if (this.l < 1 && fragment2.mFromLayout) {
        a(fragment2, 1, 0, 0, false);
      } else {
        a(fragment2);
      } 
      if (fragment2.mView != null) {
        if (i != 0)
          fragment2.mView.setId(i); 
        if (fragment2.mView.getTag() == null)
          fragment2.mView.setTag(str3); 
        return fragment2.mView;
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Fragment ");
      stringBuilder1.append(str2);
      stringBuilder1.append(" did not create a view.");
      throw new IllegalStateException(stringBuilder1.toString());
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramAttributeSet.getPositionDescription());
    stringBuilder.append(": Must specify unique android:id, android:tag, or have a parent with an id for ");
    stringBuilder.append(str2);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public View onCreateView(String paramString, Context paramContext, AttributeSet paramAttributeSet) {
    return onCreateView(null, paramString, paramContext, paramAttributeSet);
  }
  
  public void performPendingDeferredStart(Fragment paramFragment) {
    if (paramFragment.mDeferStart) {
      if (this.c) {
        this.v = true;
        return;
      } 
      paramFragment.mDeferStart = false;
      a(paramFragment, this.l, 0, 0, false);
    } 
  }
  
  public void popBackStack() {
    enqueueAction(new PopBackStackState(this, null, -1, 0), false);
  }
  
  public void popBackStack(int paramInt1, int paramInt2) {
    if (paramInt1 >= 0) {
      enqueueAction(new PopBackStackState(this, null, paramInt1, paramInt2), false);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void popBackStack(String paramString, int paramInt) {
    enqueueAction(new PopBackStackState(this, paramString, -1, paramInt), false);
  }
  
  public boolean popBackStackImmediate() {
    checkStateLoss();
    return popBackStackImmediate(null, -1, 0);
  }
  
  public boolean popBackStackImmediate(int paramInt1, int paramInt2) {
    checkStateLoss();
    execPendingActions();
    if (paramInt1 >= 0)
      return popBackStackImmediate(null, paramInt1, paramInt2); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Bad id: ");
    stringBuilder.append(paramInt1);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean popBackStackImmediate(String paramString, int paramInt) {
    checkStateLoss();
    return popBackStackImmediate(paramString, -1, paramInt);
  }
  
  public void putFragment(Bundle paramBundle, String paramString, Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    paramBundle.putInt(paramString, paramFragment.mIndex);
  }
  
  public void registerFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks, boolean paramBoolean) {
    this.mLifecycleCallbacks.add(new Pair(paramFragmentLifecycleCallbacks, Boolean.valueOf(paramBoolean)));
  }
  
  public void removeFragment(Fragment paramFragment) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("remove: ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" nesting=");
      stringBuilder.append(paramFragment.mBackStackNesting);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    int i = true ^ paramFragment.isInBackStack();
    if (!paramFragment.mDetached || i != 0)
      synchronized (this.e) {
        this.e.remove(paramFragment);
        if (paramFragment.mHasMenu && paramFragment.mMenuVisible)
          this.r = true; 
        paramFragment.mAdded = false;
        paramFragment.mRemoving = true;
        return;
      }  
  }
  
  public void removeOnBackStackChangedListener(FragmentManager.OnBackStackChangedListener paramOnBackStackChangedListener) {
    if (this.k != null)
      this.k.remove(paramOnBackStackChangedListener); 
  }
  
  public Fragment.SavedState saveFragmentInstanceState(Fragment paramFragment) {
    if (paramFragment.mIndex < 0) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Fragment ");
      stringBuilder.append(paramFragment);
      stringBuilder.append(" is not currently in the FragmentManager");
      throwException(new IllegalStateException(stringBuilder.toString()));
    } 
    if (paramFragment.mState > 0) {
      Bundle bundle = h(paramFragment);
      Fragment.SavedState savedState = null;
      if (bundle != null)
        savedState = new Fragment.SavedState(bundle); 
      return savedState;
    } 
    return null;
  }
  
  public void setBackStackIndex(int paramInt, BackStackRecord paramBackStackRecord) {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield i : Ljava/util/ArrayList;
    //   6: ifnonnull -> 20
    //   9: aload_0
    //   10: new java/util/ArrayList
    //   13: dup
    //   14: invokespecial <init> : ()V
    //   17: putfield i : Ljava/util/ArrayList;
    //   20: aload_0
    //   21: getfield i : Ljava/util/ArrayList;
    //   24: invokevirtual size : ()I
    //   27: istore #4
    //   29: iload_1
    //   30: iload #4
    //   32: if_icmpge -> 107
    //   35: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   38: ifeq -> 94
    //   41: new java/lang/StringBuilder
    //   44: dup
    //   45: invokespecial <init> : ()V
    //   48: astore #5
    //   50: aload #5
    //   52: ldc_w 'Setting back stack index '
    //   55: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   58: pop
    //   59: aload #5
    //   61: iload_1
    //   62: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   65: pop
    //   66: aload #5
    //   68: ldc_w ' to '
    //   71: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   74: pop
    //   75: aload #5
    //   77: aload_2
    //   78: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   81: pop
    //   82: ldc_w 'FragmentManager'
    //   85: aload #5
    //   87: invokevirtual toString : ()Ljava/lang/String;
    //   90: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   93: pop
    //   94: aload_0
    //   95: getfield i : Ljava/util/ArrayList;
    //   98: iload_1
    //   99: aload_2
    //   100: invokevirtual set : (ILjava/lang/Object;)Ljava/lang/Object;
    //   103: pop
    //   104: goto -> 271
    //   107: iload #4
    //   109: iload_1
    //   110: if_icmpge -> 203
    //   113: aload_0
    //   114: getfield i : Ljava/util/ArrayList;
    //   117: aconst_null
    //   118: invokevirtual add : (Ljava/lang/Object;)Z
    //   121: pop
    //   122: aload_0
    //   123: getfield j : Ljava/util/ArrayList;
    //   126: ifnonnull -> 140
    //   129: aload_0
    //   130: new java/util/ArrayList
    //   133: dup
    //   134: invokespecial <init> : ()V
    //   137: putfield j : Ljava/util/ArrayList;
    //   140: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   143: ifeq -> 184
    //   146: new java/lang/StringBuilder
    //   149: dup
    //   150: invokespecial <init> : ()V
    //   153: astore #13
    //   155: aload #13
    //   157: ldc_w 'Adding available back stack index '
    //   160: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   163: pop
    //   164: aload #13
    //   166: iload #4
    //   168: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   171: pop
    //   172: ldc_w 'FragmentManager'
    //   175: aload #13
    //   177: invokevirtual toString : ()Ljava/lang/String;
    //   180: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   183: pop
    //   184: aload_0
    //   185: getfield j : Ljava/util/ArrayList;
    //   188: iload #4
    //   190: invokestatic valueOf : (I)Ljava/lang/Integer;
    //   193: invokevirtual add : (Ljava/lang/Object;)Z
    //   196: pop
    //   197: iinc #4, 1
    //   200: goto -> 107
    //   203: getstatic android/support/v4/app/FragmentManagerImpl.a : Z
    //   206: ifeq -> 262
    //   209: new java/lang/StringBuilder
    //   212: dup
    //   213: invokespecial <init> : ()V
    //   216: astore #18
    //   218: aload #18
    //   220: ldc_w 'Adding back stack index '
    //   223: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   226: pop
    //   227: aload #18
    //   229: iload_1
    //   230: invokevirtual append : (I)Ljava/lang/StringBuilder;
    //   233: pop
    //   234: aload #18
    //   236: ldc_w ' with '
    //   239: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   242: pop
    //   243: aload #18
    //   245: aload_2
    //   246: invokevirtual append : (Ljava/lang/Object;)Ljava/lang/StringBuilder;
    //   249: pop
    //   250: ldc_w 'FragmentManager'
    //   253: aload #18
    //   255: invokevirtual toString : ()Ljava/lang/String;
    //   258: invokestatic v : (Ljava/lang/String;Ljava/lang/String;)I
    //   261: pop
    //   262: aload_0
    //   263: getfield i : Ljava/util/ArrayList;
    //   266: aload_2
    //   267: invokevirtual add : (Ljava/lang/Object;)Z
    //   270: pop
    //   271: aload_0
    //   272: monitorexit
    //   273: return
    //   274: astore_3
    //   275: aload_0
    //   276: monitorexit
    //   277: aload_3
    //   278: athrow
    // Exception table:
    //   from	to	target	type
    //   2	20	274	finally
    //   20	29	274	finally
    //   35	94	274	finally
    //   94	104	274	finally
    //   113	140	274	finally
    //   140	184	274	finally
    //   184	197	274	finally
    //   203	262	274	finally
    //   262	271	274	finally
    //   271	273	274	finally
    //   275	277	274	finally
  }
  
  public void setPrimaryNavigationFragment(Fragment paramFragment) {
    if (paramFragment == null || (this.f.get(paramFragment.mIndex) == paramFragment && (paramFragment.mHost == null || paramFragment.getFragmentManager() == this))) {
      this.p = paramFragment;
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Fragment ");
    stringBuilder.append(paramFragment);
    stringBuilder.append(" is not an active fragment of FragmentManager ");
    stringBuilder.append(this);
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void showFragment(Fragment paramFragment) {
    if (a) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("show: ");
      stringBuilder.append(paramFragment);
      Log.v("FragmentManager", stringBuilder.toString());
    } 
    if (paramFragment.mHidden) {
      paramFragment.mHidden = false;
      paramFragment.mHiddenChanged = true ^ paramFragment.mHiddenChanged;
    } 
  }
  
  public String toString() {
    StringBuilder stringBuilder = new StringBuilder(128);
    stringBuilder.append("FragmentManager{");
    stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
    stringBuilder.append(" in ");
    if (this.o != null) {
      DebugUtils.buildShortClassTag(this.o, stringBuilder);
    } else {
      DebugUtils.buildShortClassTag(this.m, stringBuilder);
    } 
    stringBuilder.append("}}");
    return stringBuilder.toString();
  }
  
  public void unregisterFragmentLifecycleCallbacks(FragmentManager.FragmentLifecycleCallbacks paramFragmentLifecycleCallbacks) {
    // Byte code:
    //   0: aload_0
    //   1: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   4: astore_2
    //   5: aload_2
    //   6: monitorenter
    //   7: iconst_0
    //   8: istore_3
    //   9: aload_0
    //   10: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   13: invokevirtual size : ()I
    //   16: istore #5
    //   18: iload_3
    //   19: iload #5
    //   21: if_icmpge -> 54
    //   24: aload_0
    //   25: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   28: iload_3
    //   29: invokevirtual get : (I)Ljava/lang/Object;
    //   32: checkcast android/support/v4/util/Pair
    //   35: getfield first : Ljava/lang/Object;
    //   38: aload_1
    //   39: if_acmpne -> 64
    //   42: aload_0
    //   43: getfield mLifecycleCallbacks : Ljava/util/concurrent/CopyOnWriteArrayList;
    //   46: iload_3
    //   47: invokevirtual remove : (I)Ljava/lang/Object;
    //   50: pop
    //   51: goto -> 54
    //   54: aload_2
    //   55: monitorexit
    //   56: return
    //   57: astore #4
    //   59: aload_2
    //   60: monitorexit
    //   61: aload #4
    //   63: athrow
    //   64: iinc #3, 1
    //   67: goto -> 18
    // Exception table:
    //   from	to	target	type
    //   9	18	57	finally
    //   24	51	57	finally
    //   54	56	57	finally
    //   59	61	57	finally
  }
  
  private static class AnimateOnHWLayerIfNeededListener extends AnimationListenerWrapper {
    View a;
    
    AnimateOnHWLayerIfNeededListener(View param1View, Animation.AnimationListener param1AnimationListener) {
      super(param1AnimationListener);
      this.a = param1View;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (ViewCompat.isAttachedToWindow(this.a) || Build.VERSION.SDK_INT >= 24) {
        this.a.post(new Runnable(this) {
              public void run() {
                this.a.a.setLayerType(0, null);
              }
            });
      } else {
        this.a.setLayerType(0, null);
      } 
      super.onAnimationEnd(param1Animation);
    }
  }
  
  class null implements Runnable {
    null(FragmentManagerImpl this$0) {}
    
    public void run() {
      this.a.a.setLayerType(0, null);
    }
  }
  
  private static class AnimationListenerWrapper implements Animation.AnimationListener {
    private final Animation.AnimationListener mWrapped;
    
    private AnimationListenerWrapper(Animation.AnimationListener param1AnimationListener) {
      this.mWrapped = param1AnimationListener;
    }
    
    @CallSuper
    public void onAnimationEnd(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationEnd(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationRepeat(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationRepeat(param1Animation); 
    }
    
    @CallSuper
    public void onAnimationStart(Animation param1Animation) {
      if (this.mWrapped != null)
        this.mWrapped.onAnimationStart(param1Animation); 
    }
  }
  
  private static class AnimationOrAnimator {
    public final Animation animation = null;
    
    public final Animator animator;
    
    private AnimationOrAnimator(Animator param1Animator) {
      this.animator = param1Animator;
      if (param1Animator != null)
        return; 
      throw new IllegalStateException("Animator cannot be null");
    }
    
    private AnimationOrAnimator(Animation param1Animation) {
      this.animator = null;
      if (param1Animation != null)
        return; 
      throw new IllegalStateException("Animation cannot be null");
    }
  }
  
  private static class AnimatorOnHWLayerIfNeededListener extends AnimatorListenerAdapter {
    View a;
    
    AnimatorOnHWLayerIfNeededListener(View param1View) {
      this.a = param1View;
    }
    
    public void onAnimationEnd(Animator param1Animator) {
      this.a.setLayerType(0, null);
      param1Animator.removeListener((Animator.AnimatorListener)this);
    }
    
    public void onAnimationStart(Animator param1Animator) {
      this.a.setLayerType(2, null);
    }
  }
  
  private static class EndViewTransitionAnimator extends AnimationSet implements Runnable {
    private final View mChild;
    
    private boolean mEnded;
    
    private final ViewGroup mParent;
    
    private boolean mTransitionEnded;
    
    EndViewTransitionAnimator(@NonNull Animation param1Animation, @NonNull ViewGroup param1ViewGroup, @NonNull View param1View) {
      super(false);
      this.mParent = param1ViewGroup;
      this.mChild = param1View;
      addAnimation(param1Animation);
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation) {
      if (this.mEnded)
        return true ^ this.mTransitionEnded; 
      if (!super.getTransformation(param1Long, param1Transformation)) {
        this.mEnded = true;
        this.mParent.post(this);
      } 
      return true;
    }
    
    public boolean getTransformation(long param1Long, Transformation param1Transformation, float param1Float) {
      if (this.mEnded)
        return true ^ this.mTransitionEnded; 
      if (!super.getTransformation(param1Long, param1Transformation, param1Float)) {
        this.mEnded = true;
        this.mParent.post(this);
      } 
      return true;
    }
    
    public void run() {
      this.mParent.endViewTransition(this.mChild);
      this.mTransitionEnded = true;
    }
  }
  
  static class FragmentTag {
    public static final int[] Fragment = new int[] { 16842755, 16842960, 16842961 };
    
    public static final int Fragment_id = 1;
    
    public static final int Fragment_name = 0;
    
    public static final int Fragment_tag = 2;
  }
  
  static interface OpGenerator {
    boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1);
  }
  
  private class PopBackStackState implements OpGenerator {
    final String a;
    
    final int b;
    
    final int c;
    
    PopBackStackState(FragmentManagerImpl this$0, String param1String, int param1Int1, int param1Int2) {
      this.a = param1String;
      this.b = param1Int1;
      this.c = param1Int2;
    }
    
    public boolean generateOps(ArrayList<BackStackRecord> param1ArrayList, ArrayList<Boolean> param1ArrayList1) {
      if (this.d.p != null && this.b < 0 && this.a == null) {
        FragmentManager fragmentManager = this.d.p.peekChildFragmentManager();
        if (fragmentManager != null && fragmentManager.popBackStackImmediate())
          return false; 
      } 
      return this.d.a(param1ArrayList, param1ArrayList1, this.a, this.b, this.c);
    }
  }
  
  static class StartEnterTransitionListener implements Fragment.OnStartEnterTransitionListener {
    private final boolean mIsBack;
    
    private int mNumPostponed;
    
    private final BackStackRecord mRecord;
    
    StartEnterTransitionListener(BackStackRecord param1BackStackRecord, boolean param1Boolean) {
      this.mIsBack = param1Boolean;
      this.mRecord = param1BackStackRecord;
    }
    
    public void cancelTransaction() {
      FragmentManagerImpl.a(this.mRecord.a, this.mRecord, this.mIsBack, false, false);
    }
    
    public void completeTransaction() {
      boolean bool;
      int i = this.mNumPostponed;
      byte b = 0;
      if (i > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      FragmentManagerImpl fragmentManagerImpl = this.mRecord.a;
      int j = fragmentManagerImpl.e.size();
      while (b < j) {
        Fragment fragment = fragmentManagerImpl.e.get(b);
        fragment.setOnStartEnterTransitionListener(null);
        if (bool && fragment.isPostponed())
          fragment.startPostponedEnterTransition(); 
        b++;
      } 
      FragmentManagerImpl.a(this.mRecord.a, this.mRecord, this.mIsBack, bool ^ true, true);
    }
    
    public boolean isReady() {
      return (this.mNumPostponed == 0);
    }
    
    public void onStartEnterTransition() {
      this.mNumPostponed = -1 + this.mNumPostponed;
      if (this.mNumPostponed != 0)
        return; 
      FragmentManagerImpl.a(this.mRecord.a);
    }
    
    public void startListening() {
      this.mNumPostponed = 1 + this.mNumPostponed;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\FragmentManagerImpl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */