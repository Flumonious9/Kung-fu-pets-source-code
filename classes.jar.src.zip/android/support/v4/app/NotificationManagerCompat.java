package android.support.v4.app;

import android.app.AppOpsManager;
import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.pm.ApplicationInfo;
import android.content.pm.ResolveInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.DeadObjectException;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.IBinder;
import android.os.Message;
import android.os.RemoteException;
import android.support.annotation.GuardedBy;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.util.Log;
import java.lang.reflect.Method;
import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

public final class NotificationManagerCompat {
  public static final String ACTION_BIND_SIDE_CHANNEL = "android.support.BIND_NOTIFICATION_SIDE_CHANNEL";
  
  private static final String CHECK_OP_NO_THROW = "checkOpNoThrow";
  
  public static final String EXTRA_USE_SIDE_CHANNEL = "android.support.useSideChannel";
  
  public static final int IMPORTANCE_DEFAULT = 3;
  
  public static final int IMPORTANCE_HIGH = 4;
  
  public static final int IMPORTANCE_LOW = 2;
  
  public static final int IMPORTANCE_MAX = 5;
  
  public static final int IMPORTANCE_MIN = 1;
  
  public static final int IMPORTANCE_NONE = 0;
  
  public static final int IMPORTANCE_UNSPECIFIED = -1000;
  
  private static final String OP_POST_NOTIFICATION = "OP_POST_NOTIFICATION";
  
  private static final String SETTING_ENABLED_NOTIFICATION_LISTENERS = "enabled_notification_listeners";
  
  private static final int SIDE_CHANNEL_RETRY_BASE_INTERVAL_MS = 1000;
  
  private static final int SIDE_CHANNEL_RETRY_MAX_COUNT = 6;
  
  private static final String TAG = "NotifManCompat";
  
  @GuardedBy("sEnabledNotificationListenersLock")
  private static Set<String> sEnabledNotificationListenerPackages;
  
  @GuardedBy("sEnabledNotificationListenersLock")
  private static String sEnabledNotificationListeners;
  
  private static final Object sEnabledNotificationListenersLock = new Object();
  
  private static final Object sLock;
  
  @GuardedBy("sLock")
  private static SideChannelManager sSideChannelManager;
  
  private final Context mContext;
  
  private final NotificationManager mNotificationManager;
  
  static {
    sEnabledNotificationListenerPackages = new HashSet<String>();
    sLock = new Object();
  }
  
  private NotificationManagerCompat(Context paramContext) {
    this.mContext = paramContext;
    this.mNotificationManager = (NotificationManager)this.mContext.getSystemService("notification");
  }
  
  @NonNull
  public static NotificationManagerCompat from(@NonNull Context paramContext) {
    return new NotificationManagerCompat(paramContext);
  }
  
  @NonNull
  public static Set<String> getEnabledListenerPackages(@NonNull Context paramContext) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getContentResolver : ()Landroid/content/ContentResolver;
    //   4: ldc 'enabled_notification_listeners'
    //   6: invokestatic getString : (Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;
    //   9: astore_1
    //   10: getstatic android/support/v4/app/NotificationManagerCompat.sEnabledNotificationListenersLock : Ljava/lang/Object;
    //   13: astore_2
    //   14: aload_2
    //   15: monitorenter
    //   16: aload_1
    //   17: ifnull -> 108
    //   20: aload_1
    //   21: getstatic android/support/v4/app/NotificationManagerCompat.sEnabledNotificationListeners : Ljava/lang/String;
    //   24: invokevirtual equals : (Ljava/lang/Object;)Z
    //   27: ifne -> 108
    //   30: aload_1
    //   31: ldc ':'
    //   33: invokevirtual split : (Ljava/lang/String;)[Ljava/lang/String;
    //   36: astore #5
    //   38: new java/util/HashSet
    //   41: dup
    //   42: aload #5
    //   44: arraylength
    //   45: invokespecial <init> : (I)V
    //   48: astore #6
    //   50: aload #5
    //   52: arraylength
    //   53: istore #7
    //   55: iconst_0
    //   56: istore #8
    //   58: iload #8
    //   60: iload #7
    //   62: if_icmpge -> 96
    //   65: aload #5
    //   67: iload #8
    //   69: aaload
    //   70: invokestatic unflattenFromString : (Ljava/lang/String;)Landroid/content/ComponentName;
    //   73: astore #9
    //   75: aload #9
    //   77: ifnull -> 121
    //   80: aload #6
    //   82: aload #9
    //   84: invokevirtual getPackageName : ()Ljava/lang/String;
    //   87: invokeinterface add : (Ljava/lang/Object;)Z
    //   92: pop
    //   93: goto -> 121
    //   96: aload #6
    //   98: putstatic android/support/v4/app/NotificationManagerCompat.sEnabledNotificationListenerPackages : Ljava/util/Set;
    //   101: aload_1
    //   102: putstatic android/support/v4/app/NotificationManagerCompat.sEnabledNotificationListeners : Ljava/lang/String;
    //   105: goto -> 108
    //   108: getstatic android/support/v4/app/NotificationManagerCompat.sEnabledNotificationListenerPackages : Ljava/util/Set;
    //   111: astore_3
    //   112: aload_2
    //   113: monitorexit
    //   114: aload_3
    //   115: areturn
    //   116: aload_2
    //   117: monitorexit
    //   118: aload #4
    //   120: athrow
    //   121: iinc #8, 1
    //   124: goto -> 58
    //   127: astore #4
    //   129: goto -> 116
    // Exception table:
    //   from	to	target	type
    //   20	55	127	finally
    //   65	75	127	finally
    //   80	93	127	finally
    //   96	105	127	finally
    //   108	114	127	finally
    //   116	118	127	finally
  }
  
  private void pushSideChannelQueue(Task paramTask) {
    synchronized (sLock) {
      if (sSideChannelManager == null)
        sSideChannelManager = new SideChannelManager(this.mContext.getApplicationContext()); 
      sSideChannelManager.queueTask(paramTask);
      return;
    } 
  }
  
  private static boolean useSideChannelForNotification(Notification paramNotification) {
    Bundle bundle = NotificationCompat.getExtras(paramNotification);
    return (bundle != null && bundle.getBoolean("android.support.useSideChannel"));
  }
  
  public boolean areNotificationsEnabled() {
    if (Build.VERSION.SDK_INT >= 24)
      return this.mNotificationManager.areNotificationsEnabled(); 
    if (Build.VERSION.SDK_INT >= 19) {
      AppOpsManager appOpsManager = (AppOpsManager)this.mContext.getSystemService("appops");
      ApplicationInfo applicationInfo = this.mContext.getApplicationInfo();
      String str = this.mContext.getApplicationContext().getPackageName();
      int i = applicationInfo.uid;
      try {
        Class<?> clazz = Class.forName(AppOpsManager.class.getName());
        Class[] arrayOfClass = new Class[3];
        arrayOfClass[0] = int.class;
        arrayOfClass[1] = int.class;
        arrayOfClass[2] = String.class;
        Method method = clazz.getMethod("checkOpNoThrow", arrayOfClass);
        int j = ((Integer)clazz.getDeclaredField("OP_POST_NOTIFICATION").get(Integer.class)).intValue();
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = Integer.valueOf(j);
        arrayOfObject[1] = Integer.valueOf(i);
        arrayOfObject[2] = str;
        int k = ((Integer)method.invoke(appOpsManager, arrayOfObject)).intValue();
        return (k == 0);
      } catch (ClassNotFoundException|NoSuchMethodException|NoSuchFieldException|java.lang.reflect.InvocationTargetException|IllegalAccessException|RuntimeException classNotFoundException) {
        return true;
      } 
    } 
    return true;
  }
  
  public void cancel(int paramInt) {
    cancel(null, paramInt);
  }
  
  public void cancel(@Nullable String paramString, int paramInt) {
    this.mNotificationManager.cancel(paramString, paramInt);
    if (Build.VERSION.SDK_INT <= 19)
      pushSideChannelQueue(new CancelTask(this.mContext.getPackageName(), paramInt, paramString)); 
  }
  
  public void cancelAll() {
    this.mNotificationManager.cancelAll();
    if (Build.VERSION.SDK_INT <= 19)
      pushSideChannelQueue(new CancelTask(this.mContext.getPackageName())); 
  }
  
  public int getImportance() {
    return (Build.VERSION.SDK_INT >= 24) ? this.mNotificationManager.getImportance() : -1000;
  }
  
  public void notify(int paramInt, @NonNull Notification paramNotification) {
    notify(null, paramInt, paramNotification);
  }
  
  public void notify(@Nullable String paramString, int paramInt, @NonNull Notification paramNotification) {
    if (useSideChannelForNotification(paramNotification)) {
      pushSideChannelQueue(new NotifyTask(this.mContext.getPackageName(), paramInt, paramString, paramNotification));
      this.mNotificationManager.cancel(paramString, paramInt);
      return;
    } 
    this.mNotificationManager.notify(paramString, paramInt, paramNotification);
  }
  
  private static class CancelTask implements Task {
    final String a;
    
    final int b;
    
    final String c;
    
    final boolean d;
    
    CancelTask(String param1String) {
      this.a = param1String;
      this.b = 0;
      this.c = null;
      this.d = true;
    }
    
    CancelTask(String param1String1, int param1Int, String param1String2) {
      this.a = param1String1;
      this.b = param1Int;
      this.c = param1String2;
      this.d = false;
    }
    
    public void send(INotificationSideChannel param1INotificationSideChannel) {
      if (this.d) {
        param1INotificationSideChannel.cancelAll(this.a);
        return;
      } 
      param1INotificationSideChannel.cancel(this.a, this.b, this.c);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("CancelTask[");
      stringBuilder.append("packageName:");
      stringBuilder.append(this.a);
      stringBuilder.append(", id:");
      stringBuilder.append(this.b);
      stringBuilder.append(", tag:");
      stringBuilder.append(this.c);
      stringBuilder.append(", all:");
      stringBuilder.append(this.d);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  private static class NotifyTask implements Task {
    final String a;
    
    final int b;
    
    final String c;
    
    final Notification d;
    
    NotifyTask(String param1String1, int param1Int, String param1String2, Notification param1Notification) {
      this.a = param1String1;
      this.b = param1Int;
      this.c = param1String2;
      this.d = param1Notification;
    }
    
    public void send(INotificationSideChannel param1INotificationSideChannel) {
      param1INotificationSideChannel.notify(this.a, this.b, this.c, this.d);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("NotifyTask[");
      stringBuilder.append("packageName:");
      stringBuilder.append(this.a);
      stringBuilder.append(", id:");
      stringBuilder.append(this.b);
      stringBuilder.append(", tag:");
      stringBuilder.append(this.c);
      stringBuilder.append("]");
      return stringBuilder.toString();
    }
  }
  
  private static class ServiceConnectedEvent {
    final ComponentName a;
    
    final IBinder b;
    
    ServiceConnectedEvent(ComponentName param1ComponentName, IBinder param1IBinder) {
      this.a = param1ComponentName;
      this.b = param1IBinder;
    }
  }
  
  private static class SideChannelManager implements ServiceConnection, Handler.Callback {
    private static final int MSG_QUEUE_TASK = 0;
    
    private static final int MSG_RETRY_LISTENER_QUEUE = 3;
    
    private static final int MSG_SERVICE_CONNECTED = 1;
    
    private static final int MSG_SERVICE_DISCONNECTED = 2;
    
    private Set<String> mCachedEnabledPackages = new HashSet<String>();
    
    private final Context mContext;
    
    private final Handler mHandler;
    
    private final HandlerThread mHandlerThread;
    
    private final Map<ComponentName, ListenerRecord> mRecordMap = new HashMap<ComponentName, ListenerRecord>();
    
    SideChannelManager(Context param1Context) {
      this.mContext = param1Context;
      this.mHandlerThread = new HandlerThread("NotificationManagerCompat");
      this.mHandlerThread.start();
      this.mHandler = new Handler(this.mHandlerThread.getLooper(), this);
    }
    
    private boolean ensureServiceBound(ListenerRecord param1ListenerRecord) {
      if (param1ListenerRecord.b)
        return true; 
      Intent intent = (new Intent("android.support.BIND_NOTIFICATION_SIDE_CHANNEL")).setComponent(param1ListenerRecord.a);
      param1ListenerRecord.b = this.mContext.bindService(intent, this, 33);
      if (param1ListenerRecord.b) {
        param1ListenerRecord.e = 0;
      } else {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Unable to bind to listener ");
        stringBuilder.append(param1ListenerRecord.a);
        Log.w("NotifManCompat", stringBuilder.toString());
        this.mContext.unbindService(this);
      } 
      return param1ListenerRecord.b;
    }
    
    private void ensureServiceUnbound(ListenerRecord param1ListenerRecord) {
      if (param1ListenerRecord.b) {
        this.mContext.unbindService(this);
        param1ListenerRecord.b = false;
      } 
      param1ListenerRecord.c = null;
    }
    
    private void handleQueueTask(NotificationManagerCompat.Task param1Task) {
      updateListenerMap();
      for (ListenerRecord listenerRecord : this.mRecordMap.values()) {
        listenerRecord.d.add(param1Task);
        processListenerQueue(listenerRecord);
      } 
    }
    
    private void handleRetryListenerQueue(ComponentName param1ComponentName) {
      ListenerRecord listenerRecord = this.mRecordMap.get(param1ComponentName);
      if (listenerRecord != null)
        processListenerQueue(listenerRecord); 
    }
    
    private void handleServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      ListenerRecord listenerRecord = this.mRecordMap.get(param1ComponentName);
      if (listenerRecord != null) {
        listenerRecord.c = INotificationSideChannel.Stub.asInterface(param1IBinder);
        listenerRecord.e = 0;
        processListenerQueue(listenerRecord);
      } 
    }
    
    private void handleServiceDisconnected(ComponentName param1ComponentName) {
      ListenerRecord listenerRecord = this.mRecordMap.get(param1ComponentName);
      if (listenerRecord != null)
        ensureServiceUnbound(listenerRecord); 
    }
    
    private void processListenerQueue(ListenerRecord param1ListenerRecord) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Processing component ");
        stringBuilder.append(param1ListenerRecord.a);
        stringBuilder.append(", ");
        stringBuilder.append(param1ListenerRecord.d.size());
        stringBuilder.append(" queued tasks");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      if (param1ListenerRecord.d.isEmpty())
        return; 
      if (!ensureServiceBound(param1ListenerRecord) || param1ListenerRecord.c == null) {
        scheduleListenerRetry(param1ListenerRecord);
        return;
      } 
      while (true) {
        NotificationManagerCompat.Task task = param1ListenerRecord.d.peek();
        if (task == null)
          break; 
        try {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Sending task ");
            stringBuilder.append(task);
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          task.send(param1ListenerRecord.c);
          param1ListenerRecord.d.remove();
        } catch (DeadObjectException deadObjectException) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Remote service has died: ");
            stringBuilder.append(param1ListenerRecord.a);
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          break;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("RemoteException communicating with ");
          stringBuilder.append(param1ListenerRecord.a);
          Log.w("NotifManCompat", stringBuilder.toString(), (Throwable)remoteException);
          break;
        } 
      } 
      if (!param1ListenerRecord.d.isEmpty())
        scheduleListenerRetry(param1ListenerRecord); 
    }
    
    private void scheduleListenerRetry(ListenerRecord param1ListenerRecord) {
      if (this.mHandler.hasMessages(3, param1ListenerRecord.a))
        return; 
      param1ListenerRecord.e = 1 + param1ListenerRecord.e;
      if (param1ListenerRecord.e > 6) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Giving up on delivering ");
        stringBuilder.append(param1ListenerRecord.d.size());
        stringBuilder.append(" tasks to ");
        stringBuilder.append(param1ListenerRecord.a);
        stringBuilder.append(" after ");
        stringBuilder.append(param1ListenerRecord.e);
        stringBuilder.append(" retries");
        Log.w("NotifManCompat", stringBuilder.toString());
        param1ListenerRecord.d.clear();
        return;
      } 
      int i = 1000 * (1 << param1ListenerRecord.e - 1);
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Scheduling retry for ");
        stringBuilder.append(i);
        stringBuilder.append(" ms");
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      Message message = this.mHandler.obtainMessage(3, param1ListenerRecord.a);
      this.mHandler.sendMessageDelayed(message, i);
    }
    
    private void updateListenerMap() {
      Set<String> set = NotificationManagerCompat.getEnabledListenerPackages(this.mContext);
      if (set.equals(this.mCachedEnabledPackages))
        return; 
      this.mCachedEnabledPackages = set;
      List list = this.mContext.getPackageManager().queryIntentServices((new Intent()).setAction("android.support.BIND_NOTIFICATION_SIDE_CHANNEL"), 0);
      HashSet<ComponentName> hashSet = new HashSet();
      for (ResolveInfo resolveInfo : list) {
        if (!set.contains(resolveInfo.serviceInfo.packageName))
          continue; 
        ComponentName componentName = new ComponentName(resolveInfo.serviceInfo.packageName, resolveInfo.serviceInfo.name);
        if (resolveInfo.serviceInfo.permission != null) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Permission present on component ");
          stringBuilder.append(componentName);
          stringBuilder.append(", not adding listener record.");
          Log.w("NotifManCompat", stringBuilder.toString());
          continue;
        } 
        hashSet.add(componentName);
      } 
      for (ComponentName componentName : hashSet) {
        if (!this.mRecordMap.containsKey(componentName)) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Adding listener record for ");
            stringBuilder.append(componentName);
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          this.mRecordMap.put(componentName, new ListenerRecord(componentName));
        } 
      } 
      Iterator<Map.Entry> iterator = this.mRecordMap.entrySet().iterator();
      while (iterator.hasNext()) {
        Map.Entry entry = iterator.next();
        if (!hashSet.contains(entry.getKey())) {
          if (Log.isLoggable("NotifManCompat", 3)) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Removing listener record for ");
            stringBuilder.append(entry.getKey());
            Log.d("NotifManCompat", stringBuilder.toString());
          } 
          ensureServiceUnbound((ListenerRecord)entry.getValue());
          iterator.remove();
        } 
      } 
    }
    
    public boolean handleMessage(Message param1Message) {
      NotificationManagerCompat.ServiceConnectedEvent serviceConnectedEvent;
      switch (param1Message.what) {
        default:
          return false;
        case 3:
          handleRetryListenerQueue((ComponentName)param1Message.obj);
          return true;
        case 2:
          handleServiceDisconnected((ComponentName)param1Message.obj);
          return true;
        case 1:
          serviceConnectedEvent = (NotificationManagerCompat.ServiceConnectedEvent)param1Message.obj;
          handleServiceConnected(serviceConnectedEvent.a, serviceConnectedEvent.b);
          return true;
        case 0:
          break;
      } 
      handleQueueTask((NotificationManagerCompat.Task)param1Message.obj);
      return true;
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Connected to service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.mHandler.obtainMessage(1, new NotificationManagerCompat.ServiceConnectedEvent(param1ComponentName, param1IBinder)).sendToTarget();
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      if (Log.isLoggable("NotifManCompat", 3)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Disconnected from service ");
        stringBuilder.append(param1ComponentName);
        Log.d("NotifManCompat", stringBuilder.toString());
      } 
      this.mHandler.obtainMessage(2, param1ComponentName).sendToTarget();
    }
    
    public void queueTask(NotificationManagerCompat.Task param1Task) {
      this.mHandler.obtainMessage(0, param1Task).sendToTarget();
    }
    
    private static class ListenerRecord {
      final ComponentName a;
      
      boolean b = false;
      
      INotificationSideChannel c;
      
      ArrayDeque<NotificationManagerCompat.Task> d = new ArrayDeque<NotificationManagerCompat.Task>();
      
      int e = 0;
      
      ListenerRecord(ComponentName param2ComponentName) {
        this.a = param2ComponentName;
      }
    }
  }
  
  private static class ListenerRecord {
    final ComponentName a;
    
    boolean b = false;
    
    INotificationSideChannel c;
    
    ArrayDeque<NotificationManagerCompat.Task> d = new ArrayDeque<NotificationManagerCompat.Task>();
    
    int e = 0;
    
    ListenerRecord(ComponentName param1ComponentName) {
      this.a = param1ComponentName;
    }
  }
  
  private static interface Task {
    void send(INotificationSideChannel param1INotificationSideChannel);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\NotificationManagerCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */