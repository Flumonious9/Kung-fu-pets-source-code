package android.support.v4.app;

import android.content.ClipData;
import android.content.ClipDescription;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RequiresApi;
import android.util.Log;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public final class RemoteInput {
  private static final String EXTRA_DATA_TYPE_RESULTS_DATA = "android.remoteinput.dataTypeResultsData";
  
  public static final String EXTRA_RESULTS_DATA = "android.remoteinput.resultsData";
  
  public static final String RESULTS_CLIP_LABEL = "android.remoteinput.results";
  
  private static final String TAG = "RemoteInput";
  
  private final boolean mAllowFreeFormTextInput;
  
  private final Set<String> mAllowedDataTypes;
  
  private final CharSequence[] mChoices;
  
  private final Bundle mExtras;
  
  private final CharSequence mLabel;
  
  private final String mResultKey;
  
  RemoteInput(String paramString, CharSequence paramCharSequence, CharSequence[] paramArrayOfCharSequence, boolean paramBoolean, Bundle paramBundle, Set<String> paramSet) {
    this.mResultKey = paramString;
    this.mLabel = paramCharSequence;
    this.mChoices = paramArrayOfCharSequence;
    this.mAllowFreeFormTextInput = paramBoolean;
    this.mExtras = paramBundle;
    this.mAllowedDataTypes = paramSet;
  }
  
  @RequiresApi(20)
  static android.app.RemoteInput a(RemoteInput paramRemoteInput) {
    return (new android.app.RemoteInput.Builder(paramRemoteInput.getResultKey())).setLabel(paramRemoteInput.getLabel()).setChoices(paramRemoteInput.getChoices()).setAllowFreeFormInput(paramRemoteInput.getAllowFreeFormInput()).addExtras(paramRemoteInput.getExtras()).build();
  }
  
  @RequiresApi(20)
  static android.app.RemoteInput[] a(RemoteInput[] paramArrayOfRemoteInput) {
    if (paramArrayOfRemoteInput == null)
      return null; 
    android.app.RemoteInput[] arrayOfRemoteInput = new android.app.RemoteInput[paramArrayOfRemoteInput.length];
    for (byte b = 0; b < paramArrayOfRemoteInput.length; b++)
      arrayOfRemoteInput[b] = a(paramArrayOfRemoteInput[b]); 
    return arrayOfRemoteInput;
  }
  
  public static void addDataResultToIntent(RemoteInput paramRemoteInput, Intent paramIntent, Map<String, Uri> paramMap) {
    if (Build.VERSION.SDK_INT >= 26) {
      android.app.RemoteInput.addDataResultToIntent(a(paramRemoteInput), paramIntent, paramMap);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent = getClipDataIntentFromIntent(paramIntent);
      if (intent == null)
        intent = new Intent(); 
      for (Map.Entry<String, Uri> entry : paramMap.entrySet()) {
        String str = (String)entry.getKey();
        Uri uri = (Uri)entry.getValue();
        if (str == null)
          continue; 
        Bundle bundle = intent.getBundleExtra(getExtraResultsKeyForData(str));
        if (bundle == null)
          bundle = new Bundle(); 
        bundle.putString(paramRemoteInput.getResultKey(), uri.toString());
        intent.putExtra(getExtraResultsKeyForData(str), bundle);
      } 
      paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", intent));
      return;
    } 
    Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
  }
  
  public static void addResultsToIntent(RemoteInput[] paramArrayOfRemoteInput, Intent paramIntent, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 26) {
      android.app.RemoteInput.addResultsToIntent(a(paramArrayOfRemoteInput), paramIntent, paramBundle);
      return;
    } 
    int i = Build.VERSION.SDK_INT;
    byte b = 0;
    if (i >= 20) {
      Bundle bundle = getResultsFromIntent(paramIntent);
      if (bundle != null) {
        bundle.putAll(paramBundle);
        paramBundle = bundle;
      } 
      int j = paramArrayOfRemoteInput.length;
      for (byte b1 = 0; b1 < j; b1++) {
        RemoteInput remoteInput = paramArrayOfRemoteInput[b1];
        Map<String, Uri> map = getDataResultsFromIntent(paramIntent, remoteInput.getResultKey());
        android.app.RemoteInput.addResultsToIntent(a(new RemoteInput[] { remoteInput }, ), paramIntent, paramBundle);
        if (map != null)
          addDataResultToIntent(remoteInput, paramIntent, map); 
      } 
    } else {
      if (Build.VERSION.SDK_INT >= 16) {
        Intent intent = getClipDataIntentFromIntent(paramIntent);
        if (intent == null)
          intent = new Intent(); 
        Bundle bundle = intent.getBundleExtra("android.remoteinput.resultsData");
        if (bundle == null)
          bundle = new Bundle(); 
        int j = paramArrayOfRemoteInput.length;
        while (b < j) {
          RemoteInput remoteInput = paramArrayOfRemoteInput[b];
          Object object = paramBundle.get(remoteInput.getResultKey());
          if (object instanceof CharSequence)
            bundle.putCharSequence(remoteInput.getResultKey(), (CharSequence)object); 
          b++;
        } 
        intent.putExtra("android.remoteinput.resultsData", bundle);
        paramIntent.setClipData(ClipData.newIntent("android.remoteinput.results", intent));
        return;
      } 
      Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
    } 
  }
  
  @RequiresApi(16)
  private static Intent getClipDataIntentFromIntent(Intent paramIntent) {
    ClipData clipData = paramIntent.getClipData();
    if (clipData == null)
      return null; 
    ClipDescription clipDescription = clipData.getDescription();
    return !clipDescription.hasMimeType("text/vnd.android.intent") ? null : (!clipDescription.getLabel().equals("android.remoteinput.results") ? null : clipData.getItemAt(0).getIntent());
  }
  
  public static Map<String, Uri> getDataResultsFromIntent(Intent paramIntent, String paramString) {
    if (Build.VERSION.SDK_INT >= 26)
      return android.app.RemoteInput.getDataResultsFromIntent(paramIntent, paramString); 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent = getClipDataIntentFromIntent(paramIntent);
      if (intent == null)
        return null; 
      HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
      for (String str : intent.getExtras().keySet()) {
        if (str.startsWith("android.remoteinput.dataTypeResultsData")) {
          String str1 = str.substring("android.remoteinput.dataTypeResultsData".length());
          if (str1.isEmpty())
            continue; 
          String str2 = intent.getBundleExtra(str).getString(paramString);
          if (str2 == null || str2.isEmpty())
            continue; 
          hashMap.put(str1, Uri.parse(str2));
        } 
      } 
      if (hashMap.isEmpty())
        hashMap = null; 
      return (Map)hashMap;
    } 
    Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
    return null;
  }
  
  private static String getExtraResultsKeyForData(String paramString) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("android.remoteinput.dataTypeResultsData");
    stringBuilder.append(paramString);
    return stringBuilder.toString();
  }
  
  public static Bundle getResultsFromIntent(Intent paramIntent) {
    if (Build.VERSION.SDK_INT >= 20)
      return android.app.RemoteInput.getResultsFromIntent(paramIntent); 
    if (Build.VERSION.SDK_INT >= 16) {
      Intent intent = getClipDataIntentFromIntent(paramIntent);
      return (intent == null) ? null : (Bundle)intent.getExtras().getParcelable("android.remoteinput.resultsData");
    } 
    Log.w("RemoteInput", "RemoteInput is only supported from API Level 16");
    return null;
  }
  
  public boolean getAllowFreeFormInput() {
    return this.mAllowFreeFormTextInput;
  }
  
  public Set<String> getAllowedDataTypes() {
    return this.mAllowedDataTypes;
  }
  
  public CharSequence[] getChoices() {
    return this.mChoices;
  }
  
  public Bundle getExtras() {
    return this.mExtras;
  }
  
  public CharSequence getLabel() {
    return this.mLabel;
  }
  
  public String getResultKey() {
    return this.mResultKey;
  }
  
  public boolean isDataOnly() {
    return (!getAllowFreeFormInput() && (getChoices() == null || (getChoices()).length == 0) && getAllowedDataTypes() != null && !getAllowedDataTypes().isEmpty());
  }
  
  public static final class Builder {
    private boolean mAllowFreeFormTextInput = true;
    
    private final Set<String> mAllowedDataTypes = new HashSet<String>();
    
    private CharSequence[] mChoices;
    
    private Bundle mExtras = new Bundle();
    
    private CharSequence mLabel;
    
    private final String mResultKey;
    
    public Builder(String param1String) {
      if (param1String != null) {
        this.mResultKey = param1String;
        return;
      } 
      throw new IllegalArgumentException("Result key can't be null");
    }
    
    public Builder addExtras(Bundle param1Bundle) {
      if (param1Bundle != null)
        this.mExtras.putAll(param1Bundle); 
      return this;
    }
    
    public RemoteInput build() {
      return new RemoteInput(this.mResultKey, this.mLabel, this.mChoices, this.mAllowFreeFormTextInput, this.mExtras, this.mAllowedDataTypes);
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public Builder setAllowDataType(String param1String, boolean param1Boolean) {
      if (param1Boolean) {
        this.mAllowedDataTypes.add(param1String);
        return this;
      } 
      this.mAllowedDataTypes.remove(param1String);
      return this;
    }
    
    public Builder setAllowFreeFormInput(boolean param1Boolean) {
      this.mAllowFreeFormTextInput = param1Boolean;
      return this;
    }
    
    public Builder setChoices(CharSequence[] param1ArrayOfCharSequence) {
      this.mChoices = param1ArrayOfCharSequence;
      return this;
    }
    
    public Builder setLabel(CharSequence param1CharSequence) {
      this.mLabel = param1CharSequence;
      return this;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\RemoteInput.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */