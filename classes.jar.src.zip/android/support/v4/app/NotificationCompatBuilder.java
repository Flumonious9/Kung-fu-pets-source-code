package android.support.v4.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.RestrictTo;
import android.text.TextUtils;
import android.util.SparseArray;
import android.widget.RemoteViews;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class NotificationCompatBuilder implements NotificationBuilderWithBuilderAccessor {
  private final List<Bundle> mActionExtrasList;
  
  private RemoteViews mBigContentView;
  
  private final Notification.Builder mBuilder;
  
  private final NotificationCompat.Builder mBuilderCompat;
  
  private RemoteViews mContentView;
  
  private final Bundle mExtras;
  
  private int mGroupAlertBehavior;
  
  private RemoteViews mHeadsUpContentView;
  
  NotificationCompatBuilder(NotificationCompat.Builder paramBuilder) {
    boolean bool1;
    boolean bool2;
    boolean bool3;
    boolean bool4;
    this.mActionExtrasList = new ArrayList<Bundle>();
    this.mExtras = new Bundle();
    this.mBuilderCompat = paramBuilder;
    if (Build.VERSION.SDK_INT >= 26) {
      this.mBuilder = new Notification.Builder(paramBuilder.mContext, paramBuilder.F);
    } else {
      this.mBuilder = new Notification.Builder(paramBuilder.mContext);
    } 
    Notification notification = paramBuilder.K;
    Notification.Builder builder1 = this.mBuilder.setWhen(notification.when).setSmallIcon(notification.icon, notification.iconLevel).setContent(notification.contentView).setTicker(notification.tickerText, paramBuilder.e).setVibrate(notification.vibrate).setLights(notification.ledARGB, notification.ledOnMS, notification.ledOffMS);
    if ((0x2 & notification.flags) != 0) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    Notification.Builder builder2 = builder1.setOngoing(bool1);
    if ((0x8 & notification.flags) != 0) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    Notification.Builder builder3 = builder2.setOnlyAlertOnce(bool2);
    if ((0x10 & notification.flags) != 0) {
      bool3 = true;
    } else {
      bool3 = false;
    } 
    Notification.Builder builder4 = builder3.setAutoCancel(bool3).setDefaults(notification.defaults).setContentTitle(paramBuilder.a).setContentText(paramBuilder.b).setContentInfo(paramBuilder.g).setContentIntent(paramBuilder.c).setDeleteIntent(notification.deleteIntent);
    PendingIntent pendingIntent = paramBuilder.d;
    if ((0x80 & notification.flags) != 0) {
      bool4 = true;
    } else {
      bool4 = false;
    } 
    builder4.setFullScreenIntent(pendingIntent, bool4).setLargeIcon(paramBuilder.f).setNumber(paramBuilder.h).setProgress(paramBuilder.o, paramBuilder.p, paramBuilder.q);
    if (Build.VERSION.SDK_INT < 21)
      this.mBuilder.setSound(notification.sound, notification.audioStreamType); 
    if (Build.VERSION.SDK_INT >= 16) {
      this.mBuilder.setSubText(paramBuilder.m).setUsesChronometer(paramBuilder.k).setPriority(paramBuilder.i);
      Iterator<NotificationCompat.Action> iterator = paramBuilder.mActions.iterator();
      while (iterator.hasNext())
        addAction(iterator.next()); 
      if (paramBuilder.y != null)
        this.mExtras.putAll(paramBuilder.y); 
      if (Build.VERSION.SDK_INT < 20) {
        if (paramBuilder.u)
          this.mExtras.putBoolean("android.support.localOnly", true); 
        if (paramBuilder.r != null) {
          this.mExtras.putString("android.support.groupKey", paramBuilder.r);
          if (paramBuilder.s) {
            this.mExtras.putBoolean("android.support.isGroupSummary", true);
          } else {
            this.mExtras.putBoolean("android.support.useSideChannel", true);
          } 
        } 
        if (paramBuilder.t != null)
          this.mExtras.putString("android.support.sortKey", paramBuilder.t); 
      } 
      this.mContentView = paramBuilder.C;
      this.mBigContentView = paramBuilder.D;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      this.mBuilder.setShowWhen(paramBuilder.j);
      if (Build.VERSION.SDK_INT < 21 && paramBuilder.mPeople != null && !paramBuilder.mPeople.isEmpty())
        this.mExtras.putStringArray("android.people", paramBuilder.mPeople.<String>toArray(new String[paramBuilder.mPeople.size()])); 
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      this.mBuilder.setLocalOnly(paramBuilder.u).setGroup(paramBuilder.r).setGroupSummary(paramBuilder.s).setSortKey(paramBuilder.t);
      this.mGroupAlertBehavior = paramBuilder.J;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.mBuilder.setCategory(paramBuilder.x).setColor(paramBuilder.z).setVisibility(paramBuilder.A).setPublicVersion(paramBuilder.B).setSound(notification.sound, notification.audioAttributes);
      for (String str : paramBuilder.mPeople)
        this.mBuilder.addPerson(str); 
      this.mHeadsUpContentView = paramBuilder.E;
    } 
    if (Build.VERSION.SDK_INT >= 24) {
      this.mBuilder.setExtras(paramBuilder.y).setRemoteInputHistory(paramBuilder.n);
      if (paramBuilder.C != null)
        this.mBuilder.setCustomContentView(paramBuilder.C); 
      if (paramBuilder.D != null)
        this.mBuilder.setCustomBigContentView(paramBuilder.D); 
      if (paramBuilder.E != null)
        this.mBuilder.setCustomHeadsUpContentView(paramBuilder.E); 
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      this.mBuilder.setBadgeIconType(paramBuilder.G).setShortcutId(paramBuilder.H).setTimeoutAfter(paramBuilder.I).setGroupAlertBehavior(paramBuilder.J);
      if (paramBuilder.w)
        this.mBuilder.setColorized(paramBuilder.v); 
      if (!TextUtils.isEmpty(paramBuilder.F))
        this.mBuilder.setSound(null).setDefaults(0).setLights(0, 0, 0).setVibrate(null); 
    } 
  }
  
  private void addAction(NotificationCompat.Action paramAction) {
    if (Build.VERSION.SDK_INT >= 20) {
      Bundle bundle;
      Notification.Action.Builder builder = new Notification.Action.Builder(paramAction.getIcon(), paramAction.getTitle(), paramAction.getActionIntent());
      if (paramAction.getRemoteInputs() != null) {
        RemoteInput[] arrayOfRemoteInput = RemoteInput.a(paramAction.getRemoteInputs());
        int i = arrayOfRemoteInput.length;
        for (byte b = 0; b < i; b++)
          builder.addRemoteInput(arrayOfRemoteInput[b]); 
      } 
      if (paramAction.getExtras() != null) {
        bundle = new Bundle(paramAction.getExtras());
      } else {
        bundle = new Bundle();
      } 
      bundle.putBoolean("android.support.allowGeneratedReplies", paramAction.getAllowGeneratedReplies());
      if (Build.VERSION.SDK_INT >= 24)
        builder.setAllowGeneratedReplies(paramAction.getAllowGeneratedReplies()); 
      builder.addExtras(bundle);
      this.mBuilder.addAction(builder.build());
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16)
      this.mActionExtrasList.add(NotificationCompatJellybean.writeActionAndGetExtras(this.mBuilder, paramAction)); 
  }
  
  private void removeSoundAndVibration(Notification paramNotification) {
    paramNotification.sound = null;
    paramNotification.vibrate = null;
    paramNotification.defaults = 0xFFFFFFFE & paramNotification.defaults;
    paramNotification.defaults = 0xFFFFFFFD & paramNotification.defaults;
  }
  
  protected Notification a() {
    if (Build.VERSION.SDK_INT >= 26)
      return this.mBuilder.build(); 
    if (Build.VERSION.SDK_INT >= 24) {
      Notification notification = this.mBuilder.build();
      if (this.mGroupAlertBehavior != 0) {
        if (notification.getGroup() != null && (0x200 & notification.flags) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (notification.getGroup() != null && (0x200 & notification.flags) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.mBuilder.setExtras(this.mExtras);
      Notification notification = this.mBuilder.build();
      if (this.mContentView != null)
        notification.contentView = this.mContentView; 
      if (this.mBigContentView != null)
        notification.bigContentView = this.mBigContentView; 
      if (this.mHeadsUpContentView != null)
        notification.headsUpContentView = this.mHeadsUpContentView; 
      if (this.mGroupAlertBehavior != 0) {
        if (notification.getGroup() != null && (0x200 & notification.flags) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (notification.getGroup() != null && (0x200 & notification.flags) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      this.mBuilder.setExtras(this.mExtras);
      Notification notification = this.mBuilder.build();
      if (this.mContentView != null)
        notification.contentView = this.mContentView; 
      if (this.mBigContentView != null)
        notification.bigContentView = this.mBigContentView; 
      if (this.mGroupAlertBehavior != 0) {
        if (notification.getGroup() != null && (0x200 & notification.flags) != 0 && this.mGroupAlertBehavior == 2)
          removeSoundAndVibration(notification); 
        if (notification.getGroup() != null && (0x200 & notification.flags) == 0 && this.mGroupAlertBehavior == 1)
          removeSoundAndVibration(notification); 
      } 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      SparseArray<Bundle> sparseArray = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
      if (sparseArray != null)
        this.mExtras.putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      this.mBuilder.setExtras(this.mExtras);
      Notification notification = this.mBuilder.build();
      if (this.mContentView != null)
        notification.contentView = this.mContentView; 
      if (this.mBigContentView != null)
        notification.bigContentView = this.mBigContentView; 
      return notification;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      Notification notification = this.mBuilder.build();
      Bundle bundle1 = NotificationCompat.getExtras(notification);
      Bundle bundle2 = new Bundle(this.mExtras);
      for (String str : this.mExtras.keySet()) {
        if (bundle1.containsKey(str))
          bundle2.remove(str); 
      } 
      bundle1.putAll(bundle2);
      SparseArray<Bundle> sparseArray = NotificationCompatJellybean.buildActionExtrasMap(this.mActionExtrasList);
      if (sparseArray != null)
        NotificationCompat.getExtras(notification).putSparseParcelableArray("android.support.actionExtras", sparseArray); 
      if (this.mContentView != null)
        notification.contentView = this.mContentView; 
      if (this.mBigContentView != null)
        notification.bigContentView = this.mBigContentView; 
      return notification;
    } 
    return this.mBuilder.getNotification();
  }
  
  public Notification build() {
    RemoteViews remoteViews;
    NotificationCompat.Style style = this.mBuilderCompat.l;
    if (style != null)
      style.apply(this); 
    if (style != null) {
      remoteViews = style.makeContentView(this);
    } else {
      remoteViews = null;
    } 
    Notification notification = a();
    if (remoteViews != null) {
      notification.contentView = remoteViews;
    } else if (this.mBuilderCompat.C != null) {
      notification.contentView = this.mBuilderCompat.C;
    } 
    if (Build.VERSION.SDK_INT >= 16 && style != null) {
      RemoteViews remoteViews1 = style.makeBigContentView(this);
      if (remoteViews1 != null)
        notification.bigContentView = remoteViews1; 
    } 
    if (Build.VERSION.SDK_INT >= 21 && style != null) {
      RemoteViews remoteViews1 = this.mBuilderCompat.l.makeHeadsUpContentView(this);
      if (remoteViews1 != null)
        notification.headsUpContentView = remoteViews1; 
    } 
    if (Build.VERSION.SDK_INT >= 16 && style != null) {
      Bundle bundle = NotificationCompat.getExtras(notification);
      if (bundle != null)
        style.addCompatExtras(bundle); 
    } 
    return notification;
  }
  
  public Notification.Builder getBuilder() {
    return this.mBuilder;
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\NotificationCompatBuilder.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */