package android.support.v4.app;

import android.app.Service;
import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobServiceEngine;
import android.app.job.JobWorkItem;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.IBinder;
import android.os.PowerManager;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import java.util.ArrayList;
import java.util.HashMap;

public abstract class JobIntentService extends Service {
  static final Object h = new Object();
  
  static final HashMap<ComponentName, WorkEnqueuer> i = new HashMap<ComponentName, WorkEnqueuer>();
  
  CompatJobEngine a;
  
  WorkEnqueuer b;
  
  CommandProcessor c;
  
  boolean d = false;
  
  boolean e = false;
  
  boolean f = false;
  
  final ArrayList<CompatWorkItem> g;
  
  public JobIntentService() {
    if (Build.VERSION.SDK_INT >= 26) {
      this.g = null;
      return;
    } 
    this.g = new ArrayList<CompatWorkItem>();
  }
  
  static WorkEnqueuer a(Context paramContext, ComponentName paramComponentName, boolean paramBoolean, int paramInt) {
    WorkEnqueuer workEnqueuer = i.get(paramComponentName);
    if (workEnqueuer == null) {
      CompatWorkEnqueuer compatWorkEnqueuer;
      if (Build.VERSION.SDK_INT >= 26) {
        if (paramBoolean) {
          JobWorkEnqueuer jobWorkEnqueuer = new JobWorkEnqueuer(paramContext, paramComponentName, paramInt);
        } else {
          throw new IllegalArgumentException("Can't be here without a job id");
        } 
      } else {
        compatWorkEnqueuer = new CompatWorkEnqueuer(paramContext, paramComponentName);
      } 
      workEnqueuer = compatWorkEnqueuer;
      i.put(paramComponentName, workEnqueuer);
    } 
    return workEnqueuer;
  }
  
  public static void enqueueWork(@NonNull Context paramContext, @NonNull ComponentName paramComponentName, int paramInt, @NonNull Intent paramIntent) {
    if (paramIntent != null)
      synchronized (h) {
        WorkEnqueuer workEnqueuer = a(paramContext, paramComponentName, true, paramInt);
        workEnqueuer.a(paramInt);
        workEnqueuer.a(paramIntent);
        return;
      }  
    throw new IllegalArgumentException("work must not be null");
  }
  
  public static void enqueueWork(@NonNull Context paramContext, @NonNull Class paramClass, int paramInt, @NonNull Intent paramIntent) {
    enqueueWork(paramContext, new ComponentName(paramContext, paramClass), paramInt, paramIntent);
  }
  
  void a(boolean paramBoolean) {
    if (this.c == null) {
      this.c = new CommandProcessor(this);
      if (this.b != null && paramBoolean)
        this.b.serviceProcessingStarted(); 
      this.c.executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, (Object[])new Void[0]);
    } 
  }
  
  boolean a() {
    if (this.c != null)
      this.c.cancel(this.d); 
    this.e = true;
    return onStopCurrentWork();
  }
  
  void b() {
    if (this.g != null)
      synchronized (this.g) {
        this.c = null;
        if (this.g != null && this.g.size() > 0) {
          a(false);
        } else if (!this.f) {
          this.b.serviceProcessingFinished();
        } 
        return;
      }  
  }
  
  GenericWorkItem c() {
    if (this.a != null)
      return this.a.dequeueWork(); 
    synchronized (this.g) {
      if (this.g.size() > 0)
        return this.g.remove(0); 
      return null;
    } 
  }
  
  public boolean isStopped() {
    return this.e;
  }
  
  public IBinder onBind(@NonNull Intent paramIntent) {
    return (this.a != null) ? this.a.compatGetBinder() : null;
  }
  
  public void onCreate() {
    super.onCreate();
    if (Build.VERSION.SDK_INT >= 26) {
      this.a = new JobServiceEngineImpl(this);
      this.b = null;
      return;
    } 
    this.a = null;
    this.b = a((Context)this, new ComponentName((Context)this, getClass()), false, 0);
  }
  
  public void onDestroy() {
    super.onDestroy();
    if (this.g != null)
      synchronized (this.g) {
        this.f = true;
        this.b.serviceProcessingFinished();
        return;
      }  
  }
  
  protected abstract void onHandleWork(@NonNull Intent paramIntent);
  
  public int onStartCommand(@Nullable Intent paramIntent, int paramInt1, int paramInt2) {
    if (this.g != null) {
      this.b.serviceStartReceived();
      synchronized (this.g) {
        ArrayList<CompatWorkItem> arrayList = this.g;
        if (paramIntent == null)
          paramIntent = new Intent(); 
        arrayList.add(new CompatWorkItem(this, paramIntent, paramInt2));
        a(true);
        return 3;
      } 
    } 
    return 2;
  }
  
  public boolean onStopCurrentWork() {
    return true;
  }
  
  public void setInterruptIfStopped(boolean paramBoolean) {
    this.d = paramBoolean;
  }
  
  final class CommandProcessor extends AsyncTask<Void, Void, Void> {
    CommandProcessor(JobIntentService this$0) {}
    
    protected Void a(Void... param1VarArgs) {
      while (true) {
        JobIntentService.GenericWorkItem genericWorkItem = this.a.c();
        if (genericWorkItem != null) {
          this.a.onHandleWork(genericWorkItem.getIntent());
          genericWorkItem.complete();
          continue;
        } 
        return null;
      } 
    }
    
    protected void a(Void param1Void) {
      this.a.b();
    }
    
    protected void b(Void param1Void) {
      this.a.b();
    }
  }
  
  static interface CompatJobEngine {
    IBinder compatGetBinder();
    
    JobIntentService.GenericWorkItem dequeueWork();
  }
  
  static final class CompatWorkEnqueuer extends WorkEnqueuer {
    boolean a;
    
    boolean b;
    
    private final Context mContext;
    
    private final PowerManager.WakeLock mLaunchWakeLock;
    
    private final PowerManager.WakeLock mRunWakeLock;
    
    CompatWorkEnqueuer(Context param1Context, ComponentName param1ComponentName) {
      super(param1Context, param1ComponentName);
      this.mContext = param1Context.getApplicationContext();
      PowerManager powerManager = (PowerManager)param1Context.getSystemService("power");
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(param1ComponentName.getClassName());
      stringBuilder1.append(":launch");
      this.mLaunchWakeLock = powerManager.newWakeLock(1, stringBuilder1.toString());
      this.mLaunchWakeLock.setReferenceCounted(false);
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append(param1ComponentName.getClassName());
      stringBuilder2.append(":run");
      this.mRunWakeLock = powerManager.newWakeLock(1, stringBuilder2.toString());
      this.mRunWakeLock.setReferenceCounted(false);
    }
    
    void a(Intent param1Intent) {
      // Byte code:
      //   0: new android/content/Intent
      //   3: dup
      //   4: aload_1
      //   5: invokespecial <init> : (Landroid/content/Intent;)V
      //   8: astore_2
      //   9: aload_2
      //   10: aload_0
      //   11: getfield c : Landroid/content/ComponentName;
      //   14: invokevirtual setComponent : (Landroid/content/ComponentName;)Landroid/content/Intent;
      //   17: pop
      //   18: aload_0
      //   19: getfield mContext : Landroid/content/Context;
      //   22: aload_2
      //   23: invokevirtual startService : (Landroid/content/Intent;)Landroid/content/ComponentName;
      //   26: ifnull -> 70
      //   29: aload_0
      //   30: monitorenter
      //   31: aload_0
      //   32: getfield a : Z
      //   35: ifne -> 60
      //   38: aload_0
      //   39: iconst_1
      //   40: putfield a : Z
      //   43: aload_0
      //   44: getfield b : Z
      //   47: ifne -> 60
      //   50: aload_0
      //   51: getfield mLaunchWakeLock : Landroid/os/PowerManager$WakeLock;
      //   54: ldc2_w 60000
      //   57: invokevirtual acquire : (J)V
      //   60: aload_0
      //   61: monitorexit
      //   62: return
      //   63: astore #4
      //   65: aload_0
      //   66: monitorexit
      //   67: aload #4
      //   69: athrow
      //   70: return
      // Exception table:
      //   from	to	target	type
      //   31	60	63	finally
      //   60	62	63	finally
      //   65	67	63	finally
    }
    
    public void serviceProcessingFinished() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Z
      //   6: ifeq -> 38
      //   9: aload_0
      //   10: getfield a : Z
      //   13: ifeq -> 26
      //   16: aload_0
      //   17: getfield mLaunchWakeLock : Landroid/os/PowerManager$WakeLock;
      //   20: ldc2_w 60000
      //   23: invokevirtual acquire : (J)V
      //   26: aload_0
      //   27: iconst_0
      //   28: putfield b : Z
      //   31: aload_0
      //   32: getfield mRunWakeLock : Landroid/os/PowerManager$WakeLock;
      //   35: invokevirtual release : ()V
      //   38: aload_0
      //   39: monitorexit
      //   40: return
      //   41: astore_1
      //   42: aload_0
      //   43: monitorexit
      //   44: aload_1
      //   45: athrow
      // Exception table:
      //   from	to	target	type
      //   2	26	41	finally
      //   26	38	41	finally
      //   38	40	41	finally
      //   42	44	41	finally
    }
    
    public void serviceProcessingStarted() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: getfield b : Z
      //   6: ifne -> 31
      //   9: aload_0
      //   10: iconst_1
      //   11: putfield b : Z
      //   14: aload_0
      //   15: getfield mRunWakeLock : Landroid/os/PowerManager$WakeLock;
      //   18: ldc2_w 600000
      //   21: invokevirtual acquire : (J)V
      //   24: aload_0
      //   25: getfield mLaunchWakeLock : Landroid/os/PowerManager$WakeLock;
      //   28: invokevirtual release : ()V
      //   31: aload_0
      //   32: monitorexit
      //   33: return
      //   34: astore_1
      //   35: aload_0
      //   36: monitorexit
      //   37: aload_1
      //   38: athrow
      // Exception table:
      //   from	to	target	type
      //   2	31	34	finally
      //   31	33	34	finally
      //   35	37	34	finally
    }
    
    public void serviceStartReceived() {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: iconst_0
      //   4: putfield a : Z
      //   7: aload_0
      //   8: monitorexit
      //   9: return
      //   10: astore_1
      //   11: aload_0
      //   12: monitorexit
      //   13: aload_1
      //   14: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	10	finally
      //   11	13	10	finally
    }
  }
  
  final class CompatWorkItem implements GenericWorkItem {
    final Intent a;
    
    final int b;
    
    CompatWorkItem(JobIntentService this$0, Intent param1Intent, int param1Int) {
      this.a = param1Intent;
      this.b = param1Int;
    }
    
    public void complete() {
      this.c.stopSelf(this.b);
    }
    
    public Intent getIntent() {
      return this.a;
    }
  }
  
  static interface GenericWorkItem {
    void complete();
    
    Intent getIntent();
  }
  
  @RequiresApi(26)
  static final class JobServiceEngineImpl extends JobServiceEngine implements CompatJobEngine {
    final JobIntentService a;
    
    final Object b = new Object();
    
    JobParameters c;
    
    JobServiceEngineImpl(JobIntentService param1JobIntentService) {
      super(param1JobIntentService);
      this.a = param1JobIntentService;
    }
    
    public IBinder compatGetBinder() {
      return getBinder();
    }
    
    public JobIntentService.GenericWorkItem dequeueWork() {
      synchronized (this.b) {
        if (this.c == null)
          return null; 
        JobWorkItem jobWorkItem = this.c.dequeueWork();
        if (jobWorkItem != null) {
          jobWorkItem.getIntent().setExtrasClassLoader(this.a.getClassLoader());
          return new WrapperWorkItem(this, jobWorkItem);
        } 
        return null;
      } 
    }
    
    public boolean onStartJob(JobParameters param1JobParameters) {
      this.c = param1JobParameters;
      this.a.a(false);
      return true;
    }
    
    public boolean onStopJob(JobParameters param1JobParameters) {
      boolean bool = this.a.a();
      synchronized (this.b) {
        this.c = null;
        return bool;
      } 
    }
    
    final class WrapperWorkItem implements JobIntentService.GenericWorkItem {
      final JobWorkItem a;
      
      WrapperWorkItem(JobIntentService.JobServiceEngineImpl this$0, JobWorkItem param2JobWorkItem) {
        this.a = param2JobWorkItem;
      }
      
      public void complete() {
        synchronized (this.b.b) {
          if (this.b.c != null)
            this.b.c.completeWork(this.a); 
          return;
        } 
      }
      
      public Intent getIntent() {
        return this.a.getIntent();
      }
    }
  }
  
  final class WrapperWorkItem implements GenericWorkItem {
    final JobWorkItem a;
    
    WrapperWorkItem(JobIntentService this$0, JobWorkItem param1JobWorkItem) {
      this.a = param1JobWorkItem;
    }
    
    public void complete() {
      synchronized (this.b.b) {
        if (this.b.c != null)
          this.b.c.completeWork(this.a); 
        return;
      } 
    }
    
    public Intent getIntent() {
      return this.a.getIntent();
    }
  }
  
  @RequiresApi(26)
  static final class JobWorkEnqueuer extends WorkEnqueuer {
    private final JobInfo mJobInfo;
    
    private final JobScheduler mJobScheduler;
    
    JobWorkEnqueuer(Context param1Context, ComponentName param1ComponentName, int param1Int) {
      super(param1Context, param1ComponentName);
      a(param1Int);
      this.mJobInfo = (new JobInfo.Builder(param1Int, this.c)).setOverrideDeadline(0L).build();
      this.mJobScheduler = (JobScheduler)param1Context.getApplicationContext().getSystemService("jobscheduler");
    }
    
    void a(Intent param1Intent) {
      this.mJobScheduler.enqueue(this.mJobInfo, new JobWorkItem(param1Intent));
    }
  }
  
  static abstract class WorkEnqueuer {
    final ComponentName c;
    
    boolean d;
    
    int e;
    
    WorkEnqueuer(Context param1Context, ComponentName param1ComponentName) {
      this.c = param1ComponentName;
    }
    
    void a(int param1Int) {
      if (!this.d) {
        this.d = true;
        this.e = param1Int;
        return;
      } 
      if (this.e == param1Int)
        return; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Given job ID ");
      stringBuilder.append(param1Int);
      stringBuilder.append(" is different than previous ");
      stringBuilder.append(this.e);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    abstract void a(Intent param1Intent);
    
    public void serviceProcessingFinished() {}
    
    public void serviceProcessingStarted() {}
    
    public void serviceStartReceived() {}
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\app\JobIntentService.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */