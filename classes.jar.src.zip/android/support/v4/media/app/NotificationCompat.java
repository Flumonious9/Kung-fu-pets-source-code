package android.support.v4.media.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.media.session.MediaSession;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.mediacompat.R;
import android.support.v4.app.BundleCompat;
import android.support.v4.app.NotificationBuilderWithBuilderAccessor;
import android.support.v4.media.session.MediaSessionCompat;
import android.widget.RemoteViews;

public class NotificationCompat {
  public static class DecoratedMediaCustomViewStyle extends MediaStyle {
    private void setBackgroundColor(RemoteViews param1RemoteViews) {
      int i;
      if (this.mBuilder.getColor() != 0) {
        i = this.mBuilder.getColor();
      } else {
        i = this.mBuilder.mContext.getResources().getColor(R.color.notification_material_background_media_default_color);
      } 
      param1RemoteViews.setInt(R.id.status_bar_latest_event_content, "setBackgroundColor", i);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 24) {
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setStyle((Notification.Style)a((Notification.MediaStyle)new Notification.DecoratedMediaCustomViewStyle()));
        return;
      } 
      super.apply(param1NotificationBuilderWithBuilderAccessor);
    }
    
    int getBigContentViewLayoutResource(int param1Int) {
      return (param1Int <= 3) ? R.layout.notification_template_big_media_narrow_custom : R.layout.notification_template_big_media_custom;
    }
    
    int getContentViewLayoutResource() {
      return (this.mBuilder.getContentView() != null) ? R.layout.notification_template_media_custom : super.getContentViewLayoutResource();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      RemoteViews remoteViews1;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      if (this.mBuilder.getBigContentView() != null) {
        remoteViews1 = this.mBuilder.getBigContentView();
      } else {
        remoteViews1 = this.mBuilder.getContentView();
      } 
      if (remoteViews1 == null)
        return null; 
      RemoteViews remoteViews2 = b();
      buildIntoRemoteViews(remoteViews2, remoteViews1);
      if (Build.VERSION.SDK_INT >= 21)
        setBackgroundColor(remoteViews2); 
      return remoteViews2;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      // Byte code:
      //   0: getstatic android/os/Build$VERSION.SDK_INT : I
      //   3: bipush #24
      //   5: if_icmplt -> 10
      //   8: aconst_null
      //   9: areturn
      //   10: aload_0
      //   11: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   14: invokevirtual getContentView : ()Landroid/widget/RemoteViews;
      //   17: ifnull -> 25
      //   20: iconst_1
      //   21: istore_2
      //   22: goto -> 27
      //   25: iconst_0
      //   26: istore_2
      //   27: getstatic android/os/Build$VERSION.SDK_INT : I
      //   30: bipush #21
      //   32: if_icmplt -> 96
      //   35: iload_2
      //   36: ifne -> 56
      //   39: aload_0
      //   40: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   43: invokevirtual getBigContentView : ()Landroid/widget/RemoteViews;
      //   46: astore #6
      //   48: iconst_0
      //   49: istore #4
      //   51: aload #6
      //   53: ifnull -> 59
      //   56: iconst_1
      //   57: istore #4
      //   59: iload #4
      //   61: ifeq -> 119
      //   64: aload_0
      //   65: invokevirtual a : ()Landroid/widget/RemoteViews;
      //   68: astore #5
      //   70: iload_2
      //   71: ifeq -> 87
      //   74: aload_0
      //   75: aload #5
      //   77: aload_0
      //   78: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   81: invokevirtual getContentView : ()Landroid/widget/RemoteViews;
      //   84: invokevirtual buildIntoRemoteViews : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   87: aload_0
      //   88: aload #5
      //   90: invokespecial setBackgroundColor : (Landroid/widget/RemoteViews;)V
      //   93: aload #5
      //   95: areturn
      //   96: aload_0
      //   97: invokevirtual a : ()Landroid/widget/RemoteViews;
      //   100: astore_3
      //   101: iload_2
      //   102: ifeq -> 119
      //   105: aload_0
      //   106: aload_3
      //   107: aload_0
      //   108: getfield mBuilder : Landroid/support/v4/app/NotificationCompat$Builder;
      //   111: invokevirtual getContentView : ()Landroid/widget/RemoteViews;
      //   114: invokevirtual buildIntoRemoteViews : (Landroid/widget/RemoteViews;Landroid/widget/RemoteViews;)V
      //   117: aload_3
      //   118: areturn
      //   119: aconst_null
      //   120: areturn
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeHeadsUpContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      RemoteViews remoteViews1;
      if (Build.VERSION.SDK_INT >= 24)
        return null; 
      if (this.mBuilder.getHeadsUpContentView() != null) {
        remoteViews1 = this.mBuilder.getHeadsUpContentView();
      } else {
        remoteViews1 = this.mBuilder.getContentView();
      } 
      if (remoteViews1 == null)
        return null; 
      RemoteViews remoteViews2 = b();
      buildIntoRemoteViews(remoteViews2, remoteViews1);
      if (Build.VERSION.SDK_INT >= 21)
        setBackgroundColor(remoteViews2); 
      return remoteViews2;
    }
  }
  
  public static class MediaStyle extends android.support.v4.app.NotificationCompat.Style {
    private static final int MAX_MEDIA_BUTTONS = 5;
    
    private static final int MAX_MEDIA_BUTTONS_IN_COMPACT = 3;
    
    int[] a = null;
    
    MediaSessionCompat.Token b;
    
    boolean c;
    
    PendingIntent g;
    
    public MediaStyle() {}
    
    public MediaStyle(android.support.v4.app.NotificationCompat.Builder param1Builder) {
      setBuilder(param1Builder);
    }
    
    private RemoteViews generateMediaActionButton(android.support.v4.app.NotificationCompat.Action param1Action) {
      boolean bool;
      if (param1Action.getActionIntent() == null) {
        bool = true;
      } else {
        bool = false;
      } 
      RemoteViews remoteViews = new RemoteViews(this.mBuilder.mContext.getPackageName(), R.layout.notification_media_action);
      remoteViews.setImageViewResource(R.id.action0, param1Action.getIcon());
      if (!bool)
        remoteViews.setOnClickPendingIntent(R.id.action0, param1Action.getActionIntent()); 
      if (Build.VERSION.SDK_INT >= 15)
        remoteViews.setContentDescription(R.id.action0, param1Action.getTitle()); 
      return remoteViews;
    }
    
    public static MediaSessionCompat.Token getMediaSession(Notification param1Notification) {
      Bundle bundle = android.support.v4.app.NotificationCompat.getExtras(param1Notification);
      if (bundle != null)
        if (Build.VERSION.SDK_INT >= 21) {
          Parcelable parcelable = bundle.getParcelable("android.mediaSession");
          if (parcelable != null)
            return MediaSessionCompat.Token.fromToken(parcelable); 
        } else {
          IBinder iBinder = BundleCompat.getBinder(bundle, "android.mediaSession");
          if (iBinder != null) {
            Parcel parcel = Parcel.obtain();
            parcel.writeStrongBinder(iBinder);
            parcel.setDataPosition(0);
            MediaSessionCompat.Token token = (MediaSessionCompat.Token)MediaSessionCompat.Token.CREATOR.createFromParcel(parcel);
            parcel.recycle();
            return token;
          } 
        }  
      return null;
    }
    
    @RequiresApi(21)
    Notification.MediaStyle a(Notification.MediaStyle param1MediaStyle) {
      if (this.a != null)
        param1MediaStyle.setShowActionsInCompactView(this.a); 
      if (this.b != null)
        param1MediaStyle.setMediaSession((MediaSession.Token)this.b.getToken()); 
      return param1MediaStyle;
    }
    
    RemoteViews a() {
      int j;
      RemoteViews remoteViews = applyStandardTemplate(false, getContentViewLayoutResource(), true);
      int i = this.mBuilder.mActions.size();
      if (this.a == null) {
        j = 0;
      } else {
        j = Math.min(this.a.length, 3);
      } 
      remoteViews.removeAllViews(R.id.media_actions);
      if (j > 0) {
        byte b = 0;
        while (b < j) {
          if (b < i) {
            RemoteViews remoteViews1 = generateMediaActionButton(this.mBuilder.mActions.get(this.a[b]));
            remoteViews.addView(R.id.media_actions, remoteViews1);
            b++;
            continue;
          } 
          Object[] arrayOfObject = new Object[2];
          arrayOfObject[0] = Integer.valueOf(b);
          arrayOfObject[1] = Integer.valueOf(i - 1);
          throw new IllegalArgumentException(String.format("setShowActionsInCompactView: action %d out of bounds (max %d)", arrayOfObject));
        } 
      } 
      if (this.c) {
        remoteViews.setViewVisibility(R.id.end_padder, 8);
        remoteViews.setViewVisibility(R.id.cancel_action, 0);
        remoteViews.setOnClickPendingIntent(R.id.cancel_action, this.g);
        remoteViews.setInt(R.id.cancel_action, "setAlpha", this.mBuilder.mContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
        return remoteViews;
      } 
      remoteViews.setViewVisibility(R.id.end_padder, 0);
      remoteViews.setViewVisibility(R.id.cancel_action, 8);
      return remoteViews;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public void apply(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setStyle((Notification.Style)a(new Notification.MediaStyle()));
        return;
      } 
      if (this.c)
        param1NotificationBuilderWithBuilderAccessor.getBuilder().setOngoing(true); 
    }
    
    RemoteViews b() {
      int i = Math.min(this.mBuilder.mActions.size(), 5);
      RemoteViews remoteViews = applyStandardTemplate(false, getBigContentViewLayoutResource(i), false);
      remoteViews.removeAllViews(R.id.media_actions);
      if (i > 0)
        for (byte b = 0; b < i; b++) {
          RemoteViews remoteViews1 = generateMediaActionButton(this.mBuilder.mActions.get(b));
          remoteViews.addView(R.id.media_actions, remoteViews1);
        }  
      if (this.c) {
        remoteViews.setViewVisibility(R.id.cancel_action, 0);
        remoteViews.setInt(R.id.cancel_action, "setAlpha", this.mBuilder.mContext.getResources().getInteger(R.integer.cancel_button_image_alpha));
        remoteViews.setOnClickPendingIntent(R.id.cancel_action, this.g);
        return remoteViews;
      } 
      remoteViews.setViewVisibility(R.id.cancel_action, 8);
      return remoteViews;
    }
    
    int getBigContentViewLayoutResource(int param1Int) {
      return (param1Int <= 3) ? R.layout.notification_template_big_media_narrow : R.layout.notification_template_big_media;
    }
    
    int getContentViewLayoutResource() {
      return R.layout.notification_template_media;
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeBigContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return (Build.VERSION.SDK_INT >= 21) ? null : b();
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public RemoteViews makeContentView(NotificationBuilderWithBuilderAccessor param1NotificationBuilderWithBuilderAccessor) {
      return (Build.VERSION.SDK_INT >= 21) ? null : a();
    }
    
    public MediaStyle setCancelButtonIntent(PendingIntent param1PendingIntent) {
      this.g = param1PendingIntent;
      return this;
    }
    
    public MediaStyle setMediaSession(MediaSessionCompat.Token param1Token) {
      this.b = param1Token;
      return this;
    }
    
    public MediaStyle setShowActionsInCompactView(int... param1VarArgs) {
      this.a = param1VarArgs;
      return this;
    }
    
    public MediaStyle setShowCancelButton(boolean param1Boolean) {
      if (Build.VERSION.SDK_INT < 21)
        this.c = param1Boolean; 
      return this;
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\app\NotificationCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */