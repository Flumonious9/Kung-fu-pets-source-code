package android.support.v4.media.session;

import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.media.AudioManager;
import android.media.RemoteControlClient;
import android.net.Uri;
import android.os.BadParcelableException;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.Message;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteCallbackList;
import android.os.RemoteException;
import android.os.ResultReceiver;
import android.os.SystemClock;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.MediaDescriptionCompat;
import android.support.v4.media.MediaMetadataCompat;
import android.support.v4.media.RatingCompat;
import android.support.v4.media.VolumeProviderCompat;
import android.text.TextUtils;
import android.util.Log;
import android.util.TypedValue;
import android.view.KeyEvent;
import android.view.ViewConfiguration;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class MediaSessionCompat {
  public static final String ACTION_FLAG_AS_INAPPROPRIATE = "android.support.v4.media.session.action.FLAG_AS_INAPPROPRIATE";
  
  public static final String ACTION_FOLLOW = "android.support.v4.media.session.action.FOLLOW";
  
  public static final String ACTION_SKIP_AD = "android.support.v4.media.session.action.SKIP_AD";
  
  public static final String ACTION_UNFOLLOW = "android.support.v4.media.session.action.UNFOLLOW";
  
  public static final String ARGUMENT_MEDIA_ATTRIBUTE = "android.support.v4.media.session.ARGUMENT_MEDIA_ATTRIBUTE";
  
  public static final String ARGUMENT_MEDIA_ATTRIBUTE_VALUE = "android.support.v4.media.session.ARGUMENT_MEDIA_ATTRIBUTE_VALUE";
  
  public static final int FLAG_HANDLES_MEDIA_BUTTONS = 1;
  
  public static final int FLAG_HANDLES_QUEUE_COMMANDS = 4;
  
  public static final int FLAG_HANDLES_TRANSPORT_CONTROLS = 2;
  
  private static final int MAX_BITMAP_SIZE_IN_DP = 320;
  
  public static final int MEDIA_ATTRIBUTE_ALBUM = 1;
  
  public static final int MEDIA_ATTRIBUTE_ARTIST = 0;
  
  public static final int MEDIA_ATTRIBUTE_PLAYLIST = 2;
  
  static int a;
  
  private final ArrayList<OnActiveChangeListener> mActiveListeners = new ArrayList<OnActiveChangeListener>();
  
  private final MediaControllerCompat mController;
  
  private final MediaSessionImpl mImpl;
  
  private MediaSessionCompat(Context paramContext, MediaSessionImpl paramMediaSessionImpl) {
    this.mImpl = paramMediaSessionImpl;
    if (Build.VERSION.SDK_INT >= 21 && !MediaSessionCompatApi21.hasCallback(paramMediaSessionImpl.getMediaSession()))
      setCallback(new Callback(this) {
          
          }); 
    this.mController = new MediaControllerCompat(paramContext, this);
  }
  
  public MediaSessionCompat(Context paramContext, String paramString) {
    this(paramContext, paramString, null, null);
  }
  
  public MediaSessionCompat(Context paramContext, String paramString, ComponentName paramComponentName, PendingIntent paramPendingIntent) {
    if (paramContext != null) {
      if (!TextUtils.isEmpty(paramString)) {
        if (paramComponentName == null) {
          paramComponentName = MediaButtonReceiver.a(paramContext);
          if (paramComponentName == null)
            Log.w("MediaSessionCompat", "Couldn't find a unique registered media button receiver in the given context."); 
        } 
        if (paramComponentName != null && paramPendingIntent == null) {
          Intent intent = new Intent("android.intent.action.MEDIA_BUTTON");
          intent.setComponent(paramComponentName);
          paramPendingIntent = PendingIntent.getBroadcast(paramContext, 0, intent, 0);
        } 
        if (Build.VERSION.SDK_INT >= 21) {
          this.mImpl = new MediaSessionImplApi21(paramContext, paramString);
          setCallback(new Callback(this) {
              
              });
          this.mImpl.setMediaButtonReceiver(paramPendingIntent);
        } else if (Build.VERSION.SDK_INT >= 19) {
          this.mImpl = new MediaSessionImplApi19(paramContext, paramString, paramComponentName, paramPendingIntent);
        } else if (Build.VERSION.SDK_INT >= 18) {
          this.mImpl = new MediaSessionImplApi18(paramContext, paramString, paramComponentName, paramPendingIntent);
        } else {
          this.mImpl = new MediaSessionImplBase(paramContext, paramString, paramComponentName, paramPendingIntent);
        } 
        this.mController = new MediaControllerCompat(paramContext, this);
        if (a == 0)
          a = (int)TypedValue.applyDimension(1, 320.0F, paramContext.getResources().getDisplayMetrics()); 
        return;
      } 
      throw new IllegalArgumentException("tag must not be null or empty");
    } 
    throw new IllegalArgumentException("context must not be null");
  }
  
  public static MediaSessionCompat fromMediaSession(Context paramContext, Object paramObject) {
    return (paramContext != null && paramObject != null && Build.VERSION.SDK_INT >= 21) ? new MediaSessionCompat(paramContext, new MediaSessionImplApi21(paramObject)) : null;
  }
  
  private static PlaybackStateCompat getStateWithUpdatedPosition(PlaybackStateCompat paramPlaybackStateCompat, MediaMetadataCompat paramMediaMetadataCompat) {
    if (paramPlaybackStateCompat != null) {
      long l1 = paramPlaybackStateCompat.getPosition();
      long l2 = -1L;
      if (l1 == l2)
        return paramPlaybackStateCompat; 
      if (paramPlaybackStateCompat.getState() == 3 || paramPlaybackStateCompat.getState() == 4 || paramPlaybackStateCompat.getState() == 5) {
        long l = paramPlaybackStateCompat.getLastPositionUpdateTime();
        if (l > 0L) {
          long l5;
          long l3 = SystemClock.elapsedRealtime();
          long l4 = (long)(paramPlaybackStateCompat.getPlaybackSpeed() * (float)(l3 - l)) + paramPlaybackStateCompat.getPosition();
          if (paramMediaMetadataCompat != null && paramMediaMetadataCompat.containsKey("android.media.metadata.DURATION"))
            l2 = paramMediaMetadataCompat.getLong("android.media.metadata.DURATION"); 
          if (l2 >= 0L && l4 > l2) {
            l5 = l2;
          } else if (l4 < 0L) {
            l5 = 0L;
          } else {
            l5 = l4;
          } 
          return (new PlaybackStateCompat.Builder(paramPlaybackStateCompat)).setState(paramPlaybackStateCompat.getState(), l5, paramPlaybackStateCompat.getPlaybackSpeed(), l3).build();
        } 
      } 
      return paramPlaybackStateCompat;
    } 
    return paramPlaybackStateCompat;
  }
  
  public void addOnActiveChangeListener(OnActiveChangeListener paramOnActiveChangeListener) {
    if (paramOnActiveChangeListener != null) {
      this.mActiveListeners.add(paramOnActiveChangeListener);
      return;
    } 
    throw new IllegalArgumentException("Listener may not be null");
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public String getCallingPackage() {
    return this.mImpl.getCallingPackage();
  }
  
  public MediaControllerCompat getController() {
    return this.mController;
  }
  
  public Object getMediaSession() {
    return this.mImpl.getMediaSession();
  }
  
  public Object getRemoteControlClient() {
    return this.mImpl.getRemoteControlClient();
  }
  
  public Token getSessionToken() {
    return this.mImpl.getSessionToken();
  }
  
  public boolean isActive() {
    return this.mImpl.isActive();
  }
  
  public void release() {
    this.mImpl.release();
  }
  
  public void removeOnActiveChangeListener(OnActiveChangeListener paramOnActiveChangeListener) {
    if (paramOnActiveChangeListener != null) {
      this.mActiveListeners.remove(paramOnActiveChangeListener);
      return;
    } 
    throw new IllegalArgumentException("Listener may not be null");
  }
  
  public void sendSessionEvent(String paramString, Bundle paramBundle) {
    if (!TextUtils.isEmpty(paramString)) {
      this.mImpl.sendSessionEvent(paramString, paramBundle);
      return;
    } 
    throw new IllegalArgumentException("event cannot be null or empty");
  }
  
  public void setActive(boolean paramBoolean) {
    this.mImpl.setActive(paramBoolean);
    Iterator<OnActiveChangeListener> iterator = this.mActiveListeners.iterator();
    while (iterator.hasNext())
      ((OnActiveChangeListener)iterator.next()).onActiveChanged(); 
  }
  
  public void setCallback(Callback paramCallback) {
    setCallback(paramCallback, null);
  }
  
  public void setCallback(Callback paramCallback, Handler paramHandler) {
    MediaSessionImpl mediaSessionImpl = this.mImpl;
    if (paramHandler == null)
      paramHandler = new Handler(); 
    mediaSessionImpl.setCallback(paramCallback, paramHandler);
  }
  
  public void setCaptioningEnabled(boolean paramBoolean) {
    this.mImpl.setCaptioningEnabled(paramBoolean);
  }
  
  public void setExtras(Bundle paramBundle) {
    this.mImpl.setExtras(paramBundle);
  }
  
  public void setFlags(int paramInt) {
    this.mImpl.setFlags(paramInt);
  }
  
  public void setMediaButtonReceiver(PendingIntent paramPendingIntent) {
    this.mImpl.setMediaButtonReceiver(paramPendingIntent);
  }
  
  public void setMetadata(MediaMetadataCompat paramMediaMetadataCompat) {
    this.mImpl.setMetadata(paramMediaMetadataCompat);
  }
  
  public void setPlaybackState(PlaybackStateCompat paramPlaybackStateCompat) {
    this.mImpl.setPlaybackState(paramPlaybackStateCompat);
  }
  
  public void setPlaybackToLocal(int paramInt) {
    this.mImpl.setPlaybackToLocal(paramInt);
  }
  
  public void setPlaybackToRemote(VolumeProviderCompat paramVolumeProviderCompat) {
    if (paramVolumeProviderCompat != null) {
      this.mImpl.setPlaybackToRemote(paramVolumeProviderCompat);
      return;
    } 
    throw new IllegalArgumentException("volumeProvider may not be null!");
  }
  
  public void setQueue(List<QueueItem> paramList) {
    this.mImpl.setQueue(paramList);
  }
  
  public void setQueueTitle(CharSequence paramCharSequence) {
    this.mImpl.setQueueTitle(paramCharSequence);
  }
  
  public void setRatingType(int paramInt) {
    this.mImpl.setRatingType(paramInt);
  }
  
  public void setRepeatMode(int paramInt) {
    this.mImpl.setRepeatMode(paramInt);
  }
  
  public void setSessionActivity(PendingIntent paramPendingIntent) {
    this.mImpl.setSessionActivity(paramPendingIntent);
  }
  
  public void setShuffleMode(int paramInt) {
    this.mImpl.setShuffleMode(paramInt);
  }
  
  public static abstract class Callback {
    final Object b;
    
    private CallbackHandler mCallbackHandler = null;
    
    private boolean mMediaPlayPauseKeyPending;
    
    private WeakReference<MediaSessionCompat.MediaSessionImpl> mSessionImpl;
    
    public Callback() {
      if (Build.VERSION.SDK_INT >= 24) {
        this.b = MediaSessionCompatApi24.createCallback(new StubApi24(this));
        return;
      } 
      if (Build.VERSION.SDK_INT >= 23) {
        this.b = MediaSessionCompatApi23.createCallback(new StubApi23(this));
        return;
      } 
      if (Build.VERSION.SDK_INT >= 21) {
        this.b = MediaSessionCompatApi21.createCallback(new StubApi21(this));
        return;
      } 
      this.b = null;
    }
    
    private void handleMediaPlayPauseKeySingleTapIfPending() {
      long l;
      boolean bool1;
      boolean bool2;
      if (!this.mMediaPlayPauseKeyPending)
        return; 
      this.mMediaPlayPauseKeyPending = false;
      this.mCallbackHandler.removeMessages(1);
      MediaSessionCompat.MediaSessionImpl mediaSessionImpl = this.mSessionImpl.get();
      if (mediaSessionImpl == null)
        return; 
      PlaybackStateCompat playbackStateCompat = mediaSessionImpl.getPlaybackState();
      if (playbackStateCompat == null) {
        l = 0L;
      } else {
        l = playbackStateCompat.getActions();
      } 
      if (playbackStateCompat != null && playbackStateCompat.getState() == 3) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      if ((0x204L & l) != 0L) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      int i = (l & 0x202L) cmp 0L;
      boolean bool3 = false;
      if (i != 0)
        bool3 = true; 
      if (bool1 && bool3) {
        onPause();
        return;
      } 
      if (!bool1 && bool2)
        onPlay(); 
    }
    
    private void setSessionImpl(MediaSessionCompat.MediaSessionImpl param1MediaSessionImpl, Handler param1Handler) {
      this.mSessionImpl = new WeakReference<MediaSessionCompat.MediaSessionImpl>(param1MediaSessionImpl);
      if (this.mCallbackHandler != null)
        this.mCallbackHandler.removeCallbacksAndMessages(null); 
      this.mCallbackHandler = new CallbackHandler(this, param1Handler.getLooper());
    }
    
    public void onAddQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {}
    
    public void onAddQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {}
    
    public void onCommand(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void onCustomAction(String param1String, Bundle param1Bundle) {}
    
    public void onFastForward() {}
    
    public boolean onMediaButtonEvent(Intent param1Intent) {
      MediaSessionCompat.MediaSessionImpl mediaSessionImpl = this.mSessionImpl.get();
      if (mediaSessionImpl != null) {
        if (this.mCallbackHandler == null)
          return false; 
        KeyEvent keyEvent = (KeyEvent)param1Intent.getParcelableExtra("android.intent.extra.KEY_EVENT");
        if (keyEvent != null) {
          if (keyEvent.getAction() != 0)
            return false; 
          int i = keyEvent.getKeyCode();
          if (i != 79 && i != 85) {
            handleMediaPlayPauseKeySingleTapIfPending();
            return false;
          } 
          if (keyEvent.getRepeatCount() > 0) {
            handleMediaPlayPauseKeySingleTapIfPending();
            return true;
          } 
          if (this.mMediaPlayPauseKeyPending) {
            long l;
            this.mCallbackHandler.removeMessages(1);
            this.mMediaPlayPauseKeyPending = false;
            PlaybackStateCompat playbackStateCompat = mediaSessionImpl.getPlaybackState();
            if (playbackStateCompat == null) {
              l = 0L;
            } else {
              l = playbackStateCompat.getActions();
            } 
            if ((l & 0x20L) != 0L) {
              onSkipToNext();
              return true;
            } 
          } else {
            this.mMediaPlayPauseKeyPending = true;
            this.mCallbackHandler.sendEmptyMessageDelayed(1, ViewConfiguration.getDoubleTapTimeout());
          } 
          return true;
        } 
        return false;
      } 
      return false;
    }
    
    public void onPause() {}
    
    public void onPlay() {}
    
    public void onPlayFromMediaId(String param1String, Bundle param1Bundle) {}
    
    public void onPlayFromSearch(String param1String, Bundle param1Bundle) {}
    
    public void onPlayFromUri(Uri param1Uri, Bundle param1Bundle) {}
    
    public void onPrepare() {}
    
    public void onPrepareFromMediaId(String param1String, Bundle param1Bundle) {}
    
    public void onPrepareFromSearch(String param1String, Bundle param1Bundle) {}
    
    public void onPrepareFromUri(Uri param1Uri, Bundle param1Bundle) {}
    
    public void onRemoveQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {}
    
    @Deprecated
    public void onRemoveQueueItemAt(int param1Int) {}
    
    public void onRewind() {}
    
    public void onSeekTo(long param1Long) {}
    
    public void onSetCaptioningEnabled(boolean param1Boolean) {}
    
    public void onSetRating(RatingCompat param1RatingCompat) {}
    
    public void onSetRating(RatingCompat param1RatingCompat, Bundle param1Bundle) {}
    
    public void onSetRepeatMode(int param1Int) {}
    
    public void onSetShuffleMode(int param1Int) {}
    
    public void onSkipToNext() {}
    
    public void onSkipToPrevious() {}
    
    public void onSkipToQueueItem(long param1Long) {}
    
    public void onStop() {}
    
    private class CallbackHandler extends Handler {
      private static final int MSG_MEDIA_PLAY_PAUSE_KEY_DOUBLE_TAP_TIMEOUT = 1;
      
      CallbackHandler(MediaSessionCompat.Callback this$0, Looper param2Looper) {
        super(param2Looper);
      }
      
      public void handleMessage(Message param2Message) {
        if (param2Message.what == 1)
          MediaSessionCompat.Callback.a(this.a); 
      }
    }
    
    @RequiresApi(21)
    private class StubApi21 implements MediaSessionCompatApi21.Callback {
      StubApi21(MediaSessionCompat.Callback this$0) {}
      
      public void onCommand(String param2String, Bundle param2Bundle, ResultReceiver param2ResultReceiver) {
        try {
          if (param2String.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER")) {
            MediaSessionCompat.MediaSessionImplApi21 mediaSessionImplApi21 = MediaSessionCompat.Callback.b(this.a).get();
            if (mediaSessionImplApi21 != null) {
              IBinder iBinder;
              Bundle bundle = new Bundle();
              IMediaSession iMediaSession = mediaSessionImplApi21.getSessionToken().getExtraBinder();
              if (iMediaSession == null) {
                iBinder = null;
              } else {
                iBinder = iMediaSession.asBinder();
              } 
              BundleCompat.putBinder(bundle, "android.support.v4.media.session.EXTRA_BINDER", iBinder);
              param2ResultReceiver.send(0, bundle);
              return;
            } 
          } else {
            if (param2String.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM")) {
              param2Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
              this.a.onAddQueueItem((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
              return;
            } 
            if (param2String.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT")) {
              param2Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
              this.a.onAddQueueItem((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"), param2Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX"));
              return;
            } 
            if (param2String.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
              param2Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
              this.a.onRemoveQueueItem((MediaDescriptionCompat)param2Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
              return;
            } 
            if (param2String.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
              MediaSessionCompat.MediaSessionImplApi21 mediaSessionImplApi21 = MediaSessionCompat.Callback.b(this.a).get();
              if (mediaSessionImplApi21 != null && MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21) != null) {
                int i = param2Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
                MediaSessionCompat.QueueItem queueItem = null;
                if (i >= 0) {
                  int j = MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21).size();
                  queueItem = null;
                  if (i < j)
                    queueItem = MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21).get(i); 
                } 
                if (queueItem != null) {
                  this.a.onRemoveQueueItem(queueItem.getDescription());
                  return;
                } 
              } 
            } else {
              this.a.onCommand(param2String, param2Bundle, param2ResultReceiver);
              return;
            } 
          } 
        } catch (BadParcelableException badParcelableException) {
          Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
        } 
      }
      
      public void onCustomAction(String param2String, Bundle param2Bundle) {
        if (param2String.equals("android.support.v4.media.session.action.PLAY_FROM_URI")) {
          Uri uri = (Uri)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
          Bundle bundle = (Bundle)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          this.a.onPlayFromUri(uri, bundle);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.PREPARE")) {
          this.a.onPrepare();
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
          String str = param2Bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
          Bundle bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          this.a.onPrepareFromMediaId(str, bundle);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
          String str = param2Bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
          Bundle bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          this.a.onPrepareFromSearch(str, bundle);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
          Uri uri = (Uri)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
          Bundle bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          this.a.onPrepareFromUri(uri, bundle);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
          boolean bool = param2Bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
          this.a.onSetCaptioningEnabled(bool);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
          int i = param2Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
          this.a.onSetRepeatMode(i);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
          int i = param2Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
          this.a.onSetShuffleMode(i);
          return;
        } 
        if (param2String.equals("android.support.v4.media.session.action.SET_RATING")) {
          param2Bundle.setClassLoader(RatingCompat.class.getClassLoader());
          RatingCompat ratingCompat = (RatingCompat)param2Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
          Bundle bundle = param2Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
          this.a.onSetRating(ratingCompat, bundle);
          return;
        } 
        this.a.onCustomAction(param2String, param2Bundle);
      }
      
      public void onFastForward() {
        this.a.onFastForward();
      }
      
      public boolean onMediaButtonEvent(Intent param2Intent) {
        return this.a.onMediaButtonEvent(param2Intent);
      }
      
      public void onPause() {
        this.a.onPause();
      }
      
      public void onPlay() {
        this.a.onPlay();
      }
      
      public void onPlayFromMediaId(String param2String, Bundle param2Bundle) {
        this.a.onPlayFromMediaId(param2String, param2Bundle);
      }
      
      public void onPlayFromSearch(String param2String, Bundle param2Bundle) {
        this.a.onPlayFromSearch(param2String, param2Bundle);
      }
      
      public void onRewind() {
        this.a.onRewind();
      }
      
      public void onSeekTo(long param2Long) {
        this.a.onSeekTo(param2Long);
      }
      
      public void onSetRating(Object param2Object) {
        this.a.onSetRating(RatingCompat.fromRating(param2Object));
      }
      
      public void onSetRating(Object param2Object, Bundle param2Bundle) {
        this.a.onSetRating(RatingCompat.fromRating(param2Object), param2Bundle);
      }
      
      public void onSkipToNext() {
        this.a.onSkipToNext();
      }
      
      public void onSkipToPrevious() {
        this.a.onSkipToPrevious();
      }
      
      public void onSkipToQueueItem(long param2Long) {
        this.a.onSkipToQueueItem(param2Long);
      }
      
      public void onStop() {
        this.a.onStop();
      }
    }
    
    @RequiresApi(23)
    private class StubApi23 extends StubApi21 implements MediaSessionCompatApi23.Callback {
      StubApi23(MediaSessionCompat.Callback this$0) {
        super(this$0);
      }
      
      public void onPlayFromUri(Uri param2Uri, Bundle param2Bundle) {
        this.b.onPlayFromUri(param2Uri, param2Bundle);
      }
    }
    
    @RequiresApi(24)
    private class StubApi24 extends StubApi23 implements MediaSessionCompatApi24.Callback {
      StubApi24(MediaSessionCompat.Callback this$0) {
        super(this$0);
      }
      
      public void onPrepare() {
        this.c.onPrepare();
      }
      
      public void onPrepareFromMediaId(String param2String, Bundle param2Bundle) {
        this.c.onPrepareFromMediaId(param2String, param2Bundle);
      }
      
      public void onPrepareFromSearch(String param2String, Bundle param2Bundle) {
        this.c.onPrepareFromSearch(param2String, param2Bundle);
      }
      
      public void onPrepareFromUri(Uri param2Uri, Bundle param2Bundle) {
        this.c.onPrepareFromUri(param2Uri, param2Bundle);
      }
    }
  }
  
  private class CallbackHandler extends Handler {
    private static final int MSG_MEDIA_PLAY_PAUSE_KEY_DOUBLE_TAP_TIMEOUT = 1;
    
    CallbackHandler(MediaSessionCompat this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    public void handleMessage(Message param1Message) {
      if (param1Message.what == 1)
        MediaSessionCompat.Callback.a(this.a); 
    }
  }
  
  @RequiresApi(21)
  private class StubApi21 implements MediaSessionCompatApi21.Callback {
    StubApi21(MediaSessionCompat this$0) {}
    
    public void onCommand(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {
      try {
        if (param1String.equals("android.support.v4.media.session.command.GET_EXTRA_BINDER")) {
          MediaSessionCompat.MediaSessionImplApi21 mediaSessionImplApi21 = MediaSessionCompat.Callback.b(this.a).get();
          if (mediaSessionImplApi21 != null) {
            IBinder iBinder;
            Bundle bundle = new Bundle();
            IMediaSession iMediaSession = mediaSessionImplApi21.getSessionToken().getExtraBinder();
            if (iMediaSession == null) {
              iBinder = null;
            } else {
              iBinder = iMediaSession.asBinder();
            } 
            BundleCompat.putBinder(bundle, "android.support.v4.media.session.EXTRA_BINDER", iBinder);
            param1ResultReceiver.send(0, bundle);
            return;
          } 
        } else {
          if (param1String.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM")) {
            param1Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
            this.a.onAddQueueItem((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
            return;
          } 
          if (param1String.equals("android.support.v4.media.session.command.ADD_QUEUE_ITEM_AT")) {
            param1Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
            this.a.onAddQueueItem((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"), param1Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX"));
            return;
          } 
          if (param1String.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM")) {
            param1Bundle.setClassLoader(MediaDescriptionCompat.class.getClassLoader());
            this.a.onRemoveQueueItem((MediaDescriptionCompat)param1Bundle.getParcelable("android.support.v4.media.session.command.ARGUMENT_MEDIA_DESCRIPTION"));
            return;
          } 
          if (param1String.equals("android.support.v4.media.session.command.REMOVE_QUEUE_ITEM_AT")) {
            MediaSessionCompat.MediaSessionImplApi21 mediaSessionImplApi21 = MediaSessionCompat.Callback.b(this.a).get();
            if (mediaSessionImplApi21 != null && MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21) != null) {
              int i = param1Bundle.getInt("android.support.v4.media.session.command.ARGUMENT_INDEX", -1);
              MediaSessionCompat.QueueItem queueItem = null;
              if (i >= 0) {
                int j = MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21).size();
                queueItem = null;
                if (i < j)
                  queueItem = MediaSessionCompat.MediaSessionImplApi21.a(mediaSessionImplApi21).get(i); 
              } 
              if (queueItem != null) {
                this.a.onRemoveQueueItem(queueItem.getDescription());
                return;
              } 
            } 
          } else {
            this.a.onCommand(param1String, param1Bundle, param1ResultReceiver);
            return;
          } 
        } 
      } catch (BadParcelableException badParcelableException) {
        Log.e("MediaSessionCompat", "Could not unparcel the extra data.");
      } 
    }
    
    public void onCustomAction(String param1String, Bundle param1Bundle) {
      if (param1String.equals("android.support.v4.media.session.action.PLAY_FROM_URI")) {
        Uri uri = (Uri)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
        Bundle bundle = (Bundle)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
        this.a.onPlayFromUri(uri, bundle);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.PREPARE")) {
        this.a.onPrepare();
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.PREPARE_FROM_MEDIA_ID")) {
        String str = param1Bundle.getString("android.support.v4.media.session.action.ARGUMENT_MEDIA_ID");
        Bundle bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
        this.a.onPrepareFromMediaId(str, bundle);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.PREPARE_FROM_SEARCH")) {
        String str = param1Bundle.getString("android.support.v4.media.session.action.ARGUMENT_QUERY");
        Bundle bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
        this.a.onPrepareFromSearch(str, bundle);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.PREPARE_FROM_URI")) {
        Uri uri = (Uri)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_URI");
        Bundle bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
        this.a.onPrepareFromUri(uri, bundle);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.SET_CAPTIONING_ENABLED")) {
        boolean bool = param1Bundle.getBoolean("android.support.v4.media.session.action.ARGUMENT_CAPTIONING_ENABLED");
        this.a.onSetCaptioningEnabled(bool);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.SET_REPEAT_MODE")) {
        int i = param1Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_REPEAT_MODE");
        this.a.onSetRepeatMode(i);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.SET_SHUFFLE_MODE")) {
        int i = param1Bundle.getInt("android.support.v4.media.session.action.ARGUMENT_SHUFFLE_MODE");
        this.a.onSetShuffleMode(i);
        return;
      } 
      if (param1String.equals("android.support.v4.media.session.action.SET_RATING")) {
        param1Bundle.setClassLoader(RatingCompat.class.getClassLoader());
        RatingCompat ratingCompat = (RatingCompat)param1Bundle.getParcelable("android.support.v4.media.session.action.ARGUMENT_RATING");
        Bundle bundle = param1Bundle.getBundle("android.support.v4.media.session.action.ARGUMENT_EXTRAS");
        this.a.onSetRating(ratingCompat, bundle);
        return;
      } 
      this.a.onCustomAction(param1String, param1Bundle);
    }
    
    public void onFastForward() {
      this.a.onFastForward();
    }
    
    public boolean onMediaButtonEvent(Intent param1Intent) {
      return this.a.onMediaButtonEvent(param1Intent);
    }
    
    public void onPause() {
      this.a.onPause();
    }
    
    public void onPlay() {
      this.a.onPlay();
    }
    
    public void onPlayFromMediaId(String param1String, Bundle param1Bundle) {
      this.a.onPlayFromMediaId(param1String, param1Bundle);
    }
    
    public void onPlayFromSearch(String param1String, Bundle param1Bundle) {
      this.a.onPlayFromSearch(param1String, param1Bundle);
    }
    
    public void onRewind() {
      this.a.onRewind();
    }
    
    public void onSeekTo(long param1Long) {
      this.a.onSeekTo(param1Long);
    }
    
    public void onSetRating(Object param1Object) {
      this.a.onSetRating(RatingCompat.fromRating(param1Object));
    }
    
    public void onSetRating(Object param1Object, Bundle param1Bundle) {
      this.a.onSetRating(RatingCompat.fromRating(param1Object), param1Bundle);
    }
    
    public void onSkipToNext() {
      this.a.onSkipToNext();
    }
    
    public void onSkipToPrevious() {
      this.a.onSkipToPrevious();
    }
    
    public void onSkipToQueueItem(long param1Long) {
      this.a.onSkipToQueueItem(param1Long);
    }
    
    public void onStop() {
      this.a.onStop();
    }
  }
  
  @RequiresApi(23)
  private class StubApi23 extends Callback.StubApi21 implements MediaSessionCompatApi23.Callback {
    StubApi23(MediaSessionCompat this$0) {
      super((MediaSessionCompat.Callback)this$0);
    }
    
    public void onPlayFromUri(Uri param1Uri, Bundle param1Bundle) {
      this.b.onPlayFromUri(param1Uri, param1Bundle);
    }
  }
  
  @RequiresApi(24)
  private class StubApi24 extends Callback.StubApi23 implements MediaSessionCompatApi24.Callback {
    StubApi24(MediaSessionCompat this$0) {
      super((MediaSessionCompat.Callback)this$0);
    }
    
    public void onPrepare() {
      this.c.onPrepare();
    }
    
    public void onPrepareFromMediaId(String param1String, Bundle param1Bundle) {
      this.c.onPrepareFromMediaId(param1String, param1Bundle);
    }
    
    public void onPrepareFromSearch(String param1String, Bundle param1Bundle) {
      this.c.onPrepareFromSearch(param1String, param1Bundle);
    }
    
    public void onPrepareFromUri(Uri param1Uri, Bundle param1Bundle) {
      this.c.onPrepareFromUri(param1Uri, param1Bundle);
    }
  }
  
  static interface MediaSessionImpl {
    String getCallingPackage();
    
    Object getMediaSession();
    
    PlaybackStateCompat getPlaybackState();
    
    Object getRemoteControlClient();
    
    MediaSessionCompat.Token getSessionToken();
    
    boolean isActive();
    
    void release();
    
    void sendSessionEvent(String param1String, Bundle param1Bundle);
    
    void setActive(boolean param1Boolean);
    
    void setCallback(MediaSessionCompat.Callback param1Callback, Handler param1Handler);
    
    void setCaptioningEnabled(boolean param1Boolean);
    
    void setExtras(Bundle param1Bundle);
    
    void setFlags(int param1Int);
    
    void setMediaButtonReceiver(PendingIntent param1PendingIntent);
    
    void setMetadata(MediaMetadataCompat param1MediaMetadataCompat);
    
    void setPlaybackState(PlaybackStateCompat param1PlaybackStateCompat);
    
    void setPlaybackToLocal(int param1Int);
    
    void setPlaybackToRemote(VolumeProviderCompat param1VolumeProviderCompat);
    
    void setQueue(List<MediaSessionCompat.QueueItem> param1List);
    
    void setQueueTitle(CharSequence param1CharSequence);
    
    void setRatingType(int param1Int);
    
    void setRepeatMode(int param1Int);
    
    void setSessionActivity(PendingIntent param1PendingIntent);
    
    void setShuffleMode(int param1Int);
  }
  
  @RequiresApi(18)
  static class MediaSessionImplApi18 extends MediaSessionImplBase {
    private static boolean sIsMbrPendingIntentSupported = true;
    
    MediaSessionImplApi18(Context param1Context, String param1String, ComponentName param1ComponentName, PendingIntent param1PendingIntent) {
      super(param1Context, param1String, param1ComponentName, param1PendingIntent);
    }
    
    int a(long param1Long) {
      int i = super.a(param1Long);
      if ((param1Long & 0x100L) != 0L)
        i |= 0x100; 
      return i;
    }
    
    void a(PendingIntent param1PendingIntent, ComponentName param1ComponentName) {
      if (sIsMbrPendingIntentSupported)
        try {
          this.c.registerMediaButtonEventReceiver(param1PendingIntent);
        } catch (NullPointerException nullPointerException) {
          Log.w("MediaSessionCompat", "Unable to register media button event receiver with PendingIntent, falling back to ComponentName.");
          sIsMbrPendingIntentSupported = false;
        }  
      if (!sIsMbrPendingIntentSupported)
        super.a(param1PendingIntent, param1ComponentName); 
    }
    
    void b(PendingIntent param1PendingIntent, ComponentName param1ComponentName) {
      if (sIsMbrPendingIntentSupported) {
        this.c.unregisterMediaButtonEventReceiver(param1PendingIntent);
        return;
      } 
      super.b(param1PendingIntent, param1ComponentName);
    }
    
    public void setCallback(MediaSessionCompat.Callback param1Callback, Handler param1Handler) {
      super.setCallback(param1Callback, param1Handler);
      if (param1Callback == null) {
        this.d.setPlaybackPositionUpdateListener(null);
        return;
      } 
      RemoteControlClient.OnPlaybackPositionUpdateListener onPlaybackPositionUpdateListener = new RemoteControlClient.OnPlaybackPositionUpdateListener(this) {
          public void onPlaybackPositionUpdate(long param2Long) {
            this.a.a(18, Long.valueOf(param2Long));
          }
        };
      this.d.setPlaybackPositionUpdateListener(onPlaybackPositionUpdateListener);
    }
    
    void setRccState(PlaybackStateCompat param1PlaybackStateCompat) {
      long l1 = param1PlaybackStateCompat.getPosition();
      float f = param1PlaybackStateCompat.getPlaybackSpeed();
      long l2 = param1PlaybackStateCompat.getLastPositionUpdateTime();
      long l3 = SystemClock.elapsedRealtime();
      if (param1PlaybackStateCompat.getState() == 3) {
        long l = 0L;
        if (l1 > l) {
          if (l2 > l) {
            l = l3 - l2;
            if (f > 0.0F && f != 1.0F)
              l = (long)(f * (float)l); 
          } 
          l1 += l;
        } 
      } 
      this.d.setPlaybackState(getRccStateFromState(param1PlaybackStateCompat.getState()), l1, f);
    }
  }
  
  class null implements RemoteControlClient.OnPlaybackPositionUpdateListener {
    null(MediaSessionCompat this$0) {}
    
    public void onPlaybackPositionUpdate(long param1Long) {
      this.a.a(18, Long.valueOf(param1Long));
    }
  }
  
  @RequiresApi(19)
  static class MediaSessionImplApi19 extends MediaSessionImplApi18 {
    MediaSessionImplApi19(Context param1Context, String param1String, ComponentName param1ComponentName, PendingIntent param1PendingIntent) {
      super(param1Context, param1String, param1ComponentName, param1PendingIntent);
    }
    
    int a(long param1Long) {
      int i = super.a(param1Long);
      if ((param1Long & 0x80L) != 0L)
        i |= 0x200; 
      return i;
    }
    
    RemoteControlClient.MetadataEditor a(Bundle param1Bundle) {
      long l;
      RemoteControlClient.MetadataEditor metadataEditor = super.a(param1Bundle);
      if (this.l == null) {
        l = 0L;
      } else {
        l = this.l.getActions();
      } 
      if ((l & 0x80L) != 0L)
        metadataEditor.addEditableKey(268435457); 
      if (param1Bundle == null)
        return metadataEditor; 
      if (param1Bundle.containsKey("android.media.metadata.YEAR"))
        metadataEditor.putLong(8, param1Bundle.getLong("android.media.metadata.YEAR")); 
      if (param1Bundle.containsKey("android.media.metadata.RATING"))
        metadataEditor.putObject(101, param1Bundle.getParcelable("android.media.metadata.RATING")); 
      if (param1Bundle.containsKey("android.media.metadata.USER_RATING"))
        metadataEditor.putObject(268435457, param1Bundle.getParcelable("android.media.metadata.USER_RATING")); 
      return metadataEditor;
    }
    
    public void setCallback(MediaSessionCompat.Callback param1Callback, Handler param1Handler) {
      super.setCallback(param1Callback, param1Handler);
      if (param1Callback == null) {
        this.d.setMetadataUpdateListener(null);
        return;
      } 
      RemoteControlClient.OnMetadataUpdateListener onMetadataUpdateListener = new RemoteControlClient.OnMetadataUpdateListener(this) {
          public void onMetadataUpdate(int param2Int, Object param2Object) {
            if (param2Int == 268435457 && param2Object instanceof android.media.Rating)
              this.a.a(19, RatingCompat.fromRating(param2Object)); 
          }
        };
      this.d.setMetadataUpdateListener(onMetadataUpdateListener);
    }
  }
  
  class null implements RemoteControlClient.OnMetadataUpdateListener {
    null(MediaSessionCompat this$0) {}
    
    public void onMetadataUpdate(int param1Int, Object param1Object) {
      if (param1Int == 268435457 && param1Object instanceof android.media.Rating)
        this.a.a(19, RatingCompat.fromRating(param1Object)); 
    }
  }
  
  @RequiresApi(21)
  static class MediaSessionImplApi21 implements MediaSessionImpl {
    int a;
    
    boolean b;
    
    int c;
    
    int d;
    
    private boolean mDestroyed = false;
    
    private final RemoteCallbackList<IMediaControllerCallback> mExtraControllerCallbacks = new RemoteCallbackList();
    
    private MediaMetadataCompat mMetadata;
    
    private PlaybackStateCompat mPlaybackState;
    
    private List<MediaSessionCompat.QueueItem> mQueue;
    
    private final Object mSessionObj;
    
    private final MediaSessionCompat.Token mToken;
    
    public MediaSessionImplApi21(Context param1Context, String param1String) {
      this.mSessionObj = MediaSessionCompatApi21.createSession(param1Context, param1String);
      this.mToken = new MediaSessionCompat.Token(MediaSessionCompatApi21.getSessionToken(this.mSessionObj), new ExtraSession(this));
    }
    
    public MediaSessionImplApi21(Object param1Object) {
      this.mSessionObj = MediaSessionCompatApi21.verifySession(param1Object);
      this.mToken = new MediaSessionCompat.Token(MediaSessionCompatApi21.getSessionToken(this.mSessionObj), new ExtraSession(this));
    }
    
    public String getCallingPackage() {
      return (Build.VERSION.SDK_INT < 24) ? null : MediaSessionCompatApi24.getCallingPackage(this.mSessionObj);
    }
    
    public Object getMediaSession() {
      return this.mSessionObj;
    }
    
    public PlaybackStateCompat getPlaybackState() {
      return this.mPlaybackState;
    }
    
    public Object getRemoteControlClient() {
      return null;
    }
    
    public MediaSessionCompat.Token getSessionToken() {
      return this.mToken;
    }
    
    public boolean isActive() {
      return MediaSessionCompatApi21.isActive(this.mSessionObj);
    }
    
    public void release() {
      this.mDestroyed = true;
      MediaSessionCompatApi21.release(this.mSessionObj);
    }
    
    public void sendSessionEvent(String param1String, Bundle param1Bundle) {
      if (Build.VERSION.SDK_INT < 23) {
        for (int i = -1 + this.mExtraControllerCallbacks.beginBroadcast(); i >= 0; i--) {
          IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.mExtraControllerCallbacks.getBroadcastItem(i);
          try {
            iMediaControllerCallback.onEvent(param1String, param1Bundle);
          } catch (RemoteException remoteException) {}
        } 
        this.mExtraControllerCallbacks.finishBroadcast();
      } 
      MediaSessionCompatApi21.sendSessionEvent(this.mSessionObj, param1String, param1Bundle);
    }
    
    public void setActive(boolean param1Boolean) {
      MediaSessionCompatApi21.setActive(this.mSessionObj, param1Boolean);
    }
    
    public void setCallback(MediaSessionCompat.Callback param1Callback, Handler param1Handler) {
      Object object2;
      Object object1 = this.mSessionObj;
      if (param1Callback == null) {
        object2 = null;
      } else {
        object2 = param1Callback.b;
      } 
      MediaSessionCompatApi21.setCallback(object1, object2, param1Handler);
      if (param1Callback != null)
        MediaSessionCompat.Callback.a(param1Callback, this, param1Handler); 
    }
    
    public void setCaptioningEnabled(boolean param1Boolean) {
      if (this.b != param1Boolean) {
        this.b = param1Boolean;
        for (int i = -1 + this.mExtraControllerCallbacks.beginBroadcast(); i >= 0; i--) {
          IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.mExtraControllerCallbacks.getBroadcastItem(i);
          try {
            iMediaControllerCallback.onCaptioningEnabledChanged(param1Boolean);
          } catch (RemoteException remoteException) {}
        } 
        this.mExtraControllerCallbacks.finishBroadcast();
      } 
    }
    
    public void setExtras(Bundle param1Bundle) {
      MediaSessionCompatApi21.setExtras(this.mSessionObj, param1Bundle);
    }
    
    public void setFlags(int param1Int) {
      MediaSessionCompatApi21.setFlags(this.mSessionObj, param1Int);
    }
    
    public void setMediaButtonReceiver(PendingIntent param1PendingIntent) {
      MediaSessionCompatApi21.setMediaButtonReceiver(this.mSessionObj, param1PendingIntent);
    }
    
    public void setMetadata(MediaMetadataCompat param1MediaMetadataCompat) {
      Object object2;
      this.mMetadata = param1MediaMetadataCompat;
      Object object1 = this.mSessionObj;
      if (param1MediaMetadataCompat == null) {
        object2 = null;
      } else {
        object2 = param1MediaMetadataCompat.getMediaMetadata();
      } 
      MediaSessionCompatApi21.setMetadata(object1, object2);
    }
    
    public void setPlaybackState(PlaybackStateCompat param1PlaybackStateCompat) {
      Object object2;
      this.mPlaybackState = param1PlaybackStateCompat;
      for (int i = -1 + this.mExtraControllerCallbacks.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.mExtraControllerCallbacks.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onPlaybackStateChanged(param1PlaybackStateCompat);
        } catch (RemoteException remoteException) {}
      } 
      this.mExtraControllerCallbacks.finishBroadcast();
      Object object1 = this.mSessionObj;
      if (param1PlaybackStateCompat == null) {
        object2 = null;
      } else {
        object2 = param1PlaybackStateCompat.getPlaybackState();
      } 
      MediaSessionCompatApi21.setPlaybackState(object1, object2);
    }
    
    public void setPlaybackToLocal(int param1Int) {
      MediaSessionCompatApi21.setPlaybackToLocal(this.mSessionObj, param1Int);
    }
    
    public void setPlaybackToRemote(VolumeProviderCompat param1VolumeProviderCompat) {
      MediaSessionCompatApi21.setPlaybackToRemote(this.mSessionObj, param1VolumeProviderCompat.getVolumeProvider());
    }
    
    public void setQueue(List<MediaSessionCompat.QueueItem> param1List) {
      List list;
      this.mQueue = param1List;
      if (param1List != null) {
        list = new ArrayList();
        Iterator<MediaSessionCompat.QueueItem> iterator = param1List.iterator();
        while (iterator.hasNext())
          list.add(((MediaSessionCompat.QueueItem)iterator.next()).getQueueItem()); 
      } else {
        list = null;
      } 
      MediaSessionCompatApi21.setQueue(this.mSessionObj, list);
    }
    
    public void setQueueTitle(CharSequence param1CharSequence) {
      MediaSessionCompatApi21.setQueueTitle(this.mSessionObj, param1CharSequence);
    }
    
    public void setRatingType(int param1Int) {
      if (Build.VERSION.SDK_INT < 22) {
        this.a = param1Int;
        return;
      } 
      MediaSessionCompatApi22.setRatingType(this.mSessionObj, param1Int);
    }
    
    public void setRepeatMode(int param1Int) {
      if (this.c != param1Int) {
        this.c = param1Int;
        for (int i = -1 + this.mExtraControllerCallbacks.beginBroadcast(); i >= 0; i--) {
          IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.mExtraControllerCallbacks.getBroadcastItem(i);
          try {
            iMediaControllerCallback.onRepeatModeChanged(param1Int);
          } catch (RemoteException remoteException) {}
        } 
        this.mExtraControllerCallbacks.finishBroadcast();
      } 
    }
    
    public void setSessionActivity(PendingIntent param1PendingIntent) {
      MediaSessionCompatApi21.setSessionActivity(this.mSessionObj, param1PendingIntent);
    }
    
    public void setShuffleMode(int param1Int) {
      if (this.d != param1Int) {
        this.d = param1Int;
        for (int i = -1 + this.mExtraControllerCallbacks.beginBroadcast(); i >= 0; i--) {
          IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.mExtraControllerCallbacks.getBroadcastItem(i);
          try {
            iMediaControllerCallback.onShuffleModeChanged(param1Int);
          } catch (RemoteException remoteException) {}
        } 
        this.mExtraControllerCallbacks.finishBroadcast();
      } 
    }
    
    class ExtraSession extends IMediaSession.Stub {
      ExtraSession(MediaSessionCompat.MediaSessionImplApi21 this$0) {}
      
      public void addQueueItem(MediaDescriptionCompat param2MediaDescriptionCompat) {
        throw new AssertionError();
      }
      
      public void addQueueItemAt(MediaDescriptionCompat param2MediaDescriptionCompat, int param2Int) {
        throw new AssertionError();
      }
      
      public void adjustVolume(int param2Int1, int param2Int2, String param2String) {
        throw new AssertionError();
      }
      
      public void fastForward() {
        throw new AssertionError();
      }
      
      public Bundle getExtras() {
        throw new AssertionError();
      }
      
      public long getFlags() {
        throw new AssertionError();
      }
      
      public PendingIntent getLaunchPendingIntent() {
        throw new AssertionError();
      }
      
      public MediaMetadataCompat getMetadata() {
        throw new AssertionError();
      }
      
      public String getPackageName() {
        throw new AssertionError();
      }
      
      public PlaybackStateCompat getPlaybackState() {
        return MediaSessionCompat.a(MediaSessionCompat.MediaSessionImplApi21.d(this.a), MediaSessionCompat.MediaSessionImplApi21.e(this.a));
      }
      
      public List<MediaSessionCompat.QueueItem> getQueue() {
        return null;
      }
      
      public CharSequence getQueueTitle() {
        throw new AssertionError();
      }
      
      public int getRatingType() {
        return this.a.a;
      }
      
      public int getRepeatMode() {
        return this.a.c;
      }
      
      public int getShuffleMode() {
        return this.a.d;
      }
      
      public String getTag() {
        throw new AssertionError();
      }
      
      public ParcelableVolumeInfo getVolumeAttributes() {
        throw new AssertionError();
      }
      
      public boolean isCaptioningEnabled() {
        return this.a.b;
      }
      
      public boolean isShuffleModeEnabledRemoved() {
        return false;
      }
      
      public boolean isTransportControlEnabled() {
        throw new AssertionError();
      }
      
      public void next() {
        throw new AssertionError();
      }
      
      public void pause() {
        throw new AssertionError();
      }
      
      public void play() {
        throw new AssertionError();
      }
      
      public void playFromMediaId(String param2String, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void playFromSearch(String param2String, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void playFromUri(Uri param2Uri, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void prepare() {
        throw new AssertionError();
      }
      
      public void prepareFromMediaId(String param2String, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void prepareFromSearch(String param2String, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void prepareFromUri(Uri param2Uri, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void previous() {
        throw new AssertionError();
      }
      
      public void rate(RatingCompat param2RatingCompat) {
        throw new AssertionError();
      }
      
      public void rateWithExtras(RatingCompat param2RatingCompat, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public void registerCallbackListener(IMediaControllerCallback param2IMediaControllerCallback) {
        if (!MediaSessionCompat.MediaSessionImplApi21.b(this.a))
          MediaSessionCompat.MediaSessionImplApi21.c(this.a).register(param2IMediaControllerCallback); 
      }
      
      public void removeQueueItem(MediaDescriptionCompat param2MediaDescriptionCompat) {
        throw new AssertionError();
      }
      
      public void removeQueueItemAt(int param2Int) {
        throw new AssertionError();
      }
      
      public void rewind() {
        throw new AssertionError();
      }
      
      public void seekTo(long param2Long) {
        throw new AssertionError();
      }
      
      public void sendCommand(String param2String, Bundle param2Bundle, MediaSessionCompat.ResultReceiverWrapper param2ResultReceiverWrapper) {
        throw new AssertionError();
      }
      
      public void sendCustomAction(String param2String, Bundle param2Bundle) {
        throw new AssertionError();
      }
      
      public boolean sendMediaButton(KeyEvent param2KeyEvent) {
        throw new AssertionError();
      }
      
      public void setCaptioningEnabled(boolean param2Boolean) {
        throw new AssertionError();
      }
      
      public void setRepeatMode(int param2Int) {
        throw new AssertionError();
      }
      
      public void setShuffleMode(int param2Int) {
        throw new AssertionError();
      }
      
      public void setShuffleModeEnabledRemoved(boolean param2Boolean) {}
      
      public void setVolumeTo(int param2Int1, int param2Int2, String param2String) {
        throw new AssertionError();
      }
      
      public void skipToQueueItem(long param2Long) {
        throw new AssertionError();
      }
      
      public void stop() {
        throw new AssertionError();
      }
      
      public void unregisterCallbackListener(IMediaControllerCallback param2IMediaControllerCallback) {
        MediaSessionCompat.MediaSessionImplApi21.c(this.a).unregister(param2IMediaControllerCallback);
      }
    }
  }
  
  class ExtraSession extends IMediaSession.Stub {
    ExtraSession(MediaSessionCompat this$0) {}
    
    public void addQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {
      throw new AssertionError();
    }
    
    public void addQueueItemAt(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {
      throw new AssertionError();
    }
    
    public void adjustVolume(int param1Int1, int param1Int2, String param1String) {
      throw new AssertionError();
    }
    
    public void fastForward() {
      throw new AssertionError();
    }
    
    public Bundle getExtras() {
      throw new AssertionError();
    }
    
    public long getFlags() {
      throw new AssertionError();
    }
    
    public PendingIntent getLaunchPendingIntent() {
      throw new AssertionError();
    }
    
    public MediaMetadataCompat getMetadata() {
      throw new AssertionError();
    }
    
    public String getPackageName() {
      throw new AssertionError();
    }
    
    public PlaybackStateCompat getPlaybackState() {
      return MediaSessionCompat.a(MediaSessionCompat.MediaSessionImplApi21.d(this.a), MediaSessionCompat.MediaSessionImplApi21.e(this.a));
    }
    
    public List<MediaSessionCompat.QueueItem> getQueue() {
      return null;
    }
    
    public CharSequence getQueueTitle() {
      throw new AssertionError();
    }
    
    public int getRatingType() {
      return this.a.a;
    }
    
    public int getRepeatMode() {
      return this.a.c;
    }
    
    public int getShuffleMode() {
      return this.a.d;
    }
    
    public String getTag() {
      throw new AssertionError();
    }
    
    public ParcelableVolumeInfo getVolumeAttributes() {
      throw new AssertionError();
    }
    
    public boolean isCaptioningEnabled() {
      return this.a.b;
    }
    
    public boolean isShuffleModeEnabledRemoved() {
      return false;
    }
    
    public boolean isTransportControlEnabled() {
      throw new AssertionError();
    }
    
    public void next() {
      throw new AssertionError();
    }
    
    public void pause() {
      throw new AssertionError();
    }
    
    public void play() {
      throw new AssertionError();
    }
    
    public void playFromMediaId(String param1String, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void playFromSearch(String param1String, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void playFromUri(Uri param1Uri, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void prepare() {
      throw new AssertionError();
    }
    
    public void prepareFromMediaId(String param1String, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void prepareFromSearch(String param1String, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void prepareFromUri(Uri param1Uri, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void previous() {
      throw new AssertionError();
    }
    
    public void rate(RatingCompat param1RatingCompat) {
      throw new AssertionError();
    }
    
    public void rateWithExtras(RatingCompat param1RatingCompat, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public void registerCallbackListener(IMediaControllerCallback param1IMediaControllerCallback) {
      if (!MediaSessionCompat.MediaSessionImplApi21.b(this.a))
        MediaSessionCompat.MediaSessionImplApi21.c(this.a).register(param1IMediaControllerCallback); 
    }
    
    public void removeQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {
      throw new AssertionError();
    }
    
    public void removeQueueItemAt(int param1Int) {
      throw new AssertionError();
    }
    
    public void rewind() {
      throw new AssertionError();
    }
    
    public void seekTo(long param1Long) {
      throw new AssertionError();
    }
    
    public void sendCommand(String param1String, Bundle param1Bundle, MediaSessionCompat.ResultReceiverWrapper param1ResultReceiverWrapper) {
      throw new AssertionError();
    }
    
    public void sendCustomAction(String param1String, Bundle param1Bundle) {
      throw new AssertionError();
    }
    
    public boolean sendMediaButton(KeyEvent param1KeyEvent) {
      throw new AssertionError();
    }
    
    public void setCaptioningEnabled(boolean param1Boolean) {
      throw new AssertionError();
    }
    
    public void setRepeatMode(int param1Int) {
      throw new AssertionError();
    }
    
    public void setShuffleMode(int param1Int) {
      throw new AssertionError();
    }
    
    public void setShuffleModeEnabledRemoved(boolean param1Boolean) {}
    
    public void setVolumeTo(int param1Int1, int param1Int2, String param1String) {
      throw new AssertionError();
    }
    
    public void skipToQueueItem(long param1Long) {
      throw new AssertionError();
    }
    
    public void stop() {
      throw new AssertionError();
    }
    
    public void unregisterCallbackListener(IMediaControllerCallback param1IMediaControllerCallback) {
      MediaSessionCompat.MediaSessionImplApi21.c(this.a).unregister(param1IMediaControllerCallback);
    }
  }
  
  static class MediaSessionImplBase implements MediaSessionImpl {
    final String a;
    
    final String b;
    
    final AudioManager c;
    
    final RemoteControlClient d;
    
    final Object e = new Object();
    
    final RemoteCallbackList<IMediaControllerCallback> f = new RemoteCallbackList();
    
    boolean g = false;
    
    boolean h = false;
    
    volatile MediaSessionCompat.Callback i;
    
    int j;
    
    MediaMetadataCompat k;
    
    PlaybackStateCompat l;
    
    PendingIntent m;
    
    private final Context mContext;
    
    private MessageHandler mHandler;
    
    private boolean mIsMbrRegistered = false;
    
    private boolean mIsRccRegistered = false;
    
    private final ComponentName mMediaButtonReceiverComponentName;
    
    private final PendingIntent mMediaButtonReceiverIntent;
    
    private final MediaSessionStub mStub;
    
    private final MediaSessionCompat.Token mToken;
    
    private VolumeProviderCompat.Callback mVolumeCallback = new VolumeProviderCompat.Callback(this) {
        public void onVolumeChanged(VolumeProviderCompat param2VolumeProviderCompat) {
          if (this.a.w != param2VolumeProviderCompat)
            return; 
          ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo(this.a.u, this.a.v, param2VolumeProviderCompat.getVolumeControl(), param2VolumeProviderCompat.getMaxVolume(), param2VolumeProviderCompat.getCurrentVolume());
          this.a.a(parcelableVolumeInfo);
        }
      };
    
    List<MediaSessionCompat.QueueItem> n;
    
    CharSequence o;
    
    int p;
    
    boolean q;
    
    int r;
    
    int s;
    
    Bundle t;
    
    int u;
    
    int v;
    
    VolumeProviderCompat w;
    
    public MediaSessionImplBase(Context param1Context, String param1String, ComponentName param1ComponentName, PendingIntent param1PendingIntent) {
      if (param1ComponentName != null) {
        this.mContext = param1Context;
        this.a = param1Context.getPackageName();
        this.c = (AudioManager)param1Context.getSystemService("audio");
        this.b = param1String;
        this.mMediaButtonReceiverComponentName = param1ComponentName;
        this.mMediaButtonReceiverIntent = param1PendingIntent;
        this.mStub = new MediaSessionStub(this);
        this.mToken = new MediaSessionCompat.Token(this.mStub);
        this.p = 0;
        this.u = 1;
        this.v = 3;
        this.d = new RemoteControlClient(param1PendingIntent);
        return;
      } 
      throw new IllegalArgumentException("MediaButtonReceiver component may not be null.");
    }
    
    private void sendCaptioningEnabled(boolean param1Boolean) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onCaptioningEnabledChanged(param1Boolean);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendEvent(String param1String, Bundle param1Bundle) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onEvent(param1String, param1Bundle);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendExtras(Bundle param1Bundle) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onExtrasChanged(param1Bundle);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendMetadata(MediaMetadataCompat param1MediaMetadataCompat) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onMetadataChanged(param1MediaMetadataCompat);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendQueue(List<MediaSessionCompat.QueueItem> param1List) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onQueueChanged(param1List);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendQueueTitle(CharSequence param1CharSequence) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onQueueTitleChanged(param1CharSequence);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendRepeatMode(int param1Int) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onRepeatModeChanged(param1Int);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendSessionDestroyed() {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onSessionDestroyed();
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
      this.f.kill();
    }
    
    private void sendShuffleMode(int param1Int) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onShuffleModeChanged(param1Int);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    private void sendState(PlaybackStateCompat param1PlaybackStateCompat) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onPlaybackStateChanged(param1PlaybackStateCompat);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    int a(long param1Long) {
      int i;
      if ((0x1L & param1Long) != 0L) {
        i = 32;
      } else {
        i = 0;
      } 
      if ((0x2L & param1Long) != 0L)
        i |= 0x10; 
      if ((0x4L & param1Long) != 0L)
        i |= 0x4; 
      if ((0x8L & param1Long) != 0L)
        i |= 0x2; 
      if ((0x10L & param1Long) != 0L)
        i |= 0x1; 
      if ((0x20L & param1Long) != 0L)
        i |= 0x80; 
      if ((0x40L & param1Long) != 0L)
        i |= 0x40; 
      if ((param1Long & 0x200L) != 0L)
        i |= 0x8; 
      return i;
    }
    
    RemoteControlClient.MetadataEditor a(Bundle param1Bundle) {
      RemoteControlClient.MetadataEditor metadataEditor = this.d.editMetadata(true);
      if (param1Bundle == null)
        return metadataEditor; 
      if (param1Bundle.containsKey("android.media.metadata.ART")) {
        Bitmap bitmap = (Bitmap)param1Bundle.getParcelable("android.media.metadata.ART");
        if (bitmap != null)
          bitmap = bitmap.copy(bitmap.getConfig(), false); 
        metadataEditor.putBitmap(100, bitmap);
      } else if (param1Bundle.containsKey("android.media.metadata.ALBUM_ART")) {
        Bitmap bitmap = (Bitmap)param1Bundle.getParcelable("android.media.metadata.ALBUM_ART");
        if (bitmap != null)
          bitmap = bitmap.copy(bitmap.getConfig(), false); 
        metadataEditor.putBitmap(100, bitmap);
      } 
      if (param1Bundle.containsKey("android.media.metadata.ALBUM"))
        metadataEditor.putString(1, param1Bundle.getString("android.media.metadata.ALBUM")); 
      if (param1Bundle.containsKey("android.media.metadata.ALBUM_ARTIST"))
        metadataEditor.putString(13, param1Bundle.getString("android.media.metadata.ALBUM_ARTIST")); 
      if (param1Bundle.containsKey("android.media.metadata.ARTIST"))
        metadataEditor.putString(2, param1Bundle.getString("android.media.metadata.ARTIST")); 
      if (param1Bundle.containsKey("android.media.metadata.AUTHOR"))
        metadataEditor.putString(3, param1Bundle.getString("android.media.metadata.AUTHOR")); 
      if (param1Bundle.containsKey("android.media.metadata.COMPILATION"))
        metadataEditor.putString(15, param1Bundle.getString("android.media.metadata.COMPILATION")); 
      if (param1Bundle.containsKey("android.media.metadata.COMPOSER"))
        metadataEditor.putString(4, param1Bundle.getString("android.media.metadata.COMPOSER")); 
      if (param1Bundle.containsKey("android.media.metadata.DATE"))
        metadataEditor.putString(5, param1Bundle.getString("android.media.metadata.DATE")); 
      if (param1Bundle.containsKey("android.media.metadata.DISC_NUMBER"))
        metadataEditor.putLong(14, param1Bundle.getLong("android.media.metadata.DISC_NUMBER")); 
      if (param1Bundle.containsKey("android.media.metadata.DURATION"))
        metadataEditor.putLong(9, param1Bundle.getLong("android.media.metadata.DURATION")); 
      if (param1Bundle.containsKey("android.media.metadata.GENRE"))
        metadataEditor.putString(6, param1Bundle.getString("android.media.metadata.GENRE")); 
      if (param1Bundle.containsKey("android.media.metadata.TITLE"))
        metadataEditor.putString(7, param1Bundle.getString("android.media.metadata.TITLE")); 
      if (param1Bundle.containsKey("android.media.metadata.TRACK_NUMBER"))
        metadataEditor.putLong(0, param1Bundle.getLong("android.media.metadata.TRACK_NUMBER")); 
      if (param1Bundle.containsKey("android.media.metadata.WRITER"))
        metadataEditor.putString(11, param1Bundle.getString("android.media.metadata.WRITER")); 
      return metadataEditor;
    }
    
    void a(int param1Int) {
      a(param1Int, (Object)null);
    }
    
    void a(int param1Int1, int param1Int2) {
      a(param1Int1, (Object)null, param1Int2);
    }
    
    void a(int param1Int, Object param1Object) {
      a(param1Int, param1Object, (Bundle)null);
    }
    
    void a(int param1Int1, Object param1Object, int param1Int2) {
      synchronized (this.e) {
        if (this.mHandler != null)
          this.mHandler.post(param1Int1, param1Object, param1Int2); 
        return;
      } 
    }
    
    void a(int param1Int, Object param1Object, Bundle param1Bundle) {
      synchronized (this.e) {
        if (this.mHandler != null)
          this.mHandler.post(param1Int, param1Object, param1Bundle); 
        return;
      } 
    }
    
    void a(PendingIntent param1PendingIntent, ComponentName param1ComponentName) {
      this.c.registerMediaButtonEventReceiver(param1ComponentName);
    }
    
    void a(ParcelableVolumeInfo param1ParcelableVolumeInfo) {
      for (int i = -1 + this.f.beginBroadcast(); i >= 0; i--) {
        IMediaControllerCallback iMediaControllerCallback = (IMediaControllerCallback)this.f.getBroadcastItem(i);
        try {
          iMediaControllerCallback.onVolumeInfoChanged(param1ParcelableVolumeInfo);
        } catch (RemoteException remoteException) {}
      } 
      this.f.finishBroadcast();
    }
    
    boolean a() {
      if (this.h) {
        if (!this.mIsMbrRegistered && (0x1 & this.j) != 0) {
          a(this.mMediaButtonReceiverIntent, this.mMediaButtonReceiverComponentName);
          this.mIsMbrRegistered = true;
        } else if (this.mIsMbrRegistered && (0x1 & this.j) == 0) {
          b(this.mMediaButtonReceiverIntent, this.mMediaButtonReceiverComponentName);
          this.mIsMbrRegistered = false;
        } 
        if (!this.mIsRccRegistered && (0x2 & this.j) != 0) {
          this.c.registerRemoteControlClient(this.d);
          this.mIsRccRegistered = true;
          return true;
        } 
        if (this.mIsRccRegistered && (0x2 & this.j) == 0) {
          this.d.setPlaybackState(0);
          this.c.unregisterRemoteControlClient(this.d);
          this.mIsRccRegistered = false;
        } 
      } else {
        if (this.mIsMbrRegistered) {
          b(this.mMediaButtonReceiverIntent, this.mMediaButtonReceiverComponentName);
          this.mIsMbrRegistered = false;
        } 
        if (this.mIsRccRegistered) {
          this.d.setPlaybackState(0);
          this.c.unregisterRemoteControlClient(this.d);
          this.mIsRccRegistered = false;
        } 
      } 
      return false;
    }
    
    void b(int param1Int1, int param1Int2) {
      if (this.u == 2) {
        if (this.w != null) {
          this.w.onAdjustVolume(param1Int1);
          return;
        } 
      } else {
        this.c.adjustStreamVolume(this.v, param1Int1, param1Int2);
      } 
    }
    
    void b(PendingIntent param1PendingIntent, ComponentName param1ComponentName) {
      this.c.unregisterMediaButtonEventReceiver(param1ComponentName);
    }
    
    public String getCallingPackage() {
      return null;
    }
    
    public Object getMediaSession() {
      return null;
    }
    
    public PlaybackStateCompat getPlaybackState() {
      synchronized (this.e) {
        return this.l;
      } 
    }
    
    int getRccStateFromState(int param1Int) {
      switch (param1Int) {
        default:
          return -1;
        case 10:
        case 11:
          return 6;
        case 9:
          return 7;
        case 7:
          return 9;
        case 6:
        case 8:
          return 8;
        case 5:
          return 5;
        case 4:
          return 4;
        case 3:
          return 3;
        case 2:
          return 2;
        case 1:
          return 1;
        case 0:
          break;
      } 
      return 0;
    }
    
    public Object getRemoteControlClient() {
      return null;
    }
    
    public MediaSessionCompat.Token getSessionToken() {
      return this.mToken;
    }
    
    public boolean isActive() {
      return this.h;
    }
    
    public void release() {
      this.h = false;
      this.g = true;
      a();
      sendSessionDestroyed();
    }
    
    public void sendSessionEvent(String param1String, Bundle param1Bundle) {
      sendEvent(param1String, param1Bundle);
    }
    
    public void setActive(boolean param1Boolean) {
      if (param1Boolean == this.h)
        return; 
      this.h = param1Boolean;
      if (a()) {
        setMetadata(this.k);
        setPlaybackState(this.l);
      } 
    }
    
    public void setCallback(MediaSessionCompat.Callback param1Callback, Handler param1Handler) {
      this.i = param1Callback;
      if (param1Callback != null) {
        if (param1Handler == null)
          param1Handler = new Handler(); 
        synchronized (this.e) {
          if (this.mHandler != null)
            this.mHandler.removeCallbacksAndMessages(null); 
          this.mHandler = new MessageHandler(this, param1Handler.getLooper());
          MediaSessionCompat.Callback.a(this.i, this, param1Handler);
          return;
        } 
      } 
    }
    
    public void setCaptioningEnabled(boolean param1Boolean) {
      if (this.q != param1Boolean) {
        this.q = param1Boolean;
        sendCaptioningEnabled(param1Boolean);
      } 
    }
    
    public void setExtras(Bundle param1Bundle) {
      this.t = param1Bundle;
      sendExtras(param1Bundle);
    }
    
    public void setFlags(int param1Int) {
      synchronized (this.e) {
        this.j = param1Int;
        a();
        return;
      } 
    }
    
    public void setMediaButtonReceiver(PendingIntent param1PendingIntent) {}
    
    public void setMetadata(MediaMetadataCompat param1MediaMetadataCompat) {
      if (param1MediaMetadataCompat != null)
        param1MediaMetadataCompat = (new MediaMetadataCompat.Builder(param1MediaMetadataCompat, MediaSessionCompat.a)).build(); 
      synchronized (this.e) {
        Bundle bundle;
        this.k = param1MediaMetadataCompat;
        sendMetadata(param1MediaMetadataCompat);
        if (!this.h)
          return; 
        if (param1MediaMetadataCompat == null) {
          bundle = null;
        } else {
          bundle = param1MediaMetadataCompat.getBundle();
        } 
        a(bundle).apply();
        return;
      } 
    }
    
    public void setPlaybackState(PlaybackStateCompat param1PlaybackStateCompat) {
      synchronized (this.e) {
        this.l = param1PlaybackStateCompat;
        sendState(param1PlaybackStateCompat);
        if (!this.h)
          return; 
        if (param1PlaybackStateCompat == null) {
          this.d.setPlaybackState(0);
          this.d.setTransportControlFlags(0);
          return;
        } 
        setRccState(param1PlaybackStateCompat);
        this.d.setTransportControlFlags(a(param1PlaybackStateCompat.getActions()));
        return;
      } 
    }
    
    public void setPlaybackToLocal(int param1Int) {
      if (this.w != null)
        this.w.setCallback(null); 
      this.u = 1;
      ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo(this.u, this.v, 2, this.c.getStreamMaxVolume(this.v), this.c.getStreamVolume(this.v));
      a(parcelableVolumeInfo);
    }
    
    public void setPlaybackToRemote(VolumeProviderCompat param1VolumeProviderCompat) {
      if (param1VolumeProviderCompat != null) {
        if (this.w != null)
          this.w.setCallback(null); 
        this.u = 2;
        this.w = param1VolumeProviderCompat;
        ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo(this.u, this.v, this.w.getVolumeControl(), this.w.getMaxVolume(), this.w.getCurrentVolume());
        a(parcelableVolumeInfo);
        param1VolumeProviderCompat.setCallback(this.mVolumeCallback);
        return;
      } 
      throw new IllegalArgumentException("volumeProvider may not be null");
    }
    
    public void setQueue(List<MediaSessionCompat.QueueItem> param1List) {
      this.n = param1List;
      sendQueue(param1List);
    }
    
    public void setQueueTitle(CharSequence param1CharSequence) {
      this.o = param1CharSequence;
      sendQueueTitle(param1CharSequence);
    }
    
    public void setRatingType(int param1Int) {
      this.p = param1Int;
    }
    
    void setRccState(PlaybackStateCompat param1PlaybackStateCompat) {
      this.d.setPlaybackState(getRccStateFromState(param1PlaybackStateCompat.getState()));
    }
    
    public void setRepeatMode(int param1Int) {
      if (this.r != param1Int) {
        this.r = param1Int;
        sendRepeatMode(param1Int);
      } 
    }
    
    public void setSessionActivity(PendingIntent param1PendingIntent) {
      synchronized (this.e) {
        this.m = param1PendingIntent;
        return;
      } 
    }
    
    public void setShuffleMode(int param1Int) {
      if (this.s != param1Int) {
        this.s = param1Int;
        sendShuffleMode(param1Int);
      } 
    }
    
    void setVolumeTo(int param1Int1, int param1Int2) {
      if (this.u == 2) {
        if (this.w != null) {
          this.w.onSetVolumeTo(param1Int1);
          return;
        } 
      } else {
        this.c.setStreamVolume(this.v, param1Int1, param1Int2);
      } 
    }
    
    private static final class Command {
      public final String command;
      
      public final Bundle extras;
      
      public final ResultReceiver stub;
      
      public Command(String param2String, Bundle param2Bundle, ResultReceiver param2ResultReceiver) {
        this.command = param2String;
        this.extras = param2Bundle;
        this.stub = param2ResultReceiver;
      }
    }
    
    class MediaSessionStub extends IMediaSession.Stub {
      MediaSessionStub(MediaSessionCompat.MediaSessionImplBase this$0) {}
      
      public void addQueueItem(MediaDescriptionCompat param2MediaDescriptionCompat) {
        this.a.a(25, param2MediaDescriptionCompat);
      }
      
      public void addQueueItemAt(MediaDescriptionCompat param2MediaDescriptionCompat, int param2Int) {
        this.a.a(26, param2MediaDescriptionCompat, param2Int);
      }
      
      public void adjustVolume(int param2Int1, int param2Int2, String param2String) {
        this.a.b(param2Int1, param2Int2);
      }
      
      public void fastForward() {
        this.a.a(16);
      }
      
      public Bundle getExtras() {
        synchronized (this.a.e) {
          return this.a.t;
        } 
      }
      
      public long getFlags() {
        synchronized (this.a.e) {
          return this.a.j;
        } 
      }
      
      public PendingIntent getLaunchPendingIntent() {
        synchronized (this.a.e) {
          return this.a.m;
        } 
      }
      
      public MediaMetadataCompat getMetadata() {
        return this.a.k;
      }
      
      public String getPackageName() {
        return this.a.a;
      }
      
      public PlaybackStateCompat getPlaybackState() {
        synchronized (this.a.e) {
          PlaybackStateCompat playbackStateCompat = this.a.l;
          MediaMetadataCompat mediaMetadataCompat = this.a.k;
          return MediaSessionCompat.a(playbackStateCompat, mediaMetadataCompat);
        } 
      }
      
      public List<MediaSessionCompat.QueueItem> getQueue() {
        synchronized (this.a.e) {
          return this.a.n;
        } 
      }
      
      public CharSequence getQueueTitle() {
        return this.a.o;
      }
      
      public int getRatingType() {
        return this.a.p;
      }
      
      public int getRepeatMode() {
        return this.a.r;
      }
      
      public int getShuffleMode() {
        return this.a.s;
      }
      
      public String getTag() {
        return this.a.b;
      }
      
      public ParcelableVolumeInfo getVolumeAttributes() {
        synchronized (this.a.e) {
          int k;
          int m;
          byte b;
          int i = this.a.u;
          int j = this.a.v;
          VolumeProviderCompat volumeProviderCompat = this.a.w;
          if (i == 2) {
            int n = volumeProviderCompat.getVolumeControl();
            int i1 = volumeProviderCompat.getMaxVolume();
            k = volumeProviderCompat.getCurrentVolume();
            m = i1;
            b = n;
          } else {
            int n = this.a.c.getStreamMaxVolume(j);
            int i1 = this.a.c.getStreamVolume(j);
            m = n;
            k = i1;
            b = 2;
          } 
          return new ParcelableVolumeInfo(i, j, b, m, k);
        } 
      }
      
      public boolean isCaptioningEnabled() {
        return this.a.q;
      }
      
      public boolean isShuffleModeEnabledRemoved() {
        return false;
      }
      
      public boolean isTransportControlEnabled() {
        return ((0x2 & this.a.j) != 0);
      }
      
      public void next() {
        this.a.a(14);
      }
      
      public void pause() {
        this.a.a(12);
      }
      
      public void play() {
        this.a.a(7);
      }
      
      public void playFromMediaId(String param2String, Bundle param2Bundle) {
        this.a.a(8, param2String, param2Bundle);
      }
      
      public void playFromSearch(String param2String, Bundle param2Bundle) {
        this.a.a(9, param2String, param2Bundle);
      }
      
      public void playFromUri(Uri param2Uri, Bundle param2Bundle) {
        this.a.a(10, param2Uri, param2Bundle);
      }
      
      public void prepare() {
        this.a.a(3);
      }
      
      public void prepareFromMediaId(String param2String, Bundle param2Bundle) {
        this.a.a(4, param2String, param2Bundle);
      }
      
      public void prepareFromSearch(String param2String, Bundle param2Bundle) {
        this.a.a(5, param2String, param2Bundle);
      }
      
      public void prepareFromUri(Uri param2Uri, Bundle param2Bundle) {
        this.a.a(6, param2Uri, param2Bundle);
      }
      
      public void previous() {
        this.a.a(15);
      }
      
      public void rate(RatingCompat param2RatingCompat) {
        this.a.a(19, param2RatingCompat);
      }
      
      public void rateWithExtras(RatingCompat param2RatingCompat, Bundle param2Bundle) {
        this.a.a(31, param2RatingCompat, param2Bundle);
      }
      
      public void registerCallbackListener(IMediaControllerCallback param2IMediaControllerCallback) {
        if (this.a.g) {
          try {
            param2IMediaControllerCallback.onSessionDestroyed();
          } catch (Exception exception) {}
          return;
        } 
        this.a.f.register(param2IMediaControllerCallback);
      }
      
      public void removeQueueItem(MediaDescriptionCompat param2MediaDescriptionCompat) {
        this.a.a(27, param2MediaDescriptionCompat);
      }
      
      public void removeQueueItemAt(int param2Int) {
        this.a.a(28, param2Int);
      }
      
      public void rewind() {
        this.a.a(17);
      }
      
      public void seekTo(long param2Long) {
        this.a.a(18, Long.valueOf(param2Long));
      }
      
      public void sendCommand(String param2String, Bundle param2Bundle, MediaSessionCompat.ResultReceiverWrapper param2ResultReceiverWrapper) {
        this.a.a(1, new MediaSessionCompat.MediaSessionImplBase.Command(param2String, param2Bundle, MediaSessionCompat.ResultReceiverWrapper.a(param2ResultReceiverWrapper)));
      }
      
      public void sendCustomAction(String param2String, Bundle param2Bundle) {
        this.a.a(20, param2String, param2Bundle);
      }
      
      public boolean sendMediaButton(KeyEvent param2KeyEvent) {
        int i = this.a.j;
        byte b = 1;
        if ((i & b) == 0)
          b = 0; 
        if (b != 0)
          this.a.a(21, param2KeyEvent); 
        return b;
      }
      
      public void setCaptioningEnabled(boolean param2Boolean) {
        this.a.a(29, Boolean.valueOf(param2Boolean));
      }
      
      public void setRepeatMode(int param2Int) {
        this.a.a(23, param2Int);
      }
      
      public void setShuffleMode(int param2Int) {
        this.a.a(30, param2Int);
      }
      
      public void setShuffleModeEnabledRemoved(boolean param2Boolean) {}
      
      public void setVolumeTo(int param2Int1, int param2Int2, String param2String) {
        this.a.setVolumeTo(param2Int1, param2Int2);
      }
      
      public void skipToQueueItem(long param2Long) {
        this.a.a(11, Long.valueOf(param2Long));
      }
      
      public void stop() {
        this.a.a(13);
      }
      
      public void unregisterCallbackListener(IMediaControllerCallback param2IMediaControllerCallback) {
        this.a.f.unregister(param2IMediaControllerCallback);
      }
    }
    
    class MessageHandler extends Handler {
      private static final int KEYCODE_MEDIA_PAUSE = 127;
      
      private static final int KEYCODE_MEDIA_PLAY = 126;
      
      private static final int MSG_ADD_QUEUE_ITEM = 25;
      
      private static final int MSG_ADD_QUEUE_ITEM_AT = 26;
      
      private static final int MSG_ADJUST_VOLUME = 2;
      
      private static final int MSG_COMMAND = 1;
      
      private static final int MSG_CUSTOM_ACTION = 20;
      
      private static final int MSG_FAST_FORWARD = 16;
      
      private static final int MSG_MEDIA_BUTTON = 21;
      
      private static final int MSG_NEXT = 14;
      
      private static final int MSG_PAUSE = 12;
      
      private static final int MSG_PLAY = 7;
      
      private static final int MSG_PLAY_MEDIA_ID = 8;
      
      private static final int MSG_PLAY_SEARCH = 9;
      
      private static final int MSG_PLAY_URI = 10;
      
      private static final int MSG_PREPARE = 3;
      
      private static final int MSG_PREPARE_MEDIA_ID = 4;
      
      private static final int MSG_PREPARE_SEARCH = 5;
      
      private static final int MSG_PREPARE_URI = 6;
      
      private static final int MSG_PREVIOUS = 15;
      
      private static final int MSG_RATE = 19;
      
      private static final int MSG_RATE_EXTRA = 31;
      
      private static final int MSG_REMOVE_QUEUE_ITEM = 27;
      
      private static final int MSG_REMOVE_QUEUE_ITEM_AT = 28;
      
      private static final int MSG_REWIND = 17;
      
      private static final int MSG_SEEK_TO = 18;
      
      private static final int MSG_SET_CAPTIONING_ENABLED = 29;
      
      private static final int MSG_SET_REPEAT_MODE = 23;
      
      private static final int MSG_SET_SHUFFLE_MODE = 30;
      
      private static final int MSG_SET_VOLUME = 22;
      
      private static final int MSG_SKIP_TO_ITEM = 11;
      
      private static final int MSG_STOP = 13;
      
      public MessageHandler(MediaSessionCompat.MediaSessionImplBase this$0, Looper param2Looper) {
        super(param2Looper);
      }
      
      private void onMediaButtonEvent(KeyEvent param2KeyEvent, MediaSessionCompat.Callback param2Callback) {
        if (param2KeyEvent != null) {
          long l;
          if (param2KeyEvent.getAction() != 0)
            return; 
          if (this.a.l == null) {
            l = 0L;
          } else {
            l = this.a.l.getActions();
          } 
          int i = param2KeyEvent.getKeyCode();
          if (i != 79)
            switch (i) {
              default:
                switch (i) {
                  default:
                    return;
                  case 127:
                    if ((l & 0x2L) != 0L) {
                      param2Callback.onPause();
                      return;
                    } 
                    return;
                  case 126:
                    break;
                } 
                if ((l & 0x4L) != 0L) {
                  param2Callback.onPlay();
                  return;
                } 
                return;
              case 90:
                if ((l & 0x40L) != 0L) {
                  param2Callback.onFastForward();
                  return;
                } 
                return;
              case 89:
                if ((l & 0x8L) != 0L) {
                  param2Callback.onRewind();
                  return;
                } 
                return;
              case 88:
                if ((l & 0x10L) != 0L) {
                  param2Callback.onSkipToPrevious();
                  return;
                } 
                return;
              case 87:
                if ((l & 0x20L) != 0L) {
                  param2Callback.onSkipToNext();
                  return;
                } 
                return;
              case 86:
                if ((l & 0x1L) != 0L) {
                  param2Callback.onStop();
                  return;
                } 
                return;
              case 85:
                break;
            }  
          Log.w("MediaSessionCompat", "KEYCODE_MEDIA_PLAY_PAUSE and KEYCODE_HEADSETHOOK are handled already");
          return;
        } 
      }
      
      public void handleMessage(Message param2Message) {
        KeyEvent keyEvent;
        Intent intent;
        MediaSessionCompat.Callback callback = this.a.i;
        if (callback == null)
          return; 
        switch (param2Message.what) {
          default:
            return;
          case 31:
            callback.onSetRating((RatingCompat)param2Message.obj, param2Message.getData());
            return;
          case 30:
            callback.onSetShuffleMode(param2Message.arg1);
            return;
          case 29:
            callback.onSetCaptioningEnabled(((Boolean)param2Message.obj).booleanValue());
            return;
          case 28:
            if (this.a.n != null) {
              MediaSessionCompat.QueueItem queueItem;
              if (param2Message.arg1 >= 0 && param2Message.arg1 < this.a.n.size()) {
                queueItem = this.a.n.get(param2Message.arg1);
              } else {
                queueItem = null;
              } 
              if (queueItem != null) {
                callback.onRemoveQueueItem(queueItem.getDescription());
                return;
              } 
            } 
            return;
          case 27:
            callback.onRemoveQueueItem((MediaDescriptionCompat)param2Message.obj);
            return;
          case 26:
            callback.onAddQueueItem((MediaDescriptionCompat)param2Message.obj, param2Message.arg1);
            return;
          case 25:
            callback.onAddQueueItem((MediaDescriptionCompat)param2Message.obj);
            return;
          case 23:
            callback.onSetRepeatMode(param2Message.arg1);
            return;
          case 22:
            this.a.setVolumeTo(param2Message.arg1, 0);
            return;
          case 21:
            keyEvent = (KeyEvent)param2Message.obj;
            intent = new Intent("android.intent.action.MEDIA_BUTTON");
            intent.putExtra("android.intent.extra.KEY_EVENT", (Parcelable)keyEvent);
            if (!callback.onMediaButtonEvent(intent)) {
              onMediaButtonEvent(keyEvent, callback);
              return;
            } 
            return;
          case 20:
            callback.onCustomAction((String)param2Message.obj, param2Message.getData());
            return;
          case 19:
            callback.onSetRating((RatingCompat)param2Message.obj);
            return;
          case 18:
            callback.onSeekTo(((Long)param2Message.obj).longValue());
            return;
          case 17:
            callback.onRewind();
            return;
          case 16:
            callback.onFastForward();
            return;
          case 15:
            callback.onSkipToPrevious();
            return;
          case 14:
            callback.onSkipToNext();
            return;
          case 13:
            callback.onStop();
            return;
          case 12:
            callback.onPause();
            return;
          case 11:
            callback.onSkipToQueueItem(((Long)param2Message.obj).longValue());
            return;
          case 10:
            callback.onPlayFromUri((Uri)param2Message.obj, param2Message.getData());
            return;
          case 9:
            callback.onPlayFromSearch((String)param2Message.obj, param2Message.getData());
            return;
          case 8:
            callback.onPlayFromMediaId((String)param2Message.obj, param2Message.getData());
            return;
          case 7:
            callback.onPlay();
            return;
          case 6:
            callback.onPrepareFromUri((Uri)param2Message.obj, param2Message.getData());
            return;
          case 5:
            callback.onPrepareFromSearch((String)param2Message.obj, param2Message.getData());
            return;
          case 4:
            callback.onPrepareFromMediaId((String)param2Message.obj, param2Message.getData());
            return;
          case 3:
            callback.onPrepare();
            return;
          case 2:
            this.a.b(param2Message.arg1, 0);
            return;
          case 1:
            break;
        } 
        MediaSessionCompat.MediaSessionImplBase.Command command = (MediaSessionCompat.MediaSessionImplBase.Command)param2Message.obj;
        callback.onCommand(command.command, command.extras, command.stub);
      }
      
      public void post(int param2Int) {
        post(param2Int, (Object)null);
      }
      
      public void post(int param2Int, Object param2Object) {
        obtainMessage(param2Int, param2Object).sendToTarget();
      }
      
      public void post(int param2Int1, Object param2Object, int param2Int2) {
        obtainMessage(param2Int1, param2Int2, 0, param2Object).sendToTarget();
      }
      
      public void post(int param2Int, Object param2Object, Bundle param2Bundle) {
        Message message = obtainMessage(param2Int, param2Object);
        message.setData(param2Bundle);
        message.sendToTarget();
      }
    }
  }
  
  class null extends VolumeProviderCompat.Callback {
    null(MediaSessionCompat this$0) {}
    
    public void onVolumeChanged(VolumeProviderCompat param1VolumeProviderCompat) {
      if (this.a.w != param1VolumeProviderCompat)
        return; 
      ParcelableVolumeInfo parcelableVolumeInfo = new ParcelableVolumeInfo(this.a.u, this.a.v, param1VolumeProviderCompat.getVolumeControl(), param1VolumeProviderCompat.getMaxVolume(), param1VolumeProviderCompat.getCurrentVolume());
      this.a.a(parcelableVolumeInfo);
    }
  }
  
  private static final class Command {
    public final String command;
    
    public final Bundle extras;
    
    public final ResultReceiver stub;
    
    public Command(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {
      this.command = param1String;
      this.extras = param1Bundle;
      this.stub = param1ResultReceiver;
    }
  }
  
  class MediaSessionStub extends IMediaSession.Stub {
    MediaSessionStub(MediaSessionCompat this$0) {}
    
    public void addQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {
      this.a.a(25, param1MediaDescriptionCompat);
    }
    
    public void addQueueItemAt(MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {
      this.a.a(26, param1MediaDescriptionCompat, param1Int);
    }
    
    public void adjustVolume(int param1Int1, int param1Int2, String param1String) {
      this.a.b(param1Int1, param1Int2);
    }
    
    public void fastForward() {
      this.a.a(16);
    }
    
    public Bundle getExtras() {
      synchronized (this.a.e) {
        return this.a.t;
      } 
    }
    
    public long getFlags() {
      synchronized (this.a.e) {
        return this.a.j;
      } 
    }
    
    public PendingIntent getLaunchPendingIntent() {
      synchronized (this.a.e) {
        return this.a.m;
      } 
    }
    
    public MediaMetadataCompat getMetadata() {
      return this.a.k;
    }
    
    public String getPackageName() {
      return this.a.a;
    }
    
    public PlaybackStateCompat getPlaybackState() {
      synchronized (this.a.e) {
        PlaybackStateCompat playbackStateCompat = this.a.l;
        MediaMetadataCompat mediaMetadataCompat = this.a.k;
        return MediaSessionCompat.a(playbackStateCompat, mediaMetadataCompat);
      } 
    }
    
    public List<MediaSessionCompat.QueueItem> getQueue() {
      synchronized (this.a.e) {
        return this.a.n;
      } 
    }
    
    public CharSequence getQueueTitle() {
      return this.a.o;
    }
    
    public int getRatingType() {
      return this.a.p;
    }
    
    public int getRepeatMode() {
      return this.a.r;
    }
    
    public int getShuffleMode() {
      return this.a.s;
    }
    
    public String getTag() {
      return this.a.b;
    }
    
    public ParcelableVolumeInfo getVolumeAttributes() {
      synchronized (this.a.e) {
        int k;
        int m;
        byte b;
        int i = this.a.u;
        int j = this.a.v;
        VolumeProviderCompat volumeProviderCompat = this.a.w;
        if (i == 2) {
          int n = volumeProviderCompat.getVolumeControl();
          int i1 = volumeProviderCompat.getMaxVolume();
          k = volumeProviderCompat.getCurrentVolume();
          m = i1;
          b = n;
        } else {
          int n = this.a.c.getStreamMaxVolume(j);
          int i1 = this.a.c.getStreamVolume(j);
          m = n;
          k = i1;
          b = 2;
        } 
        return new ParcelableVolumeInfo(i, j, b, m, k);
      } 
    }
    
    public boolean isCaptioningEnabled() {
      return this.a.q;
    }
    
    public boolean isShuffleModeEnabledRemoved() {
      return false;
    }
    
    public boolean isTransportControlEnabled() {
      return ((0x2 & this.a.j) != 0);
    }
    
    public void next() {
      this.a.a(14);
    }
    
    public void pause() {
      this.a.a(12);
    }
    
    public void play() {
      this.a.a(7);
    }
    
    public void playFromMediaId(String param1String, Bundle param1Bundle) {
      this.a.a(8, param1String, param1Bundle);
    }
    
    public void playFromSearch(String param1String, Bundle param1Bundle) {
      this.a.a(9, param1String, param1Bundle);
    }
    
    public void playFromUri(Uri param1Uri, Bundle param1Bundle) {
      this.a.a(10, param1Uri, param1Bundle);
    }
    
    public void prepare() {
      this.a.a(3);
    }
    
    public void prepareFromMediaId(String param1String, Bundle param1Bundle) {
      this.a.a(4, param1String, param1Bundle);
    }
    
    public void prepareFromSearch(String param1String, Bundle param1Bundle) {
      this.a.a(5, param1String, param1Bundle);
    }
    
    public void prepareFromUri(Uri param1Uri, Bundle param1Bundle) {
      this.a.a(6, param1Uri, param1Bundle);
    }
    
    public void previous() {
      this.a.a(15);
    }
    
    public void rate(RatingCompat param1RatingCompat) {
      this.a.a(19, param1RatingCompat);
    }
    
    public void rateWithExtras(RatingCompat param1RatingCompat, Bundle param1Bundle) {
      this.a.a(31, param1RatingCompat, param1Bundle);
    }
    
    public void registerCallbackListener(IMediaControllerCallback param1IMediaControllerCallback) {
      if (this.a.g) {
        try {
          param1IMediaControllerCallback.onSessionDestroyed();
        } catch (Exception exception) {}
        return;
      } 
      this.a.f.register(param1IMediaControllerCallback);
    }
    
    public void removeQueueItem(MediaDescriptionCompat param1MediaDescriptionCompat) {
      this.a.a(27, param1MediaDescriptionCompat);
    }
    
    public void removeQueueItemAt(int param1Int) {
      this.a.a(28, param1Int);
    }
    
    public void rewind() {
      this.a.a(17);
    }
    
    public void seekTo(long param1Long) {
      this.a.a(18, Long.valueOf(param1Long));
    }
    
    public void sendCommand(String param1String, Bundle param1Bundle, MediaSessionCompat.ResultReceiverWrapper param1ResultReceiverWrapper) {
      this.a.a(1, new MediaSessionCompat.MediaSessionImplBase.Command(param1String, param1Bundle, MediaSessionCompat.ResultReceiverWrapper.a(param1ResultReceiverWrapper)));
    }
    
    public void sendCustomAction(String param1String, Bundle param1Bundle) {
      this.a.a(20, param1String, param1Bundle);
    }
    
    public boolean sendMediaButton(KeyEvent param1KeyEvent) {
      int i = this.a.j;
      byte b = 1;
      if ((i & b) == 0)
        b = 0; 
      if (b != 0)
        this.a.a(21, param1KeyEvent); 
      return b;
    }
    
    public void setCaptioningEnabled(boolean param1Boolean) {
      this.a.a(29, Boolean.valueOf(param1Boolean));
    }
    
    public void setRepeatMode(int param1Int) {
      this.a.a(23, param1Int);
    }
    
    public void setShuffleMode(int param1Int) {
      this.a.a(30, param1Int);
    }
    
    public void setShuffleModeEnabledRemoved(boolean param1Boolean) {}
    
    public void setVolumeTo(int param1Int1, int param1Int2, String param1String) {
      this.a.setVolumeTo(param1Int1, param1Int2);
    }
    
    public void skipToQueueItem(long param1Long) {
      this.a.a(11, Long.valueOf(param1Long));
    }
    
    public void stop() {
      this.a.a(13);
    }
    
    public void unregisterCallbackListener(IMediaControllerCallback param1IMediaControllerCallback) {
      this.a.f.unregister(param1IMediaControllerCallback);
    }
  }
  
  class MessageHandler extends Handler {
    private static final int KEYCODE_MEDIA_PAUSE = 127;
    
    private static final int KEYCODE_MEDIA_PLAY = 126;
    
    private static final int MSG_ADD_QUEUE_ITEM = 25;
    
    private static final int MSG_ADD_QUEUE_ITEM_AT = 26;
    
    private static final int MSG_ADJUST_VOLUME = 2;
    
    private static final int MSG_COMMAND = 1;
    
    private static final int MSG_CUSTOM_ACTION = 20;
    
    private static final int MSG_FAST_FORWARD = 16;
    
    private static final int MSG_MEDIA_BUTTON = 21;
    
    private static final int MSG_NEXT = 14;
    
    private static final int MSG_PAUSE = 12;
    
    private static final int MSG_PLAY = 7;
    
    private static final int MSG_PLAY_MEDIA_ID = 8;
    
    private static final int MSG_PLAY_SEARCH = 9;
    
    private static final int MSG_PLAY_URI = 10;
    
    private static final int MSG_PREPARE = 3;
    
    private static final int MSG_PREPARE_MEDIA_ID = 4;
    
    private static final int MSG_PREPARE_SEARCH = 5;
    
    private static final int MSG_PREPARE_URI = 6;
    
    private static final int MSG_PREVIOUS = 15;
    
    private static final int MSG_RATE = 19;
    
    private static final int MSG_RATE_EXTRA = 31;
    
    private static final int MSG_REMOVE_QUEUE_ITEM = 27;
    
    private static final int MSG_REMOVE_QUEUE_ITEM_AT = 28;
    
    private static final int MSG_REWIND = 17;
    
    private static final int MSG_SEEK_TO = 18;
    
    private static final int MSG_SET_CAPTIONING_ENABLED = 29;
    
    private static final int MSG_SET_REPEAT_MODE = 23;
    
    private static final int MSG_SET_SHUFFLE_MODE = 30;
    
    private static final int MSG_SET_VOLUME = 22;
    
    private static final int MSG_SKIP_TO_ITEM = 11;
    
    private static final int MSG_STOP = 13;
    
    public MessageHandler(MediaSessionCompat this$0, Looper param1Looper) {
      super(param1Looper);
    }
    
    private void onMediaButtonEvent(KeyEvent param1KeyEvent, MediaSessionCompat.Callback param1Callback) {
      if (param1KeyEvent != null) {
        long l;
        if (param1KeyEvent.getAction() != 0)
          return; 
        if (this.a.l == null) {
          l = 0L;
        } else {
          l = this.a.l.getActions();
        } 
        int i = param1KeyEvent.getKeyCode();
        if (i != 79)
          switch (i) {
            default:
              switch (i) {
                default:
                  return;
                case 127:
                  if ((l & 0x2L) != 0L) {
                    param1Callback.onPause();
                    return;
                  } 
                  return;
                case 126:
                  break;
              } 
              if ((l & 0x4L) != 0L) {
                param1Callback.onPlay();
                return;
              } 
              return;
            case 90:
              if ((l & 0x40L) != 0L) {
                param1Callback.onFastForward();
                return;
              } 
              return;
            case 89:
              if ((l & 0x8L) != 0L) {
                param1Callback.onRewind();
                return;
              } 
              return;
            case 88:
              if ((l & 0x10L) != 0L) {
                param1Callback.onSkipToPrevious();
                return;
              } 
              return;
            case 87:
              if ((l & 0x20L) != 0L) {
                param1Callback.onSkipToNext();
                return;
              } 
              return;
            case 86:
              if ((l & 0x1L) != 0L) {
                param1Callback.onStop();
                return;
              } 
              return;
            case 85:
              break;
          }  
        Log.w("MediaSessionCompat", "KEYCODE_MEDIA_PLAY_PAUSE and KEYCODE_HEADSETHOOK are handled already");
        return;
      } 
    }
    
    public void handleMessage(Message param1Message) {
      KeyEvent keyEvent;
      Intent intent;
      MediaSessionCompat.Callback callback = this.a.i;
      if (callback == null)
        return; 
      switch (param1Message.what) {
        default:
          return;
        case 31:
          callback.onSetRating((RatingCompat)param1Message.obj, param1Message.getData());
          return;
        case 30:
          callback.onSetShuffleMode(param1Message.arg1);
          return;
        case 29:
          callback.onSetCaptioningEnabled(((Boolean)param1Message.obj).booleanValue());
          return;
        case 28:
          if (this.a.n != null) {
            MediaSessionCompat.QueueItem queueItem;
            if (param1Message.arg1 >= 0 && param1Message.arg1 < this.a.n.size()) {
              queueItem = this.a.n.get(param1Message.arg1);
            } else {
              queueItem = null;
            } 
            if (queueItem != null) {
              callback.onRemoveQueueItem(queueItem.getDescription());
              return;
            } 
          } 
          return;
        case 27:
          callback.onRemoveQueueItem((MediaDescriptionCompat)param1Message.obj);
          return;
        case 26:
          callback.onAddQueueItem((MediaDescriptionCompat)param1Message.obj, param1Message.arg1);
          return;
        case 25:
          callback.onAddQueueItem((MediaDescriptionCompat)param1Message.obj);
          return;
        case 23:
          callback.onSetRepeatMode(param1Message.arg1);
          return;
        case 22:
          this.a.setVolumeTo(param1Message.arg1, 0);
          return;
        case 21:
          keyEvent = (KeyEvent)param1Message.obj;
          intent = new Intent("android.intent.action.MEDIA_BUTTON");
          intent.putExtra("android.intent.extra.KEY_EVENT", (Parcelable)keyEvent);
          if (!callback.onMediaButtonEvent(intent)) {
            onMediaButtonEvent(keyEvent, callback);
            return;
          } 
          return;
        case 20:
          callback.onCustomAction((String)param1Message.obj, param1Message.getData());
          return;
        case 19:
          callback.onSetRating((RatingCompat)param1Message.obj);
          return;
        case 18:
          callback.onSeekTo(((Long)param1Message.obj).longValue());
          return;
        case 17:
          callback.onRewind();
          return;
        case 16:
          callback.onFastForward();
          return;
        case 15:
          callback.onSkipToPrevious();
          return;
        case 14:
          callback.onSkipToNext();
          return;
        case 13:
          callback.onStop();
          return;
        case 12:
          callback.onPause();
          return;
        case 11:
          callback.onSkipToQueueItem(((Long)param1Message.obj).longValue());
          return;
        case 10:
          callback.onPlayFromUri((Uri)param1Message.obj, param1Message.getData());
          return;
        case 9:
          callback.onPlayFromSearch((String)param1Message.obj, param1Message.getData());
          return;
        case 8:
          callback.onPlayFromMediaId((String)param1Message.obj, param1Message.getData());
          return;
        case 7:
          callback.onPlay();
          return;
        case 6:
          callback.onPrepareFromUri((Uri)param1Message.obj, param1Message.getData());
          return;
        case 5:
          callback.onPrepareFromSearch((String)param1Message.obj, param1Message.getData());
          return;
        case 4:
          callback.onPrepareFromMediaId((String)param1Message.obj, param1Message.getData());
          return;
        case 3:
          callback.onPrepare();
          return;
        case 2:
          this.a.b(param1Message.arg1, 0);
          return;
        case 1:
          break;
      } 
      MediaSessionCompat.MediaSessionImplBase.Command command = (MediaSessionCompat.MediaSessionImplBase.Command)param1Message.obj;
      callback.onCommand(command.command, command.extras, command.stub);
    }
    
    public void post(int param1Int) {
      post(param1Int, (Object)null);
    }
    
    public void post(int param1Int, Object param1Object) {
      obtainMessage(param1Int, param1Object).sendToTarget();
    }
    
    public void post(int param1Int1, Object param1Object, int param1Int2) {
      obtainMessage(param1Int1, param1Int2, 0, param1Object).sendToTarget();
    }
    
    public void post(int param1Int, Object param1Object, Bundle param1Bundle) {
      Message message = obtainMessage(param1Int, param1Object);
      message.setData(param1Bundle);
      message.sendToTarget();
    }
  }
  
  public static interface OnActiveChangeListener {
    void onActiveChanged();
  }
  
  public static final class QueueItem implements Parcelable {
    public static final Parcelable.Creator<QueueItem> CREATOR = new Parcelable.Creator<QueueItem>() {
        public MediaSessionCompat.QueueItem createFromParcel(Parcel param2Parcel) {
          return new MediaSessionCompat.QueueItem(param2Parcel);
        }
        
        public MediaSessionCompat.QueueItem[] newArray(int param2Int) {
          return new MediaSessionCompat.QueueItem[param2Int];
        }
      };
    
    public static final int UNKNOWN_ID = -1;
    
    private final MediaDescriptionCompat mDescription;
    
    private final long mId;
    
    private Object mItem;
    
    QueueItem(Parcel param1Parcel) {
      this.mDescription = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
      this.mId = param1Parcel.readLong();
    }
    
    public QueueItem(MediaDescriptionCompat param1MediaDescriptionCompat, long param1Long) {
      this(null, param1MediaDescriptionCompat, param1Long);
    }
    
    private QueueItem(Object param1Object, MediaDescriptionCompat param1MediaDescriptionCompat, long param1Long) {
      if (param1MediaDescriptionCompat != null) {
        if (param1Long != -1L) {
          this.mDescription = param1MediaDescriptionCompat;
          this.mId = param1Long;
          this.mItem = param1Object;
          return;
        } 
        throw new IllegalArgumentException("Id cannot be QueueItem.UNKNOWN_ID");
      } 
      throw new IllegalArgumentException("Description cannot be null.");
    }
    
    public static QueueItem fromQueueItem(Object param1Object) {
      return (param1Object == null || Build.VERSION.SDK_INT < 21) ? null : new QueueItem(param1Object, MediaDescriptionCompat.fromMediaDescription(MediaSessionCompatApi21.QueueItem.getDescription(param1Object)), MediaSessionCompatApi21.QueueItem.getQueueId(param1Object));
    }
    
    public static List<QueueItem> fromQueueItemList(List<?> param1List) {
      if (param1List == null || Build.VERSION.SDK_INT < 21)
        return null; 
      ArrayList<QueueItem> arrayList = new ArrayList();
      Iterator<?> iterator = param1List.iterator();
      while (iterator.hasNext())
        arrayList.add(fromQueueItem(iterator.next())); 
      return arrayList;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public MediaDescriptionCompat getDescription() {
      return this.mDescription;
    }
    
    public long getQueueId() {
      return this.mId;
    }
    
    public Object getQueueItem() {
      if (this.mItem != null || Build.VERSION.SDK_INT < 21)
        return this.mItem; 
      this.mItem = MediaSessionCompatApi21.QueueItem.createItem(this.mDescription.getMediaDescription(), this.mId);
      return this.mItem;
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("MediaSession.QueueItem {Description=");
      stringBuilder.append(this.mDescription);
      stringBuilder.append(", Id=");
      stringBuilder.append(this.mId);
      stringBuilder.append(" }");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.mDescription.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeLong(this.mId);
    }
  }
  
  static final class null implements Parcelable.Creator<QueueItem> {
    public MediaSessionCompat.QueueItem createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.QueueItem(param1Parcel);
    }
    
    public MediaSessionCompat.QueueItem[] newArray(int param1Int) {
      return new MediaSessionCompat.QueueItem[param1Int];
    }
  }
  
  static final class ResultReceiverWrapper implements Parcelable {
    public static final Parcelable.Creator<ResultReceiverWrapper> CREATOR = new Parcelable.Creator<ResultReceiverWrapper>() {
        public MediaSessionCompat.ResultReceiverWrapper createFromParcel(Parcel param2Parcel) {
          return new MediaSessionCompat.ResultReceiverWrapper(param2Parcel);
        }
        
        public MediaSessionCompat.ResultReceiverWrapper[] newArray(int param2Int) {
          return new MediaSessionCompat.ResultReceiverWrapper[param2Int];
        }
      };
    
    private ResultReceiver mResultReceiver;
    
    ResultReceiverWrapper(Parcel param1Parcel) {
      this.mResultReceiver = (ResultReceiver)ResultReceiver.CREATOR.createFromParcel(param1Parcel);
    }
    
    public ResultReceiverWrapper(ResultReceiver param1ResultReceiver) {
      this.mResultReceiver = param1ResultReceiver;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      this.mResultReceiver.writeToParcel(param1Parcel, param1Int);
    }
  }
  
  static final class null implements Parcelable.Creator<ResultReceiverWrapper> {
    public MediaSessionCompat.ResultReceiverWrapper createFromParcel(Parcel param1Parcel) {
      return new MediaSessionCompat.ResultReceiverWrapper(param1Parcel);
    }
    
    public MediaSessionCompat.ResultReceiverWrapper[] newArray(int param1Int) {
      return new MediaSessionCompat.ResultReceiverWrapper[param1Int];
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface SessionFlags {}
  
  public static final class Token implements Parcelable {
    public static final Parcelable.Creator<Token> CREATOR = new Parcelable.Creator<Token>() {
        public MediaSessionCompat.Token createFromParcel(Parcel param2Parcel) {
          IBinder iBinder;
          if (Build.VERSION.SDK_INT >= 21) {
            Parcelable parcelable = param2Parcel.readParcelable(null);
          } else {
            iBinder = param2Parcel.readStrongBinder();
          } 
          return new MediaSessionCompat.Token(iBinder);
        }
        
        public MediaSessionCompat.Token[] newArray(int param2Int) {
          return new MediaSessionCompat.Token[param2Int];
        }
      };
    
    private final IMediaSession mExtraBinder;
    
    private final Object mInner;
    
    Token(Object param1Object) {
      this(param1Object, null);
    }
    
    Token(Object param1Object, IMediaSession param1IMediaSession) {
      this.mInner = param1Object;
      this.mExtraBinder = param1IMediaSession;
    }
    
    public static Token fromToken(Object param1Object) {
      return fromToken(param1Object, null);
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static Token fromToken(Object param1Object, IMediaSession param1IMediaSession) {
      return (param1Object != null && Build.VERSION.SDK_INT >= 21) ? new Token(MediaSessionCompatApi21.verifyToken(param1Object), param1IMediaSession) : null;
    }
    
    public int describeContents() {
      return 0;
    }
    
    public boolean equals(Object param1Object) {
      if (this == param1Object)
        return true; 
      if (!(param1Object instanceof Token))
        return false; 
      Token token = (Token)param1Object;
      return (this.mInner == null) ? ((token.mInner == null)) : ((token.mInner == null) ? false : this.mInner.equals(token.mInner));
    }
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public IMediaSession getExtraBinder() {
      return this.mExtraBinder;
    }
    
    public Object getToken() {
      return this.mInner;
    }
    
    public int hashCode() {
      return (this.mInner == null) ? 0 : this.mInner.hashCode();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      if (Build.VERSION.SDK_INT >= 21) {
        param1Parcel.writeParcelable((Parcelable)this.mInner, param1Int);
        return;
      } 
      param1Parcel.writeStrongBinder((IBinder)this.mInner);
    }
  }
  
  static final class null implements Parcelable.Creator<Token> {
    public MediaSessionCompat.Token createFromParcel(Parcel param1Parcel) {
      IBinder iBinder;
      if (Build.VERSION.SDK_INT >= 21) {
        Parcelable parcelable = param1Parcel.readParcelable(null);
      } else {
        iBinder = param1Parcel.readStrongBinder();
      } 
      return new MediaSessionCompat.Token(iBinder);
    }
    
    public MediaSessionCompat.Token[] newArray(int param1Int) {
      return new MediaSessionCompat.Token[param1Int];
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\session\MediaSessionCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */