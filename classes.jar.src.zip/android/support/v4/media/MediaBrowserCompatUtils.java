package android.support.v4.media;

import android.os.Bundle;
import android.support.annotation.RestrictTo;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class MediaBrowserCompatUtils {
  public static boolean areSameOptions(Bundle paramBundle1, Bundle paramBundle2) {
    return (paramBundle1 == paramBundle2) ? true : ((paramBundle1 == null) ? ((paramBundle2.getInt("android.media.browse.extra.PAGE", -1) == -1 && paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1)) : ((paramBundle2 == null) ? ((paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == -1 && paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == -1)) : ((paramBundle1.getInt("android.media.browse.extra.PAGE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE", -1) && paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1) == paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1)))));
  }
  
  public static boolean hasDuplicatedItems(Bundle paramBundle1, Bundle paramBundle2) {
    int i;
    int j;
    int k;
    int m;
    int i1;
    int i2;
    int i3;
    if (paramBundle1 == null) {
      i = -1;
    } else {
      i = paramBundle1.getInt("android.media.browse.extra.PAGE", -1);
    } 
    if (paramBundle2 == null) {
      j = -1;
    } else {
      j = paramBundle2.getInt("android.media.browse.extra.PAGE", -1);
    } 
    if (paramBundle1 == null) {
      k = -1;
    } else {
      k = paramBundle1.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    } 
    if (paramBundle2 == null) {
      m = -1;
    } else {
      m = paramBundle2.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    } 
    int n = Integer.MAX_VALUE;
    if (i == -1 || k == -1) {
      i1 = Integer.MAX_VALUE;
      i2 = 0;
    } else {
      i2 = i * k;
      i1 = k + i2 - 1;
    } 
    if (j == -1 || m == -1) {
      i3 = 0;
    } else {
      i3 = m * j;
      n = -1 + m + i3;
    } 
    return (i2 <= i3 && i3 <= i1) ? true : ((i2 <= n && n <= i1));
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\MediaBrowserCompatUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */