package android.support.v4.media;

import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.RestrictTo;
import android.support.v4.util.ArrayMap;
import android.util.Log;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.Set;

public final class MediaMetadataCompat implements Parcelable {
  public static final Parcelable.Creator<MediaMetadataCompat> CREATOR;
  
  public static final String METADATA_KEY_ADVERTISEMENT = "android.media.metadata.ADVERTISEMENT";
  
  public static final String METADATA_KEY_ALBUM = "android.media.metadata.ALBUM";
  
  public static final String METADATA_KEY_ALBUM_ART = "android.media.metadata.ALBUM_ART";
  
  public static final String METADATA_KEY_ALBUM_ARTIST = "android.media.metadata.ALBUM_ARTIST";
  
  public static final String METADATA_KEY_ALBUM_ART_URI = "android.media.metadata.ALBUM_ART_URI";
  
  public static final String METADATA_KEY_ART = "android.media.metadata.ART";
  
  public static final String METADATA_KEY_ARTIST = "android.media.metadata.ARTIST";
  
  public static final String METADATA_KEY_ART_URI = "android.media.metadata.ART_URI";
  
  public static final String METADATA_KEY_AUTHOR = "android.media.metadata.AUTHOR";
  
  public static final String METADATA_KEY_BT_FOLDER_TYPE = "android.media.metadata.BT_FOLDER_TYPE";
  
  public static final String METADATA_KEY_COMPILATION = "android.media.metadata.COMPILATION";
  
  public static final String METADATA_KEY_COMPOSER = "android.media.metadata.COMPOSER";
  
  public static final String METADATA_KEY_DATE = "android.media.metadata.DATE";
  
  public static final String METADATA_KEY_DISC_NUMBER = "android.media.metadata.DISC_NUMBER";
  
  public static final String METADATA_KEY_DISPLAY_DESCRIPTION = "android.media.metadata.DISPLAY_DESCRIPTION";
  
  public static final String METADATA_KEY_DISPLAY_ICON = "android.media.metadata.DISPLAY_ICON";
  
  public static final String METADATA_KEY_DISPLAY_ICON_URI = "android.media.metadata.DISPLAY_ICON_URI";
  
  public static final String METADATA_KEY_DISPLAY_SUBTITLE = "android.media.metadata.DISPLAY_SUBTITLE";
  
  public static final String METADATA_KEY_DISPLAY_TITLE = "android.media.metadata.DISPLAY_TITLE";
  
  public static final String METADATA_KEY_DOWNLOAD_STATUS = "android.media.metadata.DOWNLOAD_STATUS";
  
  public static final String METADATA_KEY_DURATION = "android.media.metadata.DURATION";
  
  public static final String METADATA_KEY_GENRE = "android.media.metadata.GENRE";
  
  public static final String METADATA_KEY_MEDIA_ID = "android.media.metadata.MEDIA_ID";
  
  public static final String METADATA_KEY_MEDIA_URI = "android.media.metadata.MEDIA_URI";
  
  public static final String METADATA_KEY_NUM_TRACKS = "android.media.metadata.NUM_TRACKS";
  
  public static final String METADATA_KEY_RATING = "android.media.metadata.RATING";
  
  public static final String METADATA_KEY_TITLE = "android.media.metadata.TITLE";
  
  public static final String METADATA_KEY_TRACK_NUMBER = "android.media.metadata.TRACK_NUMBER";
  
  public static final String METADATA_KEY_USER_RATING = "android.media.metadata.USER_RATING";
  
  public static final String METADATA_KEY_WRITER = "android.media.metadata.WRITER";
  
  public static final String METADATA_KEY_YEAR = "android.media.metadata.YEAR";
  
  private static final String[] PREFERRED_BITMAP_ORDER;
  
  private static final String[] PREFERRED_DESCRIPTION_ORDER;
  
  private static final String[] PREFERRED_URI_ORDER;
  
  private static final String TAG = "MediaMetadata";
  
  static final ArrayMap<String, Integer> a = new ArrayMap();
  
  final Bundle b;
  
  private MediaDescriptionCompat mDescription;
  
  private Object mMetadataObj;
  
  static {
    a.put("android.media.metadata.TITLE", Integer.valueOf(1));
    a.put("android.media.metadata.ARTIST", Integer.valueOf(1));
    a.put("android.media.metadata.DURATION", Integer.valueOf(0));
    a.put("android.media.metadata.ALBUM", Integer.valueOf(1));
    a.put("android.media.metadata.AUTHOR", Integer.valueOf(1));
    a.put("android.media.metadata.WRITER", Integer.valueOf(1));
    a.put("android.media.metadata.COMPOSER", Integer.valueOf(1));
    a.put("android.media.metadata.COMPILATION", Integer.valueOf(1));
    a.put("android.media.metadata.DATE", Integer.valueOf(1));
    a.put("android.media.metadata.YEAR", Integer.valueOf(0));
    a.put("android.media.metadata.GENRE", Integer.valueOf(1));
    a.put("android.media.metadata.TRACK_NUMBER", Integer.valueOf(0));
    a.put("android.media.metadata.NUM_TRACKS", Integer.valueOf(0));
    a.put("android.media.metadata.DISC_NUMBER", Integer.valueOf(0));
    a.put("android.media.metadata.ALBUM_ARTIST", Integer.valueOf(1));
    a.put("android.media.metadata.ART", Integer.valueOf(2));
    a.put("android.media.metadata.ART_URI", Integer.valueOf(1));
    a.put("android.media.metadata.ALBUM_ART", Integer.valueOf(2));
    a.put("android.media.metadata.ALBUM_ART_URI", Integer.valueOf(1));
    a.put("android.media.metadata.USER_RATING", Integer.valueOf(3));
    a.put("android.media.metadata.RATING", Integer.valueOf(3));
    a.put("android.media.metadata.DISPLAY_TITLE", Integer.valueOf(1));
    a.put("android.media.metadata.DISPLAY_SUBTITLE", Integer.valueOf(1));
    a.put("android.media.metadata.DISPLAY_DESCRIPTION", Integer.valueOf(1));
    a.put("android.media.metadata.DISPLAY_ICON", Integer.valueOf(2));
    a.put("android.media.metadata.DISPLAY_ICON_URI", Integer.valueOf(1));
    a.put("android.media.metadata.MEDIA_ID", Integer.valueOf(1));
    a.put("android.media.metadata.BT_FOLDER_TYPE", Integer.valueOf(0));
    a.put("android.media.metadata.MEDIA_URI", Integer.valueOf(1));
    a.put("android.media.metadata.ADVERTISEMENT", Integer.valueOf(0));
    a.put("android.media.metadata.DOWNLOAD_STATUS", Integer.valueOf(0));
    PREFERRED_DESCRIPTION_ORDER = new String[] { "android.media.metadata.TITLE", "android.media.metadata.ARTIST", "android.media.metadata.ALBUM", "android.media.metadata.ALBUM_ARTIST", "android.media.metadata.WRITER", "android.media.metadata.AUTHOR", "android.media.metadata.COMPOSER" };
    PREFERRED_BITMAP_ORDER = new String[] { "android.media.metadata.DISPLAY_ICON", "android.media.metadata.ART", "android.media.metadata.ALBUM_ART" };
    PREFERRED_URI_ORDER = new String[] { "android.media.metadata.DISPLAY_ICON_URI", "android.media.metadata.ART_URI", "android.media.metadata.ALBUM_ART_URI" };
    CREATOR = new Parcelable.Creator<MediaMetadataCompat>() {
        public MediaMetadataCompat createFromParcel(Parcel param1Parcel) {
          return new MediaMetadataCompat(param1Parcel);
        }
        
        public MediaMetadataCompat[] newArray(int param1Int) {
          return new MediaMetadataCompat[param1Int];
        }
      };
  }
  
  MediaMetadataCompat(Bundle paramBundle) {
    this.b = new Bundle(paramBundle);
    this.b.setClassLoader(MediaMetadataCompat.class.getClassLoader());
  }
  
  MediaMetadataCompat(Parcel paramParcel) {
    this.b = paramParcel.readBundle();
    this.b.setClassLoader(MediaMetadataCompat.class.getClassLoader());
  }
  
  public static MediaMetadataCompat fromMediaMetadata(Object paramObject) {
    if (paramObject != null && Build.VERSION.SDK_INT >= 21) {
      Parcel parcel = Parcel.obtain();
      MediaMetadataCompatApi21.writeToParcel(paramObject, parcel, 0);
      parcel.setDataPosition(0);
      MediaMetadataCompat mediaMetadataCompat = (MediaMetadataCompat)CREATOR.createFromParcel(parcel);
      parcel.recycle();
      mediaMetadataCompat.mMetadataObj = paramObject;
      return mediaMetadataCompat;
    } 
    return null;
  }
  
  public boolean containsKey(String paramString) {
    return this.b.containsKey(paramString);
  }
  
  public int describeContents() {
    return 0;
  }
  
  public Bitmap getBitmap(String paramString) {
    try {
      return (Bitmap)this.b.getParcelable(paramString);
    } catch (Exception exception) {
      Log.w("MediaMetadata", "Failed to retrieve a key as Bitmap.", exception);
      return null;
    } 
  }
  
  public Bundle getBundle() {
    return this.b;
  }
  
  public MediaDescriptionCompat getDescription() {
    // Byte code:
    //   0: aload_0
    //   1: getfield mDescription : Landroid/support/v4/media/MediaDescriptionCompat;
    //   4: ifnull -> 12
    //   7: aload_0
    //   8: getfield mDescription : Landroid/support/v4/media/MediaDescriptionCompat;
    //   11: areturn
    //   12: aload_0
    //   13: ldc 'android.media.metadata.MEDIA_ID'
    //   15: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   18: astore_1
    //   19: iconst_3
    //   20: anewarray java/lang/CharSequence
    //   23: astore_2
    //   24: aload_0
    //   25: ldc 'android.media.metadata.DISPLAY_TITLE'
    //   27: invokevirtual getText : (Ljava/lang/String;)Ljava/lang/CharSequence;
    //   30: astore_3
    //   31: aload_3
    //   32: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   35: ifne -> 63
    //   38: aload_2
    //   39: iconst_0
    //   40: aload_3
    //   41: aastore
    //   42: aload_2
    //   43: iconst_1
    //   44: aload_0
    //   45: ldc 'android.media.metadata.DISPLAY_SUBTITLE'
    //   47: invokevirtual getText : (Ljava/lang/String;)Ljava/lang/CharSequence;
    //   50: aastore
    //   51: aload_2
    //   52: iconst_2
    //   53: aload_0
    //   54: ldc 'android.media.metadata.DISPLAY_DESCRIPTION'
    //   56: invokevirtual getText : (Ljava/lang/String;)Ljava/lang/CharSequence;
    //   59: aastore
    //   60: goto -> 138
    //   63: iconst_0
    //   64: istore #4
    //   66: iconst_0
    //   67: istore #5
    //   69: iload #4
    //   71: aload_2
    //   72: arraylength
    //   73: if_icmpge -> 138
    //   76: iload #5
    //   78: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_DESCRIPTION_ORDER : [Ljava/lang/String;
    //   81: arraylength
    //   82: if_icmpge -> 138
    //   85: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_DESCRIPTION_ORDER : [Ljava/lang/String;
    //   88: astore #24
    //   90: iload #5
    //   92: iconst_1
    //   93: iadd
    //   94: istore #25
    //   96: aload_0
    //   97: aload #24
    //   99: iload #5
    //   101: aaload
    //   102: invokevirtual getText : (Ljava/lang/String;)Ljava/lang/CharSequence;
    //   105: astore #26
    //   107: aload #26
    //   109: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   112: ifne -> 131
    //   115: iload #4
    //   117: iconst_1
    //   118: iadd
    //   119: istore #27
    //   121: aload_2
    //   122: iload #4
    //   124: aload #26
    //   126: aastore
    //   127: iload #27
    //   129: istore #4
    //   131: iload #25
    //   133: istore #5
    //   135: goto -> 69
    //   138: iconst_0
    //   139: istore #6
    //   141: iload #6
    //   143: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_BITMAP_ORDER : [Ljava/lang/String;
    //   146: arraylength
    //   147: if_icmpge -> 176
    //   150: aload_0
    //   151: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_BITMAP_ORDER : [Ljava/lang/String;
    //   154: iload #6
    //   156: aaload
    //   157: invokevirtual getBitmap : (Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   160: astore #7
    //   162: aload #7
    //   164: ifnull -> 170
    //   167: goto -> 179
    //   170: iinc #6, 1
    //   173: goto -> 141
    //   176: aconst_null
    //   177: astore #7
    //   179: iconst_0
    //   180: istore #8
    //   182: iload #8
    //   184: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_URI_ORDER : [Ljava/lang/String;
    //   187: arraylength
    //   188: if_icmpge -> 227
    //   191: aload_0
    //   192: getstatic android/support/v4/media/MediaMetadataCompat.PREFERRED_URI_ORDER : [Ljava/lang/String;
    //   195: iload #8
    //   197: aaload
    //   198: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   201: astore #23
    //   203: aload #23
    //   205: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   208: ifne -> 221
    //   211: aload #23
    //   213: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   216: astore #9
    //   218: goto -> 230
    //   221: iinc #8, 1
    //   224: goto -> 182
    //   227: aconst_null
    //   228: astore #9
    //   230: aload_0
    //   231: ldc 'android.media.metadata.MEDIA_URI'
    //   233: invokevirtual getString : (Ljava/lang/String;)Ljava/lang/String;
    //   236: astore #10
    //   238: aload #10
    //   240: invokestatic isEmpty : (Ljava/lang/CharSequence;)Z
    //   243: istore #11
    //   245: aconst_null
    //   246: astore #12
    //   248: iload #11
    //   250: ifne -> 260
    //   253: aload #10
    //   255: invokestatic parse : (Ljava/lang/String;)Landroid/net/Uri;
    //   258: astore #12
    //   260: new android/support/v4/media/MediaDescriptionCompat$Builder
    //   263: dup
    //   264: invokespecial <init> : ()V
    //   267: astore #13
    //   269: aload #13
    //   271: aload_1
    //   272: invokevirtual setMediaId : (Ljava/lang/String;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   275: pop
    //   276: aload #13
    //   278: aload_2
    //   279: iconst_0
    //   280: aaload
    //   281: invokevirtual setTitle : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   284: pop
    //   285: aload #13
    //   287: aload_2
    //   288: iconst_1
    //   289: aaload
    //   290: invokevirtual setSubtitle : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   293: pop
    //   294: aload #13
    //   296: aload_2
    //   297: iconst_2
    //   298: aaload
    //   299: invokevirtual setDescription : (Ljava/lang/CharSequence;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   302: pop
    //   303: aload #13
    //   305: aload #7
    //   307: invokevirtual setIconBitmap : (Landroid/graphics/Bitmap;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   310: pop
    //   311: aload #13
    //   313: aload #9
    //   315: invokevirtual setIconUri : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   318: pop
    //   319: aload #13
    //   321: aload #12
    //   323: invokevirtual setMediaUri : (Landroid/net/Uri;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   326: pop
    //   327: new android/os/Bundle
    //   330: dup
    //   331: invokespecial <init> : ()V
    //   334: astore #21
    //   336: aload_0
    //   337: getfield b : Landroid/os/Bundle;
    //   340: ldc 'android.media.metadata.BT_FOLDER_TYPE'
    //   342: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   345: ifeq -> 362
    //   348: aload #21
    //   350: ldc_w 'android.media.extra.BT_FOLDER_TYPE'
    //   353: aload_0
    //   354: ldc 'android.media.metadata.BT_FOLDER_TYPE'
    //   356: invokevirtual getLong : (Ljava/lang/String;)J
    //   359: invokevirtual putLong : (Ljava/lang/String;J)V
    //   362: aload_0
    //   363: getfield b : Landroid/os/Bundle;
    //   366: ldc 'android.media.metadata.DOWNLOAD_STATUS'
    //   368: invokevirtual containsKey : (Ljava/lang/String;)Z
    //   371: ifeq -> 388
    //   374: aload #21
    //   376: ldc_w 'android.media.extra.DOWNLOAD_STATUS'
    //   379: aload_0
    //   380: ldc 'android.media.metadata.DOWNLOAD_STATUS'
    //   382: invokevirtual getLong : (Ljava/lang/String;)J
    //   385: invokevirtual putLong : (Ljava/lang/String;J)V
    //   388: aload #21
    //   390: invokevirtual isEmpty : ()Z
    //   393: ifne -> 404
    //   396: aload #13
    //   398: aload #21
    //   400: invokevirtual setExtras : (Landroid/os/Bundle;)Landroid/support/v4/media/MediaDescriptionCompat$Builder;
    //   403: pop
    //   404: aload_0
    //   405: aload #13
    //   407: invokevirtual build : ()Landroid/support/v4/media/MediaDescriptionCompat;
    //   410: putfield mDescription : Landroid/support/v4/media/MediaDescriptionCompat;
    //   413: aload_0
    //   414: getfield mDescription : Landroid/support/v4/media/MediaDescriptionCompat;
    //   417: areturn
  }
  
  public long getLong(String paramString) {
    return this.b.getLong(paramString, 0L);
  }
  
  public Object getMediaMetadata() {
    if (this.mMetadataObj == null && Build.VERSION.SDK_INT >= 21) {
      Parcel parcel = Parcel.obtain();
      writeToParcel(parcel, 0);
      parcel.setDataPosition(0);
      this.mMetadataObj = MediaMetadataCompatApi21.createFromParcel(parcel);
      parcel.recycle();
    } 
    return this.mMetadataObj;
  }
  
  public RatingCompat getRating(String paramString) {
    try {
      return (Build.VERSION.SDK_INT >= 19) ? RatingCompat.fromRating(this.b.getParcelable(paramString)) : (RatingCompat)this.b.getParcelable(paramString);
    } catch (Exception exception) {
      Log.w("MediaMetadata", "Failed to retrieve a key as Rating.", exception);
      return null;
    } 
  }
  
  public String getString(String paramString) {
    CharSequence charSequence = this.b.getCharSequence(paramString);
    return (charSequence != null) ? charSequence.toString() : null;
  }
  
  public CharSequence getText(String paramString) {
    return this.b.getCharSequence(paramString);
  }
  
  public Set<String> keySet() {
    return this.b.keySet();
  }
  
  public int size() {
    return this.b.size();
  }
  
  public void writeToParcel(Parcel paramParcel, int paramInt) {
    paramParcel.writeBundle(this.b);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface BitmapKey {}
  
  public static final class Builder {
    private final Bundle mBundle = new Bundle();
    
    public Builder() {}
    
    public Builder(MediaMetadataCompat param1MediaMetadataCompat) {}
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public Builder(MediaMetadataCompat param1MediaMetadataCompat, int param1Int) {
      this(param1MediaMetadataCompat);
      for (String str : this.mBundle.keySet()) {
        Object object = this.mBundle.get(str);
        if (object instanceof Bitmap) {
          Bitmap bitmap = (Bitmap)object;
          if (bitmap.getHeight() > param1Int || bitmap.getWidth() > param1Int)
            putBitmap(str, scaleBitmap(bitmap, param1Int)); 
        } 
      } 
    }
    
    private Bitmap scaleBitmap(Bitmap param1Bitmap, int param1Int) {
      float f1 = param1Int;
      float f2 = Math.min(f1 / param1Bitmap.getWidth(), f1 / param1Bitmap.getHeight());
      int i = (int)(f2 * param1Bitmap.getHeight());
      return Bitmap.createScaledBitmap(param1Bitmap, (int)(f2 * param1Bitmap.getWidth()), i, true);
    }
    
    public MediaMetadataCompat build() {
      return new MediaMetadataCompat(this.mBundle);
    }
    
    public Builder putBitmap(String param1String, Bitmap param1Bitmap) {
      if (!MediaMetadataCompat.a.containsKey(param1String) || ((Integer)MediaMetadataCompat.a.get(param1String)).intValue() == 2) {
        this.mBundle.putParcelable(param1String, (Parcelable)param1Bitmap);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a Bitmap");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putLong(String param1String, long param1Long) {
      if (!MediaMetadataCompat.a.containsKey(param1String) || ((Integer)MediaMetadataCompat.a.get(param1String)).intValue() == 0) {
        this.mBundle.putLong(param1String, param1Long);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a long");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putRating(String param1String, RatingCompat param1RatingCompat) {
      if (!MediaMetadataCompat.a.containsKey(param1String) || ((Integer)MediaMetadataCompat.a.get(param1String)).intValue() == 3) {
        if (Build.VERSION.SDK_INT >= 19) {
          this.mBundle.putParcelable(param1String, (Parcelable)param1RatingCompat.getRating());
          return this;
        } 
        this.mBundle.putParcelable(param1String, param1RatingCompat);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a Rating");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putString(String param1String1, String param1String2) {
      if (!MediaMetadataCompat.a.containsKey(param1String1) || ((Integer)MediaMetadataCompat.a.get(param1String1)).intValue() == 1) {
        this.mBundle.putCharSequence(param1String1, param1String2);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String1);
      stringBuilder.append(" key cannot be used to put a String");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public Builder putText(String param1String, CharSequence param1CharSequence) {
      if (!MediaMetadataCompat.a.containsKey(param1String) || ((Integer)MediaMetadataCompat.a.get(param1String)).intValue() == 1) {
        this.mBundle.putCharSequence(param1String, param1CharSequence);
        return this;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("The ");
      stringBuilder.append(param1String);
      stringBuilder.append(" key cannot be used to put a CharSequence");
      throw new IllegalArgumentException(stringBuilder.toString());
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface LongKey {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface RatingKey {}
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface TextKey {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\MediaMetadataCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */