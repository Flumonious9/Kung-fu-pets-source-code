package android.support.v4.media;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.BadParcelableException;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.session.IMediaSession;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.support.v4.util.ArrayMap;
import android.text.TextUtils;
import android.util.Log;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public final class MediaBrowserCompat {
  public static final String CUSTOM_ACTION_DOWNLOAD = "android.support.v4.media.action.DOWNLOAD";
  
  public static final String CUSTOM_ACTION_REMOVE_DOWNLOADED_FILE = "android.support.v4.media.action.REMOVE_DOWNLOADED_FILE";
  
  public static final String EXTRA_DOWNLOAD_PROGRESS = "android.media.browse.extra.DOWNLOAD_PROGRESS";
  
  public static final String EXTRA_MEDIA_ID = "android.media.browse.extra.MEDIA_ID";
  
  public static final String EXTRA_PAGE = "android.media.browse.extra.PAGE";
  
  public static final String EXTRA_PAGE_SIZE = "android.media.browse.extra.PAGE_SIZE";
  
  static final boolean a = Log.isLoggable("MediaBrowserCompat", 3);
  
  private final MediaBrowserImpl mImpl;
  
  public MediaBrowserCompat(Context paramContext, ComponentName paramComponentName, ConnectionCallback paramConnectionCallback, Bundle paramBundle) {
    if (Build.VERSION.SDK_INT >= 26) {
      this.mImpl = new MediaBrowserImplApi26(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      this.mImpl = new MediaBrowserImplApi23(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      this.mImpl = new MediaBrowserImplApi21(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
      return;
    } 
    this.mImpl = new MediaBrowserImplBase(paramContext, paramComponentName, paramConnectionCallback, paramBundle);
  }
  
  public void connect() {
    this.mImpl.connect();
  }
  
  public void disconnect() {
    this.mImpl.disconnect();
  }
  
  @Nullable
  public Bundle getExtras() {
    return this.mImpl.getExtras();
  }
  
  public void getItem(@NonNull String paramString, @NonNull ItemCallback paramItemCallback) {
    this.mImpl.getItem(paramString, paramItemCallback);
  }
  
  @NonNull
  public String getRoot() {
    return this.mImpl.getRoot();
  }
  
  @NonNull
  public ComponentName getServiceComponent() {
    return this.mImpl.getServiceComponent();
  }
  
  @NonNull
  public MediaSessionCompat.Token getSessionToken() {
    return this.mImpl.getSessionToken();
  }
  
  public boolean isConnected() {
    return this.mImpl.isConnected();
  }
  
  public void search(@NonNull String paramString, Bundle paramBundle, @NonNull SearchCallback paramSearchCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSearchCallback != null) {
        this.mImpl.search(paramString, paramBundle, paramSearchCallback);
        return;
      } 
      throw new IllegalArgumentException("callback cannot be null");
    } 
    throw new IllegalArgumentException("query cannot be empty");
  }
  
  public void sendCustomAction(@NonNull String paramString, Bundle paramBundle, @Nullable CustomActionCallback paramCustomActionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      this.mImpl.sendCustomAction(paramString, paramBundle, paramCustomActionCallback);
      return;
    } 
    throw new IllegalArgumentException("action cannot be empty");
  }
  
  public void subscribe(@NonNull String paramString, @NonNull Bundle paramBundle, @NonNull SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        if (paramBundle != null) {
          this.mImpl.subscribe(paramString, paramBundle, paramSubscriptionCallback);
          return;
        } 
        throw new IllegalArgumentException("options are null");
      } 
      throw new IllegalArgumentException("callback is null");
    } 
    throw new IllegalArgumentException("parentId is empty");
  }
  
  public void subscribe(@NonNull String paramString, @NonNull SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        this.mImpl.subscribe(paramString, null, paramSubscriptionCallback);
        return;
      } 
      throw new IllegalArgumentException("callback is null");
    } 
    throw new IllegalArgumentException("parentId is empty");
  }
  
  public void unsubscribe(@NonNull String paramString) {
    if (!TextUtils.isEmpty(paramString)) {
      this.mImpl.unsubscribe(paramString, null);
      return;
    } 
    throw new IllegalArgumentException("parentId is empty");
  }
  
  public void unsubscribe(@NonNull String paramString, @NonNull SubscriptionCallback paramSubscriptionCallback) {
    if (!TextUtils.isEmpty(paramString)) {
      if (paramSubscriptionCallback != null) {
        this.mImpl.unsubscribe(paramString, paramSubscriptionCallback);
        return;
      } 
      throw new IllegalArgumentException("callback is null");
    } 
    throw new IllegalArgumentException("parentId is empty");
  }
  
  private static class CallbackHandler extends Handler {
    private final WeakReference<MediaBrowserCompat.MediaBrowserServiceCallbackImpl> mCallbackImplRef;
    
    private WeakReference<Messenger> mCallbacksMessengerRef;
    
    CallbackHandler(MediaBrowserCompat.MediaBrowserServiceCallbackImpl param1MediaBrowserServiceCallbackImpl) {
      this.mCallbackImplRef = new WeakReference<MediaBrowserCompat.MediaBrowserServiceCallbackImpl>(param1MediaBrowserServiceCallbackImpl);
    }
    
    public void handleMessage(Message param1Message) {
      if (this.mCallbacksMessengerRef != null && this.mCallbacksMessengerRef.get() != null) {
        if (this.mCallbackImplRef.get() == null)
          return; 
        Bundle bundle = param1Message.getData();
        bundle.setClassLoader(MediaSessionCompat.class.getClassLoader());
        MediaBrowserCompat.MediaBrowserServiceCallbackImpl mediaBrowserServiceCallbackImpl = this.mCallbackImplRef.get();
        Messenger messenger = this.mCallbacksMessengerRef.get();
        try {
          switch (param1Message.what) {
            case 3:
              mediaBrowserServiceCallbackImpl.onLoadChildren(messenger, bundle.getString("data_media_item_id"), bundle.getParcelableArrayList("data_media_item_list"), bundle.getBundle("data_options"));
              return;
            case 2:
              mediaBrowserServiceCallbackImpl.onConnectionFailed(messenger);
              return;
            case 1:
              mediaBrowserServiceCallbackImpl.onServiceConnected(messenger, bundle.getString("data_media_item_id"), (MediaSessionCompat.Token)bundle.getParcelable("data_media_session_token"), bundle.getBundle("data_root_hints"));
              return;
          } 
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Unhandled message: ");
          stringBuilder.append(param1Message);
          stringBuilder.append("\n  Client version: ");
          stringBuilder.append(1);
          stringBuilder.append("\n  Service version: ");
          stringBuilder.append(param1Message.arg1);
          Log.w("MediaBrowserCompat", stringBuilder.toString());
          return;
        } catch (BadParcelableException badParcelableException) {
          Log.e("MediaBrowserCompat", "Could not unparcel the data.");
          if (param1Message.what == 1)
            mediaBrowserServiceCallbackImpl.onConnectionFailed(messenger); 
          return;
        } 
      } 
    }
    
    void setCallbacksMessenger(Messenger param1Messenger) {
      this.mCallbacksMessengerRef = new WeakReference<Messenger>(param1Messenger);
    }
  }
  
  public static class ConnectionCallback {
    final Object a;
    
    ConnectionCallbackInternal b;
    
    public ConnectionCallback() {
      if (Build.VERSION.SDK_INT >= 21) {
        this.a = MediaBrowserCompatApi21.createConnectionCallback(new StubApi21(this));
        return;
      } 
      this.a = null;
    }
    
    public void onConnected() {}
    
    public void onConnectionFailed() {}
    
    public void onConnectionSuspended() {}
    
    void setInternalConnectionCallback(ConnectionCallbackInternal param1ConnectionCallbackInternal) {
      this.b = param1ConnectionCallbackInternal;
    }
    
    static interface ConnectionCallbackInternal {
      void onConnected();
      
      void onConnectionFailed();
      
      void onConnectionSuspended();
    }
    
    private class StubApi21 implements MediaBrowserCompatApi21.ConnectionCallback {
      StubApi21(MediaBrowserCompat.ConnectionCallback this$0) {}
      
      public void onConnected() {
        if (this.a.b != null)
          this.a.b.onConnected(); 
        this.a.onConnected();
      }
      
      public void onConnectionFailed() {
        if (this.a.b != null)
          this.a.b.onConnectionFailed(); 
        this.a.onConnectionFailed();
      }
      
      public void onConnectionSuspended() {
        if (this.a.b != null)
          this.a.b.onConnectionSuspended(); 
        this.a.onConnectionSuspended();
      }
    }
  }
  
  static interface ConnectionCallbackInternal {
    void onConnected();
    
    void onConnectionFailed();
    
    void onConnectionSuspended();
  }
  
  private class StubApi21 implements MediaBrowserCompatApi21.ConnectionCallback {
    StubApi21(MediaBrowserCompat this$0) {}
    
    public void onConnected() {
      if (this.a.b != null)
        this.a.b.onConnected(); 
      this.a.onConnected();
    }
    
    public void onConnectionFailed() {
      if (this.a.b != null)
        this.a.b.onConnectionFailed(); 
      this.a.onConnectionFailed();
    }
    
    public void onConnectionSuspended() {
      if (this.a.b != null)
        this.a.b.onConnectionSuspended(); 
      this.a.onConnectionSuspended();
    }
  }
  
  public static abstract class CustomActionCallback {
    public void onError(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
    
    public void onProgressUpdate(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
    
    public void onResult(String param1String, Bundle param1Bundle1, Bundle param1Bundle2) {}
  }
  
  private static class CustomActionResultReceiver extends ResultReceiver {
    private final String mAction;
    
    private final MediaBrowserCompat.CustomActionCallback mCallback;
    
    private final Bundle mExtras;
    
    CustomActionResultReceiver(String param1String, Bundle param1Bundle, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback, Handler param1Handler) {
      super(param1Handler);
      this.mAction = param1String;
      this.mExtras = param1Bundle;
      this.mCallback = param1CustomActionCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      StringBuilder stringBuilder;
      if (this.mCallback == null)
        return; 
      switch (param1Int) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unknown result code: ");
          stringBuilder.append(param1Int);
          stringBuilder.append(" (extras=");
          stringBuilder.append(this.mExtras);
          stringBuilder.append(", resultData=");
          stringBuilder.append(param1Bundle);
          stringBuilder.append(")");
          Log.w("MediaBrowserCompat", stringBuilder.toString());
          return;
        case 1:
          this.mCallback.onProgressUpdate(this.mAction, this.mExtras, param1Bundle);
          return;
        case 0:
          this.mCallback.onResult(this.mAction, this.mExtras, param1Bundle);
          return;
        case -1:
          break;
      } 
      this.mCallback.onError(this.mAction, this.mExtras, param1Bundle);
    }
  }
  
  public static abstract class ItemCallback {
    final Object a;
    
    public ItemCallback() {
      if (Build.VERSION.SDK_INT >= 23) {
        this.a = MediaBrowserCompatApi23.createItemCallback(new StubApi23(this));
        return;
      } 
      this.a = null;
    }
    
    public void onError(@NonNull String param1String) {}
    
    public void onItemLoaded(MediaBrowserCompat.MediaItem param1MediaItem) {}
    
    private class StubApi23 implements MediaBrowserCompatApi23.ItemCallback {
      StubApi23(MediaBrowserCompat.ItemCallback this$0) {}
      
      public void onError(@NonNull String param2String) {
        this.a.onError(param2String);
      }
      
      public void onItemLoaded(Parcel param2Parcel) {
        if (param2Parcel == null) {
          this.a.onItemLoaded(null);
          return;
        } 
        param2Parcel.setDataPosition(0);
        MediaBrowserCompat.MediaItem mediaItem = (MediaBrowserCompat.MediaItem)MediaBrowserCompat.MediaItem.CREATOR.createFromParcel(param2Parcel);
        param2Parcel.recycle();
        this.a.onItemLoaded(mediaItem);
      }
    }
  }
  
  private class StubApi23 implements MediaBrowserCompatApi23.ItemCallback {
    StubApi23(MediaBrowserCompat this$0) {}
    
    public void onError(@NonNull String param1String) {
      this.a.onError(param1String);
    }
    
    public void onItemLoaded(Parcel param1Parcel) {
      if (param1Parcel == null) {
        this.a.onItemLoaded(null);
        return;
      } 
      param1Parcel.setDataPosition(0);
      MediaBrowserCompat.MediaItem mediaItem = (MediaBrowserCompat.MediaItem)MediaBrowserCompat.MediaItem.CREATOR.createFromParcel(param1Parcel);
      param1Parcel.recycle();
      this.a.onItemLoaded(mediaItem);
    }
  }
  
  private static class ItemReceiver extends ResultReceiver {
    private final MediaBrowserCompat.ItemCallback mCallback;
    
    private final String mMediaId;
    
    ItemReceiver(String param1String, MediaBrowserCompat.ItemCallback param1ItemCallback, Handler param1Handler) {
      super(param1Handler);
      this.mMediaId = param1String;
      this.mCallback = param1ItemCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      if (param1Bundle != null)
        param1Bundle.setClassLoader(MediaBrowserCompat.class.getClassLoader()); 
      if (param1Int != 0 || param1Bundle == null || !param1Bundle.containsKey("media_item")) {
        this.mCallback.onError(this.mMediaId);
        return;
      } 
      Parcelable parcelable = param1Bundle.getParcelable("media_item");
      if (parcelable == null || parcelable instanceof MediaBrowserCompat.MediaItem) {
        this.mCallback.onItemLoaded((MediaBrowserCompat.MediaItem)parcelable);
        return;
      } 
      this.mCallback.onError(this.mMediaId);
    }
  }
  
  static interface MediaBrowserImpl {
    void connect();
    
    void disconnect();
    
    @Nullable
    Bundle getExtras();
    
    void getItem(@NonNull String param1String, @NonNull MediaBrowserCompat.ItemCallback param1ItemCallback);
    
    @NonNull
    String getRoot();
    
    ComponentName getServiceComponent();
    
    @NonNull
    MediaSessionCompat.Token getSessionToken();
    
    boolean isConnected();
    
    void search(@NonNull String param1String, Bundle param1Bundle, @NonNull MediaBrowserCompat.SearchCallback param1SearchCallback);
    
    void sendCustomAction(@NonNull String param1String, Bundle param1Bundle, @Nullable MediaBrowserCompat.CustomActionCallback param1CustomActionCallback);
    
    void subscribe(@NonNull String param1String, @Nullable Bundle param1Bundle, @NonNull MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback);
    
    void unsubscribe(@NonNull String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback);
  }
  
  @RequiresApi(21)
  static class MediaBrowserImplApi21 implements ConnectionCallback.ConnectionCallbackInternal, MediaBrowserImpl, MediaBrowserServiceCallbackImpl {
    final Context a;
    
    protected final Object b;
    
    protected final Bundle c;
    
    protected final MediaBrowserCompat.CallbackHandler d = new MediaBrowserCompat.CallbackHandler(this);
    
    protected int e;
    
    protected MediaBrowserCompat.ServiceBinderWrapper f;
    
    protected Messenger g;
    
    private MediaSessionCompat.Token mMediaSessionToken;
    
    private final ArrayMap<String, MediaBrowserCompat.Subscription> mSubscriptions = new ArrayMap();
    
    MediaBrowserImplApi21(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      this.a = param1Context;
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      param1Bundle.putInt("extra_client_version", 1);
      this.c = new Bundle(param1Bundle);
      param1ConnectionCallback.setInternalConnectionCallback(this);
      this.b = MediaBrowserCompatApi21.createBrowser(param1Context, param1ComponentName, param1ConnectionCallback.a, this.c);
    }
    
    public void connect() {
      MediaBrowserCompatApi21.connect(this.b);
    }
    
    public void disconnect() {
      if (this.f != null && this.g != null)
        try {
          this.f.c(this.g);
        } catch (RemoteException remoteException) {
          Log.i("MediaBrowserCompat", "Remote error unregistering client messenger.");
        }  
      MediaBrowserCompatApi21.disconnect(this.b);
    }
    
    @Nullable
    public Bundle getExtras() {
      return MediaBrowserCompatApi21.getExtras(this.b);
    }
    
    public void getItem(@NonNull String param1String, @NonNull MediaBrowserCompat.ItemCallback param1ItemCallback) {
      if (!TextUtils.isEmpty(param1String)) {
        if (param1ItemCallback != null) {
          if (!MediaBrowserCompatApi21.isConnected(this.b)) {
            Log.i("MediaBrowserCompat", "Not connected, unable to retrieve the MediaItem.");
            this.d.post(new Runnable(this, param1ItemCallback, param1String) {
                  public void run() {
                    this.a.onError(this.b);
                  }
                });
            return;
          } 
          if (this.f == null) {
            this.d.post(new Runnable(this, param1ItemCallback, param1String) {
                  public void run() {
                    this.a.onError(this.b);
                  }
                });
            return;
          } 
          MediaBrowserCompat.ItemReceiver itemReceiver = new MediaBrowserCompat.ItemReceiver(param1String, param1ItemCallback, this.d);
          try {
            this.f.a(param1String, itemReceiver, this.g);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Remote error getting media item: ");
            stringBuilder.append(param1String);
            Log.i("MediaBrowserCompat", stringBuilder.toString());
            this.d.post(new Runnable(this, param1ItemCallback, param1String) {
                  public void run() {
                    this.a.onError(this.b);
                  }
                });
            return;
          } 
        } 
        throw new IllegalArgumentException("cb is null");
      } 
      throw new IllegalArgumentException("mediaId is empty");
    }
    
    @NonNull
    public String getRoot() {
      return MediaBrowserCompatApi21.getRoot(this.b);
    }
    
    public ComponentName getServiceComponent() {
      return MediaBrowserCompatApi21.getServiceComponent(this.b);
    }
    
    @NonNull
    public MediaSessionCompat.Token getSessionToken() {
      if (this.mMediaSessionToken == null)
        this.mMediaSessionToken = MediaSessionCompat.Token.fromToken(MediaBrowserCompatApi21.getSessionToken(this.b)); 
      return this.mMediaSessionToken;
    }
    
    public boolean isConnected() {
      return MediaBrowserCompatApi21.isConnected(this.b);
    }
    
    public void onConnected() {
      Bundle bundle = MediaBrowserCompatApi21.getExtras(this.b);
      if (bundle == null)
        return; 
      this.e = bundle.getInt("extra_service_version", 0);
      IBinder iBinder = BundleCompat.getBinder(bundle, "extra_messenger");
      if (iBinder != null) {
        this.f = new MediaBrowserCompat.ServiceBinderWrapper(iBinder, this.c);
        this.g = new Messenger(this.d);
        this.d.setCallbacksMessenger(this.g);
        try {
          this.f.b(this.g);
        } catch (RemoteException remoteException) {
          Log.i("MediaBrowserCompat", "Remote error registering client messenger.");
        } 
      } 
      IMediaSession iMediaSession = IMediaSession.Stub.asInterface(BundleCompat.getBinder(bundle, "extra_session_binder"));
      if (iMediaSession != null)
        this.mMediaSessionToken = MediaSessionCompat.Token.fromToken(MediaBrowserCompatApi21.getSessionToken(this.b), iMediaSession); 
    }
    
    public void onConnectionFailed() {}
    
    public void onConnectionFailed(Messenger param1Messenger) {}
    
    public void onConnectionSuspended() {
      this.f = null;
      this.g = null;
      this.mMediaSessionToken = null;
      this.d.setCallbacksMessenger((Messenger)null);
    }
    
    public void onLoadChildren(Messenger param1Messenger, String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {
      if (this.g != param1Messenger)
        return; 
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        if (MediaBrowserCompat.a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onLoadChildren for id that isn't subscribed id=");
          stringBuilder.append(param1String);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
        } 
        return;
      } 
      MediaBrowserCompat.SubscriptionCallback subscriptionCallback = subscription.getCallback(this.a, param1Bundle);
      if (subscriptionCallback != null) {
        if (param1Bundle == null) {
          if (param1List == null) {
            subscriptionCallback.onError(param1String);
            return;
          } 
          subscriptionCallback.onChildrenLoaded(param1String, param1List);
          return;
        } 
        if (param1List == null) {
          subscriptionCallback.onError(param1String, param1Bundle);
          return;
        } 
        subscriptionCallback.onChildrenLoaded(param1String, param1List, param1Bundle);
      } 
    }
    
    public void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {}
    
    public void search(@NonNull String param1String, Bundle param1Bundle, @NonNull MediaBrowserCompat.SearchCallback param1SearchCallback) {
      if (isConnected()) {
        if (this.f == null) {
          Log.i("MediaBrowserCompat", "The connected service doesn't support search.");
          this.d.post(new Runnable(this, param1SearchCallback, param1String, param1Bundle) {
                public void run() {
                  this.a.onError(this.b, this.c);
                }
              });
          return;
        } 
        MediaBrowserCompat.SearchResultReceiver searchResultReceiver = new MediaBrowserCompat.SearchResultReceiver(param1String, param1Bundle, param1SearchCallback, this.d);
        try {
          this.f.a(param1String, param1Bundle, searchResultReceiver, this.g);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Remote error searching items with query: ");
          stringBuilder.append(param1String);
          Log.i("MediaBrowserCompat", stringBuilder.toString(), (Throwable)remoteException);
          this.d.post(new Runnable(this, param1SearchCallback, param1String, param1Bundle) {
                public void run() {
                  this.a.onError(this.b, this.c);
                }
              });
          return;
        } 
      } 
      throw new IllegalStateException("search() called while not connected");
    }
    
    public void sendCustomAction(@NonNull String param1String, Bundle param1Bundle, @Nullable MediaBrowserCompat.CustomActionCallback param1CustomActionCallback) {
      if (isConnected()) {
        if (this.f == null) {
          Log.i("MediaBrowserCompat", "The connected service doesn't support sendCustomAction.");
          if (param1CustomActionCallback != null)
            this.d.post(new Runnable(this, param1CustomActionCallback, param1String, param1Bundle) {
                  public void run() {
                    this.a.onError(this.b, this.c, null);
                  }
                }); 
        } 
        MediaBrowserCompat.CustomActionResultReceiver customActionResultReceiver = new MediaBrowserCompat.CustomActionResultReceiver(param1String, param1Bundle, param1CustomActionCallback, this.d);
        try {
          this.f.b(param1String, param1Bundle, customActionResultReceiver, this.g);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Remote error sending a custom action: action=");
          stringBuilder1.append(param1String);
          stringBuilder1.append(", extras=");
          stringBuilder1.append(param1Bundle);
          Log.i("MediaBrowserCompat", stringBuilder1.toString(), (Throwable)remoteException);
          if (param1CustomActionCallback != null)
            this.d.post(new Runnable(this, param1CustomActionCallback, param1String, param1Bundle) {
                  public void run() {
                    this.a.onError(this.b, this.c, null);
                  }
                }); 
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot send a custom action (");
      stringBuilder.append(param1String);
      stringBuilder.append(") with ");
      stringBuilder.append("extras ");
      stringBuilder.append(param1Bundle);
      stringBuilder.append(" because the browser is not connected to the ");
      stringBuilder.append("service.");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void subscribe(@NonNull String param1String, Bundle param1Bundle, @NonNull MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      Bundle bundle;
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        subscription = new MediaBrowserCompat.Subscription();
        this.mSubscriptions.put(param1String, subscription);
      } 
      MediaBrowserCompat.SubscriptionCallback.a(param1SubscriptionCallback, subscription);
      if (param1Bundle == null) {
        bundle = null;
      } else {
        bundle = new Bundle(param1Bundle);
      } 
      subscription.putCallback(this.a, bundle, param1SubscriptionCallback);
      if (this.f == null) {
        MediaBrowserCompatApi21.subscribe(this.b, param1String, MediaBrowserCompat.SubscriptionCallback.b(param1SubscriptionCallback));
        return;
      } 
      try {
        this.f.a(param1String, MediaBrowserCompat.SubscriptionCallback.a(param1SubscriptionCallback), bundle, this.g);
        return;
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Remote error subscribing media item: ");
        stringBuilder.append(param1String);
        Log.i("MediaBrowserCompat", stringBuilder.toString());
        return;
      } 
    }
    
    public void unsubscribe(@NonNull String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null)
        return; 
      if (this.f == null) {
        if (param1SubscriptionCallback == null) {
          MediaBrowserCompatApi21.unsubscribe(this.b, param1String);
        } else {
          List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
          List<Bundle> list1 = subscription.getOptionsList();
          for (int i = -1 + list.size(); i >= 0; i--) {
            if (list.get(i) == param1SubscriptionCallback) {
              list.remove(i);
              list1.remove(i);
            } 
          } 
          if (list.size() == 0)
            MediaBrowserCompatApi21.unsubscribe(this.b, param1String); 
        } 
      } else if (param1SubscriptionCallback == null) {
        try {
          this.f.a(param1String, (IBinder)null, this.g);
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("removeSubscription failed with RemoteException parentId=");
          stringBuilder.append(param1String);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
        } 
      } else {
        List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
        List<Bundle> list1 = subscription.getOptionsList();
        for (int i = -1 + list.size(); i >= 0; i--) {
          if (list.get(i) == param1SubscriptionCallback) {
            this.f.a(param1String, MediaBrowserCompat.SubscriptionCallback.a(param1SubscriptionCallback), this.g);
            list.remove(i);
            list1.remove(i);
          } 
        } 
      } 
      if (subscription.isEmpty() || param1SubscriptionCallback == null)
        this.mSubscriptions.remove(param1String); 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.ItemCallback param1ItemCallback, String param1String) {}
    
    public void run() {
      this.a.onError(this.b);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.ItemCallback param1ItemCallback, String param1String) {}
    
    public void run() {
      this.a.onError(this.b);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.ItemCallback param1ItemCallback, String param1String) {}
    
    public void run() {
      this.a.onError(this.b);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.SearchCallback param1SearchCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.SearchCallback param1SearchCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c, null);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c, null);
    }
  }
  
  @RequiresApi(23)
  static class MediaBrowserImplApi23 extends MediaBrowserImplApi21 {
    MediaBrowserImplApi23(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1ConnectionCallback, param1Bundle);
    }
    
    public void getItem(@NonNull String param1String, @NonNull MediaBrowserCompat.ItemCallback param1ItemCallback) {
      if (this.f == null) {
        MediaBrowserCompatApi23.getItem(this.b, param1String, param1ItemCallback.a);
        return;
      } 
      super.getItem(param1String, param1ItemCallback);
    }
  }
  
  @RequiresApi(26)
  static class MediaBrowserImplApi26 extends MediaBrowserImplApi23 {
    MediaBrowserImplApi26(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      super(param1Context, param1ComponentName, param1ConnectionCallback, param1Bundle);
    }
    
    public void subscribe(@NonNull String param1String, @Nullable Bundle param1Bundle, @NonNull MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      if (this.f == null || this.e < 2) {
        if (param1Bundle == null) {
          MediaBrowserCompatApi21.subscribe(this.b, param1String, MediaBrowserCompat.SubscriptionCallback.b(param1SubscriptionCallback));
          return;
        } 
        MediaBrowserCompatApi26.subscribe(this.b, param1String, param1Bundle, MediaBrowserCompat.SubscriptionCallback.b(param1SubscriptionCallback));
        return;
      } 
      super.subscribe(param1String, param1Bundle, param1SubscriptionCallback);
    }
    
    public void unsubscribe(@NonNull String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      if (this.f == null || this.e < 2) {
        if (param1SubscriptionCallback == null) {
          MediaBrowserCompatApi21.unsubscribe(this.b, param1String);
          return;
        } 
        MediaBrowserCompatApi26.unsubscribe(this.b, param1String, MediaBrowserCompat.SubscriptionCallback.b(param1SubscriptionCallback));
        return;
      } 
      super.unsubscribe(param1String, param1SubscriptionCallback);
    }
  }
  
  static class MediaBrowserImplBase implements MediaBrowserImpl, MediaBrowserServiceCallbackImpl {
    final Context a;
    
    final ComponentName b;
    
    final MediaBrowserCompat.ConnectionCallback c;
    
    final Bundle d;
    
    final MediaBrowserCompat.CallbackHandler e = new MediaBrowserCompat.CallbackHandler(this);
    
    int f = 1;
    
    MediaServiceConnection g;
    
    MediaBrowserCompat.ServiceBinderWrapper h;
    
    Messenger i;
    
    private Bundle mExtras;
    
    private MediaSessionCompat.Token mMediaSessionToken;
    
    private String mRootId;
    
    private final ArrayMap<String, MediaBrowserCompat.Subscription> mSubscriptions = new ArrayMap();
    
    public MediaBrowserImplBase(Context param1Context, ComponentName param1ComponentName, MediaBrowserCompat.ConnectionCallback param1ConnectionCallback, Bundle param1Bundle) {
      if (param1Context != null) {
        if (param1ComponentName != null) {
          if (param1ConnectionCallback != null) {
            Bundle bundle;
            this.a = param1Context;
            this.b = param1ComponentName;
            this.c = param1ConnectionCallback;
            if (param1Bundle == null) {
              bundle = null;
            } else {
              bundle = new Bundle(param1Bundle);
            } 
            this.d = bundle;
            return;
          } 
          throw new IllegalArgumentException("connection callback must not be null");
        } 
        throw new IllegalArgumentException("service component must not be null");
      } 
      throw new IllegalArgumentException("context must not be null");
    }
    
    private static String getStateLabel(int param1Int) {
      StringBuilder stringBuilder;
      switch (param1Int) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("UNKNOWN/");
          stringBuilder.append(param1Int);
          return stringBuilder.toString();
        case 4:
          return "CONNECT_STATE_SUSPENDED";
        case 3:
          return "CONNECT_STATE_CONNECTED";
        case 2:
          return "CONNECT_STATE_CONNECTING";
        case 1:
          return "CONNECT_STATE_DISCONNECTED";
        case 0:
          break;
      } 
      return "CONNECT_STATE_DISCONNECTING";
    }
    
    private boolean isCurrent(Messenger param1Messenger, String param1String) {
      if (this.i != param1Messenger || this.f == 0 || this.f == 1) {
        if (this.f != 0 && this.f != 1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(param1String);
          stringBuilder.append(" for ");
          stringBuilder.append(this.b);
          stringBuilder.append(" with mCallbacksMessenger=");
          stringBuilder.append(this.i);
          stringBuilder.append(" this=");
          stringBuilder.append(this);
          Log.i("MediaBrowserCompat", stringBuilder.toString());
        } 
        return false;
      } 
      return true;
    }
    
    void a() {
      if (this.g != null)
        this.a.unbindService(this.g); 
      this.f = 1;
      this.g = null;
      this.h = null;
      this.i = null;
      this.e.setCallbacksMessenger((Messenger)null);
      this.mRootId = null;
      this.mMediaSessionToken = null;
    }
    
    void b() {
      Log.d("MediaBrowserCompat", "MediaBrowserCompat...");
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("  mServiceComponent=");
      stringBuilder1.append(this.b);
      Log.d("MediaBrowserCompat", stringBuilder1.toString());
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("  mCallback=");
      stringBuilder2.append(this.c);
      Log.d("MediaBrowserCompat", stringBuilder2.toString());
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append("  mRootHints=");
      stringBuilder3.append(this.d);
      Log.d("MediaBrowserCompat", stringBuilder3.toString());
      StringBuilder stringBuilder4 = new StringBuilder();
      stringBuilder4.append("  mState=");
      stringBuilder4.append(getStateLabel(this.f));
      Log.d("MediaBrowserCompat", stringBuilder4.toString());
      StringBuilder stringBuilder5 = new StringBuilder();
      stringBuilder5.append("  mServiceConnection=");
      stringBuilder5.append(this.g);
      Log.d("MediaBrowserCompat", stringBuilder5.toString());
      StringBuilder stringBuilder6 = new StringBuilder();
      stringBuilder6.append("  mServiceBinderWrapper=");
      stringBuilder6.append(this.h);
      Log.d("MediaBrowserCompat", stringBuilder6.toString());
      StringBuilder stringBuilder7 = new StringBuilder();
      stringBuilder7.append("  mCallbacksMessenger=");
      stringBuilder7.append(this.i);
      Log.d("MediaBrowserCompat", stringBuilder7.toString());
      StringBuilder stringBuilder8 = new StringBuilder();
      stringBuilder8.append("  mRootId=");
      stringBuilder8.append(this.mRootId);
      Log.d("MediaBrowserCompat", stringBuilder8.toString());
      StringBuilder stringBuilder9 = new StringBuilder();
      stringBuilder9.append("  mMediaSessionToken=");
      stringBuilder9.append(this.mMediaSessionToken);
      Log.d("MediaBrowserCompat", stringBuilder9.toString());
    }
    
    public void connect() {
      if (this.f == 0 || this.f == 1) {
        this.f = 2;
        this.e.post(new Runnable(this) {
              public void run() {
                if (this.a.f == 0)
                  return; 
                this.a.f = 2;
                if (!MediaBrowserCompat.a || this.a.g == null) {
                  if (this.a.h == null) {
                    if (this.a.i == null) {
                      boolean bool;
                      Intent intent = new Intent("android.media.browse.MediaBrowserService");
                      intent.setComponent(this.a.b);
                      this.a.g = new MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection(this.a);
                      try {
                        bool = this.a.a.bindService(intent, this.a.g, 1);
                      } catch (Exception exception) {
                        StringBuilder stringBuilder3 = new StringBuilder();
                        stringBuilder3.append("Failed binding to service ");
                        stringBuilder3.append(this.a.b);
                        Log.e("MediaBrowserCompat", stringBuilder3.toString());
                        bool = false;
                      } 
                      if (!bool) {
                        this.a.a();
                        this.a.c.onConnectionFailed();
                      } 
                      if (MediaBrowserCompat.a) {
                        Log.d("MediaBrowserCompat", "connect...");
                        this.a.b();
                      } 
                      return;
                    } 
                    StringBuilder stringBuilder2 = new StringBuilder();
                    stringBuilder2.append("mCallbacksMessenger should be null. Instead it is ");
                    stringBuilder2.append(this.a.i);
                    throw new RuntimeException(stringBuilder2.toString());
                  } 
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append("mServiceBinderWrapper should be null. Instead it is ");
                  stringBuilder1.append(this.a.h);
                  throw new RuntimeException(stringBuilder1.toString());
                } 
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("mServiceConnection should be null. Instead it is ");
                stringBuilder.append(this.a.g);
                throw new RuntimeException(stringBuilder.toString());
              }
            });
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("connect() called while neigther disconnecting nor disconnected (state=");
      stringBuilder.append(getStateLabel(this.f));
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void disconnect() {
      this.f = 0;
      this.e.post(new Runnable(this) {
            public void run() {
              if (this.a.i != null)
                try {
                  this.a.h.a(this.a.i);
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("RemoteException during connect for ");
                  stringBuilder.append(this.a.b);
                  Log.w("MediaBrowserCompat", stringBuilder.toString());
                }  
              int i = this.a.f;
              this.a.a();
              if (i != 0)
                this.a.f = i; 
              if (MediaBrowserCompat.a) {
                Log.d("MediaBrowserCompat", "disconnect...");
                this.a.b();
              } 
            }
          });
    }
    
    @Nullable
    public Bundle getExtras() {
      if (isConnected())
        return this.mExtras; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getExtras() called while not connected (state=");
      stringBuilder.append(getStateLabel(this.f));
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void getItem(@NonNull String param1String, @NonNull MediaBrowserCompat.ItemCallback param1ItemCallback) {
      if (!TextUtils.isEmpty(param1String)) {
        if (param1ItemCallback != null) {
          if (!isConnected()) {
            Log.i("MediaBrowserCompat", "Not connected, unable to retrieve the MediaItem.");
            this.e.post(new Runnable(this, param1ItemCallback, param1String) {
                  public void run() {
                    this.a.onError(this.b);
                  }
                });
            return;
          } 
          MediaBrowserCompat.ItemReceiver itemReceiver = new MediaBrowserCompat.ItemReceiver(param1String, param1ItemCallback, this.e);
          try {
            this.h.a(param1String, itemReceiver, this.i);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Remote error getting media item: ");
            stringBuilder.append(param1String);
            Log.i("MediaBrowserCompat", stringBuilder.toString());
            this.e.post(new Runnable(this, param1ItemCallback, param1String) {
                  public void run() {
                    this.a.onError(this.b);
                  }
                });
            return;
          } 
        } 
        throw new IllegalArgumentException("cb is null");
      } 
      throw new IllegalArgumentException("mediaId is empty");
    }
    
    @NonNull
    public String getRoot() {
      if (isConnected())
        return this.mRootId; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getRoot() called while not connected(state=");
      stringBuilder.append(getStateLabel(this.f));
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    @NonNull
    public ComponentName getServiceComponent() {
      if (isConnected())
        return this.b; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getServiceComponent() called while not connected (state=");
      stringBuilder.append(this.f);
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    @NonNull
    public MediaSessionCompat.Token getSessionToken() {
      if (isConnected())
        return this.mMediaSessionToken; 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("getSessionToken() called while not connected(state=");
      stringBuilder.append(this.f);
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public boolean isConnected() {
      return (this.f == 3);
    }
    
    public void onConnectionFailed(Messenger param1Messenger) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("onConnectFailed for ");
      stringBuilder.append(this.b);
      Log.e("MediaBrowserCompat", stringBuilder.toString());
      if (!isCurrent(param1Messenger, "onConnectFailed"))
        return; 
      if (this.f != 2) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("onConnect from service while mState=");
        stringBuilder1.append(getStateLabel(this.f));
        stringBuilder1.append("... ignoring");
        Log.w("MediaBrowserCompat", stringBuilder1.toString());
        return;
      } 
      a();
      this.c.onConnectionFailed();
    }
    
    public void onLoadChildren(Messenger param1Messenger, String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {
      if (!isCurrent(param1Messenger, "onLoadChildren"))
        return; 
      if (MediaBrowserCompat.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onLoadChildren for ");
        stringBuilder.append(this.b);
        stringBuilder.append(" id=");
        stringBuilder.append(param1String);
        Log.d("MediaBrowserCompat", stringBuilder.toString());
      } 
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        if (MediaBrowserCompat.a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("onLoadChildren for id that isn't subscribed id=");
          stringBuilder.append(param1String);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
        } 
        return;
      } 
      MediaBrowserCompat.SubscriptionCallback subscriptionCallback = subscription.getCallback(this.a, param1Bundle);
      if (subscriptionCallback != null) {
        if (param1Bundle == null) {
          if (param1List == null) {
            subscriptionCallback.onError(param1String);
            return;
          } 
          subscriptionCallback.onChildrenLoaded(param1String, param1List);
          return;
        } 
        if (param1List == null) {
          subscriptionCallback.onError(param1String, param1Bundle);
          return;
        } 
        subscriptionCallback.onChildrenLoaded(param1String, param1List, param1Bundle);
      } 
    }
    
    public void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {
      if (!isCurrent(param1Messenger, "onConnect"))
        return; 
      if (this.f != 2) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("onConnect from service while mState=");
        stringBuilder.append(getStateLabel(this.f));
        stringBuilder.append("... ignoring");
        Log.w("MediaBrowserCompat", stringBuilder.toString());
        return;
      } 
      this.mRootId = param1String;
      this.mMediaSessionToken = param1Token;
      this.mExtras = param1Bundle;
      this.f = 3;
      if (MediaBrowserCompat.a) {
        Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
        b();
      } 
      this.c.onConnected();
      try {
        for (Map.Entry entry : this.mSubscriptions.entrySet()) {
          String str = (String)entry.getKey();
          MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)entry.getValue();
          List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
          List<Bundle> list1 = subscription.getOptionsList();
          for (byte b = 0; b < list.size(); b++)
            this.h.a(str, MediaBrowserCompat.SubscriptionCallback.a(list.get(b)), list1.get(b), this.i); 
        } 
      } catch (RemoteException remoteException) {
        Log.d("MediaBrowserCompat", "addSubscription failed with RemoteException.");
      } 
    }
    
    public void search(@NonNull String param1String, Bundle param1Bundle, @NonNull MediaBrowserCompat.SearchCallback param1SearchCallback) {
      if (isConnected()) {
        MediaBrowserCompat.SearchResultReceiver searchResultReceiver = new MediaBrowserCompat.SearchResultReceiver(param1String, param1Bundle, param1SearchCallback, this.e);
        try {
          this.h.a(param1String, param1Bundle, searchResultReceiver, this.i);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Remote error searching items with query: ");
          stringBuilder1.append(param1String);
          Log.i("MediaBrowserCompat", stringBuilder1.toString(), (Throwable)remoteException);
          this.e.post(new Runnable(this, param1SearchCallback, param1String, param1Bundle) {
                public void run() {
                  this.a.onError(this.b, this.c);
                }
              });
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("search() called while not connected (state=");
      stringBuilder.append(getStateLabel(this.f));
      stringBuilder.append(")");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendCustomAction(@NonNull String param1String, Bundle param1Bundle, @Nullable MediaBrowserCompat.CustomActionCallback param1CustomActionCallback) {
      if (isConnected()) {
        MediaBrowserCompat.CustomActionResultReceiver customActionResultReceiver = new MediaBrowserCompat.CustomActionResultReceiver(param1String, param1Bundle, param1CustomActionCallback, this.e);
        try {
          this.h.b(param1String, param1Bundle, customActionResultReceiver, this.i);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Remote error sending a custom action: action=");
          stringBuilder1.append(param1String);
          stringBuilder1.append(", extras=");
          stringBuilder1.append(param1Bundle);
          Log.i("MediaBrowserCompat", stringBuilder1.toString(), (Throwable)remoteException);
          if (param1CustomActionCallback != null)
            this.e.post(new Runnable(this, param1CustomActionCallback, param1String, param1Bundle) {
                  public void run() {
                    this.a.onError(this.b, this.c, null);
                  }
                }); 
          return;
        } 
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Cannot send a custom action (");
      stringBuilder.append(param1String);
      stringBuilder.append(") with ");
      stringBuilder.append("extras ");
      stringBuilder.append(param1Bundle);
      stringBuilder.append(" because the browser is not connected to the ");
      stringBuilder.append("service.");
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void subscribe(@NonNull String param1String, Bundle param1Bundle, @NonNull MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      Bundle bundle;
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null) {
        subscription = new MediaBrowserCompat.Subscription();
        this.mSubscriptions.put(param1String, subscription);
      } 
      if (param1Bundle == null) {
        bundle = null;
      } else {
        bundle = new Bundle(param1Bundle);
      } 
      subscription.putCallback(this.a, bundle, param1SubscriptionCallback);
      if (isConnected())
        try {
          this.h.a(param1String, MediaBrowserCompat.SubscriptionCallback.a(param1SubscriptionCallback), bundle, this.i);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("addSubscription failed with RemoteException parentId=");
          stringBuilder.append(param1String);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
        }  
    }
    
    public void unsubscribe(@NonNull String param1String, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      MediaBrowserCompat.Subscription subscription = (MediaBrowserCompat.Subscription)this.mSubscriptions.get(param1String);
      if (subscription == null)
        return; 
      if (param1SubscriptionCallback == null) {
        try {
          if (isConnected())
            this.h.a(param1String, (IBinder)null, this.i); 
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("removeSubscription failed with RemoteException parentId=");
          stringBuilder.append(param1String);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
        } 
      } else {
        List<MediaBrowserCompat.SubscriptionCallback> list = subscription.getCallbacks();
        List<Bundle> list1 = subscription.getOptionsList();
        for (int i = -1 + list.size(); i >= 0; i--) {
          if (list.get(i) == param1SubscriptionCallback) {
            if (isConnected())
              this.h.a(param1String, MediaBrowserCompat.SubscriptionCallback.a(param1SubscriptionCallback), this.i); 
            list.remove(i);
            list1.remove(i);
          } 
        } 
      } 
      if (subscription.isEmpty() || param1SubscriptionCallback == null)
        this.mSubscriptions.remove(param1String); 
    }
    
    private class MediaServiceConnection implements ServiceConnection {
      MediaServiceConnection(MediaBrowserCompat.MediaBrowserImplBase this$0) {}
      
      private void postOrRun(Runnable param2Runnable) {
        if (Thread.currentThread() == this.a.e.getLooper().getThread()) {
          param2Runnable.run();
          return;
        } 
        this.a.e.post(param2Runnable);
      }
      
      boolean a(String param2String) {
        if (this.a.g != this || this.a.f == 0 || this.a.f == 1) {
          if (this.a.f != 0 && this.a.f != 1) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append(param2String);
            stringBuilder.append(" for ");
            stringBuilder.append(this.a.b);
            stringBuilder.append(" with mServiceConnection=");
            stringBuilder.append(this.a.g);
            stringBuilder.append(" this=");
            stringBuilder.append(this);
            Log.i("MediaBrowserCompat", stringBuilder.toString());
          } 
          return false;
        } 
        return true;
      }
      
      public void onServiceConnected(ComponentName param2ComponentName, IBinder param2IBinder) {
        postOrRun(new Runnable(this, param2ComponentName, param2IBinder) {
              public void run() {
                if (MediaBrowserCompat.a) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("MediaServiceConnection.onServiceConnected name=");
                  stringBuilder.append(this.a);
                  stringBuilder.append(" binder=");
                  stringBuilder.append(this.b);
                  Log.d("MediaBrowserCompat", stringBuilder.toString());
                  this.c.a.b();
                } 
                if (!this.c.a("onServiceConnected"))
                  return; 
                this.c.a.h = new MediaBrowserCompat.ServiceBinderWrapper(this.b, this.c.a.d);
                this.c.a.i = new Messenger(this.c.a.e);
                this.c.a.e.setCallbacksMessenger(this.c.a.i);
                this.c.a.f = 2;
                try {
                  if (MediaBrowserCompat.a) {
                    Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
                    this.c.a.b();
                  } 
                  this.c.a.h.a(this.c.a.a, this.c.a.i);
                  return;
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("RemoteException during connect for ");
                  stringBuilder.append(this.c.a.b);
                  Log.w("MediaBrowserCompat", stringBuilder.toString());
                  if (MediaBrowserCompat.a) {
                    Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
                    this.c.a.b();
                  } 
                  return;
                } 
              }
            });
      }
      
      public void onServiceDisconnected(ComponentName param2ComponentName) {
        postOrRun(new Runnable(this, param2ComponentName) {
              public void run() {
                if (MediaBrowserCompat.a) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("MediaServiceConnection.onServiceDisconnected name=");
                  stringBuilder.append(this.a);
                  stringBuilder.append(" this=");
                  stringBuilder.append(this);
                  stringBuilder.append(" mServiceConnection=");
                  stringBuilder.append(this.b.a.g);
                  Log.d("MediaBrowserCompat", stringBuilder.toString());
                  this.b.a.b();
                } 
                if (!this.b.a("onServiceDisconnected"))
                  return; 
                this.b.a.h = null;
                this.b.a.i = null;
                this.b.a.e.setCallbacksMessenger((Messenger)null);
                this.b.a.f = 4;
                this.b.a.c.onConnectionSuspended();
              }
            });
      }
    }
    
    class null implements Runnable {
      null(MediaBrowserCompat.MediaBrowserImplBase this$0, ComponentName param2ComponentName, IBinder param2IBinder) {}
      
      public void run() {
        if (MediaBrowserCompat.a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MediaServiceConnection.onServiceConnected name=");
          stringBuilder.append(this.a);
          stringBuilder.append(" binder=");
          stringBuilder.append(this.b);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
          this.c.a.b();
        } 
        if (!this.c.a("onServiceConnected"))
          return; 
        this.c.a.h = new MediaBrowserCompat.ServiceBinderWrapper(this.b, this.c.a.d);
        this.c.a.i = new Messenger(this.c.a.e);
        this.c.a.e.setCallbacksMessenger(this.c.a.i);
        this.c.a.f = 2;
        try {
          if (MediaBrowserCompat.a) {
            Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
            this.c.a.b();
          } 
          this.c.a.h.a(this.c.a.a, this.c.a.i);
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("RemoteException during connect for ");
          stringBuilder.append(this.c.a.b);
          Log.w("MediaBrowserCompat", stringBuilder.toString());
          if (MediaBrowserCompat.a) {
            Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
            this.c.a.b();
          } 
          return;
        } 
      }
    }
    
    class null implements Runnable {
      null(MediaBrowserCompat.MediaBrowserImplBase this$0, ComponentName param2ComponentName) {}
      
      public void run() {
        if (MediaBrowserCompat.a) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("MediaServiceConnection.onServiceDisconnected name=");
          stringBuilder.append(this.a);
          stringBuilder.append(" this=");
          stringBuilder.append(this);
          stringBuilder.append(" mServiceConnection=");
          stringBuilder.append(this.b.a.g);
          Log.d("MediaBrowserCompat", stringBuilder.toString());
          this.b.a.b();
        } 
        if (!this.b.a("onServiceDisconnected"))
          return; 
        this.b.a.h = null;
        this.b.a.i = null;
        this.b.a.e.setCallbacksMessenger((Messenger)null);
        this.b.a.f = 4;
        this.b.a.c.onConnectionSuspended();
      }
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0) {}
    
    public void run() {
      if (this.a.f == 0)
        return; 
      this.a.f = 2;
      if (!MediaBrowserCompat.a || this.a.g == null) {
        if (this.a.h == null) {
          if (this.a.i == null) {
            boolean bool;
            Intent intent = new Intent("android.media.browse.MediaBrowserService");
            intent.setComponent(this.a.b);
            this.a.g = new MediaBrowserCompat.MediaBrowserImplBase.MediaServiceConnection(this.a);
            try {
              bool = this.a.a.bindService(intent, this.a.g, 1);
            } catch (Exception exception) {
              StringBuilder stringBuilder3 = new StringBuilder();
              stringBuilder3.append("Failed binding to service ");
              stringBuilder3.append(this.a.b);
              Log.e("MediaBrowserCompat", stringBuilder3.toString());
              bool = false;
            } 
            if (!bool) {
              this.a.a();
              this.a.c.onConnectionFailed();
            } 
            if (MediaBrowserCompat.a) {
              Log.d("MediaBrowserCompat", "connect...");
              this.a.b();
            } 
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("mCallbacksMessenger should be null. Instead it is ");
          stringBuilder2.append(this.a.i);
          throw new RuntimeException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("mServiceBinderWrapper should be null. Instead it is ");
        stringBuilder1.append(this.a.h);
        throw new RuntimeException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("mServiceConnection should be null. Instead it is ");
      stringBuilder.append(this.a.g);
      throw new RuntimeException(stringBuilder.toString());
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0) {}
    
    public void run() {
      if (this.a.i != null)
        try {
          this.a.h.a(this.a.i);
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("RemoteException during connect for ");
          stringBuilder.append(this.a.b);
          Log.w("MediaBrowserCompat", stringBuilder.toString());
        }  
      int i = this.a.f;
      this.a.a();
      if (i != 0)
        this.a.f = i; 
      if (MediaBrowserCompat.a) {
        Log.d("MediaBrowserCompat", "disconnect...");
        this.a.b();
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.ItemCallback param1ItemCallback, String param1String) {}
    
    public void run() {
      this.a.onError(this.b);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.ItemCallback param1ItemCallback, String param1String) {}
    
    public void run() {
      this.a.onError(this.b);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.SearchCallback param1SearchCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, MediaBrowserCompat.CustomActionCallback param1CustomActionCallback, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      this.a.onError(this.b, this.c, null);
    }
  }
  
  private class MediaServiceConnection implements ServiceConnection {
    MediaServiceConnection(MediaBrowserCompat this$0) {}
    
    private void postOrRun(Runnable param1Runnable) {
      if (Thread.currentThread() == this.a.e.getLooper().getThread()) {
        param1Runnable.run();
        return;
      } 
      this.a.e.post(param1Runnable);
    }
    
    boolean a(String param1String) {
      if (this.a.g != this || this.a.f == 0 || this.a.f == 1) {
        if (this.a.f != 0 && this.a.f != 1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append(param1String);
          stringBuilder.append(" for ");
          stringBuilder.append(this.a.b);
          stringBuilder.append(" with mServiceConnection=");
          stringBuilder.append(this.a.g);
          stringBuilder.append(" this=");
          stringBuilder.append(this);
          Log.i("MediaBrowserCompat", stringBuilder.toString());
        } 
        return false;
      } 
      return true;
    }
    
    public void onServiceConnected(ComponentName param1ComponentName, IBinder param1IBinder) {
      postOrRun(new Runnable(this, param1ComponentName, param1IBinder) {
            public void run() {
              if (MediaBrowserCompat.a) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MediaServiceConnection.onServiceConnected name=");
                stringBuilder.append(this.a);
                stringBuilder.append(" binder=");
                stringBuilder.append(this.b);
                Log.d("MediaBrowserCompat", stringBuilder.toString());
                this.c.a.b();
              } 
              if (!this.c.a("onServiceConnected"))
                return; 
              this.c.a.h = new MediaBrowserCompat.ServiceBinderWrapper(this.b, this.c.a.d);
              this.c.a.i = new Messenger(this.c.a.e);
              this.c.a.e.setCallbacksMessenger(this.c.a.i);
              this.c.a.f = 2;
              try {
                if (MediaBrowserCompat.a) {
                  Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
                  this.c.a.b();
                } 
                this.c.a.h.a(this.c.a.a, this.c.a.i);
                return;
              } catch (RemoteException remoteException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("RemoteException during connect for ");
                stringBuilder.append(this.c.a.b);
                Log.w("MediaBrowserCompat", stringBuilder.toString());
                if (MediaBrowserCompat.a) {
                  Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
                  this.c.a.b();
                } 
                return;
              } 
            }
          });
    }
    
    public void onServiceDisconnected(ComponentName param1ComponentName) {
      postOrRun(new Runnable(this, param1ComponentName) {
            public void run() {
              if (MediaBrowserCompat.a) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("MediaServiceConnection.onServiceDisconnected name=");
                stringBuilder.append(this.a);
                stringBuilder.append(" this=");
                stringBuilder.append(this);
                stringBuilder.append(" mServiceConnection=");
                stringBuilder.append(this.b.a.g);
                Log.d("MediaBrowserCompat", stringBuilder.toString());
                this.b.a.b();
              } 
              if (!this.b.a("onServiceDisconnected"))
                return; 
              this.b.a.h = null;
              this.b.a.i = null;
              this.b.a.e.setCallbacksMessenger((Messenger)null);
              this.b.a.f = 4;
              this.b.a.c.onConnectionSuspended();
            }
          });
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, ComponentName param1ComponentName, IBinder param1IBinder) {}
    
    public void run() {
      if (MediaBrowserCompat.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MediaServiceConnection.onServiceConnected name=");
        stringBuilder.append(this.a);
        stringBuilder.append(" binder=");
        stringBuilder.append(this.b);
        Log.d("MediaBrowserCompat", stringBuilder.toString());
        this.c.a.b();
      } 
      if (!this.c.a("onServiceConnected"))
        return; 
      this.c.a.h = new MediaBrowserCompat.ServiceBinderWrapper(this.b, this.c.a.d);
      this.c.a.i = new Messenger(this.c.a.e);
      this.c.a.e.setCallbacksMessenger(this.c.a.i);
      this.c.a.f = 2;
      try {
        if (MediaBrowserCompat.a) {
          Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
          this.c.a.b();
        } 
        this.c.a.h.a(this.c.a.a, this.c.a.i);
        return;
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("RemoteException during connect for ");
        stringBuilder.append(this.c.a.b);
        Log.w("MediaBrowserCompat", stringBuilder.toString());
        if (MediaBrowserCompat.a) {
          Log.d("MediaBrowserCompat", "ServiceCallbacks.onConnect...");
          this.c.a.b();
        } 
        return;
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserCompat this$0, ComponentName param1ComponentName) {}
    
    public void run() {
      if (MediaBrowserCompat.a) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MediaServiceConnection.onServiceDisconnected name=");
        stringBuilder.append(this.a);
        stringBuilder.append(" this=");
        stringBuilder.append(this);
        stringBuilder.append(" mServiceConnection=");
        stringBuilder.append(this.b.a.g);
        Log.d("MediaBrowserCompat", stringBuilder.toString());
        this.b.a.b();
      } 
      if (!this.b.a("onServiceDisconnected"))
        return; 
      this.b.a.h = null;
      this.b.a.i = null;
      this.b.a.e.setCallbacksMessenger((Messenger)null);
      this.b.a.f = 4;
      this.b.a.c.onConnectionSuspended();
    }
  }
  
  static interface MediaBrowserServiceCallbackImpl {
    void onConnectionFailed(Messenger param1Messenger);
    
    void onLoadChildren(Messenger param1Messenger, String param1String, List param1List, Bundle param1Bundle);
    
    void onServiceConnected(Messenger param1Messenger, String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle);
  }
  
  public static class MediaItem implements Parcelable {
    public static final Parcelable.Creator<MediaItem> CREATOR = new Parcelable.Creator<MediaItem>() {
        public MediaBrowserCompat.MediaItem createFromParcel(Parcel param2Parcel) {
          return new MediaBrowserCompat.MediaItem(param2Parcel);
        }
        
        public MediaBrowserCompat.MediaItem[] newArray(int param2Int) {
          return new MediaBrowserCompat.MediaItem[param2Int];
        }
      };
    
    public static final int FLAG_BROWSABLE = 1;
    
    public static final int FLAG_PLAYABLE = 2;
    
    private final MediaDescriptionCompat mDescription;
    
    private final int mFlags;
    
    MediaItem(Parcel param1Parcel) {
      this.mFlags = param1Parcel.readInt();
      this.mDescription = (MediaDescriptionCompat)MediaDescriptionCompat.CREATOR.createFromParcel(param1Parcel);
    }
    
    public MediaItem(@NonNull MediaDescriptionCompat param1MediaDescriptionCompat, int param1Int) {
      if (param1MediaDescriptionCompat != null) {
        if (!TextUtils.isEmpty(param1MediaDescriptionCompat.getMediaId())) {
          this.mFlags = param1Int;
          this.mDescription = param1MediaDescriptionCompat;
          return;
        } 
        throw new IllegalArgumentException("description must have a non-empty media id");
      } 
      throw new IllegalArgumentException("description cannot be null");
    }
    
    public static MediaItem fromMediaItem(Object param1Object) {
      if (param1Object == null || Build.VERSION.SDK_INT < 21)
        return null; 
      int i = MediaBrowserCompatApi21.MediaItem.getFlags(param1Object);
      return new MediaItem(MediaDescriptionCompat.fromMediaDescription(MediaBrowserCompatApi21.MediaItem.getDescription(param1Object)), i);
    }
    
    public static List<MediaItem> fromMediaItemList(List<?> param1List) {
      if (param1List == null || Build.VERSION.SDK_INT < 21)
        return null; 
      ArrayList<MediaItem> arrayList = new ArrayList(param1List.size());
      Iterator<?> iterator = param1List.iterator();
      while (iterator.hasNext())
        arrayList.add(fromMediaItem(iterator.next())); 
      return arrayList;
    }
    
    public int describeContents() {
      return 0;
    }
    
    @NonNull
    public MediaDescriptionCompat getDescription() {
      return this.mDescription;
    }
    
    public int getFlags() {
      return this.mFlags;
    }
    
    @Nullable
    public String getMediaId() {
      return this.mDescription.getMediaId();
    }
    
    public boolean isBrowsable() {
      return ((0x1 & this.mFlags) != 0);
    }
    
    public boolean isPlayable() {
      return ((0x2 & this.mFlags) != 0);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder("MediaItem{");
      stringBuilder.append("mFlags=");
      stringBuilder.append(this.mFlags);
      stringBuilder.append(", mDescription=");
      stringBuilder.append(this.mDescription);
      stringBuilder.append('}');
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      param1Parcel.writeInt(this.mFlags);
      this.mDescription.writeToParcel(param1Parcel, param1Int);
    }
    
    @Retention(RetentionPolicy.SOURCE)
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public static @interface Flags {}
  }
  
  static final class null implements Parcelable.Creator<MediaItem> {
    public MediaBrowserCompat.MediaItem createFromParcel(Parcel param1Parcel) {
      return new MediaBrowserCompat.MediaItem(param1Parcel);
    }
    
    public MediaBrowserCompat.MediaItem[] newArray(int param1Int) {
      return new MediaBrowserCompat.MediaItem[param1Int];
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface Flags {}
  
  public static abstract class SearchCallback {
    public void onError(@NonNull String param1String, Bundle param1Bundle) {}
    
    public void onSearchResult(@NonNull String param1String, Bundle param1Bundle, @NonNull List<MediaBrowserCompat.MediaItem> param1List) {}
  }
  
  private static class SearchResultReceiver extends ResultReceiver {
    private final MediaBrowserCompat.SearchCallback mCallback;
    
    private final Bundle mExtras;
    
    private final String mQuery;
    
    SearchResultReceiver(String param1String, Bundle param1Bundle, MediaBrowserCompat.SearchCallback param1SearchCallback, Handler param1Handler) {
      super(param1Handler);
      this.mQuery = param1String;
      this.mExtras = param1Bundle;
      this.mCallback = param1SearchCallback;
    }
    
    protected void onReceiveResult(int param1Int, Bundle param1Bundle) {
      if (param1Bundle != null)
        param1Bundle.setClassLoader(MediaBrowserCompat.class.getClassLoader()); 
      if (param1Int != 0 || param1Bundle == null || !param1Bundle.containsKey("search_results")) {
        this.mCallback.onError(this.mQuery, this.mExtras);
        return;
      } 
      Parcelable[] arrayOfParcelable = param1Bundle.getParcelableArray("search_results");
      ArrayList<MediaBrowserCompat.MediaItem> arrayList = null;
      if (arrayOfParcelable != null) {
        arrayList = new ArrayList();
        int i = arrayOfParcelable.length;
        for (byte b = 0; b < i; b++)
          arrayList.add((MediaBrowserCompat.MediaItem)arrayOfParcelable[b]); 
      } 
      this.mCallback.onSearchResult(this.mQuery, this.mExtras, arrayList);
    }
  }
  
  private static class ServiceBinderWrapper {
    private Messenger mMessenger;
    
    private Bundle mRootHints;
    
    public ServiceBinderWrapper(IBinder param1IBinder, Bundle param1Bundle) {
      this.mMessenger = new Messenger(param1IBinder);
      this.mRootHints = param1Bundle;
    }
    
    private void sendRequest(int param1Int, Bundle param1Bundle, Messenger param1Messenger) {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 1;
      message.setData(param1Bundle);
      message.replyTo = param1Messenger;
      this.mMessenger.send(message);
    }
    
    void a(Context param1Context, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_package_name", param1Context.getPackageName());
      bundle.putBundle("data_root_hints", this.mRootHints);
      sendRequest(1, bundle, param1Messenger);
    }
    
    void a(Messenger param1Messenger) {
      sendRequest(2, null, param1Messenger);
    }
    
    void a(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_search_query", param1String);
      bundle.putBundle("data_search_extras", param1Bundle);
      bundle.putParcelable("data_result_receiver", (Parcelable)param1ResultReceiver);
      sendRequest(8, bundle, param1Messenger);
    }
    
    void a(String param1String, IBinder param1IBinder, Bundle param1Bundle, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      BundleCompat.putBinder(bundle, "data_callback_token", param1IBinder);
      bundle.putBundle("data_options", param1Bundle);
      sendRequest(3, bundle, param1Messenger);
    }
    
    void a(String param1String, IBinder param1IBinder, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      BundleCompat.putBinder(bundle, "data_callback_token", param1IBinder);
      sendRequest(4, bundle, param1Messenger);
    }
    
    void a(String param1String, ResultReceiver param1ResultReceiver, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      bundle.putParcelable("data_result_receiver", (Parcelable)param1ResultReceiver);
      sendRequest(5, bundle, param1Messenger);
    }
    
    void b(Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putBundle("data_root_hints", this.mRootHints);
      sendRequest(6, bundle, param1Messenger);
    }
    
    void b(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, Messenger param1Messenger) {
      Bundle bundle = new Bundle();
      bundle.putString("data_custom_action", param1String);
      bundle.putBundle("data_custom_action_extras", param1Bundle);
      bundle.putParcelable("data_result_receiver", (Parcelable)param1ResultReceiver);
      sendRequest(9, bundle, param1Messenger);
    }
    
    void c(Messenger param1Messenger) {
      sendRequest(7, null, param1Messenger);
    }
  }
  
  private static class Subscription {
    private final List<MediaBrowserCompat.SubscriptionCallback> mCallbacks = new ArrayList<MediaBrowserCompat.SubscriptionCallback>();
    
    private final List<Bundle> mOptionsList = new ArrayList<Bundle>();
    
    public MediaBrowserCompat.SubscriptionCallback getCallback(Context param1Context, Bundle param1Bundle) {
      if (param1Bundle != null)
        param1Bundle.setClassLoader(param1Context.getClassLoader()); 
      for (byte b = 0; b < this.mOptionsList.size(); b++) {
        if (MediaBrowserCompatUtils.areSameOptions(this.mOptionsList.get(b), param1Bundle))
          return this.mCallbacks.get(b); 
      } 
      return null;
    }
    
    public List<MediaBrowserCompat.SubscriptionCallback> getCallbacks() {
      return this.mCallbacks;
    }
    
    public List<Bundle> getOptionsList() {
      return this.mOptionsList;
    }
    
    public boolean isEmpty() {
      return this.mCallbacks.isEmpty();
    }
    
    public void putCallback(Context param1Context, Bundle param1Bundle, MediaBrowserCompat.SubscriptionCallback param1SubscriptionCallback) {
      if (param1Bundle != null)
        param1Bundle.setClassLoader(param1Context.getClassLoader()); 
      for (byte b = 0; b < this.mOptionsList.size(); b++) {
        if (MediaBrowserCompatUtils.areSameOptions(this.mOptionsList.get(b), param1Bundle)) {
          this.mCallbacks.set(b, param1SubscriptionCallback);
          return;
        } 
      } 
      this.mCallbacks.add(param1SubscriptionCallback);
      this.mOptionsList.add(param1Bundle);
    }
  }
  
  public static abstract class SubscriptionCallback {
    WeakReference<MediaBrowserCompat.Subscription> a;
    
    private final Object mSubscriptionCallbackObj;
    
    private final IBinder mToken = (IBinder)new Binder();
    
    public SubscriptionCallback() {
      if (Build.VERSION.SDK_INT >= 26) {
        this.mSubscriptionCallbackObj = MediaBrowserCompatApi26.a(new StubApi26(this));
        return;
      } 
      if (Build.VERSION.SDK_INT >= 21) {
        this.mSubscriptionCallbackObj = MediaBrowserCompatApi21.createSubscriptionCallback(new StubApi21(this));
        return;
      } 
      this.mSubscriptionCallbackObj = null;
    }
    
    private void setSubscription(MediaBrowserCompat.Subscription param1Subscription) {
      this.a = new WeakReference<MediaBrowserCompat.Subscription>(param1Subscription);
    }
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List) {}
    
    public void onChildrenLoaded(@NonNull String param1String, @NonNull List<MediaBrowserCompat.MediaItem> param1List, @NonNull Bundle param1Bundle) {}
    
    public void onError(@NonNull String param1String) {}
    
    public void onError(@NonNull String param1String, @NonNull Bundle param1Bundle) {}
    
    private class StubApi21 implements MediaBrowserCompatApi21.SubscriptionCallback {
      StubApi21(MediaBrowserCompat.SubscriptionCallback this$0) {}
      
      List<MediaBrowserCompat.MediaItem> a(List<MediaBrowserCompat.MediaItem> param2List, Bundle param2Bundle) {
        if (param2List == null)
          return null; 
        int i = param2Bundle.getInt("android.media.browse.extra.PAGE", -1);
        int j = param2Bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
        if (i == -1 && j == -1)
          return param2List; 
        int k = j * i;
        int m = k + j;
        if (i < 0 || j < 1 || k >= param2List.size())
          return Collections.EMPTY_LIST; 
        if (m > param2List.size())
          m = param2List.size(); 
        return param2List.subList(k, m);
      }
      
      public void onChildrenLoaded(@NonNull String param2String, List<?> param2List) {
        MediaBrowserCompat.Subscription subscription;
        if (this.a.a == null) {
          subscription = null;
        } else {
          subscription = this.a.a.get();
        } 
        if (subscription == null) {
          this.a.onChildrenLoaded(param2String, MediaBrowserCompat.MediaItem.fromMediaItemList(param2List));
          return;
        } 
        List<MediaBrowserCompat.MediaItem> list = MediaBrowserCompat.MediaItem.fromMediaItemList(param2List);
        List<MediaBrowserCompat.SubscriptionCallback> list1 = subscription.getCallbacks();
        List<Bundle> list2 = subscription.getOptionsList();
        for (byte b = 0; b < list1.size(); b++) {
          Bundle bundle = list2.get(b);
          if (bundle == null) {
            this.a.onChildrenLoaded(param2String, list);
          } else {
            this.a.onChildrenLoaded(param2String, a(list, bundle), bundle);
          } 
        } 
      }
      
      public void onError(@NonNull String param2String) {
        this.a.onError(param2String);
      }
    }
    
    private class StubApi26 extends StubApi21 implements MediaBrowserCompatApi26.SubscriptionCallback {
      StubApi26(MediaBrowserCompat.SubscriptionCallback this$0) {
        super(this$0);
      }
      
      public void onChildrenLoaded(@NonNull String param2String, List<?> param2List, @NonNull Bundle param2Bundle) {
        this.b.onChildrenLoaded(param2String, MediaBrowserCompat.MediaItem.fromMediaItemList(param2List), param2Bundle);
      }
      
      public void onError(@NonNull String param2String, @NonNull Bundle param2Bundle) {
        this.b.onError(param2String, param2Bundle);
      }
    }
  }
  
  private class StubApi21 implements MediaBrowserCompatApi21.SubscriptionCallback {
    StubApi21(MediaBrowserCompat this$0) {}
    
    List<MediaBrowserCompat.MediaItem> a(List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {
      if (param1List == null)
        return null; 
      int i = param1Bundle.getInt("android.media.browse.extra.PAGE", -1);
      int j = param1Bundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
      if (i == -1 && j == -1)
        return param1List; 
      int k = j * i;
      int m = k + j;
      if (i < 0 || j < 1 || k >= param1List.size())
        return Collections.EMPTY_LIST; 
      if (m > param1List.size())
        m = param1List.size(); 
      return param1List.subList(k, m);
    }
    
    public void onChildrenLoaded(@NonNull String param1String, List<?> param1List) {
      MediaBrowserCompat.Subscription subscription;
      if (this.a.a == null) {
        subscription = null;
      } else {
        subscription = this.a.a.get();
      } 
      if (subscription == null) {
        this.a.onChildrenLoaded(param1String, MediaBrowserCompat.MediaItem.fromMediaItemList(param1List));
        return;
      } 
      List<MediaBrowserCompat.MediaItem> list = MediaBrowserCompat.MediaItem.fromMediaItemList(param1List);
      List<MediaBrowserCompat.SubscriptionCallback> list1 = subscription.getCallbacks();
      List<Bundle> list2 = subscription.getOptionsList();
      for (byte b = 0; b < list1.size(); b++) {
        Bundle bundle = list2.get(b);
        if (bundle == null) {
          this.a.onChildrenLoaded(param1String, list);
        } else {
          this.a.onChildrenLoaded(param1String, a(list, bundle), bundle);
        } 
      } 
    }
    
    public void onError(@NonNull String param1String) {
      this.a.onError(param1String);
    }
  }
  
  private class StubApi26 extends SubscriptionCallback.StubApi21 implements MediaBrowserCompatApi26.SubscriptionCallback {
    StubApi26(MediaBrowserCompat this$0) {
      super((MediaBrowserCompat.SubscriptionCallback)this$0);
    }
    
    public void onChildrenLoaded(@NonNull String param1String, List<?> param1List, @NonNull Bundle param1Bundle) {
      this.b.onChildrenLoaded(param1String, MediaBrowserCompat.MediaItem.fromMediaItemList(param1List), param1Bundle);
    }
    
    public void onError(@NonNull String param1String, @NonNull Bundle param1Bundle) {
      this.b.onError(param1String, param1Bundle);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\MediaBrowserCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */