package android.support.v4.media;

import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.os.Binder;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Messenger;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.RemoteException;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.app.BundleCompat;
import android.support.v4.media.session.IMediaSession;
import android.support.v4.media.session.MediaSessionCompat;
import android.support.v4.os.ResultReceiver;
import android.support.v4.util.ArrayMap;
import android.support.v4.util.Pair;
import android.text.TextUtils;
import android.util.Log;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

public abstract class MediaBrowserServiceCompat extends Service {
  private static final float EPSILON = 1.0E-5F;
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final String KEY_MEDIA_ITEM = "media_item";
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static final String KEY_SEARCH_RESULTS = "search_results";
  
  public static final String SERVICE_INTERFACE = "android.media.browse.MediaBrowserService";
  
  static final boolean a = Log.isLoggable("MBServiceCompat", 3);
  
  final ArrayMap<IBinder, ConnectionRecord> b = new ArrayMap();
  
  ConnectionRecord c;
  
  final ServiceHandler d = new ServiceHandler(this);
  
  MediaSessionCompat.Token e;
  
  private MediaBrowserServiceImpl mImpl;
  
  List<MediaBrowserCompat.MediaItem> a(List<MediaBrowserCompat.MediaItem> paramList, Bundle paramBundle) {
    if (paramList == null)
      return null; 
    int i = paramBundle.getInt("android.media.browse.extra.PAGE", -1);
    int j = paramBundle.getInt("android.media.browse.extra.PAGE_SIZE", -1);
    if (i == -1 && j == -1)
      return paramList; 
    int k = j * i;
    int m = k + j;
    if (i < 0 || j < 1 || k >= paramList.size())
      return Collections.EMPTY_LIST; 
    if (m > paramList.size())
      m = paramList.size(); 
    return paramList.subList(k, m);
  }
  
  void a(String paramString, Bundle paramBundle, ConnectionRecord paramConnectionRecord, ResultReceiver paramResultReceiver) {
    Result<List<MediaBrowserCompat.MediaItem>> result = new Result<List<MediaBrowserCompat.MediaItem>>(this, paramString, paramResultReceiver) {
        void a(List<MediaBrowserCompat.MediaItem> param1List) {
          if ((0x4 & getFlags()) != 0 || param1List == null) {
            this.a.send(-1, null);
            return;
          } 
          Bundle bundle = new Bundle();
          bundle.putParcelableArray("search_results", param1List.<Parcelable>toArray((Parcelable[])new MediaBrowserCompat.MediaItem[0]));
          this.a.send(0, bundle);
        }
      };
    this.c = paramConnectionRecord;
    onSearch(paramString, paramBundle, result);
    this.c = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onSearch must call detach() or sendResult() before returning for query=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void a(String paramString, ConnectionRecord paramConnectionRecord, Bundle paramBundle) {
    Result<List<MediaBrowserCompat.MediaItem>> result = new Result<List<MediaBrowserCompat.MediaItem>>(this, paramString, paramConnectionRecord, paramString, paramBundle) {
        void a(List<MediaBrowserCompat.MediaItem> param1List) {
          if (this.d.b.get(this.a.c.asBinder()) != this.a) {
            if (MediaBrowserServiceCompat.a) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Not sending onLoadChildren result for connection that has been disconnected. pkg=");
              stringBuilder.append(this.a.a);
              stringBuilder.append(" id=");
              stringBuilder.append(this.b);
              Log.d("MBServiceCompat", stringBuilder.toString());
            } 
            return;
          } 
          if ((0x1 & getFlags()) != 0)
            param1List = this.d.a(param1List, this.c); 
          try {
            this.a.c.onLoadChildren(this.b, param1List, this.c);
            return;
          } catch (RemoteException remoteException) {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Calling onLoadChildren() failed for id=");
            stringBuilder.append(this.b);
            stringBuilder.append(" package=");
            stringBuilder.append(this.a.a);
            Log.w("MBServiceCompat", stringBuilder.toString());
            return;
          } 
        }
      };
    this.c = paramConnectionRecord;
    if (paramBundle == null) {
      onLoadChildren(paramString, result);
    } else {
      onLoadChildren(paramString, result, paramBundle);
    } 
    this.c = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadChildren must call detach() or sendResult() before returning for package=");
    stringBuilder.append(paramConnectionRecord.a);
    stringBuilder.append(" id=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  void a(String paramString, ConnectionRecord paramConnectionRecord, IBinder paramIBinder, Bundle paramBundle) {
    List<Pair> list = (List)paramConnectionRecord.e.get(paramString);
    if (list == null)
      list = new ArrayList(); 
    for (Pair pair : list) {
      if (paramIBinder == pair.first && MediaBrowserCompatUtils.areSameOptions(paramBundle, (Bundle)pair.second))
        return; 
    } 
    list.add(new Pair(paramIBinder, paramBundle));
    paramConnectionRecord.e.put(paramString, list);
    a(paramString, paramConnectionRecord, paramBundle);
  }
  
  void a(String paramString, ConnectionRecord paramConnectionRecord, ResultReceiver paramResultReceiver) {
    Result<MediaBrowserCompat.MediaItem> result = new Result<MediaBrowserCompat.MediaItem>(this, paramString, paramResultReceiver) {
        void a(MediaBrowserCompat.MediaItem param1MediaItem) {
          if ((0x2 & getFlags()) != 0) {
            this.a.send(-1, null);
            return;
          } 
          Bundle bundle = new Bundle();
          bundle.putParcelable("media_item", param1MediaItem);
          this.a.send(0, bundle);
        }
      };
    this.c = paramConnectionRecord;
    onLoadItem(paramString, result);
    this.c = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onLoadItem must call detach() or sendResult() before returning for id=");
    stringBuilder.append(paramString);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  boolean a(String paramString, int paramInt) {
    if (paramString == null)
      return false; 
    String[] arrayOfString = getPackageManager().getPackagesForUid(paramInt);
    int i = arrayOfString.length;
    for (byte b = 0; b < i; b++) {
      if (arrayOfString[b].equals(paramString))
        return true; 
    } 
    return false;
  }
  
  boolean a(String paramString, ConnectionRecord paramConnectionRecord, IBinder paramIBinder) {
    if (paramIBinder == null)
      return (paramConnectionRecord.e.remove(paramString) != null); 
    List list = paramConnectionRecord.e.get(paramString);
    boolean bool = false;
    if (list != null) {
      Iterator iterator = list.iterator();
      while (iterator.hasNext()) {
        if (paramIBinder == ((Pair)iterator.next()).first) {
          iterator.remove();
          bool = true;
        } 
      } 
      if (list.size() == 0)
        paramConnectionRecord.e.remove(paramString); 
    } 
    return bool;
  }
  
  void b(String paramString, Bundle paramBundle, ConnectionRecord paramConnectionRecord, ResultReceiver paramResultReceiver) {
    Result<Bundle> result = new Result<Bundle>(this, paramString, paramResultReceiver) {
        void a(Bundle param1Bundle) {
          this.a.send(0, param1Bundle);
        }
        
        void b(Bundle param1Bundle) {
          this.a.send(1, param1Bundle);
        }
        
        void c(Bundle param1Bundle) {
          this.a.send(-1, param1Bundle);
        }
      };
    this.c = paramConnectionRecord;
    onCustomAction(paramString, paramBundle, result);
    this.c = null;
    if (result.isDone())
      return; 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("onCustomAction must call detach() or sendResult() or sendError() before returning for action=");
    stringBuilder.append(paramString);
    stringBuilder.append(" extras=");
    stringBuilder.append(paramBundle);
    throw new IllegalStateException(stringBuilder.toString());
  }
  
  public void dump(FileDescriptor paramFileDescriptor, PrintWriter paramPrintWriter, String[] paramArrayOfString) {}
  
  public final Bundle getBrowserRootHints() {
    return this.mImpl.getBrowserRootHints();
  }
  
  @Nullable
  public MediaSessionCompat.Token getSessionToken() {
    return this.e;
  }
  
  public void notifyChildrenChanged(@NonNull String paramString) {
    if (paramString != null) {
      this.mImpl.notifyChildrenChanged(paramString, null);
      return;
    } 
    throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
  }
  
  public void notifyChildrenChanged(@NonNull String paramString, @NonNull Bundle paramBundle) {
    if (paramString != null) {
      if (paramBundle != null) {
        this.mImpl.notifyChildrenChanged(paramString, paramBundle);
        return;
      } 
      throw new IllegalArgumentException("options cannot be null in notifyChildrenChanged");
    } 
    throw new IllegalArgumentException("parentId cannot be null in notifyChildrenChanged");
  }
  
  public IBinder onBind(Intent paramIntent) {
    return this.mImpl.onBind(paramIntent);
  }
  
  public void onCreate() {
    super.onCreate();
    if (Build.VERSION.SDK_INT >= 26) {
      this.mImpl = new MediaBrowserServiceImplApi26(this);
    } else if (Build.VERSION.SDK_INT >= 23) {
      this.mImpl = new MediaBrowserServiceImplApi23(this);
    } else if (Build.VERSION.SDK_INT >= 21) {
      this.mImpl = new MediaBrowserServiceImplApi21(this);
    } else {
      this.mImpl = new MediaBrowserServiceImplBase(this);
    } 
    this.mImpl.onCreate();
  }
  
  public void onCustomAction(@NonNull String paramString, Bundle paramBundle, @NonNull Result<Bundle> paramResult) {
    paramResult.sendError(null);
  }
  
  @Nullable
  public abstract BrowserRoot onGetRoot(@NonNull String paramString, int paramInt, @Nullable Bundle paramBundle);
  
  public abstract void onLoadChildren(@NonNull String paramString, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult);
  
  public void onLoadChildren(@NonNull String paramString, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult, @NonNull Bundle paramBundle) {
    paramResult.setFlags(1);
    onLoadChildren(paramString, paramResult);
  }
  
  public void onLoadItem(String paramString, @NonNull Result<MediaBrowserCompat.MediaItem> paramResult) {
    paramResult.setFlags(2);
    paramResult.sendResult(null);
  }
  
  public void onSearch(@NonNull String paramString, Bundle paramBundle, @NonNull Result<List<MediaBrowserCompat.MediaItem>> paramResult) {
    paramResult.setFlags(4);
    paramResult.sendResult(null);
  }
  
  public void setSessionToken(MediaSessionCompat.Token paramToken) {
    if (paramToken != null) {
      if (this.e == null) {
        this.e = paramToken;
        this.mImpl.setSessionToken(paramToken);
        return;
      } 
      throw new IllegalStateException("The session token has already been set.");
    } 
    throw new IllegalArgumentException("Session token may not be null.");
  }
  
  public static final class BrowserRoot {
    public static final String EXTRA_OFFLINE = "android.service.media.extra.OFFLINE";
    
    public static final String EXTRA_RECENT = "android.service.media.extra.RECENT";
    
    public static final String EXTRA_SUGGESTED = "android.service.media.extra.SUGGESTED";
    
    @Deprecated
    public static final String EXTRA_SUGGESTION_KEYWORDS = "android.service.media.extra.SUGGESTION_KEYWORDS";
    
    private final Bundle mExtras;
    
    private final String mRootId;
    
    public BrowserRoot(@NonNull String param1String, @Nullable Bundle param1Bundle) {
      if (param1String != null) {
        this.mRootId = param1String;
        this.mExtras = param1Bundle;
        return;
      } 
      throw new IllegalArgumentException("The root id in BrowserRoot cannot be null. Use null for BrowserRoot instead.");
    }
    
    public Bundle getExtras() {
      return this.mExtras;
    }
    
    public String getRootId() {
      return this.mRootId;
    }
  }
  
  private class ConnectionRecord implements IBinder.DeathRecipient {
    String a;
    
    Bundle b;
    
    MediaBrowserServiceCompat.ServiceCallbacks c;
    
    MediaBrowserServiceCompat.BrowserRoot d;
    
    HashMap<String, List<Pair<IBinder, Bundle>>> e = new HashMap<String, List<Pair<IBinder, Bundle>>>();
    
    ConnectionRecord(MediaBrowserServiceCompat this$0) {}
    
    public void binderDied() {
      this.f.d.post(new Runnable(this) {
            public void run() {
              this.a.f.b.remove(this.a.c.asBinder());
            }
          });
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0) {}
    
    public void run() {
      this.a.f.b.remove(this.a.c.asBinder());
    }
  }
  
  static interface MediaBrowserServiceImpl {
    Bundle getBrowserRootHints();
    
    void notifyChildrenChanged(String param1String, Bundle param1Bundle);
    
    IBinder onBind(Intent param1Intent);
    
    void onCreate();
    
    void setSessionToken(MediaSessionCompat.Token param1Token);
  }
  
  @RequiresApi(21)
  class MediaBrowserServiceImplApi21 implements MediaBrowserServiceImpl, MediaBrowserServiceCompatApi21.ServiceCompatProxy {
    final List<Bundle> a = new ArrayList<Bundle>();
    
    Object b;
    
    Messenger c;
    
    MediaBrowserServiceImplApi21(MediaBrowserServiceCompat this$0) {}
    
    void a(String param1String, Bundle param1Bundle) {
      MediaBrowserServiceCompatApi21.notifyChildrenChanged(this.b, param1String);
    }
    
    void b(String param1String, Bundle param1Bundle) {
      this.d.d.post(new Runnable(this, param1String, param1Bundle) {
            public void run() {
              for (IBinder iBinder : this.c.d.b.keySet()) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.c.d.b.get(iBinder);
                List list = connectionRecord.e.get(this.a);
                if (list != null)
                  for (Pair pair : list) {
                    if (MediaBrowserCompatUtils.hasDuplicatedItems(this.b, (Bundle)pair.second))
                      this.c.d.a(this.a, connectionRecord, (Bundle)pair.second); 
                  }  
              } 
            }
          });
    }
    
    public Bundle getBrowserRootHints() {
      if (this.c == null)
        return null; 
      if (this.d.c != null)
        return (this.d.c.b == null) ? null : new Bundle(this.d.c.b); 
      throw new IllegalStateException("This should be called inside of onLoadChildren, onLoadItem or onSearch methods");
    }
    
    public void notifyChildrenChanged(String param1String, Bundle param1Bundle) {
      a(param1String, param1Bundle);
      b(param1String, param1Bundle);
    }
    
    public IBinder onBind(Intent param1Intent) {
      return MediaBrowserServiceCompatApi21.onBind(this.b, param1Intent);
    }
    
    public void onCreate() {
      this.b = MediaBrowserServiceCompatApi21.createService((Context)this.d, this);
      MediaBrowserServiceCompatApi21.onCreate(this.b);
    }
    
    public MediaBrowserServiceCompatApi21.BrowserRoot onGetRoot(String param1String, int param1Int, Bundle param1Bundle) {
      Bundle bundle;
      if (param1Bundle != null && param1Bundle.getInt("extra_client_version", 0) != 0) {
        param1Bundle.remove("extra_client_version");
        this.c = new Messenger(this.d.d);
        bundle = new Bundle();
        bundle.putInt("extra_service_version", 2);
        BundleCompat.putBinder(bundle, "extra_messenger", this.c.getBinder());
        if (this.d.e != null) {
          IBinder iBinder;
          IMediaSession iMediaSession = this.d.e.getExtraBinder();
          if (iMediaSession == null) {
            iBinder = null;
          } else {
            iBinder = iMediaSession.asBinder();
          } 
          BundleCompat.putBinder(bundle, "extra_session_binder", iBinder);
        } else {
          this.a.add(bundle);
        } 
      } else {
        bundle = null;
      } 
      MediaBrowserServiceCompat.BrowserRoot browserRoot = this.d.onGetRoot(param1String, param1Int, param1Bundle);
      if (browserRoot == null)
        return null; 
      if (bundle == null) {
        bundle = browserRoot.getExtras();
      } else if (browserRoot.getExtras() != null) {
        bundle.putAll(browserRoot.getExtras());
      } 
      return new MediaBrowserServiceCompatApi21.BrowserRoot(browserRoot.getRootId(), bundle);
    }
    
    public void onLoadChildren(String param1String, MediaBrowserServiceCompatApi21.ResultWrapper<List<Parcel>> param1ResultWrapper) {
      MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result = new MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>>(this, param1String, param1ResultWrapper) {
          void a(List<MediaBrowserCompat.MediaItem> param2List) {
            Object object;
            if (param2List != null) {
              object = new ArrayList();
              for (MediaBrowserCompat.MediaItem mediaItem : param2List) {
                Parcel parcel = Parcel.obtain();
                mediaItem.writeToParcel(parcel, 0);
                object.add(parcel);
              } 
            } else {
              object = null;
            } 
            this.a.sendResult(object);
          }
          
          public void detach() {
            this.a.detach();
          }
        };
      this.d.onLoadChildren(param1String, result);
    }
    
    public void setSessionToken(MediaSessionCompat.Token param1Token) {
      this.d.d.postOrRun(new Runnable(this, param1Token) {
            public void run() {
              if (!this.b.a.isEmpty()) {
                IMediaSession iMediaSession = this.a.getExtraBinder();
                if (iMediaSession != null) {
                  Iterator<Bundle> iterator = this.b.a.iterator();
                  while (iterator.hasNext())
                    BundleCompat.putBinder(iterator.next(), "extra_session_binder", iMediaSession.asBinder()); 
                } 
                this.b.a.clear();
              } 
              MediaBrowserServiceCompatApi21.setSessionToken(this.b.b, this.a.getToken());
            }
          });
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaSessionCompat.Token param1Token) {}
    
    public void run() {
      if (!this.b.a.isEmpty()) {
        IMediaSession iMediaSession = this.a.getExtraBinder();
        if (iMediaSession != null) {
          Iterator<Bundle> iterator = this.b.a.iterator();
          while (iterator.hasNext())
            BundleCompat.putBinder(iterator.next(), "extra_session_binder", iMediaSession.asBinder()); 
        } 
        this.b.a.clear();
      } 
      MediaBrowserServiceCompatApi21.setSessionToken(this.b.b, this.a.getToken());
    }
  }
  
  class null extends Result<List<MediaBrowserCompat.MediaItem>> {
    null(MediaBrowserServiceCompat this$0, Object param1Object, MediaBrowserServiceCompatApi21.ResultWrapper param1ResultWrapper) {
      super(param1Object);
    }
    
    void a(List<MediaBrowserCompat.MediaItem> param1List) {
      Object object;
      if (param1List != null) {
        object = new ArrayList();
        for (MediaBrowserCompat.MediaItem mediaItem : param1List) {
          Parcel parcel = Parcel.obtain();
          mediaItem.writeToParcel(parcel, 0);
          object.add(parcel);
        } 
      } else {
        object = null;
      } 
      this.a.sendResult(object);
    }
    
    public void detach() {
      this.a.detach();
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      for (IBinder iBinder : this.c.d.b.keySet()) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.c.d.b.get(iBinder);
        List list = connectionRecord.e.get(this.a);
        if (list != null)
          for (Pair pair : list) {
            if (MediaBrowserCompatUtils.hasDuplicatedItems(this.b, (Bundle)pair.second))
              this.c.d.a(this.a, connectionRecord, (Bundle)pair.second); 
          }  
      } 
    }
  }
  
  @RequiresApi(23)
  class MediaBrowserServiceImplApi23 extends MediaBrowserServiceImplApi21 implements MediaBrowserServiceCompatApi23.ServiceCompatProxy {
    MediaBrowserServiceImplApi23(MediaBrowserServiceCompat this$0) {
      super(this$0);
    }
    
    public void onCreate() {
      this.b = MediaBrowserServiceCompatApi23.createService((Context)this.e, this);
      MediaBrowserServiceCompatApi21.onCreate(this.b);
    }
    
    public void onLoadItem(String param1String, MediaBrowserServiceCompatApi21.ResultWrapper<Parcel> param1ResultWrapper) {
      MediaBrowserServiceCompat.Result<MediaBrowserCompat.MediaItem> result = new MediaBrowserServiceCompat.Result<MediaBrowserCompat.MediaItem>(this, param1String, param1ResultWrapper) {
          void a(MediaBrowserCompat.MediaItem param2MediaItem) {
            if (param2MediaItem == null) {
              this.a.sendResult(null);
              return;
            } 
            Parcel parcel = Parcel.obtain();
            param2MediaItem.writeToParcel(parcel, 0);
            this.a.sendResult(parcel);
          }
          
          public void detach() {
            this.a.detach();
          }
        };
      this.e.onLoadItem(param1String, result);
    }
  }
  
  class null extends Result<MediaBrowserCompat.MediaItem> {
    null(MediaBrowserServiceCompat this$0, Object param1Object, MediaBrowserServiceCompatApi21.ResultWrapper param1ResultWrapper) {
      super(param1Object);
    }
    
    void a(MediaBrowserCompat.MediaItem param1MediaItem) {
      if (param1MediaItem == null) {
        this.a.sendResult(null);
        return;
      } 
      Parcel parcel = Parcel.obtain();
      param1MediaItem.writeToParcel(parcel, 0);
      this.a.sendResult(parcel);
    }
    
    public void detach() {
      this.a.detach();
    }
  }
  
  @RequiresApi(26)
  class MediaBrowserServiceImplApi26 extends MediaBrowserServiceImplApi23 implements MediaBrowserServiceCompatApi26.ServiceCompatProxy {
    MediaBrowserServiceImplApi26(MediaBrowserServiceCompat this$0) {
      super(this$0);
    }
    
    void a(String param1String, Bundle param1Bundle) {
      if (param1Bundle != null) {
        MediaBrowserServiceCompatApi26.notifyChildrenChanged(this.b, param1String, param1Bundle);
        return;
      } 
      super.a(param1String, param1Bundle);
    }
    
    public Bundle getBrowserRootHints() {
      return (this.f.c != null) ? ((this.f.c.b == null) ? null : new Bundle(this.f.c.b)) : MediaBrowserServiceCompatApi26.getBrowserRootHints(this.b);
    }
    
    public void onCreate() {
      this.b = MediaBrowserServiceCompatApi26.createService((Context)this.f, this);
      MediaBrowserServiceCompatApi21.onCreate(this.b);
    }
    
    public void onLoadChildren(String param1String, MediaBrowserServiceCompatApi26.ResultWrapper param1ResultWrapper, Bundle param1Bundle) {
      MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>> result = new MediaBrowserServiceCompat.Result<List<MediaBrowserCompat.MediaItem>>(this, param1String, param1ResultWrapper) {
          void a(List<MediaBrowserCompat.MediaItem> param2List) {
            List list;
            if (param2List != null) {
              list = new ArrayList();
              for (MediaBrowserCompat.MediaItem mediaItem : param2List) {
                Parcel parcel = Parcel.obtain();
                mediaItem.writeToParcel(parcel, 0);
                list.add(parcel);
              } 
            } else {
              list = null;
            } 
            this.a.sendResult(list, getFlags());
          }
          
          public void detach() {
            this.a.detach();
          }
        };
      this.f.onLoadChildren(param1String, result, param1Bundle);
    }
  }
  
  class null extends Result<List<MediaBrowserCompat.MediaItem>> {
    null(MediaBrowserServiceCompat this$0, Object param1Object, MediaBrowserServiceCompatApi26.ResultWrapper param1ResultWrapper) {
      super(param1Object);
    }
    
    void a(List<MediaBrowserCompat.MediaItem> param1List) {
      List list;
      if (param1List != null) {
        list = new ArrayList();
        for (MediaBrowserCompat.MediaItem mediaItem : param1List) {
          Parcel parcel = Parcel.obtain();
          mediaItem.writeToParcel(parcel, 0);
          list.add(parcel);
        } 
      } else {
        list = null;
      } 
      this.a.sendResult(list, getFlags());
    }
    
    public void detach() {
      this.a.detach();
    }
  }
  
  class MediaBrowserServiceImplBase implements MediaBrowserServiceImpl {
    private Messenger mMessenger;
    
    MediaBrowserServiceImplBase(MediaBrowserServiceCompat this$0) {}
    
    public Bundle getBrowserRootHints() {
      if (this.a.c != null)
        return (this.a.c.b == null) ? null : new Bundle(this.a.c.b); 
      throw new IllegalStateException("This should be called inside of onLoadChildren, onLoadItem or onSearch methods");
    }
    
    public void notifyChildrenChanged(@NonNull String param1String, Bundle param1Bundle) {
      this.a.d.post(new Runnable(this, param1String, param1Bundle) {
            public void run() {
              for (IBinder iBinder : this.c.a.b.keySet()) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.c.a.b.get(iBinder);
                List list = connectionRecord.e.get(this.a);
                if (list != null)
                  for (Pair pair : list) {
                    if (MediaBrowserCompatUtils.hasDuplicatedItems(this.b, (Bundle)pair.second))
                      this.c.a.a(this.a, connectionRecord, (Bundle)pair.second); 
                  }  
              } 
            }
          });
    }
    
    public IBinder onBind(Intent param1Intent) {
      return "android.media.browse.MediaBrowserService".equals(param1Intent.getAction()) ? this.mMessenger.getBinder() : null;
    }
    
    public void onCreate() {
      this.mMessenger = new Messenger(this.a.d);
    }
    
    public void setSessionToken(MediaSessionCompat.Token param1Token) {
      this.a.d.post(new Runnable(this, param1Token) {
            public void run() {
              Iterator<MediaBrowserServiceCompat.ConnectionRecord> iterator = this.b.a.b.values().iterator();
              while (iterator.hasNext()) {
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = iterator.next();
                try {
                  connectionRecord.c.onConnect(connectionRecord.d.getRootId(), this.a, connectionRecord.d.getExtras());
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("Connection for ");
                  stringBuilder.append(connectionRecord.a);
                  stringBuilder.append(" is no longer valid.");
                  Log.w("MBServiceCompat", stringBuilder.toString());
                  iterator.remove();
                } 
              } 
            }
          });
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaSessionCompat.Token param1Token) {}
    
    public void run() {
      Iterator<MediaBrowserServiceCompat.ConnectionRecord> iterator = this.b.a.b.values().iterator();
      while (iterator.hasNext()) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = iterator.next();
        try {
          connectionRecord.c.onConnect(connectionRecord.d.getRootId(), this.a, connectionRecord.d.getExtras());
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Connection for ");
          stringBuilder.append(connectionRecord.a);
          stringBuilder.append(" is no longer valid.");
          Log.w("MBServiceCompat", stringBuilder.toString());
          iterator.remove();
        } 
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, String param1String, Bundle param1Bundle) {}
    
    public void run() {
      for (IBinder iBinder : this.c.a.b.keySet()) {
        MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.c.a.b.get(iBinder);
        List list = connectionRecord.e.get(this.a);
        if (list != null)
          for (Pair pair : list) {
            if (MediaBrowserCompatUtils.hasDuplicatedItems(this.b, (Bundle)pair.second))
              this.c.a.a(this.a, connectionRecord, (Bundle)pair.second); 
          }  
      } 
    }
  }
  
  public static class Result<T> {
    private final Object mDebug;
    
    private boolean mDetachCalled;
    
    private int mFlags;
    
    private boolean mSendErrorCalled;
    
    private boolean mSendProgressUpdateCalled;
    
    private boolean mSendResultCalled;
    
    Result(Object param1Object) {
      this.mDebug = param1Object;
    }
    
    private void checkExtraFields(Bundle param1Bundle) {
      if (param1Bundle == null)
        return; 
      if (param1Bundle.containsKey("android.media.browse.extra.DOWNLOAD_PROGRESS")) {
        float f = param1Bundle.getFloat("android.media.browse.extra.DOWNLOAD_PROGRESS");
        if (f >= -1.0E-5F && f <= 1.00001F)
          return; 
        throw new IllegalArgumentException("The value of the EXTRA_DOWNLOAD_PROGRESS field must be a float number within [0.0, 1.0].");
      } 
    }
    
    void a(T param1T) {}
    
    void b(Bundle param1Bundle) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("It is not supported to send an interim update for ");
      stringBuilder.append(this.mDebug);
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    void c(Bundle param1Bundle) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("It is not supported to send an error for ");
      stringBuilder.append(this.mDebug);
      throw new UnsupportedOperationException(stringBuilder.toString());
    }
    
    public void detach() {
      if (!this.mDetachCalled) {
        if (!this.mSendResultCalled) {
          if (!this.mSendErrorCalled) {
            this.mDetachCalled = true;
            return;
          } 
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append("detach() called when sendError() had already been called for: ");
          stringBuilder2.append(this.mDebug);
          throw new IllegalStateException(stringBuilder2.toString());
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("detach() called when sendResult() had already been called for: ");
        stringBuilder1.append(this.mDebug);
        throw new IllegalStateException(stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("detach() called when detach() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    int getFlags() {
      return this.mFlags;
    }
    
    boolean isDone() {
      return (this.mDetachCalled || this.mSendResultCalled || this.mSendErrorCalled);
    }
    
    public void sendError(Bundle param1Bundle) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        this.mSendErrorCalled = true;
        c(param1Bundle);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendError() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendProgressUpdate(Bundle param1Bundle) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        checkExtraFields(param1Bundle);
        this.mSendProgressUpdateCalled = true;
        b(param1Bundle);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendProgressUpdate() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    public void sendResult(T param1T) {
      if (!this.mSendResultCalled && !this.mSendErrorCalled) {
        this.mSendResultCalled = true;
        a(param1T);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("sendResult() called when either sendResult() or sendError() had already been called for: ");
      stringBuilder.append(this.mDebug);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    void setFlags(int param1Int) {
      this.mFlags = param1Int;
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  private static @interface ResultFlags {}
  
  private class ServiceBinderImpl {
    ServiceBinderImpl(MediaBrowserServiceCompat this$0) {}
    
    public void addSubscription(String param1String, IBinder param1IBinder, Bundle param1Bundle, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      MediaBrowserServiceCompat.ServiceHandler serviceHandler = this.a.d;
      Runnable runnable = new Runnable(this, param1ServiceCallbacks, param1String, param1IBinder, param1Bundle) {
          public void run() {
            IBinder iBinder = this.a.asBinder();
            MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
            if (connectionRecord == null) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("addSubscription for callback that isn't registered id=");
              stringBuilder.append(this.b);
              Log.w("MBServiceCompat", stringBuilder.toString());
              return;
            } 
            this.e.a.a(this.b, connectionRecord, this.c, this.d);
          }
        };
      serviceHandler.postOrRun(runnable);
    }
    
    public void connect(String param1String, int param1Int, Bundle param1Bundle, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      if (this.a.a(param1String, param1Int)) {
        MediaBrowserServiceCompat.ServiceHandler serviceHandler = this.a.d;
        Runnable runnable = new Runnable(this, param1ServiceCallbacks, param1String, param1Bundle, param1Int) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              this.e.a.b.remove(iBinder);
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(this.e.a);
              connectionRecord.a = this.b;
              connectionRecord.b = this.c;
              connectionRecord.c = this.a;
              connectionRecord.d = this.e.a.onGetRoot(this.b, this.d, this.c);
              if (connectionRecord.d == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("No root for client ");
                stringBuilder.append(this.b);
                stringBuilder.append(" from service ");
                stringBuilder.append(getClass().getName());
                Log.i("MBServiceCompat", stringBuilder.toString());
                try {
                  this.a.onConnectFailed();
                  return;
                } catch (RemoteException remoteException) {
                  StringBuilder stringBuilder1 = new StringBuilder();
                  stringBuilder1.append("Calling onConnectFailed() failed. Ignoring. pkg=");
                  stringBuilder1.append(this.b);
                  Log.w("MBServiceCompat", stringBuilder1.toString());
                  return;
                } 
              } 
              try {
                this.e.a.b.put(iBinder, connectionRecord);
                iBinder.linkToDeath(connectionRecord, 0);
                if (this.e.a.e != null) {
                  this.a.onConnect(connectionRecord.d.getRootId(), this.e.a.e, connectionRecord.d.getExtras());
                  return;
                } 
              } catch (RemoteException remoteException) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("Calling onConnect() failed. Dropping client. pkg=");
                stringBuilder.append(this.b);
                Log.w("MBServiceCompat", stringBuilder.toString());
                this.e.a.b.remove(iBinder);
              } 
            }
          };
        serviceHandler.postOrRun(runnable);
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Package/uid mismatch: uid=");
      stringBuilder.append(param1Int);
      stringBuilder.append(" package=");
      stringBuilder.append(param1String);
      throw new IllegalArgumentException(stringBuilder.toString());
    }
    
    public void disconnect(MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      this.a.d.postOrRun(new Runnable(this, param1ServiceCallbacks) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.b.a.b.remove(iBinder);
              if (connectionRecord != null)
                connectionRecord.c.asBinder().unlinkToDeath(connectionRecord, 0); 
            }
          });
    }
    
    public void getMediaItem(String param1String, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      if (!TextUtils.isEmpty(param1String)) {
        if (param1ResultReceiver == null)
          return; 
        this.a.d.postOrRun(new Runnable(this, param1ServiceCallbacks, param1String, param1ResultReceiver) {
              public void run() {
                IBinder iBinder = this.a.asBinder();
                MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.d.a.b.get(iBinder);
                if (connectionRecord == null) {
                  StringBuilder stringBuilder = new StringBuilder();
                  stringBuilder.append("getMediaItem for callback that isn't registered id=");
                  stringBuilder.append(this.b);
                  Log.w("MBServiceCompat", stringBuilder.toString());
                  return;
                } 
                this.d.a.a(this.b, connectionRecord, this.c);
              }
            });
        return;
      } 
    }
    
    public void registerCallbacks(MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, Bundle param1Bundle) {
      this.a.d.postOrRun(new Runnable(this, param1ServiceCallbacks, param1Bundle) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              this.c.a.b.remove(iBinder);
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(this.c.a);
              connectionRecord.c = this.a;
              connectionRecord.b = this.b;
              this.c.a.b.put(iBinder, connectionRecord);
              try {
                iBinder.linkToDeath(connectionRecord, 0);
                return;
              } catch (RemoteException remoteException) {
                Log.w("MBServiceCompat", "IBinder is already dead.");
                return;
              } 
            }
          });
    }
    
    public void removeSubscription(String param1String, IBinder param1IBinder, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      this.a.d.postOrRun(new Runnable(this, param1ServiceCallbacks, param1String, param1IBinder) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.d.a.b.get(iBinder);
              if (connectionRecord == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("removeSubscription for callback that isn't registered id=");
                stringBuilder.append(this.b);
                Log.w("MBServiceCompat", stringBuilder.toString());
                return;
              } 
              if (!this.d.a.a(this.b, connectionRecord, this.c)) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("removeSubscription called for ");
                stringBuilder.append(this.b);
                stringBuilder.append(" which is not subscribed");
                Log.w("MBServiceCompat", stringBuilder.toString());
              } 
            }
          });
    }
    
    public void search(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      if (!TextUtils.isEmpty(param1String)) {
        if (param1ResultReceiver == null)
          return; 
        MediaBrowserServiceCompat.ServiceHandler serviceHandler = this.a.d;
        Runnable runnable = new Runnable(this, param1ServiceCallbacks, param1String, param1Bundle, param1ResultReceiver) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
              if (connectionRecord == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("search for callback that isn't registered query=");
                stringBuilder.append(this.b);
                Log.w("MBServiceCompat", stringBuilder.toString());
                return;
              } 
              this.e.a.a(this.b, this.c, connectionRecord, this.d);
            }
          };
        serviceHandler.postOrRun(runnable);
        return;
      } 
    }
    
    public void sendCustomAction(String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      if (!TextUtils.isEmpty(param1String)) {
        if (param1ResultReceiver == null)
          return; 
        MediaBrowserServiceCompat.ServiceHandler serviceHandler = this.a.d;
        Runnable runnable = new Runnable(this, param1ServiceCallbacks, param1String, param1Bundle, param1ResultReceiver) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
              if (connectionRecord == null) {
                StringBuilder stringBuilder = new StringBuilder();
                stringBuilder.append("sendCustomAction for callback that isn't registered action=");
                stringBuilder.append(this.b);
                stringBuilder.append(", extras=");
                stringBuilder.append(this.c);
                Log.w("MBServiceCompat", stringBuilder.toString());
                return;
              } 
              this.e.a.b(this.b, this.c, connectionRecord, this.d);
            }
          };
        serviceHandler.postOrRun(runnable);
        return;
      } 
    }
    
    public void unregisterCallbacks(MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {
      this.a.d.postOrRun(new Runnable(this, param1ServiceCallbacks) {
            public void run() {
              IBinder iBinder = this.a.asBinder();
              MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.b.a.b.remove(iBinder);
              if (connectionRecord != null)
                iBinder.unlinkToDeath(connectionRecord, 0); 
            }
          });
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, Bundle param1Bundle, int param1Int) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      this.e.a.b.remove(iBinder);
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(this.e.a);
      connectionRecord.a = this.b;
      connectionRecord.b = this.c;
      connectionRecord.c = this.a;
      connectionRecord.d = this.e.a.onGetRoot(this.b, this.d, this.c);
      if (connectionRecord.d == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("No root for client ");
        stringBuilder.append(this.b);
        stringBuilder.append(" from service ");
        stringBuilder.append(getClass().getName());
        Log.i("MBServiceCompat", stringBuilder.toString());
        try {
          this.a.onConnectFailed();
          return;
        } catch (RemoteException remoteException) {
          StringBuilder stringBuilder1 = new StringBuilder();
          stringBuilder1.append("Calling onConnectFailed() failed. Ignoring. pkg=");
          stringBuilder1.append(this.b);
          Log.w("MBServiceCompat", stringBuilder1.toString());
          return;
        } 
      } 
      try {
        this.e.a.b.put(iBinder, connectionRecord);
        iBinder.linkToDeath(connectionRecord, 0);
        if (this.e.a.e != null) {
          this.a.onConnect(connectionRecord.d.getRootId(), this.e.a.e, connectionRecord.d.getExtras());
          return;
        } 
      } catch (RemoteException remoteException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Calling onConnect() failed. Dropping client. pkg=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        this.e.a.b.remove(iBinder);
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.b.a.b.remove(iBinder);
      if (connectionRecord != null)
        connectionRecord.c.asBinder().unlinkToDeath(connectionRecord, 0); 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, IBinder param1IBinder, Bundle param1Bundle) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
      if (connectionRecord == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("addSubscription for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.a(this.b, connectionRecord, this.c, this.d);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, IBinder param1IBinder) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.d.a.b.get(iBinder);
      if (connectionRecord == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      if (!this.d.a.a(this.b, connectionRecord, this.c)) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("removeSubscription called for ");
        stringBuilder.append(this.b);
        stringBuilder.append(" which is not subscribed");
        Log.w("MBServiceCompat", stringBuilder.toString());
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.d.a.b.get(iBinder);
      if (connectionRecord == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("getMediaItem for callback that isn't registered id=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.d.a.a(this.b, connectionRecord, this.c);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, Bundle param1Bundle) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      this.c.a.b.remove(iBinder);
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = new MediaBrowserServiceCompat.ConnectionRecord(this.c.a);
      connectionRecord.c = this.a;
      connectionRecord.b = this.b;
      this.c.a.b.put(iBinder, connectionRecord);
      try {
        iBinder.linkToDeath(connectionRecord, 0);
        return;
      } catch (RemoteException remoteException) {
        Log.w("MBServiceCompat", "IBinder is already dead.");
        return;
      } 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.b.a.b.remove(iBinder);
      if (connectionRecord != null)
        iBinder.unlinkToDeath(connectionRecord, 0); 
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
      if (connectionRecord == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("search for callback that isn't registered query=");
        stringBuilder.append(this.b);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.a(this.b, this.c, connectionRecord, this.d);
    }
  }
  
  class null implements Runnable {
    null(MediaBrowserServiceCompat this$0, MediaBrowserServiceCompat.ServiceCallbacks param1ServiceCallbacks, String param1String, Bundle param1Bundle, ResultReceiver param1ResultReceiver) {}
    
    public void run() {
      IBinder iBinder = this.a.asBinder();
      MediaBrowserServiceCompat.ConnectionRecord connectionRecord = (MediaBrowserServiceCompat.ConnectionRecord)this.e.a.b.get(iBinder);
      if (connectionRecord == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("sendCustomAction for callback that isn't registered action=");
        stringBuilder.append(this.b);
        stringBuilder.append(", extras=");
        stringBuilder.append(this.c);
        Log.w("MBServiceCompat", stringBuilder.toString());
        return;
      } 
      this.e.a.b(this.b, this.c, connectionRecord, this.d);
    }
  }
  
  private static interface ServiceCallbacks {
    IBinder asBinder();
    
    void onConnect(String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle);
    
    void onConnectFailed();
    
    void onLoadChildren(String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle);
  }
  
  private static class ServiceCallbacksCompat implements ServiceCallbacks {
    final Messenger a;
    
    ServiceCallbacksCompat(Messenger param1Messenger) {
      this.a = param1Messenger;
    }
    
    private void sendRequest(int param1Int, Bundle param1Bundle) {
      Message message = Message.obtain();
      message.what = param1Int;
      message.arg1 = 2;
      message.setData(param1Bundle);
      this.a.send(message);
    }
    
    public IBinder asBinder() {
      return this.a.getBinder();
    }
    
    public void onConnect(String param1String, MediaSessionCompat.Token param1Token, Bundle param1Bundle) {
      if (param1Bundle == null)
        param1Bundle = new Bundle(); 
      param1Bundle.putInt("extra_service_version", 2);
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      bundle.putParcelable("data_media_session_token", (Parcelable)param1Token);
      bundle.putBundle("data_root_hints", param1Bundle);
      sendRequest(1, bundle);
    }
    
    public void onConnectFailed() {
      sendRequest(2, null);
    }
    
    public void onLoadChildren(String param1String, List<MediaBrowserCompat.MediaItem> param1List, Bundle param1Bundle) {
      Bundle bundle = new Bundle();
      bundle.putString("data_media_item_id", param1String);
      bundle.putBundle("data_options", param1Bundle);
      if (param1List != null) {
        ArrayList<MediaBrowserCompat.MediaItem> arrayList;
        if (param1List instanceof ArrayList) {
          arrayList = (ArrayList)param1List;
        } else {
          arrayList = new ArrayList<MediaBrowserCompat.MediaItem>(param1List);
        } 
        bundle.putParcelableArrayList("data_media_item_list", arrayList);
      } 
      sendRequest(3, bundle);
    }
  }
  
  private final class ServiceHandler extends Handler {
    private final MediaBrowserServiceCompat.ServiceBinderImpl mServiceBinderImpl = new MediaBrowserServiceCompat.ServiceBinderImpl(this.a);
    
    ServiceHandler(MediaBrowserServiceCompat this$0) {}
    
    public void handleMessage(Message param1Message) {
      StringBuilder stringBuilder;
      Bundle bundle = param1Message.getData();
      switch (param1Message.what) {
        default:
          stringBuilder = new StringBuilder();
          stringBuilder.append("Unhandled message: ");
          stringBuilder.append(param1Message);
          stringBuilder.append("\n  Service version: ");
          stringBuilder.append(2);
          stringBuilder.append("\n  Client version: ");
          stringBuilder.append(param1Message.arg1);
          Log.w("MBServiceCompat", stringBuilder.toString());
          return;
        case 9:
          this.mServiceBinderImpl.sendCustomAction(bundle.getString("data_custom_action"), bundle.getBundle("data_custom_action_extras"), (ResultReceiver)bundle.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 8:
          this.mServiceBinderImpl.search(bundle.getString("data_search_query"), bundle.getBundle("data_search_extras"), (ResultReceiver)bundle.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 7:
          this.mServiceBinderImpl.unregisterCallbacks(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 6:
          this.mServiceBinderImpl.registerCallbacks(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo), bundle.getBundle("data_root_hints"));
          return;
        case 5:
          this.mServiceBinderImpl.getMediaItem(bundle.getString("data_media_item_id"), (ResultReceiver)bundle.getParcelable("data_result_receiver"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 4:
          this.mServiceBinderImpl.removeSubscription(bundle.getString("data_media_item_id"), BundleCompat.getBinder(bundle, "data_callback_token"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 3:
          this.mServiceBinderImpl.addSubscription(bundle.getString("data_media_item_id"), BundleCompat.getBinder(bundle, "data_callback_token"), bundle.getBundle("data_options"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 2:
          this.mServiceBinderImpl.disconnect(new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
          return;
        case 1:
          break;
      } 
      this.mServiceBinderImpl.connect(bundle.getString("data_package_name"), bundle.getInt("data_calling_uid"), bundle.getBundle("data_root_hints"), new MediaBrowserServiceCompat.ServiceCallbacksCompat(param1Message.replyTo));
    }
    
    public void postOrRun(Runnable param1Runnable) {
      if (Thread.currentThread() == getLooper().getThread()) {
        param1Runnable.run();
        return;
      } 
      post(param1Runnable);
    }
    
    public boolean sendMessageAtTime(Message param1Message, long param1Long) {
      Bundle bundle = param1Message.getData();
      bundle.setClassLoader(MediaBrowserCompat.class.getClassLoader());
      bundle.putInt("data_calling_uid", Binder.getCallingUid());
      return super.sendMessageAtTime(param1Message, param1Long);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\media\MediaBrowserServiceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */