package android.support.v4.widget;

import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.util.Log;
import android.view.View;
import android.widget.PopupWindow;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class PopupWindowCompat {
  static final PopupWindowCompatBaseImpl a = new PopupWindowCompatBaseImpl();
  
  public static boolean getOverlapAnchor(@NonNull PopupWindow paramPopupWindow) {
    return a.getOverlapAnchor(paramPopupWindow);
  }
  
  public static int getWindowLayoutType(@NonNull PopupWindow paramPopupWindow) {
    return a.getWindowLayoutType(paramPopupWindow);
  }
  
  public static void setOverlapAnchor(@NonNull PopupWindow paramPopupWindow, boolean paramBoolean) {
    a.setOverlapAnchor(paramPopupWindow, paramBoolean);
  }
  
  public static void setWindowLayoutType(@NonNull PopupWindow paramPopupWindow, int paramInt) {
    a.setWindowLayoutType(paramPopupWindow, paramInt);
  }
  
  public static void showAsDropDown(@NonNull PopupWindow paramPopupWindow, @NonNull View paramView, int paramInt1, int paramInt2, int paramInt3) {
    a.showAsDropDown(paramPopupWindow, paramView, paramInt1, paramInt2, paramInt3);
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 23) {
      a = new PopupWindowCompatApi23Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 21) {
      a = new PopupWindowCompatApi21Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      a = new PopupWindowCompatApi19Impl();
      return;
    } 
  }
  
  @RequiresApi(19)
  static class PopupWindowCompatApi19Impl extends PopupWindowCompatBaseImpl {
    public void showAsDropDown(PopupWindow param1PopupWindow, View param1View, int param1Int1, int param1Int2, int param1Int3) {
      param1PopupWindow.showAsDropDown(param1View, param1Int1, param1Int2, param1Int3);
    }
  }
  
  @RequiresApi(21)
  static class PopupWindowCompatApi21Impl extends PopupWindowCompatApi19Impl {
    private static final String TAG = "PopupWindowCompatApi21";
    
    private static Field sOverlapAnchorField;
    
    static {
      try {
        sOverlapAnchorField = PopupWindow.class.getDeclaredField("mOverlapAnchor");
        sOverlapAnchorField.setAccessible(true);
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.i("PopupWindowCompatApi21", "Could not fetch mOverlapAnchor field from PopupWindow", noSuchFieldException);
        return;
      } 
    }
    
    public boolean getOverlapAnchor(PopupWindow param1PopupWindow) {
      if (sOverlapAnchorField != null)
        try {
          return ((Boolean)sOverlapAnchorField.get(param1PopupWindow)).booleanValue();
        } catch (IllegalAccessException illegalAccessException) {
          Log.i("PopupWindowCompatApi21", "Could not get overlap anchor field in PopupWindow", illegalAccessException);
        }  
      return false;
    }
    
    public void setOverlapAnchor(PopupWindow param1PopupWindow, boolean param1Boolean) {
      if (sOverlapAnchorField != null)
        try {
          sOverlapAnchorField.set(param1PopupWindow, Boolean.valueOf(param1Boolean));
          return;
        } catch (IllegalAccessException illegalAccessException) {
          Log.i("PopupWindowCompatApi21", "Could not set overlap anchor field in PopupWindow", illegalAccessException);
        }  
    }
  }
  
  @RequiresApi(23)
  static class PopupWindowCompatApi23Impl extends PopupWindowCompatApi21Impl {
    public boolean getOverlapAnchor(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getOverlapAnchor();
    }
    
    public int getWindowLayoutType(PopupWindow param1PopupWindow) {
      return param1PopupWindow.getWindowLayoutType();
    }
    
    public void setOverlapAnchor(PopupWindow param1PopupWindow, boolean param1Boolean) {
      param1PopupWindow.setOverlapAnchor(param1Boolean);
    }
    
    public void setWindowLayoutType(PopupWindow param1PopupWindow, int param1Int) {
      param1PopupWindow.setWindowLayoutType(param1Int);
    }
  }
  
  static class PopupWindowCompatBaseImpl {
    private static Method sGetWindowLayoutTypeMethod;
    
    private static boolean sGetWindowLayoutTypeMethodAttempted;
    
    private static Method sSetWindowLayoutTypeMethod;
    
    private static boolean sSetWindowLayoutTypeMethodAttempted;
    
    public boolean getOverlapAnchor(PopupWindow param1PopupWindow) {
      return false;
    }
    
    public int getWindowLayoutType(PopupWindow param1PopupWindow) {
      if (!sGetWindowLayoutTypeMethodAttempted) {
        try {
          sGetWindowLayoutTypeMethod = PopupWindow.class.getDeclaredMethod("getWindowLayoutType", new Class[0]);
          sGetWindowLayoutTypeMethod.setAccessible(true);
        } catch (Exception exception) {}
        sGetWindowLayoutTypeMethodAttempted = true;
      } 
      return (sGetWindowLayoutTypeMethod != null) ? ((Integer)sGetWindowLayoutTypeMethod.invoke(param1PopupWindow, new Object[0])).intValue() : 0;
    }
    
    public void setOverlapAnchor(PopupWindow param1PopupWindow, boolean param1Boolean) {}
    
    public void setWindowLayoutType(PopupWindow param1PopupWindow, int param1Int) {
      // Byte code:
      //   0: getstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethodAttempted : Z
      //   3: ifne -> 46
      //   6: iconst_1
      //   7: anewarray java/lang/Class
      //   10: astore #8
      //   12: aload #8
      //   14: iconst_0
      //   15: getstatic java/lang/Integer.TYPE : Ljava/lang/Class;
      //   18: aastore
      //   19: ldc android/widget/PopupWindow
      //   21: ldc 'setWindowLayoutType'
      //   23: aload #8
      //   25: invokevirtual getDeclaredMethod : (Ljava/lang/String;[Ljava/lang/Class;)Ljava/lang/reflect/Method;
      //   28: putstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethod : Ljava/lang/reflect/Method;
      //   31: getstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethod : Ljava/lang/reflect/Method;
      //   34: iconst_1
      //   35: invokevirtual setAccessible : (Z)V
      //   38: goto -> 42
      //   41: pop
      //   42: iconst_1
      //   43: putstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethodAttempted : Z
      //   46: getstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethod : Ljava/lang/reflect/Method;
      //   49: ifnull -> 83
      //   52: getstatic android/support/v4/widget/PopupWindowCompat$PopupWindowCompatBaseImpl.sSetWindowLayoutTypeMethod : Ljava/lang/reflect/Method;
      //   55: astore #4
      //   57: iconst_1
      //   58: anewarray java/lang/Object
      //   61: astore #5
      //   63: aload #5
      //   65: iconst_0
      //   66: iload_2
      //   67: invokestatic valueOf : (I)Ljava/lang/Integer;
      //   70: aastore
      //   71: aload #4
      //   73: aload_1
      //   74: aload #5
      //   76: invokevirtual invoke : (Ljava/lang/Object;[Ljava/lang/Object;)Ljava/lang/Object;
      //   79: pop
      //   80: goto -> 84
      //   83: pop
      //   84: return
      // Exception table:
      //   from	to	target	type
      //   6	38	41	java/lang/Exception
      //   52	80	83	java/lang/Exception
    }
    
    public void showAsDropDown(PopupWindow param1PopupWindow, View param1View, int param1Int1, int param1Int2, int param1Int3) {
      if ((0x7 & GravityCompat.getAbsoluteGravity(param1Int3, ViewCompat.getLayoutDirection(param1View))) == 5)
        param1Int1 -= param1PopupWindow.getWidth() - param1View.getWidth(); 
      param1PopupWindow.showAsDropDown(param1View, param1Int1, param1Int2);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\PopupWindowCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */