package android.support.v4.widget;

import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.support.annotation.RestrictTo;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;

@RestrictTo({RestrictTo.Scope.LIBRARY})
public class ViewGroupUtils {
  private static final ThreadLocal<Matrix> sMatrix = new ThreadLocal<Matrix>();
  
  private static final ThreadLocal<RectF> sRectF = new ThreadLocal<RectF>();
  
  static void a(ViewGroup paramViewGroup, View paramView, Rect paramRect) {
    Matrix matrix = sMatrix.get();
    if (matrix == null) {
      matrix = new Matrix();
      sMatrix.set(matrix);
    } else {
      matrix.reset();
    } 
    offsetDescendantMatrix((ViewParent)paramViewGroup, paramView, matrix);
    RectF rectF = sRectF.get();
    if (rectF == null) {
      rectF = new RectF();
      sRectF.set(rectF);
    } 
    rectF.set(paramRect);
    matrix.mapRect(rectF);
    paramRect.set((int)(0.5F + rectF.left), (int)(0.5F + rectF.top), (int)(0.5F + rectF.right), (int)(0.5F + rectF.bottom));
  }
  
  public static void getDescendantRect(ViewGroup paramViewGroup, View paramView, Rect paramRect) {
    paramRect.set(0, 0, paramView.getWidth(), paramView.getHeight());
    a(paramViewGroup, paramView, paramRect);
  }
  
  private static void offsetDescendantMatrix(ViewParent paramViewParent, View paramView, Matrix paramMatrix) {
    ViewParent viewParent = paramView.getParent();
    if (viewParent instanceof View && viewParent != paramViewParent) {
      View view = (View)viewParent;
      offsetDescendantMatrix(paramViewParent, view, paramMatrix);
      paramMatrix.preTranslate(-view.getScrollX(), -view.getScrollY());
    } 
    paramMatrix.preTranslate(paramView.getLeft(), paramView.getTop());
    if (!paramView.getMatrix().isIdentity())
      paramMatrix.preConcat(paramView.getMatrix()); 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\ViewGroupUtils.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */