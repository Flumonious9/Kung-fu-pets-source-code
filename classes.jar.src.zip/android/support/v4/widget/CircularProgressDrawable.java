package android.support.v4.widget;

import android.animation.Animator;
import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Animatable;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.RestrictTo;
import android.support.v4.util.Preconditions;
import android.support.v4.view.animation.FastOutSlowInInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.LinearInterpolator;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public class CircularProgressDrawable extends Drawable implements Animatable {
  private static final int ANIMATION_DURATION = 1332;
  
  private static final int ARROW_HEIGHT = 5;
  
  private static final int ARROW_HEIGHT_LARGE = 6;
  
  private static final int ARROW_WIDTH = 10;
  
  private static final int ARROW_WIDTH_LARGE = 12;
  
  private static final float CENTER_RADIUS = 7.5F;
  
  private static final float CENTER_RADIUS_LARGE = 11.0F;
  
  private static final int[] COLORS;
  
  private static final float COLOR_CHANGE_OFFSET = 0.75F;
  
  public static final int DEFAULT = 1;
  
  private static final float GROUP_FULL_ROTATION = 216.0F;
  
  public static final int LARGE = 0;
  
  private static final Interpolator LINEAR_INTERPOLATOR = (Interpolator)new LinearInterpolator();
  
  private static final Interpolator MATERIAL_INTERPOLATOR = (Interpolator)new FastOutSlowInInterpolator();
  
  private static final float MAX_PROGRESS_ARC = 0.8F;
  
  private static final float MIN_PROGRESS_ARC = 0.01F;
  
  private static final float RING_ROTATION = 0.20999998F;
  
  private static final float SHRINK_OFFSET = 0.5F;
  
  private static final float STROKE_WIDTH = 2.5F;
  
  private static final float STROKE_WIDTH_LARGE = 3.0F;
  
  private Animator mAnimator;
  
  private boolean mFinishing;
  
  private Resources mResources;
  
  private final Ring mRing;
  
  private float mRotation;
  
  private float mRotationCount;
  
  static {
    COLORS = new int[] { -16777216 };
  }
  
  public CircularProgressDrawable(@NonNull Context paramContext) {
    this.mResources = ((Context)Preconditions.checkNotNull(paramContext)).getResources();
    this.mRing = new Ring();
    this.mRing.setColors(COLORS);
    setStrokeWidth(2.5F);
    setupAnimators();
  }
  
  private void applyFinishTranslation(float paramFloat, Ring paramRing) {
    updateRingColor(paramFloat, paramRing);
    float f = (float)(1.0D + Math.floor((paramRing.getStartingRotation() / 0.8F)));
    paramRing.setStartTrim(paramRing.getStartingStartTrim() + paramFloat * (paramRing.getStartingEndTrim() - 0.01F - paramRing.getStartingStartTrim()));
    paramRing.setEndTrim(paramRing.getStartingEndTrim());
    paramRing.setRotation(paramRing.getStartingRotation() + paramFloat * (f - paramRing.getStartingRotation()));
  }
  
  private void applyTransformation(float paramFloat, Ring paramRing, boolean paramBoolean) {
    if (this.mFinishing) {
      applyFinishTranslation(paramFloat, paramRing);
      return;
    } 
    if (paramFloat != 1.0F || paramBoolean) {
      float f2;
      float f3;
      float f1 = paramRing.getStartingRotation();
      if (paramFloat < 0.5F) {
        float f6 = paramFloat / 0.5F;
        float f7 = paramRing.getStartingStartTrim();
        f2 = f7 + 0.01F + 0.79F * MATERIAL_INTERPOLATOR.getInterpolation(f6);
        f3 = f7;
      } else {
        float f = (paramFloat - 0.5F) / 0.5F;
        f2 = 0.79F + paramRing.getStartingStartTrim();
        f3 = f2 - 0.01F + 0.79F * (1.0F - MATERIAL_INTERPOLATOR.getInterpolation(f));
      } 
      float f4 = f1 + 0.20999998F * paramFloat;
      float f5 = 216.0F * (paramFloat + this.mRotationCount);
      paramRing.setStartTrim(f3);
      paramRing.setEndTrim(f2);
      paramRing.setRotation(f4);
      setRotation(f5);
    } 
  }
  
  private int evaluateColorChange(float paramFloat, int paramInt1, int paramInt2) {
    int i = 0xFF & paramInt1 >> 24;
    int j = 0xFF & paramInt1 >> 16;
    int k = 0xFF & paramInt1 >> 8;
    int m = paramInt1 & 0xFF;
    int n = 0xFF & paramInt2 >> 24;
    int i1 = 0xFF & paramInt2 >> 16;
    int i2 = 0xFF & paramInt2 >> 8;
    int i3 = paramInt2 & 0xFF;
    return i + (int)(paramFloat * (n - i)) << 24 | j + (int)(paramFloat * (i1 - j)) << 16 | k + (int)(paramFloat * (i2 - k)) << 8 | m + (int)(paramFloat * (i3 - m));
  }
  
  private float getRotation() {
    return this.mRotation;
  }
  
  private void setRotation(float paramFloat) {
    this.mRotation = paramFloat;
  }
  
  private void setSizeParameters(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4) {
    Ring ring = this.mRing;
    float f = (this.mResources.getDisplayMetrics()).density;
    ring.setStrokeWidth(paramFloat2 * f);
    ring.setCenterRadius(paramFloat1 * f);
    ring.setColorIndex(0);
    ring.a(paramFloat3 * f, paramFloat4 * f);
  }
  
  private void setupAnimators() {
    Ring ring = this.mRing;
    ValueAnimator valueAnimator = ValueAnimator.ofFloat(new float[] { 0.0F, 1.0F });
    valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener(this, ring) {
          public void onAnimationUpdate(ValueAnimator param1ValueAnimator) {
            float f = ((Float)param1ValueAnimator.getAnimatedValue()).floatValue();
            CircularProgressDrawable.a(this.b, f, this.a);
            CircularProgressDrawable.a(this.b, f, this.a, false);
            this.b.invalidateSelf();
          }
        });
    valueAnimator.setRepeatCount(-1);
    valueAnimator.setRepeatMode(1);
    valueAnimator.setInterpolator((TimeInterpolator)LINEAR_INTERPOLATOR);
    valueAnimator.addListener(new Animator.AnimatorListener(this, ring) {
          public void onAnimationCancel(Animator param1Animator) {}
          
          public void onAnimationEnd(Animator param1Animator) {}
          
          public void onAnimationRepeat(Animator param1Animator) {
            CircularProgressDrawable.a(this.b, 1.0F, this.a, true);
            this.a.b();
            this.a.a();
            if (CircularProgressDrawable.a(this.b)) {
              CircularProgressDrawable.a(this.b, false);
              param1Animator.cancel();
              param1Animator.setDuration(1332L);
              param1Animator.start();
              this.a.setShowArrow(false);
              return;
            } 
            CircularProgressDrawable.a(this.b, 1.0F + CircularProgressDrawable.b(this.b));
          }
          
          public void onAnimationStart(Animator param1Animator) {
            CircularProgressDrawable.a(this.b, 0.0F);
          }
        });
    this.mAnimator = (Animator)valueAnimator;
  }
  
  private void updateRingColor(float paramFloat, Ring paramRing) {
    if (paramFloat > 0.75F) {
      paramRing.setColor(evaluateColorChange((paramFloat - 0.75F) / 0.25F, paramRing.getStartingColor(), paramRing.getNextColor()));
      return;
    } 
    paramRing.setColor(paramRing.getStartingColor());
  }
  
  public void draw(Canvas paramCanvas) {
    Rect rect = getBounds();
    paramCanvas.save();
    paramCanvas.rotate(this.mRotation, rect.exactCenterX(), rect.exactCenterY());
    this.mRing.a(paramCanvas, rect);
    paramCanvas.restore();
  }
  
  public int getAlpha() {
    return this.mRing.getAlpha();
  }
  
  public boolean getArrowEnabled() {
    return this.mRing.getShowArrow();
  }
  
  public float getArrowHeight() {
    return this.mRing.getArrowHeight();
  }
  
  public float getArrowScale() {
    return this.mRing.getArrowScale();
  }
  
  public float getArrowWidth() {
    return this.mRing.getArrowWidth();
  }
  
  public int getBackgroundColor() {
    return this.mRing.getBackgroundColor();
  }
  
  public float getCenterRadius() {
    return this.mRing.getCenterRadius();
  }
  
  @NonNull
  public int[] getColorSchemeColors() {
    return this.mRing.getColors();
  }
  
  public float getEndTrim() {
    return this.mRing.getEndTrim();
  }
  
  public int getOpacity() {
    return -3;
  }
  
  public float getProgressRotation() {
    return this.mRing.getRotation();
  }
  
  public float getStartTrim() {
    return this.mRing.getStartTrim();
  }
  
  @NonNull
  public Paint.Cap getStrokeCap() {
    return this.mRing.getStrokeCap();
  }
  
  public float getStrokeWidth() {
    return this.mRing.getStrokeWidth();
  }
  
  public boolean isRunning() {
    return this.mAnimator.isRunning();
  }
  
  public void setAlpha(int paramInt) {
    this.mRing.setAlpha(paramInt);
    invalidateSelf();
  }
  
  public void setArrowDimensions(float paramFloat1, float paramFloat2) {
    this.mRing.a(paramFloat1, paramFloat2);
    invalidateSelf();
  }
  
  public void setArrowEnabled(boolean paramBoolean) {
    this.mRing.setShowArrow(paramBoolean);
    invalidateSelf();
  }
  
  public void setArrowScale(float paramFloat) {
    this.mRing.setArrowScale(paramFloat);
    invalidateSelf();
  }
  
  public void setBackgroundColor(int paramInt) {
    this.mRing.setBackgroundColor(paramInt);
    invalidateSelf();
  }
  
  public void setCenterRadius(float paramFloat) {
    this.mRing.setCenterRadius(paramFloat);
    invalidateSelf();
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.mRing.setColorFilter(paramColorFilter);
    invalidateSelf();
  }
  
  public void setColorSchemeColors(@NonNull int... paramVarArgs) {
    this.mRing.setColors(paramVarArgs);
    this.mRing.setColorIndex(0);
    invalidateSelf();
  }
  
  public void setProgressRotation(float paramFloat) {
    this.mRing.setRotation(paramFloat);
    invalidateSelf();
  }
  
  public void setStartEndTrim(float paramFloat1, float paramFloat2) {
    this.mRing.setStartTrim(paramFloat1);
    this.mRing.setEndTrim(paramFloat2);
    invalidateSelf();
  }
  
  public void setStrokeCap(@NonNull Paint.Cap paramCap) {
    this.mRing.setStrokeCap(paramCap);
    invalidateSelf();
  }
  
  public void setStrokeWidth(float paramFloat) {
    this.mRing.setStrokeWidth(paramFloat);
    invalidateSelf();
  }
  
  public void setStyle(int paramInt) {
    if (paramInt == 0) {
      setSizeParameters(11.0F, 3.0F, 12.0F, 6.0F);
    } else {
      setSizeParameters(7.5F, 2.5F, 10.0F, 5.0F);
    } 
    invalidateSelf();
  }
  
  public void start() {
    this.mAnimator.cancel();
    this.mRing.b();
    if (this.mRing.getEndTrim() != this.mRing.getStartTrim()) {
      this.mFinishing = true;
      this.mAnimator.setDuration(666L);
      this.mAnimator.start();
      return;
    } 
    this.mRing.setColorIndex(0);
    this.mRing.c();
    this.mAnimator.setDuration(1332L);
    this.mAnimator.start();
  }
  
  public void stop() {
    this.mAnimator.cancel();
    setRotation(0.0F);
    this.mRing.setShowArrow(false);
    this.mRing.setColorIndex(0);
    this.mRing.c();
    invalidateSelf();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface ProgressDrawableSize {}
  
  private static class Ring {
    final RectF a = new RectF();
    
    final Paint b = new Paint();
    
    final Paint c = new Paint();
    
    final Paint d = new Paint();
    
    float e = 0.0F;
    
    float f = 0.0F;
    
    float g = 0.0F;
    
    float h = 5.0F;
    
    int[] i;
    
    int j;
    
    float k;
    
    float l;
    
    float m;
    
    boolean n;
    
    Path o;
    
    float p = 1.0F;
    
    float q;
    
    int r;
    
    int s;
    
    int t = 255;
    
    int u;
    
    Ring() {
      this.b.setStrokeCap(Paint.Cap.SQUARE);
      this.b.setAntiAlias(true);
      this.b.setStyle(Paint.Style.STROKE);
      this.c.setStyle(Paint.Style.FILL);
      this.c.setAntiAlias(true);
      this.d.setColor(0);
    }
    
    void a() {
      setColorIndex(getNextColorIndex());
    }
    
    void a(float param1Float1, float param1Float2) {
      this.r = (int)param1Float1;
      this.s = (int)param1Float2;
    }
    
    void a(Canvas param1Canvas, float param1Float1, float param1Float2, RectF param1RectF) {
      if (this.n) {
        if (this.o == null) {
          this.o = new Path();
          this.o.setFillType(Path.FillType.EVEN_ODD);
        } else {
          this.o.reset();
        } 
        float f1 = Math.min(param1RectF.width(), param1RectF.height()) / 2.0F;
        float f2 = this.r * this.p / 2.0F;
        this.o.moveTo(0.0F, 0.0F);
        this.o.lineTo(this.r * this.p, 0.0F);
        this.o.lineTo(this.r * this.p / 2.0F, this.s * this.p);
        this.o.offset(f1 + param1RectF.centerX() - f2, param1RectF.centerY() + this.h / 2.0F);
        this.o.close();
        this.c.setColor(this.u);
        this.c.setAlpha(this.t);
        param1Canvas.save();
        param1Canvas.rotate(param1Float1 + param1Float2, param1RectF.centerX(), param1RectF.centerY());
        param1Canvas.drawPath(this.o, this.c);
        param1Canvas.restore();
      } 
    }
    
    void a(Canvas param1Canvas, Rect param1Rect) {
      RectF rectF = this.a;
      float f1 = this.q + this.h / 2.0F;
      if (this.q <= 0.0F)
        f1 = Math.min(param1Rect.width(), param1Rect.height()) / 2.0F - Math.max(this.r * this.p / 2.0F, this.h / 2.0F); 
      rectF.set(param1Rect.centerX() - f1, param1Rect.centerY() - f1, f1 + param1Rect.centerX(), f1 + param1Rect.centerY());
      float f2 = 360.0F * (this.e + this.g);
      float f3 = 360.0F * (this.f + this.g) - f2;
      this.b.setColor(this.u);
      this.b.setAlpha(this.t);
      float f4 = this.h / 2.0F;
      rectF.inset(f4, f4);
      param1Canvas.drawCircle(rectF.centerX(), rectF.centerY(), rectF.width() / 2.0F, this.d);
      float f5 = -f4;
      rectF.inset(f5, f5);
      param1Canvas.drawArc(rectF, f2, f3, false, this.b);
      a(param1Canvas, f2, f3, rectF);
    }
    
    void b() {
      this.k = this.e;
      this.l = this.f;
      this.m = this.g;
    }
    
    void c() {
      this.k = 0.0F;
      this.l = 0.0F;
      this.m = 0.0F;
      setStartTrim(0.0F);
      setEndTrim(0.0F);
      setRotation(0.0F);
    }
    
    int getAlpha() {
      return this.t;
    }
    
    float getArrowHeight() {
      return this.s;
    }
    
    float getArrowScale() {
      return this.p;
    }
    
    float getArrowWidth() {
      return this.r;
    }
    
    int getBackgroundColor() {
      return this.d.getColor();
    }
    
    float getCenterRadius() {
      return this.q;
    }
    
    int[] getColors() {
      return this.i;
    }
    
    float getEndTrim() {
      return this.f;
    }
    
    int getNextColor() {
      return this.i[getNextColorIndex()];
    }
    
    int getNextColorIndex() {
      return (1 + this.j) % this.i.length;
    }
    
    float getRotation() {
      return this.g;
    }
    
    boolean getShowArrow() {
      return this.n;
    }
    
    float getStartTrim() {
      return this.e;
    }
    
    int getStartingColor() {
      return this.i[this.j];
    }
    
    float getStartingEndTrim() {
      return this.l;
    }
    
    float getStartingRotation() {
      return this.m;
    }
    
    float getStartingStartTrim() {
      return this.k;
    }
    
    Paint.Cap getStrokeCap() {
      return this.b.getStrokeCap();
    }
    
    float getStrokeWidth() {
      return this.h;
    }
    
    void setAlpha(int param1Int) {
      this.t = param1Int;
    }
    
    void setArrowScale(float param1Float) {
      if (param1Float != this.p)
        this.p = param1Float; 
    }
    
    void setBackgroundColor(int param1Int) {
      this.d.setColor(param1Int);
    }
    
    void setCenterRadius(float param1Float) {
      this.q = param1Float;
    }
    
    void setColor(int param1Int) {
      this.u = param1Int;
    }
    
    void setColorFilter(ColorFilter param1ColorFilter) {
      this.b.setColorFilter(param1ColorFilter);
    }
    
    void setColorIndex(int param1Int) {
      this.j = param1Int;
      this.u = this.i[this.j];
    }
    
    void setColors(@NonNull int[] param1ArrayOfint) {
      this.i = param1ArrayOfint;
      setColorIndex(0);
    }
    
    void setEndTrim(float param1Float) {
      this.f = param1Float;
    }
    
    void setRotation(float param1Float) {
      this.g = param1Float;
    }
    
    void setShowArrow(boolean param1Boolean) {
      if (this.n != param1Boolean)
        this.n = param1Boolean; 
    }
    
    void setStartTrim(float param1Float) {
      this.e = param1Float;
    }
    
    void setStrokeCap(Paint.Cap param1Cap) {
      this.b.setStrokeCap(param1Cap);
    }
    
    void setStrokeWidth(float param1Float) {
      this.h = param1Float;
      this.b.setStrokeWidth(param1Float);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\CircularProgressDrawable.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */