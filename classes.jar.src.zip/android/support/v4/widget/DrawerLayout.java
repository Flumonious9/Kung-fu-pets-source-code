package android.support.v4.widget;

import android.annotation.TargetApi;
import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.WindowInsets;
import android.view.accessibility.AccessibilityEvent;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.List;

public class DrawerLayout extends ViewGroup {
  private static final boolean ALLOW_EDGE_LOCK = false;
  
  private static final boolean CHILDREN_DISALLOW_INTERCEPT = true;
  
  private static final int DEFAULT_SCRIM_COLOR = -1728053248;
  
  private static final int DRAWER_ELEVATION = 10;
  
  public static final int LOCK_MODE_LOCKED_CLOSED = 1;
  
  public static final int LOCK_MODE_LOCKED_OPEN = 2;
  
  public static final int LOCK_MODE_UNDEFINED = 3;
  
  public static final int LOCK_MODE_UNLOCKED = 0;
  
  private static final int MIN_DRAWER_MARGIN = 64;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  private static final int PEEK_DELAY = 160;
  
  private static final boolean SET_DRAWER_SHADOW_FROM_ELEVATION = false;
  
  public static final int STATE_DRAGGING = 1;
  
  public static final int STATE_IDLE = 0;
  
  public static final int STATE_SETTLING = 2;
  
  private static final String TAG = "DrawerLayout";
  
  private static final int[] THEME_ATTRS;
  
  private static final float TOUCH_SLOP_SENSITIVITY = 1.0F;
  
  static final int[] a;
  
  static final boolean b;
  
  private final ChildAccessibilityDelegate mChildAccessibilityDelegate = new ChildAccessibilityDelegate();
  
  private boolean mChildrenCanceledTouch;
  
  private boolean mDisallowInterceptRequested;
  
  private boolean mDrawStatusBarBackground;
  
  private float mDrawerElevation;
  
  private int mDrawerState;
  
  private boolean mFirstLayout = true;
  
  private boolean mInLayout;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private Object mLastInsets;
  
  private final ViewDragCallback mLeftCallback;
  
  private final ViewDragHelper mLeftDragger;
  
  @Nullable
  private DrawerListener mListener;
  
  private List<DrawerListener> mListeners;
  
  private int mLockModeEnd = 3;
  
  private int mLockModeLeft = 3;
  
  private int mLockModeRight = 3;
  
  private int mLockModeStart = 3;
  
  private int mMinDrawerMargin;
  
  private final ArrayList<View> mNonDrawerViews;
  
  private final ViewDragCallback mRightCallback;
  
  private final ViewDragHelper mRightDragger;
  
  private int mScrimColor = -1728053248;
  
  private float mScrimOpacity;
  
  private Paint mScrimPaint = new Paint();
  
  private Drawable mShadowEnd = null;
  
  private Drawable mShadowLeft = null;
  
  private Drawable mShadowLeftResolved;
  
  private Drawable mShadowRight = null;
  
  private Drawable mShadowRightResolved;
  
  private Drawable mShadowStart = null;
  
  private Drawable mStatusBarBackground;
  
  private CharSequence mTitleLeft;
  
  private CharSequence mTitleRight;
  
  static {
    boolean bool2;
    boolean bool1 = true;
    int[] arrayOfInt1 = new int[bool1];
    arrayOfInt1[0] = 16843828;
    THEME_ATTRS = arrayOfInt1;
    int[] arrayOfInt2 = new int[bool1];
    arrayOfInt2[0] = 16842931;
    a = arrayOfInt2;
    if (Build.VERSION.SDK_INT >= 19) {
      bool2 = true;
    } else {
      bool2 = false;
    } 
    b = bool2;
    if (Build.VERSION.SDK_INT < 21)
      bool1 = false; 
    SET_DRAWER_SHADOW_FROM_ELEVATION = bool1;
  }
  
  public DrawerLayout(@NonNull Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public DrawerLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public DrawerLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    setDescendantFocusability(262144);
    float f1 = (getResources().getDisplayMetrics()).density;
    this.mMinDrawerMargin = (int)(0.5F + 64.0F * f1);
    float f2 = 400.0F * f1;
    this.mLeftCallback = new ViewDragCallback(this, 3);
    this.mRightCallback = new ViewDragCallback(this, 5);
    this.mLeftDragger = ViewDragHelper.create(this, 1.0F, this.mLeftCallback);
    this.mLeftDragger.setEdgeTrackingEnabled(1);
    this.mLeftDragger.setMinVelocity(f2);
    this.mLeftCallback.setDragger(this.mLeftDragger);
    this.mRightDragger = ViewDragHelper.create(this, 1.0F, this.mRightCallback);
    this.mRightDragger.setEdgeTrackingEnabled(2);
    this.mRightDragger.setMinVelocity(f2);
    this.mRightCallback.setDragger(this.mRightDragger);
    setFocusableInTouchMode(true);
    ViewCompat.setImportantForAccessibility((View)this, 1);
    ViewCompat.setAccessibilityDelegate((View)this, new AccessibilityDelegate(this));
    setMotionEventSplittingEnabled(false);
    if (ViewCompat.getFitsSystemWindows((View)this))
      if (Build.VERSION.SDK_INT >= 21) {
        setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener(this) {
              @TargetApi(21)
              public WindowInsets onApplyWindowInsets(View param1View, WindowInsets param1WindowInsets) {
                boolean bool;
                DrawerLayout drawerLayout = (DrawerLayout)param1View;
                if (param1WindowInsets.getSystemWindowInsetTop() > 0) {
                  bool = true;
                } else {
                  bool = false;
                } 
                drawerLayout.setChildInsets(param1WindowInsets, bool);
                return param1WindowInsets.consumeSystemWindowInsets();
              }
            });
        setSystemUiVisibility(1280);
        TypedArray typedArray = paramContext.obtainStyledAttributes(THEME_ATTRS);
        try {
          this.mStatusBarBackground = typedArray.getDrawable(0);
        } finally {
          typedArray.recycle();
        } 
      } else {
        this.mStatusBarBackground = null;
      }  
    this.mDrawerElevation = f1 * 10.0F;
    this.mNonDrawerViews = new ArrayList<View>();
  }
  
  static String b(int paramInt) {
    return ((paramInt & 0x3) == 3) ? "LEFT" : (((paramInt & 0x5) == 5) ? "RIGHT" : Integer.toHexString(paramInt));
  }
  
  static boolean g(View paramView) {
    return (ViewCompat.getImportantForAccessibility(paramView) != 4 && ViewCompat.getImportantForAccessibility(paramView) != 2);
  }
  
  private static boolean hasOpaqueBackground(View paramView) {
    Drawable drawable = paramView.getBackground();
    if (drawable != null) {
      int i = drawable.getOpacity();
      boolean bool = false;
      if (i == -1)
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  private boolean hasPeekingDrawer() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      if (((LayoutParams)getChildAt(b).getLayoutParams()).b)
        return true; 
    } 
    return false;
  }
  
  private boolean hasVisibleDrawer() {
    return (b() != null);
  }
  
  private boolean mirror(Drawable paramDrawable, int paramInt) {
    if (paramDrawable == null || !DrawableCompat.isAutoMirrored(paramDrawable))
      return false; 
    DrawableCompat.setLayoutDirection(paramDrawable, paramInt);
    return true;
  }
  
  private Drawable resolveLeftShadow() {
    int i = ViewCompat.getLayoutDirection((View)this);
    if (i == 0) {
      if (this.mShadowStart != null) {
        mirror(this.mShadowStart, i);
        return this.mShadowStart;
      } 
    } else if (this.mShadowEnd != null) {
      mirror(this.mShadowEnd, i);
      return this.mShadowEnd;
    } 
    return this.mShadowLeft;
  }
  
  private Drawable resolveRightShadow() {
    int i = ViewCompat.getLayoutDirection((View)this);
    if (i == 0) {
      if (this.mShadowEnd != null) {
        mirror(this.mShadowEnd, i);
        return this.mShadowEnd;
      } 
    } else if (this.mShadowStart != null) {
      mirror(this.mShadowStart, i);
      return this.mShadowStart;
    } 
    return this.mShadowRight;
  }
  
  private void resolveShadowDrawables() {
    if (SET_DRAWER_SHADOW_FROM_ELEVATION)
      return; 
    this.mShadowLeftResolved = resolveLeftShadow();
    this.mShadowRightResolved = resolveRightShadow();
  }
  
  private void updateChildrenImportantForAccessibility(View paramView, boolean paramBoolean) {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if ((!paramBoolean && !f(view)) || (paramBoolean && view == paramView)) {
        ViewCompat.setImportantForAccessibility(view, 1);
      } else {
        ViewCompat.setImportantForAccessibility(view, 4);
      } 
    } 
  }
  
  View a() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if ((0x1 & ((LayoutParams)view.getLayoutParams()).c) == 1)
        return view; 
    } 
    return null;
  }
  
  View a(int paramInt) {
    int i = 0x7 & GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    int j = getChildCount();
    for (byte b = 0; b < j; b++) {
      View view = getChildAt(b);
      if ((0x7 & d(view)) == i)
        return view; 
    } 
    return null;
  }
  
  void a(int paramInt1, int paramInt2, View paramView) {
    int i = this.mLeftDragger.getViewDragState();
    int j = this.mRightDragger.getViewDragState();
    byte b = 2;
    if (i == 1 || j == 1) {
      b = 1;
    } else if (i != b && j != b) {
      b = 0;
    } 
    if (paramView != null && paramInt2 == 0) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      if (layoutParams.a == 0.0F) {
        a(paramView);
      } else if (layoutParams.a == 1.0F) {
        b(paramView);
      } 
    } 
    if (b != this.mDrawerState) {
      this.mDrawerState = b;
      if (this.mListeners != null)
        for (int k = this.mListeners.size() - 1; k >= 0; k--)
          ((DrawerListener)this.mListeners.get(k)).onDrawerStateChanged(b);  
    } 
  }
  
  void a(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((0x1 & layoutParams.c) == 1) {
      layoutParams.c = 0;
      if (this.mListeners != null)
        for (int i = this.mListeners.size() - 1; i >= 0; i--)
          ((DrawerListener)this.mListeners.get(i)).onDrawerClosed(paramView);  
      updateChildrenImportantForAccessibility(paramView, false);
      if (hasWindowFocus()) {
        View view = getRootView();
        if (view != null)
          view.sendAccessibilityEvent(32); 
      } 
    } 
  }
  
  void a(View paramView, float paramFloat) {
    if (this.mListeners != null)
      for (int i = -1 + this.mListeners.size(); i >= 0; i--)
        ((DrawerListener)this.mListeners.get(i)).onDrawerSlide(paramView, paramFloat);  
  }
  
  void a(boolean paramBoolean) {
    int i = getChildCount();
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      View view = getChildAt(b);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (f(view) && (!paramBoolean || layoutParams.b)) {
        int j = view.getWidth();
        if (a(view, 3)) {
          bool |= this.mLeftDragger.smoothSlideViewTo(view, -j, view.getTop());
        } else {
          bool |= this.mRightDragger.smoothSlideViewTo(view, getWidth(), view.getTop());
        } 
        layoutParams.b = false;
      } 
      b++;
    } 
    this.mLeftCallback.removeCallbacks();
    this.mRightCallback.removeCallbacks();
    if (bool)
      invalidate(); 
  }
  
  boolean a(View paramView, int paramInt) {
    return ((paramInt & d(paramView)) == paramInt);
  }
  
  public void addDrawerListener(@NonNull DrawerListener paramDrawerListener) {
    if (paramDrawerListener == null)
      return; 
    if (this.mListeners == null)
      this.mListeners = new ArrayList<DrawerListener>(); 
    this.mListeners.add(paramDrawerListener);
  }
  
  public void addFocusables(ArrayList<View> paramArrayList, int paramInt1, int paramInt2) {
    if (getDescendantFocusability() == 393216)
      return; 
    int i = getChildCount();
    byte b1 = 0;
    byte b2 = 0;
    boolean bool = false;
    while (b2 < i) {
      View view = getChildAt(b2);
      if (f(view)) {
        if (isDrawerOpen(view)) {
          view.addFocusables(paramArrayList, paramInt1, paramInt2);
          bool = true;
        } 
      } else {
        this.mNonDrawerViews.add(view);
      } 
      b2++;
    } 
    if (!bool) {
      int j = this.mNonDrawerViews.size();
      while (b1 < j) {
        View view = this.mNonDrawerViews.get(b1);
        if (view.getVisibility() == 0)
          view.addFocusables(paramArrayList, paramInt1, paramInt2); 
        b1++;
      } 
    } 
    this.mNonDrawerViews.clear();
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    super.addView(paramView, paramInt, paramLayoutParams);
    if (a() != null || f(paramView)) {
      ViewCompat.setImportantForAccessibility(paramView, 4);
    } else {
      ViewCompat.setImportantForAccessibility(paramView, 1);
    } 
    if (!b)
      ViewCompat.setAccessibilityDelegate(paramView, this.mChildAccessibilityDelegate); 
  }
  
  View b() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (f(view) && isDrawerVisible(view))
        return view; 
    } 
    return null;
  }
  
  void b(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if ((0x1 & layoutParams.c) == 0) {
      layoutParams.c = 1;
      if (this.mListeners != null)
        for (int i = this.mListeners.size() - 1; i >= 0; i--)
          ((DrawerListener)this.mListeners.get(i)).onDrawerOpened(paramView);  
      updateChildrenImportantForAccessibility(paramView, true);
      if (hasWindowFocus())
        sendAccessibilityEvent(32); 
    } 
  }
  
  void b(View paramView, float paramFloat) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat == layoutParams.a)
      return; 
    layoutParams.a = paramFloat;
    a(paramView, paramFloat);
  }
  
  float c(View paramView) {
    return ((LayoutParams)paramView.getLayoutParams()).a;
  }
  
  void c() {
    if (!this.mChildrenCanceledTouch) {
      long l = SystemClock.uptimeMillis();
      MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
      int i = getChildCount();
      for (byte b = 0; b < i; b++)
        getChildAt(b).dispatchTouchEvent(motionEvent); 
      motionEvent.recycle();
      this.mChildrenCanceledTouch = true;
    } 
  }
  
  void c(View paramView, float paramFloat) {
    float f1 = c(paramView);
    float f2 = paramView.getWidth();
    int i = (int)(f1 * f2);
    int j = (int)(f2 * paramFloat) - i;
    if (!a(paramView, 3))
      j = -j; 
    paramView.offsetLeftAndRight(j);
    b(paramView, paramFloat);
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void closeDrawer(int paramInt) {
    closeDrawer(paramInt, true);
  }
  
  public void closeDrawer(int paramInt, boolean paramBoolean) {
    View view = a(paramInt);
    if (view != null) {
      closeDrawer(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(b(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void closeDrawer(@NonNull View paramView) {
    closeDrawer(paramView, true);
  }
  
  public void closeDrawer(@NonNull View paramView, boolean paramBoolean) {
    if (f(paramView)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      if (this.mFirstLayout) {
        layoutParams.a = 0.0F;
        layoutParams.c = 0;
      } else if (paramBoolean) {
        layoutParams.c = 0x4 | layoutParams.c;
        if (a(paramView, 3)) {
          this.mLeftDragger.smoothSlideViewTo(paramView, -paramView.getWidth(), paramView.getTop());
        } else {
          this.mRightDragger.smoothSlideViewTo(paramView, getWidth(), paramView.getTop());
        } 
      } else {
        c(paramView, 0.0F);
        a(layoutParams.gravity, 0, paramView);
        paramView.setVisibility(4);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void closeDrawers() {
    a(false);
  }
  
  public void computeScroll() {
    int i = getChildCount();
    float f = 0.0F;
    for (byte b = 0; b < i; b++)
      f = Math.max(f, ((LayoutParams)getChildAt(b).getLayoutParams()).a); 
    this.mScrimOpacity = f;
    boolean bool1 = this.mLeftDragger.continueSettling(true);
    boolean bool2 = this.mRightDragger.continueSettling(true);
    if (bool1 || bool2)
      ViewCompat.postInvalidateOnAnimation((View)this); 
  }
  
  int d(View paramView) {
    return GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection((View)this));
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    int n;
    int i = getHeight();
    boolean bool1 = e(paramView);
    int j = getWidth();
    int k = paramCanvas.save();
    int m = 0;
    if (bool1) {
      int i1 = getChildCount();
      n = j;
      byte b = 0;
      int i2 = 0;
      while (b < i1) {
        View view = getChildAt(b);
        if (view != paramView && view.getVisibility() == 0 && hasOpaqueBackground(view) && f(view) && view.getHeight() >= i)
          if (a(view, 3)) {
            int i3 = view.getRight();
            if (i3 > i2)
              i2 = i3; 
          } else {
            int i3 = view.getLeft();
            if (i3 < n)
              n = i3; 
          }  
        b++;
      } 
      paramCanvas.clipRect(i2, 0, n, getHeight());
      m = i2;
    } else {
      n = j;
    } 
    boolean bool2 = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(k);
    if (this.mScrimOpacity > 0.0F && bool1) {
      int i1 = (int)(((0xFF000000 & this.mScrimColor) >>> 24) * this.mScrimOpacity) << 24 | 0xFFFFFF & this.mScrimColor;
      this.mScrimPaint.setColor(i1);
      paramCanvas.drawRect(m, 0.0F, n, getHeight(), this.mScrimPaint);
      return bool2;
    } 
    if (this.mShadowLeftResolved != null && a(paramView, 3)) {
      int i1 = this.mShadowLeftResolved.getIntrinsicWidth();
      int i2 = paramView.getRight();
      int i3 = this.mLeftDragger.getEdgeSize();
      float f = Math.max(0.0F, Math.min(i2 / i3, 1.0F));
      this.mShadowLeftResolved.setBounds(i2, paramView.getTop(), i1 + i2, paramView.getBottom());
      this.mShadowLeftResolved.setAlpha((int)(f * 255.0F));
      this.mShadowLeftResolved.draw(paramCanvas);
      return bool2;
    } 
    if (this.mShadowRightResolved != null && a(paramView, 5)) {
      int i1 = this.mShadowRightResolved.getIntrinsicWidth();
      int i2 = paramView.getLeft();
      int i3 = getWidth() - i2;
      int i4 = this.mRightDragger.getEdgeSize();
      float f = Math.max(0.0F, Math.min(i3 / i4, 1.0F));
      this.mShadowRightResolved.setBounds(i2 - i1, paramView.getTop(), i2, paramView.getBottom());
      this.mShadowRightResolved.setAlpha((int)(f * 255.0F));
      this.mShadowRightResolved.draw(paramCanvas);
    } 
    return bool2;
  }
  
  boolean e(View paramView) {
    return (((LayoutParams)paramView.getLayoutParams()).gravity == 0);
  }
  
  boolean f(View paramView) {
    int i = GravityCompat.getAbsoluteGravity(((LayoutParams)paramView.getLayoutParams()).gravity, ViewCompat.getLayoutDirection(paramView));
    return ((i & 0x3) != 0) ? true : (((i & 0x5) != 0));
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new LayoutParams(-1, -1);
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof LayoutParams) ? new LayoutParams((LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams)));
  }
  
  public float getDrawerElevation() {
    return SET_DRAWER_SHADOW_FROM_ELEVATION ? this.mDrawerElevation : 0.0F;
  }
  
  public int getDrawerLockMode(int paramInt) {
    int i = ViewCompat.getLayoutDirection((View)this);
    if (paramInt != 3) {
      if (paramInt != 5) {
        if (paramInt != 8388611) {
          if (paramInt == 8388613) {
            int j;
            if (this.mLockModeEnd != 3)
              return this.mLockModeEnd; 
            if (i == 0) {
              j = this.mLockModeRight;
            } else {
              j = this.mLockModeLeft;
            } 
            if (j != 3)
              return j; 
          } 
        } else {
          int j;
          if (this.mLockModeStart != 3)
            return this.mLockModeStart; 
          if (i == 0) {
            j = this.mLockModeLeft;
          } else {
            j = this.mLockModeRight;
          } 
          if (j != 3)
            return j; 
        } 
      } else {
        int j;
        if (this.mLockModeRight != 3)
          return this.mLockModeRight; 
        if (i == 0) {
          j = this.mLockModeEnd;
        } else {
          j = this.mLockModeStart;
        } 
        if (j != 3)
          return j; 
      } 
    } else {
      int j;
      if (this.mLockModeLeft != 3)
        return this.mLockModeLeft; 
      if (i == 0) {
        j = this.mLockModeStart;
      } else {
        j = this.mLockModeEnd;
      } 
      if (j != 3)
        return j; 
    } 
    return 0;
  }
  
  public int getDrawerLockMode(@NonNull View paramView) {
    if (f(paramView))
      return getDrawerLockMode(((LayoutParams)paramView.getLayoutParams()).gravity); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  @Nullable
  public CharSequence getDrawerTitle(int paramInt) {
    int i = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    return (i == 3) ? this.mTitleLeft : ((i == 5) ? this.mTitleRight : null);
  }
  
  @Nullable
  public Drawable getStatusBarBackgroundDrawable() {
    return this.mStatusBarBackground;
  }
  
  public boolean isDrawerOpen(int paramInt) {
    View view = a(paramInt);
    return (view != null) ? isDrawerOpen(view) : false;
  }
  
  public boolean isDrawerOpen(@NonNull View paramView) {
    if (f(paramView))
      return ((0x1 & ((LayoutParams)paramView.getLayoutParams()).c) == 1); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public boolean isDrawerVisible(int paramInt) {
    View view = a(paramInt);
    return (view != null) ? isDrawerVisible(view) : false;
  }
  
  public boolean isDrawerVisible(@NonNull View paramView) {
    if (f(paramView))
      return (((LayoutParams)paramView.getLayoutParams()).a > 0.0F); 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null) {
      boolean bool;
      if (Build.VERSION.SDK_INT >= 21 && this.mLastInsets != null) {
        bool = ((WindowInsets)this.mLastInsets).getSystemWindowInsetTop();
      } else {
        bool = false;
      } 
      if (bool) {
        this.mStatusBarBackground.setBounds(0, 0, getWidth(), bool);
        this.mStatusBarBackground.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   9: aload_1
    //   10: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   13: aload_0
    //   14: getfield mRightDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   17: aload_1
    //   18: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   21: ior
    //   22: istore_3
    //   23: iconst_1
    //   24: istore #4
    //   26: iload_2
    //   27: tableswitch default -> 56, 0 -> 106, 1 -> 87, 2 -> 59, 3 -> 87
    //   56: goto -> 190
    //   59: aload_0
    //   60: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   63: iconst_3
    //   64: invokevirtual checkTouchSlop : (I)Z
    //   67: ifeq -> 190
    //   70: aload_0
    //   71: getfield mLeftCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   74: invokevirtual removeCallbacks : ()V
    //   77: aload_0
    //   78: getfield mRightCallback : Landroid/support/v4/widget/DrawerLayout$ViewDragCallback;
    //   81: invokevirtual removeCallbacks : ()V
    //   84: goto -> 190
    //   87: aload_0
    //   88: iload #4
    //   90: invokevirtual a : (Z)V
    //   93: aload_0
    //   94: iconst_0
    //   95: putfield mDisallowInterceptRequested : Z
    //   98: aload_0
    //   99: iconst_0
    //   100: putfield mChildrenCanceledTouch : Z
    //   103: goto -> 190
    //   106: aload_1
    //   107: invokevirtual getX : ()F
    //   110: fstore #5
    //   112: aload_1
    //   113: invokevirtual getY : ()F
    //   116: fstore #6
    //   118: aload_0
    //   119: fload #5
    //   121: putfield mInitialMotionX : F
    //   124: aload_0
    //   125: fload #6
    //   127: putfield mInitialMotionY : F
    //   130: aload_0
    //   131: getfield mScrimOpacity : F
    //   134: fconst_0
    //   135: fcmpl
    //   136: ifle -> 174
    //   139: aload_0
    //   140: getfield mLeftDragger : Landroid/support/v4/widget/ViewDragHelper;
    //   143: fload #5
    //   145: f2i
    //   146: fload #6
    //   148: f2i
    //   149: invokevirtual findTopChildUnder : (II)Landroid/view/View;
    //   152: astore #8
    //   154: aload #8
    //   156: ifnull -> 174
    //   159: aload_0
    //   160: aload #8
    //   162: invokevirtual e : (Landroid/view/View;)Z
    //   165: ifeq -> 174
    //   168: iconst_1
    //   169: istore #7
    //   171: goto -> 177
    //   174: iconst_0
    //   175: istore #7
    //   177: aload_0
    //   178: iconst_0
    //   179: putfield mDisallowInterceptRequested : Z
    //   182: aload_0
    //   183: iconst_0
    //   184: putfield mChildrenCanceledTouch : Z
    //   187: goto -> 193
    //   190: iconst_0
    //   191: istore #7
    //   193: iload_3
    //   194: ifne -> 222
    //   197: iload #7
    //   199: ifne -> 222
    //   202: aload_0
    //   203: invokespecial hasPeekingDrawer : ()Z
    //   206: ifne -> 222
    //   209: aload_0
    //   210: getfield mChildrenCanceledTouch : Z
    //   213: ifeq -> 219
    //   216: iload #4
    //   218: ireturn
    //   219: iconst_0
    //   220: istore #4
    //   222: iload #4
    //   224: ireturn
  }
  
  public boolean onKeyDown(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4 && hasVisibleDrawer()) {
      paramKeyEvent.startTracking();
      return true;
    } 
    return super.onKeyDown(paramInt, paramKeyEvent);
  }
  
  public boolean onKeyUp(int paramInt, KeyEvent paramKeyEvent) {
    if (paramInt == 4) {
      View view = b();
      if (view != null && getDrawerLockMode(view) == 0)
        closeDrawers(); 
      return (view != null);
    } 
    return super.onKeyUp(paramInt, paramKeyEvent);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    this.mInLayout = true;
    int i = paramInt3 - paramInt1;
    int j = getChildCount();
    for (byte b = 0; b < j; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (e(view)) {
          view.layout(layoutParams.leftMargin, layoutParams.topMargin, layoutParams.leftMargin + view.getMeasuredWidth(), layoutParams.topMargin + view.getMeasuredHeight());
        } else {
          float f;
          int n;
          boolean bool;
          byte b1;
          int k = view.getMeasuredWidth();
          int m = view.getMeasuredHeight();
          if (a(view, 3)) {
            int i2 = -k;
            float f1 = k;
            n = i2 + (int)(f1 * layoutParams.a);
            f = (k + n) / f1;
          } else {
            float f1 = k;
            int i2 = i - (int)(f1 * layoutParams.a);
            f = (i - i2) / f1;
            n = i2;
          } 
          if (f != layoutParams.a) {
            bool = true;
          } else {
            bool = false;
          } 
          int i1 = 0x70 & layoutParams.gravity;
          if (i1 != 16) {
            if (i1 != 80) {
              view.layout(n, layoutParams.topMargin, k + n, m + layoutParams.topMargin);
            } else {
              int i2 = paramInt4 - paramInt2;
              view.layout(n, i2 - layoutParams.bottomMargin - view.getMeasuredHeight(), k + n, i2 - layoutParams.bottomMargin);
            } 
          } else {
            int i2 = paramInt4 - paramInt2;
            int i3 = (i2 - m) / 2;
            if (i3 < layoutParams.topMargin) {
              i3 = layoutParams.topMargin;
            } else if (i3 + m > i2 - layoutParams.bottomMargin) {
              i3 = i2 - layoutParams.bottomMargin - m;
            } 
            view.layout(n, i3, k + n, m + i3);
          } 
          if (bool)
            b(view, f); 
          if (layoutParams.a > 0.0F) {
            b1 = 0;
          } else {
            b1 = 4;
          } 
          if (view.getVisibility() != b1)
            view.setVisibility(b1); 
        } 
      } 
    } 
    this.mInLayout = false;
    this.mFirstLayout = false;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    boolean bool1;
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getMode(paramInt2);
    int k = View.MeasureSpec.getSize(paramInt1);
    int m = View.MeasureSpec.getSize(paramInt2);
    if (i != 1073741824 || j != 1073741824)
      if (isInEditMode()) {
        if (i != Integer.MIN_VALUE && i == 0)
          k = 300; 
        if (j != Integer.MIN_VALUE && j == 0)
          m = 300; 
      } else {
        throw new IllegalArgumentException("DrawerLayout must be measured with MeasureSpec.EXACTLY.");
      }  
    setMeasuredDimension(k, m);
    if (this.mLastInsets != null && ViewCompat.getFitsSystemWindows((View)this)) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    int n = ViewCompat.getLayoutDirection((View)this);
    int i1 = getChildCount();
    byte b = 0;
    boolean bool2 = false;
    boolean bool3 = false;
    while (b < i1) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (bool1) {
          int i2 = GravityCompat.getAbsoluteGravity(layoutParams.gravity, n);
          if (ViewCompat.getFitsSystemWindows(view)) {
            if (Build.VERSION.SDK_INT >= 21) {
              WindowInsets windowInsets = (WindowInsets)this.mLastInsets;
              if (i2 == 3) {
                windowInsets = windowInsets.replaceSystemWindowInsets(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), 0, windowInsets.getSystemWindowInsetBottom());
              } else if (i2 == 5) {
                windowInsets = windowInsets.replaceSystemWindowInsets(0, windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
              } 
              view.dispatchApplyWindowInsets(windowInsets);
            } 
          } else if (Build.VERSION.SDK_INT >= 21) {
            WindowInsets windowInsets = (WindowInsets)this.mLastInsets;
            if (i2 == 3) {
              windowInsets = windowInsets.replaceSystemWindowInsets(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), 0, windowInsets.getSystemWindowInsetBottom());
            } else if (i2 == 5) {
              windowInsets = windowInsets.replaceSystemWindowInsets(0, windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
            } 
            layoutParams.leftMargin = windowInsets.getSystemWindowInsetLeft();
            layoutParams.topMargin = windowInsets.getSystemWindowInsetTop();
            layoutParams.rightMargin = windowInsets.getSystemWindowInsetRight();
            layoutParams.bottomMargin = windowInsets.getSystemWindowInsetBottom();
          } 
        } 
        if (e(view)) {
          view.measure(View.MeasureSpec.makeMeasureSpec(k - layoutParams.leftMargin - layoutParams.rightMargin, 1073741824), View.MeasureSpec.makeMeasureSpec(m - layoutParams.topMargin - layoutParams.bottomMargin, 1073741824));
        } else if (f(view)) {
          boolean bool;
          if (SET_DRAWER_SHADOW_FROM_ELEVATION && ViewCompat.getElevation(view) != this.mDrawerElevation)
            ViewCompat.setElevation(view, this.mDrawerElevation); 
          int i2 = 0x7 & d(view);
          if (i2 == 3) {
            bool = true;
          } else {
            bool = false;
          } 
          if ((!bool || !bool2) && (bool || !bool3)) {
            if (bool) {
              bool2 = true;
            } else {
              bool3 = true;
            } 
            view.measure(getChildMeasureSpec(paramInt1, this.mMinDrawerMargin + layoutParams.leftMargin + layoutParams.rightMargin, layoutParams.width), getChildMeasureSpec(paramInt2, layoutParams.topMargin + layoutParams.bottomMargin, layoutParams.height));
          } else {
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("Child drawer has absolute gravity ");
            stringBuilder.append(b(i2));
            stringBuilder.append(" but this ");
            stringBuilder.append("DrawerLayout");
            stringBuilder.append(" already has a ");
            stringBuilder.append("drawer view along that edge");
            throw new IllegalStateException(stringBuilder.toString());
          } 
        } else {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Child ");
          stringBuilder.append(view);
          stringBuilder.append(" at index ");
          stringBuilder.append(b);
          stringBuilder.append(" does not have a valid layout_gravity - must be Gravity.LEFT, ");
          stringBuilder.append("Gravity.RIGHT or Gravity.NO_GRAVITY");
          throw new IllegalStateException(stringBuilder.toString());
        } 
      } 
      b++;
    } 
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.a != 0) {
      View view = a(savedState.a);
      if (view != null)
        openDrawer(view); 
    } 
    if (savedState.b != 3)
      setDrawerLockMode(savedState.b, 3); 
    if (savedState.c != 3)
      setDrawerLockMode(savedState.c, 5); 
    if (savedState.d != 3)
      setDrawerLockMode(savedState.d, 8388611); 
    if (savedState.e != 3)
      setDrawerLockMode(savedState.e, 8388613); 
  }
  
  public void onRtlPropertiesChanged(int paramInt) {
    resolveShadowDrawables();
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      boolean bool;
      LayoutParams layoutParams = (LayoutParams)getChildAt(b).getLayoutParams();
      int j = layoutParams.c;
      byte b1 = 1;
      if (j == b1) {
        bool = true;
      } else {
        bool = false;
      } 
      if (layoutParams.c != 2)
        b1 = 0; 
      if (bool || b1 != 0) {
        savedState.a = layoutParams.gravity;
        break;
      } 
    } 
    savedState.b = this.mLockModeLeft;
    savedState.c = this.mLockModeRight;
    savedState.d = this.mLockModeStart;
    savedState.e = this.mLockModeEnd;
    return (Parcelable)savedState;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    this.mLeftDragger.processTouchEvent(paramMotionEvent);
    this.mRightDragger.processTouchEvent(paramMotionEvent);
    int i = 0xFF & paramMotionEvent.getAction();
    if (i != 3) {
      float f3;
      float f4;
      View view;
      boolean bool;
      switch (i) {
        default:
          return true;
        case 1:
          f3 = paramMotionEvent.getX();
          f4 = paramMotionEvent.getY();
          view = this.mLeftDragger.findTopChildUnder((int)f3, (int)f4);
          if (view != null && e(view)) {
            float f5 = f3 - this.mInitialMotionX;
            float f6 = f4 - this.mInitialMotionY;
            int j = this.mLeftDragger.getTouchSlop();
            if (f5 * f5 + f6 * f6 < (j * j)) {
              View view1 = a();
              if (view1 == null || getDrawerLockMode(view1) == 2) {
                boolean bool2 = true;
                a(bool2);
                this.mDisallowInterceptRequested = false;
                return true;
              } 
              boolean bool1 = false;
              a(bool1);
              this.mDisallowInterceptRequested = false;
              return true;
            } 
          } 
          bool = true;
          a(bool);
          this.mDisallowInterceptRequested = false;
          return true;
        case 0:
          break;
      } 
      float f1 = paramMotionEvent.getX();
      float f2 = paramMotionEvent.getY();
      this.mInitialMotionX = f1;
      this.mInitialMotionY = f2;
      this.mDisallowInterceptRequested = false;
      this.mChildrenCanceledTouch = false;
      return true;
    } 
    a(true);
    this.mDisallowInterceptRequested = false;
    this.mChildrenCanceledTouch = false;
    return true;
  }
  
  public void openDrawer(int paramInt) {
    openDrawer(paramInt, true);
  }
  
  public void openDrawer(int paramInt, boolean paramBoolean) {
    View view = a(paramInt);
    if (view != null) {
      openDrawer(view, paramBoolean);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("No drawer view found with gravity ");
    stringBuilder.append(b(paramInt));
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void openDrawer(@NonNull View paramView) {
    openDrawer(paramView, true);
  }
  
  public void openDrawer(@NonNull View paramView, boolean paramBoolean) {
    if (f(paramView)) {
      LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
      if (this.mFirstLayout) {
        layoutParams.a = 1.0F;
        layoutParams.c = 1;
        updateChildrenImportantForAccessibility(paramView, true);
      } else if (paramBoolean) {
        layoutParams.c = 0x2 | layoutParams.c;
        if (a(paramView, 3)) {
          this.mLeftDragger.smoothSlideViewTo(paramView, 0, paramView.getTop());
        } else {
          this.mRightDragger.smoothSlideViewTo(paramView, getWidth() - paramView.getWidth(), paramView.getTop());
        } 
      } else {
        c(paramView, 1.0F);
        a(layoutParams.gravity, 0, paramView);
        paramView.setVisibility(0);
      } 
      invalidate();
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a sliding drawer");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void removeDrawerListener(@NonNull DrawerListener paramDrawerListener) {
    if (paramDrawerListener == null)
      return; 
    if (this.mListeners == null)
      return; 
    this.mListeners.remove(paramDrawerListener);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    this.mDisallowInterceptRequested = paramBoolean;
    if (paramBoolean)
      a(true); 
  }
  
  public void requestLayout() {
    if (!this.mInLayout)
      super.requestLayout(); 
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public void setChildInsets(Object paramObject, boolean paramBoolean) {
    boolean bool;
    this.mLastInsets = paramObject;
    this.mDrawStatusBarBackground = paramBoolean;
    if (!paramBoolean && getBackground() == null) {
      bool = true;
    } else {
      bool = false;
    } 
    setWillNotDraw(bool);
    requestLayout();
  }
  
  public void setDrawerElevation(float paramFloat) {
    this.mDrawerElevation = paramFloat;
    for (byte b = 0; b < getChildCount(); b++) {
      View view = getChildAt(b);
      if (f(view))
        ViewCompat.setElevation(view, this.mDrawerElevation); 
    } 
  }
  
  @Deprecated
  public void setDrawerListener(DrawerListener paramDrawerListener) {
    if (this.mListener != null)
      removeDrawerListener(this.mListener); 
    if (paramDrawerListener != null)
      addDrawerListener(paramDrawerListener); 
    this.mListener = paramDrawerListener;
  }
  
  public void setDrawerLockMode(int paramInt) {
    setDrawerLockMode(paramInt, 3);
    setDrawerLockMode(paramInt, 5);
  }
  
  public void setDrawerLockMode(int paramInt1, int paramInt2) {
    View view2;
    int i = GravityCompat.getAbsoluteGravity(paramInt2, ViewCompat.getLayoutDirection((View)this));
    if (paramInt2 != 3) {
      if (paramInt2 != 5) {
        if (paramInt2 != 8388611) {
          if (paramInt2 == 8388613)
            this.mLockModeEnd = paramInt1; 
        } else {
          this.mLockModeStart = paramInt1;
        } 
      } else {
        this.mLockModeRight = paramInt1;
      } 
    } else {
      this.mLockModeLeft = paramInt1;
    } 
    if (paramInt1 != 0) {
      ViewDragHelper viewDragHelper;
      if (i == 3) {
        viewDragHelper = this.mLeftDragger;
      } else {
        viewDragHelper = this.mRightDragger;
      } 
      viewDragHelper.cancel();
    } 
    switch (paramInt1) {
      default:
        return;
      case 2:
        view2 = a(i);
        if (view2 != null) {
          openDrawer(view2);
          return;
        } 
        return;
      case 1:
        break;
    } 
    View view1 = a(i);
    if (view1 != null)
      closeDrawer(view1); 
  }
  
  public void setDrawerLockMode(int paramInt, @NonNull View paramView) {
    if (f(paramView)) {
      setDrawerLockMode(paramInt, ((LayoutParams)paramView.getLayoutParams()).gravity);
      return;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("View ");
    stringBuilder.append(paramView);
    stringBuilder.append(" is not a ");
    stringBuilder.append("drawer with appropriate layout_gravity");
    throw new IllegalArgumentException(stringBuilder.toString());
  }
  
  public void setDrawerShadow(@DrawableRes int paramInt1, int paramInt2) {
    setDrawerShadow(ContextCompat.getDrawable(getContext(), paramInt1), paramInt2);
  }
  
  public void setDrawerShadow(Drawable paramDrawable, int paramInt) {
    if (SET_DRAWER_SHADOW_FROM_ELEVATION)
      return; 
    if ((paramInt & 0x800003) == 8388611) {
      this.mShadowStart = paramDrawable;
    } else if ((paramInt & 0x800005) == 8388613) {
      this.mShadowEnd = paramDrawable;
    } else if ((paramInt & 0x3) == 3) {
      this.mShadowLeft = paramDrawable;
    } else if ((paramInt & 0x5) == 5) {
      this.mShadowRight = paramDrawable;
    } else {
      return;
    } 
    resolveShadowDrawables();
    invalidate();
  }
  
  public void setDrawerTitle(int paramInt, @Nullable CharSequence paramCharSequence) {
    int i = GravityCompat.getAbsoluteGravity(paramInt, ViewCompat.getLayoutDirection((View)this));
    if (i == 3) {
      this.mTitleLeft = paramCharSequence;
      return;
    } 
    if (i == 5)
      this.mTitleRight = paramCharSequence; 
  }
  
  public void setScrimColor(@ColorInt int paramInt) {
    this.mScrimColor = paramInt;
    invalidate();
  }
  
  public void setStatusBarBackground(int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = ContextCompat.getDrawable(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    this.mStatusBarBackground = drawable;
    invalidate();
  }
  
  public void setStatusBarBackground(@Nullable Drawable paramDrawable) {
    this.mStatusBarBackground = paramDrawable;
    invalidate();
  }
  
  public void setStatusBarBackgroundColor(@ColorInt int paramInt) {
    this.mStatusBarBackground = (Drawable)new ColorDrawable(paramInt);
    invalidate();
  }
  
  class AccessibilityDelegate extends AccessibilityDelegateCompat {
    private final Rect mTmpRect = new Rect();
    
    AccessibilityDelegate(DrawerLayout this$0) {}
    
    private void addChildrenForAccessibility(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat, ViewGroup param1ViewGroup) {
      int i = param1ViewGroup.getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = param1ViewGroup.getChildAt(b);
        if (DrawerLayout.g(view))
          param1AccessibilityNodeInfoCompat.addChild(view); 
      } 
    }
    
    private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat1, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat2) {
      Rect rect = this.mTmpRect;
      param1AccessibilityNodeInfoCompat2.getBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat2.getBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setVisibleToUser(param1AccessibilityNodeInfoCompat2.isVisibleToUser());
      param1AccessibilityNodeInfoCompat1.setPackageName(param1AccessibilityNodeInfoCompat2.getPackageName());
      param1AccessibilityNodeInfoCompat1.setClassName(param1AccessibilityNodeInfoCompat2.getClassName());
      param1AccessibilityNodeInfoCompat1.setContentDescription(param1AccessibilityNodeInfoCompat2.getContentDescription());
      param1AccessibilityNodeInfoCompat1.setEnabled(param1AccessibilityNodeInfoCompat2.isEnabled());
      param1AccessibilityNodeInfoCompat1.setClickable(param1AccessibilityNodeInfoCompat2.isClickable());
      param1AccessibilityNodeInfoCompat1.setFocusable(param1AccessibilityNodeInfoCompat2.isFocusable());
      param1AccessibilityNodeInfoCompat1.setFocused(param1AccessibilityNodeInfoCompat2.isFocused());
      param1AccessibilityNodeInfoCompat1.setAccessibilityFocused(param1AccessibilityNodeInfoCompat2.isAccessibilityFocused());
      param1AccessibilityNodeInfoCompat1.setSelected(param1AccessibilityNodeInfoCompat2.isSelected());
      param1AccessibilityNodeInfoCompat1.setLongClickable(param1AccessibilityNodeInfoCompat2.isLongClickable());
      param1AccessibilityNodeInfoCompat1.addAction(param1AccessibilityNodeInfoCompat2.getActions());
    }
    
    public boolean dispatchPopulateAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      if (param1AccessibilityEvent.getEventType() == 32) {
        List<CharSequence> list = param1AccessibilityEvent.getText();
        View view = this.b.b();
        if (view != null) {
          int i = this.b.d(view);
          CharSequence charSequence = this.b.getDrawerTitle(i);
          if (charSequence != null)
            list.add(charSequence); 
        } 
        return true;
      } 
      return super.dispatchPopulateAccessibilityEvent(param1View, param1AccessibilityEvent);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(DrawerLayout.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      if (DrawerLayout.b) {
        super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      } else {
        AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(param1AccessibilityNodeInfoCompat);
        super.onInitializeAccessibilityNodeInfo(param1View, accessibilityNodeInfoCompat);
        param1AccessibilityNodeInfoCompat.setSource(param1View);
        ViewParent viewParent = ViewCompat.getParentForAccessibility(param1View);
        if (viewParent instanceof View)
          param1AccessibilityNodeInfoCompat.setParent((View)viewParent); 
        copyNodeInfoNoChildren(param1AccessibilityNodeInfoCompat, accessibilityNodeInfoCompat);
        accessibilityNodeInfoCompat.recycle();
        addChildrenForAccessibility(param1AccessibilityNodeInfoCompat, (ViewGroup)param1View);
      } 
      param1AccessibilityNodeInfoCompat.setClassName(DrawerLayout.class.getName());
      param1AccessibilityNodeInfoCompat.setFocusable(false);
      param1AccessibilityNodeInfoCompat.setFocused(false);
      param1AccessibilityNodeInfoCompat.removeAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_FOCUS);
      param1AccessibilityNodeInfoCompat.removeAction(AccessibilityNodeInfoCompat.AccessibilityActionCompat.ACTION_CLEAR_FOCUS);
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return (DrawerLayout.b || DrawerLayout.g(param1View)) ? super.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  static final class ChildAccessibilityDelegate extends AccessibilityDelegateCompat {
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      if (!DrawerLayout.g(param1View))
        param1AccessibilityNodeInfoCompat.setParent(null); 
    }
  }
  
  public static interface DrawerListener {
    void onDrawerClosed(@NonNull View param1View);
    
    void onDrawerOpened(@NonNull View param1View);
    
    void onDrawerSlide(@NonNull View param1View, float param1Float);
    
    void onDrawerStateChanged(int param1Int);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface EdgeGravity {}
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    private static final int FLAG_IS_CLOSING = 4;
    
    private static final int FLAG_IS_OPENED = 1;
    
    private static final int FLAG_IS_OPENING = 2;
    
    float a;
    
    boolean b;
    
    int c;
    
    public int gravity = 0;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(int param1Int1, int param1Int2, int param1Int3) {
      this(param1Int1, param1Int2);
      this.gravity = param1Int3;
    }
    
    public LayoutParams(@NonNull Context param1Context, @Nullable AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, DrawerLayout.a);
      this.gravity = typedArray.getInt(0, 0);
      typedArray.recycle();
    }
    
    public LayoutParams(@NonNull LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.gravity = param1LayoutParams.gravity;
    }
    
    public LayoutParams(@NonNull ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(@NonNull ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface LockMode {}
  
  protected static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public DrawerLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new DrawerLayout.SavedState(param2Parcel, null);
        }
        
        public DrawerLayout.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
          return new DrawerLayout.SavedState(param2Parcel, param2ClassLoader);
        }
        
        public DrawerLayout.SavedState[] newArray(int param2Int) {
          return new DrawerLayout.SavedState[param2Int];
        }
      };
    
    int a = 0;
    
    int b;
    
    int c;
    
    int d;
    
    int e;
    
    public SavedState(@NonNull Parcel param1Parcel, @Nullable ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      this.a = param1Parcel.readInt();
      this.b = param1Parcel.readInt();
      this.c = param1Parcel.readInt();
      this.d = param1Parcel.readInt();
      this.e = param1Parcel.readInt();
    }
    
    public SavedState(@NonNull Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.a);
      param1Parcel.writeInt(this.b);
      param1Parcel.writeInt(this.c);
      param1Parcel.writeInt(this.d);
      param1Parcel.writeInt(this.e);
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
    public DrawerLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new DrawerLayout.SavedState(param1Parcel, null);
    }
    
    public DrawerLayout.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new DrawerLayout.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public DrawerLayout.SavedState[] newArray(int param1Int) {
      return new DrawerLayout.SavedState[param1Int];
    }
  }
  
  public static abstract class SimpleDrawerListener implements DrawerListener {
    public void onDrawerClosed(View param1View) {}
    
    public void onDrawerOpened(View param1View) {}
    
    public void onDrawerSlide(View param1View, float param1Float) {}
    
    public void onDrawerStateChanged(int param1Int) {}
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface State {}
  
  private class ViewDragCallback extends ViewDragHelper.Callback {
    private final int mAbsGravity;
    
    private ViewDragHelper mDragger;
    
    private final Runnable mPeekRunnable = new Runnable(this) {
        public void run() {
          this.a.a();
        }
      };
    
    ViewDragCallback(DrawerLayout this$0, int param1Int) {
      this.mAbsGravity = param1Int;
    }
    
    private void closeOtherDrawer() {
      int i = this.mAbsGravity;
      byte b = 3;
      if (i == b)
        b = 5; 
      View view = this.a.a(b);
      if (view != null)
        this.a.closeDrawer(view); 
    }
    
    void a() {
      boolean bool;
      View view;
      int j;
      int i = this.mDragger.getEdgeSize();
      if (this.mAbsGravity == 3) {
        bool = true;
      } else {
        bool = false;
      } 
      if (bool) {
        view = this.a.a(3);
        int k = 0;
        if (view != null)
          k = -view.getWidth(); 
        j = k + i;
      } else {
        view = this.a.a(5);
        j = this.a.getWidth() - i;
      } 
      if (view != null && ((bool && view.getLeft() < j) || (!bool && view.getLeft() > j)) && this.a.getDrawerLockMode(view) == 0) {
        DrawerLayout.LayoutParams layoutParams = (DrawerLayout.LayoutParams)view.getLayoutParams();
        this.mDragger.smoothSlideViewTo(view, j, view.getTop());
        layoutParams.b = true;
        this.a.invalidate();
        closeOtherDrawer();
        this.a.c();
      } 
    }
    
    public int clampViewPositionHorizontal(View param1View, int param1Int1, int param1Int2) {
      if (this.a.a(param1View, 3))
        return Math.max(-param1View.getWidth(), Math.min(param1Int1, 0)); 
      int i = this.a.getWidth();
      return Math.max(i - param1View.getWidth(), Math.min(param1Int1, i));
    }
    
    public int clampViewPositionVertical(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int getViewHorizontalDragRange(View param1View) {
      return this.a.f(param1View) ? param1View.getWidth() : 0;
    }
    
    public void onEdgeDragStarted(int param1Int1, int param1Int2) {
      View view;
      if ((param1Int1 & 0x1) == 1) {
        view = this.a.a(3);
      } else {
        view = this.a.a(5);
      } 
      if (view != null && this.a.getDrawerLockMode(view) == 0)
        this.mDragger.captureChildView(view, param1Int2); 
    }
    
    public boolean onEdgeLock(int param1Int) {
      return false;
    }
    
    public void onEdgeTouched(int param1Int1, int param1Int2) {
      this.a.postDelayed(this.mPeekRunnable, 160L);
    }
    
    public void onViewCaptured(View param1View, int param1Int) {
      ((DrawerLayout.LayoutParams)param1View.getLayoutParams()).b = false;
      closeOtherDrawer();
    }
    
    public void onViewDragStateChanged(int param1Int) {
      this.a.a(this.mAbsGravity, param1Int, this.mDragger.getCapturedView());
    }
    
    public void onViewPositionChanged(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      float f;
      boolean bool;
      int i = param1View.getWidth();
      if (this.a.a(param1View, 3)) {
        f = (param1Int1 + i) / i;
      } else {
        f = (this.a.getWidth() - param1Int1) / i;
      } 
      this.a.b(param1View, f);
      if (f == 0.0F) {
        bool = true;
      } else {
        bool = false;
      } 
      param1View.setVisibility(bool);
      this.a.invalidate();
    }
    
    public void onViewReleased(View param1View, float param1Float1, float param1Float2) {
      int j;
      float f = this.a.c(param1View);
      int i = param1View.getWidth();
      if (this.a.a(param1View, 3)) {
        if (param1Float1 > 0.0F || (param1Float1 == 0.0F && f > 0.5F)) {
          j = 0;
        } else {
          j = -i;
        } 
      } else {
        int k = this.a.getWidth();
        if (param1Float1 < 0.0F || (param1Float1 == 0.0F && f > 0.5F))
          k -= i; 
        j = k;
      } 
      this.mDragger.settleCapturedViewAt(j, param1View.getTop());
      this.a.invalidate();
    }
    
    public void removeCallbacks() {
      this.a.removeCallbacks(this.mPeekRunnable);
    }
    
    public void setDragger(ViewDragHelper param1ViewDragHelper) {
      this.mDragger = param1ViewDragHelper;
    }
    
    public boolean tryCaptureView(View param1View, int param1Int) {
      return (this.a.f(param1View) && this.a.a(param1View, this.mAbsGravity) && this.a.getDrawerLockMode(param1View) == 0);
    }
  }
  
  class null implements Runnable {
    null(DrawerLayout this$0) {}
    
    public void run() {
      this.a.a();
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\DrawerLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */