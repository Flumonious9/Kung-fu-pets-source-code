package android.support.v4.widget;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.ShapeDrawable;
import android.graphics.drawable.shapes.OvalShape;
import android.graphics.drawable.shapes.Shape;
import android.os.Build;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.ViewCompat;
import android.view.View;
import android.view.animation.Animation;
import android.widget.ImageView;

class CircleImageView extends ImageView {
  private static final int FILL_SHADOW_COLOR = 1023410176;
  
  private static final int KEY_SHADOW_COLOR = 503316480;
  
  private static final int SHADOW_ELEVATION = 4;
  
  private static final float SHADOW_RADIUS = 3.5F;
  
  private static final float X_OFFSET = 0.0F;
  
  private static final float Y_OFFSET = 1.75F;
  
  int a;
  
  private Animation.AnimationListener mListener;
  
  CircleImageView(Context paramContext, int paramInt) {
    super(paramContext);
    ShapeDrawable shapeDrawable;
    float f = (getContext().getResources().getDisplayMetrics()).density;
    int i = (int)(1.75F * f);
    int j = (int)(0.0F * f);
    this.a = (int)(3.5F * f);
    if (elevationSupported()) {
      shapeDrawable = new ShapeDrawable((Shape)new OvalShape());
      ViewCompat.setElevation((View)this, f * 4.0F);
    } else {
      ShapeDrawable shapeDrawable1 = new ShapeDrawable((Shape)new OvalShadow(this, this.a));
      setLayerType(1, shapeDrawable1.getPaint());
      shapeDrawable1.getPaint().setShadowLayer(this.a, j, i, 503316480);
      int k = this.a;
      setPadding(k, k, k, k);
      shapeDrawable = shapeDrawable1;
    } 
    shapeDrawable.getPaint().setColor(paramInt);
    ViewCompat.setBackground((View)this, (Drawable)shapeDrawable);
  }
  
  private boolean elevationSupported() {
    return (Build.VERSION.SDK_INT >= 21);
  }
  
  public void onAnimationEnd() {
    super.onAnimationEnd();
    if (this.mListener != null)
      this.mListener.onAnimationEnd(getAnimation()); 
  }
  
  public void onAnimationStart() {
    super.onAnimationStart();
    if (this.mListener != null)
      this.mListener.onAnimationStart(getAnimation()); 
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!elevationSupported())
      setMeasuredDimension(getMeasuredWidth() + 2 * this.a, getMeasuredHeight() + 2 * this.a); 
  }
  
  public void setAnimationListener(Animation.AnimationListener paramAnimationListener) {
    this.mListener = paramAnimationListener;
  }
  
  public void setBackgroundColor(int paramInt) {
    if (getBackground() instanceof ShapeDrawable)
      ((ShapeDrawable)getBackground()).getPaint().setColor(paramInt); 
  }
  
  public void setBackgroundColorRes(int paramInt) {
    setBackgroundColor(ContextCompat.getColor(getContext(), paramInt));
  }
  
  private class OvalShadow extends OvalShape {
    private RadialGradient mRadialGradient;
    
    private Paint mShadowPaint = new Paint();
    
    OvalShadow(CircleImageView this$0, int param1Int) {
      this$0.a = param1Int;
      updateRadialGradient((int)rect().width());
    }
    
    private void updateRadialGradient(int param1Int) {
      float f = (param1Int / 2);
      RadialGradient radialGradient = new RadialGradient(f, f, this.a.a, new int[] { 1023410176, 0 }, null, Shader.TileMode.CLAMP);
      this.mRadialGradient = radialGradient;
      this.mShadowPaint.setShader((Shader)this.mRadialGradient);
    }
    
    public void draw(Canvas param1Canvas, Paint param1Paint) {
      int i = this.a.getWidth();
      int j = this.a.getHeight();
      int k = i / 2;
      float f1 = k;
      float f2 = (j / 2);
      param1Canvas.drawCircle(f1, f2, f1, this.mShadowPaint);
      param1Canvas.drawCircle(f1, f2, (k - this.a.a), param1Paint);
    }
    
    protected void onResize(float param1Float1, float param1Float2) {
      super.onResize(param1Float1, param1Float2);
      updateRadialGradient((int)param1Float1);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\CircleImageView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */