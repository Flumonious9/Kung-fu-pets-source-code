package android.support.v4.widget;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.annotation.StyleRes;
import android.support.v4.os.BuildCompat;
import android.util.Log;
import android.view.ActionMode;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

public final class TextViewCompat {
  public static final int AUTO_SIZE_TEXT_TYPE_NONE = 0;
  
  public static final int AUTO_SIZE_TEXT_TYPE_UNIFORM = 1;
  
  static final TextViewCompatBaseImpl a = new TextViewCompatBaseImpl();
  
  public static int getAutoSizeMaxTextSize(@NonNull TextView paramTextView) {
    return a.getAutoSizeMaxTextSize(paramTextView);
  }
  
  public static int getAutoSizeMinTextSize(@NonNull TextView paramTextView) {
    return a.getAutoSizeMinTextSize(paramTextView);
  }
  
  public static int getAutoSizeStepGranularity(@NonNull TextView paramTextView) {
    return a.getAutoSizeStepGranularity(paramTextView);
  }
  
  @NonNull
  public static int[] getAutoSizeTextAvailableSizes(@NonNull TextView paramTextView) {
    return a.getAutoSizeTextAvailableSizes(paramTextView);
  }
  
  public static int getAutoSizeTextType(@NonNull TextView paramTextView) {
    return a.getAutoSizeTextType(paramTextView);
  }
  
  @NonNull
  public static Drawable[] getCompoundDrawablesRelative(@NonNull TextView paramTextView) {
    return a.getCompoundDrawablesRelative(paramTextView);
  }
  
  public static int getMaxLines(@NonNull TextView paramTextView) {
    return a.getMaxLines(paramTextView);
  }
  
  public static int getMinLines(@NonNull TextView paramTextView) {
    return a.getMinLines(paramTextView);
  }
  
  public static void setAutoSizeTextTypeUniformWithConfiguration(@NonNull TextView paramTextView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    a.setAutoSizeTextTypeUniformWithConfiguration(paramTextView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void setAutoSizeTextTypeUniformWithPresetSizes(@NonNull TextView paramTextView, @NonNull int[] paramArrayOfint, int paramInt) {
    a.setAutoSizeTextTypeUniformWithPresetSizes(paramTextView, paramArrayOfint, paramInt);
  }
  
  public static void setAutoSizeTextTypeWithDefaults(@NonNull TextView paramTextView, int paramInt) {
    a.setAutoSizeTextTypeWithDefaults(paramTextView, paramInt);
  }
  
  public static void setCompoundDrawablesRelative(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    a.setCompoundDrawablesRelative(paramTextView, paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }
  
  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @DrawableRes int paramInt1, @DrawableRes int paramInt2, @DrawableRes int paramInt3, @DrawableRes int paramInt4) {
    a.setCompoundDrawablesRelativeWithIntrinsicBounds(paramTextView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public static void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView paramTextView, @Nullable Drawable paramDrawable1, @Nullable Drawable paramDrawable2, @Nullable Drawable paramDrawable3, @Nullable Drawable paramDrawable4) {
    a.setCompoundDrawablesRelativeWithIntrinsicBounds(paramTextView, paramDrawable1, paramDrawable2, paramDrawable3, paramDrawable4);
  }
  
  public static void setCustomSelectionActionModeCallback(@NonNull TextView paramTextView, @NonNull ActionMode.Callback paramCallback) {
    a.setCustomSelectionActionModeCallback(paramTextView, paramCallback);
  }
  
  public static void setTextAppearance(@NonNull TextView paramTextView, @StyleRes int paramInt) {
    a.setTextAppearance(paramTextView, paramInt);
  }
  
  static {
    if (BuildCompat.isAtLeastOMR1()) {
      a = new TextViewCompatApi27Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 26) {
      a = new TextViewCompatApi26Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      a = new TextViewCompatApi23Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 18) {
      a = new TextViewCompatApi18Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 17) {
      a = new TextViewCompatApi17Impl();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      a = new TextViewCompatApi16Impl();
      return;
    } 
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface AutoSizeTextType {}
  
  @RequiresApi(16)
  static class TextViewCompatApi16Impl extends TextViewCompatBaseImpl {
    public int getMaxLines(TextView param1TextView) {
      return param1TextView.getMaxLines();
    }
    
    public int getMinLines(TextView param1TextView) {
      return param1TextView.getMinLines();
    }
  }
  
  @RequiresApi(17)
  static class TextViewCompatApi17Impl extends TextViewCompatApi16Impl {
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      int i = param1TextView.getLayoutDirection();
      byte b = 1;
      if (i != b)
        b = 0; 
      Drawable[] arrayOfDrawable = param1TextView.getCompoundDrawables();
      if (b != 0) {
        Drawable drawable1 = arrayOfDrawable[2];
        Drawable drawable2 = arrayOfDrawable[0];
        arrayOfDrawable[0] = drawable1;
        arrayOfDrawable[2] = drawable2;
      } 
      return arrayOfDrawable;
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      Drawable drawable;
      int i = param1TextView.getLayoutDirection();
      byte b = 1;
      if (i != b)
        b = 0; 
      if (b != 0) {
        drawable = param1Drawable3;
      } else {
        drawable = param1Drawable1;
      } 
      if (b == 0)
        param1Drawable1 = param1Drawable3; 
      param1TextView.setCompoundDrawables(drawable, param1Drawable2, param1Drawable1, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      int j;
      int i = param1TextView.getLayoutDirection();
      byte b = 1;
      if (i != b)
        b = 0; 
      if (b != 0) {
        j = param1Int3;
      } else {
        j = param1Int1;
      } 
      if (b == 0)
        param1Int1 = param1Int3; 
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(j, param1Int2, param1Int1, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      Drawable drawable;
      int i = param1TextView.getLayoutDirection();
      byte b = 1;
      if (i != b)
        b = 0; 
      if (b != 0) {
        drawable = param1Drawable3;
      } else {
        drawable = param1Drawable1;
      } 
      if (b == 0)
        param1Drawable1 = param1Drawable3; 
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(drawable, param1Drawable2, param1Drawable1, param1Drawable4);
    }
  }
  
  @RequiresApi(18)
  static class TextViewCompatApi18Impl extends TextViewCompatApi17Impl {
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      return param1TextView.getCompoundDrawablesRelative();
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelative(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesRelativeWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
  }
  
  @RequiresApi(23)
  static class TextViewCompatApi23Impl extends TextViewCompatApi18Impl {
    public void setTextAppearance(@NonNull TextView param1TextView, @StyleRes int param1Int) {
      param1TextView.setTextAppearance(param1Int);
    }
  }
  
  @RequiresApi(26)
  static class TextViewCompatApi26Impl extends TextViewCompatApi23Impl {
    public void setCustomSelectionActionModeCallback(TextView param1TextView, ActionMode.Callback param1Callback) {
      if (Build.VERSION.SDK_INT != 26 && Build.VERSION.SDK_INT != 27) {
        super.setCustomSelectionActionModeCallback(param1TextView, param1Callback);
        return;
      } 
      param1TextView.setCustomSelectionActionModeCallback(new ActionMode.Callback(this, param1Callback, param1TextView) {
            private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
            
            private boolean mCanUseMenuBuilderReferences;
            
            private boolean mInitializedMenuBuilderReferences = false;
            
            private Class mMenuBuilderClass;
            
            private Method mMenuBuilderRemoveItemAtMethod;
            
            private Intent createProcessTextIntent() {
              return (new Intent()).setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
            }
            
            private Intent createProcessTextIntentForResolveInfo(ResolveInfo param2ResolveInfo, TextView param2TextView) {
              return createProcessTextIntent().putExtra("android.intent.extra.PROCESS_TEXT_READONLY", true ^ isEditable(param2TextView)).setClassName(param2ResolveInfo.activityInfo.packageName, param2ResolveInfo.activityInfo.name);
            }
            
            private List<ResolveInfo> getSupportedActivities(Context param2Context, PackageManager param2PackageManager) {
              ArrayList<ResolveInfo> arrayList = new ArrayList();
              if (!(param2Context instanceof android.app.Activity))
                return arrayList; 
              for (ResolveInfo resolveInfo : param2PackageManager.queryIntentActivities(createProcessTextIntent(), 0)) {
                if (isSupportedActivity(resolveInfo, param2Context))
                  arrayList.add(resolveInfo); 
              } 
              return arrayList;
            }
            
            private boolean isEditable(TextView param2TextView) {
              return (param2TextView instanceof android.text.Editable && param2TextView.onCheckIsTextEditor() && param2TextView.isEnabled());
            }
            
            private boolean isSupportedActivity(ResolveInfo param2ResolveInfo, Context param2Context) {
              boolean bool = param2Context.getPackageName().equals(param2ResolveInfo.activityInfo.packageName);
              boolean bool1 = true;
              if (bool)
                return bool1; 
              if (!param2ResolveInfo.activityInfo.exported)
                return false; 
              if (param2ResolveInfo.activityInfo.permission != null) {
                if (param2Context.checkSelfPermission(param2ResolveInfo.activityInfo.permission) == 0)
                  return bool1; 
                bool1 = false;
              } 
              return bool1;
            }
            
            private void recomputeProcessTextMenuItems(Menu param2Menu) {
              Context context = this.b.getContext();
              PackageManager packageManager = context.getPackageManager();
              if (!this.mInitializedMenuBuilderReferences) {
                this.mInitializedMenuBuilderReferences = true;
                try {
                  this.mMenuBuilderClass = Class.forName("com.android.internal.view.menu.MenuBuilder");
                  Class clazz = this.mMenuBuilderClass;
                  Class[] arrayOfClass = new Class[1];
                  arrayOfClass[0] = int.class;
                  this.mMenuBuilderRemoveItemAtMethod = clazz.getDeclaredMethod("removeItemAt", arrayOfClass);
                  this.mCanUseMenuBuilderReferences = true;
                } catch (ClassNotFoundException|NoSuchMethodException classNotFoundException) {
                  this.mMenuBuilderClass = null;
                  this.mMenuBuilderRemoveItemAtMethod = null;
                  this.mCanUseMenuBuilderReferences = false;
                } 
              } 
              try {
                Method method;
                if (this.mCanUseMenuBuilderReferences && this.mMenuBuilderClass.isInstance(param2Menu)) {
                  method = this.mMenuBuilderRemoveItemAtMethod;
                } else {
                  Class<?> clazz = param2Menu.getClass();
                  Class[] arrayOfClass = new Class[1];
                  arrayOfClass[0] = int.class;
                  method = clazz.getDeclaredMethod("removeItemAt", arrayOfClass);
                } 
                for (int i = param2Menu.size() - 1; i >= 0; i--) {
                  MenuItem menuItem = param2Menu.getItem(i);
                  if (menuItem.getIntent() != null && "android.intent.action.PROCESS_TEXT".equals(menuItem.getIntent().getAction())) {
                    Object[] arrayOfObject = new Object[1];
                    arrayOfObject[0] = Integer.valueOf(i);
                    method.invoke(param2Menu, arrayOfObject);
                  } 
                } 
                List<ResolveInfo> list = getSupportedActivities(context, packageManager);
                for (byte b = 0; b < list.size(); b++) {
                  ResolveInfo resolveInfo = list.get(b);
                  param2Menu.add(0, 0, b + 100, resolveInfo.loadLabel(packageManager)).setIntent(createProcessTextIntentForResolveInfo(resolveInfo, this.b)).setShowAsAction(1);
                } 
                return;
              } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
                return;
              } 
            }
            
            public boolean onActionItemClicked(ActionMode param2ActionMode, MenuItem param2MenuItem) {
              return this.a.onActionItemClicked(param2ActionMode, param2MenuItem);
            }
            
            public boolean onCreateActionMode(ActionMode param2ActionMode, Menu param2Menu) {
              return this.a.onCreateActionMode(param2ActionMode, param2Menu);
            }
            
            public void onDestroyActionMode(ActionMode param2ActionMode) {
              this.a.onDestroyActionMode(param2ActionMode);
            }
            
            public boolean onPrepareActionMode(ActionMode param2ActionMode, Menu param2Menu) {
              recomputeProcessTextMenuItems(param2Menu);
              return this.a.onPrepareActionMode(param2ActionMode, param2Menu);
            }
          });
    }
  }
  
  class null implements ActionMode.Callback {
    private static final int MENU_ITEM_ORDER_PROCESS_TEXT_INTENT_ACTIONS_START = 100;
    
    private boolean mCanUseMenuBuilderReferences;
    
    private boolean mInitializedMenuBuilderReferences = false;
    
    private Class mMenuBuilderClass;
    
    private Method mMenuBuilderRemoveItemAtMethod;
    
    null(TextViewCompat this$0, ActionMode.Callback param1Callback, TextView param1TextView) {}
    
    private Intent createProcessTextIntent() {
      return (new Intent()).setAction("android.intent.action.PROCESS_TEXT").setType("text/plain");
    }
    
    private Intent createProcessTextIntentForResolveInfo(ResolveInfo param1ResolveInfo, TextView param1TextView) {
      return createProcessTextIntent().putExtra("android.intent.extra.PROCESS_TEXT_READONLY", true ^ isEditable(param1TextView)).setClassName(param1ResolveInfo.activityInfo.packageName, param1ResolveInfo.activityInfo.name);
    }
    
    private List<ResolveInfo> getSupportedActivities(Context param1Context, PackageManager param1PackageManager) {
      ArrayList<ResolveInfo> arrayList = new ArrayList();
      if (!(param1Context instanceof android.app.Activity))
        return arrayList; 
      for (ResolveInfo resolveInfo : param1PackageManager.queryIntentActivities(createProcessTextIntent(), 0)) {
        if (isSupportedActivity(resolveInfo, param1Context))
          arrayList.add(resolveInfo); 
      } 
      return arrayList;
    }
    
    private boolean isEditable(TextView param1TextView) {
      return (param1TextView instanceof android.text.Editable && param1TextView.onCheckIsTextEditor() && param1TextView.isEnabled());
    }
    
    private boolean isSupportedActivity(ResolveInfo param1ResolveInfo, Context param1Context) {
      boolean bool = param1Context.getPackageName().equals(param1ResolveInfo.activityInfo.packageName);
      boolean bool1 = true;
      if (bool)
        return bool1; 
      if (!param1ResolveInfo.activityInfo.exported)
        return false; 
      if (param1ResolveInfo.activityInfo.permission != null) {
        if (param1Context.checkSelfPermission(param1ResolveInfo.activityInfo.permission) == 0)
          return bool1; 
        bool1 = false;
      } 
      return bool1;
    }
    
    private void recomputeProcessTextMenuItems(Menu param1Menu) {
      Context context = this.b.getContext();
      PackageManager packageManager = context.getPackageManager();
      if (!this.mInitializedMenuBuilderReferences) {
        this.mInitializedMenuBuilderReferences = true;
        try {
          this.mMenuBuilderClass = Class.forName("com.android.internal.view.menu.MenuBuilder");
          Class clazz = this.mMenuBuilderClass;
          Class[] arrayOfClass = new Class[1];
          arrayOfClass[0] = int.class;
          this.mMenuBuilderRemoveItemAtMethod = clazz.getDeclaredMethod("removeItemAt", arrayOfClass);
          this.mCanUseMenuBuilderReferences = true;
        } catch (ClassNotFoundException|NoSuchMethodException classNotFoundException) {
          this.mMenuBuilderClass = null;
          this.mMenuBuilderRemoveItemAtMethod = null;
          this.mCanUseMenuBuilderReferences = false;
        } 
      } 
      try {
        Method method;
        if (this.mCanUseMenuBuilderReferences && this.mMenuBuilderClass.isInstance(param1Menu)) {
          method = this.mMenuBuilderRemoveItemAtMethod;
        } else {
          Class<?> clazz = param1Menu.getClass();
          Class[] arrayOfClass = new Class[1];
          arrayOfClass[0] = int.class;
          method = clazz.getDeclaredMethod("removeItemAt", arrayOfClass);
        } 
        for (int i = param1Menu.size() - 1; i >= 0; i--) {
          MenuItem menuItem = param1Menu.getItem(i);
          if (menuItem.getIntent() != null && "android.intent.action.PROCESS_TEXT".equals(menuItem.getIntent().getAction())) {
            Object[] arrayOfObject = new Object[1];
            arrayOfObject[0] = Integer.valueOf(i);
            method.invoke(param1Menu, arrayOfObject);
          } 
        } 
        List<ResolveInfo> list = getSupportedActivities(context, packageManager);
        for (byte b = 0; b < list.size(); b++) {
          ResolveInfo resolveInfo = list.get(b);
          param1Menu.add(0, 0, b + 100, resolveInfo.loadLabel(packageManager)).setIntent(createProcessTextIntentForResolveInfo(resolveInfo, this.b)).setShowAsAction(1);
        } 
        return;
      } catch (NoSuchMethodException|IllegalAccessException|java.lang.reflect.InvocationTargetException noSuchMethodException) {
        return;
      } 
    }
    
    public boolean onActionItemClicked(ActionMode param1ActionMode, MenuItem param1MenuItem) {
      return this.a.onActionItemClicked(param1ActionMode, param1MenuItem);
    }
    
    public boolean onCreateActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      return this.a.onCreateActionMode(param1ActionMode, param1Menu);
    }
    
    public void onDestroyActionMode(ActionMode param1ActionMode) {
      this.a.onDestroyActionMode(param1ActionMode);
    }
    
    public boolean onPrepareActionMode(ActionMode param1ActionMode, Menu param1Menu) {
      recomputeProcessTextMenuItems(param1Menu);
      return this.a.onPrepareActionMode(param1ActionMode, param1Menu);
    }
  }
  
  @RequiresApi(27)
  static class TextViewCompatApi27Impl extends TextViewCompatApi26Impl {
    public int getAutoSizeMaxTextSize(TextView param1TextView) {
      return param1TextView.getAutoSizeMaxTextSize();
    }
    
    public int getAutoSizeMinTextSize(TextView param1TextView) {
      return param1TextView.getAutoSizeMinTextSize();
    }
    
    public int getAutoSizeStepGranularity(TextView param1TextView) {
      return param1TextView.getAutoSizeStepGranularity();
    }
    
    public int[] getAutoSizeTextAvailableSizes(TextView param1TextView) {
      return param1TextView.getAutoSizeTextAvailableSizes();
    }
    
    public int getAutoSizeTextType(TextView param1TextView) {
      return param1TextView.getAutoSizeTextType();
    }
    
    public void setAutoSizeTextTypeUniformWithConfiguration(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      param1TextView.setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setAutoSizeTextTypeUniformWithPresetSizes(TextView param1TextView, @NonNull int[] param1ArrayOfint, int param1Int) {
      param1TextView.setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int);
    }
    
    public void setAutoSizeTextTypeWithDefaults(TextView param1TextView, int param1Int) {
      param1TextView.setAutoSizeTextTypeWithDefaults(param1Int);
    }
  }
  
  static class TextViewCompatBaseImpl {
    private static final int LINES = 1;
    
    private static final String LOG_TAG = "TextViewCompatBase";
    
    private static Field sMaxModeField;
    
    private static boolean sMaxModeFieldFetched;
    
    private static Field sMaximumField;
    
    private static boolean sMaximumFieldFetched;
    
    private static Field sMinModeField;
    
    private static boolean sMinModeFieldFetched;
    
    private static Field sMinimumField;
    
    private static boolean sMinimumFieldFetched;
    
    private static Field retrieveField(String param1String) {
      Field field;
      try {
        field = TextView.class.getDeclaredField(param1String);
        try {
          field.setAccessible(true);
          return field;
        } catch (NoSuchFieldException noSuchFieldException) {}
      } catch (NoSuchFieldException noSuchFieldException) {}
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not retrieve ");
      stringBuilder.append(param1String);
      stringBuilder.append(" field.");
      Log.e("TextViewCompatBase", stringBuilder.toString());
      return field;
    }
    
    private static int retrieveIntFromField(Field param1Field, TextView param1TextView) {
      try {
        return param1Field.getInt(param1TextView);
      } catch (IllegalAccessException illegalAccessException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Could not retrieve value of ");
        stringBuilder.append(param1Field.getName());
        stringBuilder.append(" field.");
        Log.d("TextViewCompatBase", stringBuilder.toString());
        return -1;
      } 
    }
    
    public int getAutoSizeMaxTextSize(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeMaxTextSize() : -1;
    }
    
    public int getAutoSizeMinTextSize(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeMinTextSize() : -1;
    }
    
    public int getAutoSizeStepGranularity(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeStepGranularity() : -1;
    }
    
    public int[] getAutoSizeTextAvailableSizes(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeTextAvailableSizes() : new int[0];
    }
    
    public int getAutoSizeTextType(TextView param1TextView) {
      return (param1TextView instanceof AutoSizeableTextView) ? ((AutoSizeableTextView)param1TextView).getAutoSizeTextType() : 0;
    }
    
    public Drawable[] getCompoundDrawablesRelative(@NonNull TextView param1TextView) {
      return param1TextView.getCompoundDrawables();
    }
    
    public int getMaxLines(TextView param1TextView) {
      if (!sMaxModeFieldFetched) {
        sMaxModeField = retrieveField("mMaxMode");
        sMaxModeFieldFetched = true;
      } 
      if (sMaxModeField != null && retrieveIntFromField(sMaxModeField, param1TextView) == 1) {
        if (!sMaximumFieldFetched) {
          sMaximumField = retrieveField("mMaximum");
          sMaximumFieldFetched = true;
        } 
        if (sMaximumField != null)
          return retrieveIntFromField(sMaximumField, param1TextView); 
      } 
      return -1;
    }
    
    public int getMinLines(TextView param1TextView) {
      if (!sMinModeFieldFetched) {
        sMinModeField = retrieveField("mMinMode");
        sMinModeFieldFetched = true;
      } 
      if (sMinModeField != null && retrieveIntFromField(sMinModeField, param1TextView) == 1) {
        if (!sMinimumFieldFetched) {
          sMinimumField = retrieveField("mMinimum");
          sMinimumFieldFetched = true;
        } 
        if (sMinimumField != null)
          return retrieveIntFromField(sMinimumField, param1TextView); 
      } 
      return -1;
    }
    
    public void setAutoSizeTextTypeUniformWithConfiguration(TextView param1TextView, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeUniformWithConfiguration(param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    public void setAutoSizeTextTypeUniformWithPresetSizes(TextView param1TextView, @NonNull int[] param1ArrayOfint, int param1Int) {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeUniformWithPresetSizes(param1ArrayOfint, param1Int); 
    }
    
    public void setAutoSizeTextTypeWithDefaults(TextView param1TextView, int param1Int) {
      if (param1TextView instanceof AutoSizeableTextView)
        ((AutoSizeableTextView)param1TextView).setAutoSizeTextTypeWithDefaults(param1Int); 
    }
    
    public void setCompoundDrawablesRelative(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawables(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @DrawableRes int param1Int1, @DrawableRes int param1Int2, @DrawableRes int param1Int3, @DrawableRes int param1Int4) {
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(param1Int1, param1Int2, param1Int3, param1Int4);
    }
    
    public void setCompoundDrawablesRelativeWithIntrinsicBounds(@NonNull TextView param1TextView, @Nullable Drawable param1Drawable1, @Nullable Drawable param1Drawable2, @Nullable Drawable param1Drawable3, @Nullable Drawable param1Drawable4) {
      param1TextView.setCompoundDrawablesWithIntrinsicBounds(param1Drawable1, param1Drawable2, param1Drawable3, param1Drawable4);
    }
    
    public void setCustomSelectionActionModeCallback(TextView param1TextView, ActionMode.Callback param1Callback) {
      param1TextView.setCustomSelectionActionModeCallback(param1Callback);
    }
    
    public void setTextAppearance(TextView param1TextView, @StyleRes int param1Int) {
      param1TextView.setTextAppearance(param1TextView.getContext(), param1Int);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\TextViewCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */