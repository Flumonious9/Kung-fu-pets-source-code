package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class SlidingPaneLayout extends ViewGroup {
  private static final int DEFAULT_FADE_COLOR = -858993460;
  
  private static final int DEFAULT_OVERHANG_SIZE = 32;
  
  private static final int MIN_FLING_VELOCITY = 400;
  
  private static final String TAG = "SlidingPaneLayout";
  
  static final SlidingPanelLayoutImpl h = new SlidingPanelLayoutImplBase();
  
  View a;
  
  float b;
  
  int c;
  
  boolean d;
  
  final ViewDragHelper e;
  
  boolean f;
  
  final ArrayList<DisableLayerRunnable> g = new ArrayList<DisableLayerRunnable>();
  
  private boolean mCanSlide;
  
  private int mCoveredFadeColor;
  
  private boolean mFirstLayout = true;
  
  private float mInitialMotionX;
  
  private float mInitialMotionY;
  
  private final int mOverhangSize;
  
  private PanelSlideListener mPanelSlideListener;
  
  private int mParallaxBy;
  
  private float mParallaxOffset;
  
  private Drawable mShadowDrawableLeft;
  
  private Drawable mShadowDrawableRight;
  
  private int mSliderFadeColor = -858993460;
  
  private final Rect mTmpRect = new Rect();
  
  public SlidingPaneLayout(@NonNull Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SlidingPaneLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public SlidingPaneLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    float f = (paramContext.getResources().getDisplayMetrics()).density;
    this.mOverhangSize = (int)(0.5F + 32.0F * f);
    setWillNotDraw(false);
    ViewCompat.setAccessibilityDelegate((View)this, new AccessibilityDelegate(this));
    ViewCompat.setImportantForAccessibility((View)this, 1);
    this.e = ViewDragHelper.create(this, 0.5F, new DragHelperCallback(this));
    this.e.setMinVelocity(f * 400.0F);
  }
  
  private boolean closePane(View paramView, int paramInt) {
    if (this.mFirstLayout || a(0.0F, paramInt)) {
      this.f = false;
      return true;
    } 
    return false;
  }
  
  private void dimChildView(View paramView, float paramFloat, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (paramFloat > 0.0F && paramInt != 0) {
      int i = (int)(paramFloat * ((0xFF000000 & paramInt) >>> 24)) << 24 | paramInt & 0xFFFFFF;
      if (layoutParams.c == null)
        layoutParams.c = new Paint(); 
      layoutParams.c.setColorFilter((ColorFilter)new PorterDuffColorFilter(i, PorterDuff.Mode.SRC_OVER));
      if (paramView.getLayerType() != 2)
        paramView.setLayerType(2, layoutParams.c); 
      e(paramView);
      return;
    } 
    if (paramView.getLayerType() != 0) {
      if (layoutParams.c != null)
        layoutParams.c.setColorFilter(null); 
      DisableLayerRunnable disableLayerRunnable = new DisableLayerRunnable(this, paramView);
      this.g.add(disableLayerRunnable);
      ViewCompat.postOnAnimation((View)this, disableLayerRunnable);
    } 
  }
  
  private boolean openPane(View paramView, int paramInt) {
    if (this.mFirstLayout || a(1.0F, paramInt)) {
      this.f = true;
      return true;
    } 
    return false;
  }
  
  private void parallaxOtherViews(float paramFloat) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isLayoutRtlSupport : ()Z
    //   4: istore_2
    //   5: aload_0
    //   6: getfield a : Landroid/view/View;
    //   9: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   12: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   15: astore_3
    //   16: aload_3
    //   17: getfield b : Z
    //   20: istore #4
    //   22: iconst_0
    //   23: istore #5
    //   25: iload #4
    //   27: ifeq -> 60
    //   30: iload_2
    //   31: ifeq -> 43
    //   34: aload_3
    //   35: getfield rightMargin : I
    //   38: istore #12
    //   40: goto -> 49
    //   43: aload_3
    //   44: getfield leftMargin : I
    //   47: istore #12
    //   49: iload #12
    //   51: ifgt -> 60
    //   54: iconst_1
    //   55: istore #6
    //   57: goto -> 63
    //   60: iconst_0
    //   61: istore #6
    //   63: aload_0
    //   64: invokevirtual getChildCount : ()I
    //   67: istore #7
    //   69: iload #5
    //   71: iload #7
    //   73: if_icmpge -> 193
    //   76: aload_0
    //   77: iload #5
    //   79: invokevirtual getChildAt : (I)Landroid/view/View;
    //   82: astore #8
    //   84: aload #8
    //   86: aload_0
    //   87: getfield a : Landroid/view/View;
    //   90: if_acmpne -> 96
    //   93: goto -> 187
    //   96: fconst_1
    //   97: aload_0
    //   98: getfield mParallaxOffset : F
    //   101: fsub
    //   102: aload_0
    //   103: getfield mParallaxBy : I
    //   106: i2f
    //   107: fmul
    //   108: f2i
    //   109: istore #9
    //   111: aload_0
    //   112: fload_1
    //   113: putfield mParallaxOffset : F
    //   116: iload #9
    //   118: fconst_1
    //   119: fload_1
    //   120: fsub
    //   121: aload_0
    //   122: getfield mParallaxBy : I
    //   125: i2f
    //   126: fmul
    //   127: f2i
    //   128: isub
    //   129: istore #10
    //   131: iload_2
    //   132: ifeq -> 140
    //   135: iload #10
    //   137: ineg
    //   138: istore #10
    //   140: aload #8
    //   142: iload #10
    //   144: invokevirtual offsetLeftAndRight : (I)V
    //   147: iload #6
    //   149: ifeq -> 187
    //   152: iload_2
    //   153: ifeq -> 167
    //   156: aload_0
    //   157: getfield mParallaxOffset : F
    //   160: fconst_1
    //   161: fsub
    //   162: fstore #11
    //   164: goto -> 175
    //   167: fconst_1
    //   168: aload_0
    //   169: getfield mParallaxOffset : F
    //   172: fsub
    //   173: fstore #11
    //   175: aload_0
    //   176: aload #8
    //   178: fload #11
    //   180: aload_0
    //   181: getfield mCoveredFadeColor : I
    //   184: invokespecial dimChildView : (Landroid/view/View;FI)V
    //   187: iinc #5, 1
    //   190: goto -> 69
    //   193: return
  }
  
  private static boolean viewIsOpaque(View paramView) {
    if (paramView.isOpaque())
      return true; 
    if (Build.VERSION.SDK_INT >= 18)
      return false; 
    Drawable drawable = paramView.getBackground();
    return (drawable != null) ? ((drawable.getOpacity() == -1)) : false;
  }
  
  void a() {
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() == 4)
        view.setVisibility(0); 
    } 
  }
  
  void a(int paramInt) {
    int j;
    int k;
    if (this.a == null) {
      this.b = 0.0F;
      return;
    } 
    boolean bool = isLayoutRtlSupport();
    LayoutParams layoutParams = (LayoutParams)this.a.getLayoutParams();
    int i = this.a.getWidth();
    if (bool)
      paramInt = getWidth() - paramInt - i; 
    if (bool) {
      j = getPaddingRight();
    } else {
      j = getPaddingLeft();
    } 
    if (bool) {
      k = layoutParams.rightMargin;
    } else {
      k = layoutParams.leftMargin;
    } 
    this.b = (paramInt - j + k) / this.c;
    if (this.mParallaxBy != 0)
      parallaxOtherViews(this.b); 
    if (layoutParams.b)
      dimChildView(this.a, this.b, this.mSliderFadeColor); 
    a(this.a);
  }
  
  void a(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelSlide(paramView, this.b); 
  }
  
  boolean a(float paramFloat, int paramInt) {
    int i;
    if (!this.mCanSlide)
      return false; 
    boolean bool = isLayoutRtlSupport();
    LayoutParams layoutParams = (LayoutParams)this.a.getLayoutParams();
    if (bool) {
      int j = getPaddingRight() + layoutParams.rightMargin;
      int k = this.a.getWidth();
      i = (int)(getWidth() - j + paramFloat * this.c + k);
    } else {
      i = (int)((getPaddingLeft() + layoutParams.leftMargin) + paramFloat * this.c);
    } 
    if (this.e.smoothSlideViewTo(this.a, i, this.a.getTop())) {
      a();
      ViewCompat.postInvalidateOnAnimation((View)this);
      return true;
    } 
    return false;
  }
  
  void b(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelOpened(paramView); 
    sendAccessibilityEvent(32);
  }
  
  void c(View paramView) {
    if (this.mPanelSlideListener != null)
      this.mPanelSlideListener.onPanelClosed(paramView); 
    sendAccessibilityEvent(32);
  }
  
  protected boolean canScroll(View paramView, boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
    if (paramView instanceof ViewGroup) {
      ViewGroup viewGroup = (ViewGroup)paramView;
      int i = paramView.getScrollX();
      int j = paramView.getScrollY();
      for (int k = viewGroup.getChildCount() - 1; k >= 0; k--) {
        View view = viewGroup.getChildAt(k);
        int m = paramInt2 + i;
        if (m >= view.getLeft() && m < view.getRight()) {
          int n = paramInt3 + j;
          if (n >= view.getTop() && n < view.getBottom() && canScroll(view, true, paramInt1, m - view.getLeft(), n - view.getTop()))
            return true; 
        } 
      } 
    } 
    if (paramBoolean) {
      int i;
      if (isLayoutRtlSupport()) {
        i = paramInt1;
      } else {
        i = -paramInt1;
      } 
      if (paramView.canScrollHorizontally(i))
        return true; 
    } 
    return false;
  }
  
  @Deprecated
  public boolean canSlide() {
    return this.mCanSlide;
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public boolean closePane() {
    return closePane(this.a, 0);
  }
  
  public void computeScroll() {
    if (this.e.continueSettling(true)) {
      if (!this.mCanSlide) {
        this.e.abort();
        return;
      } 
      ViewCompat.postInvalidateOnAnimation((View)this);
    } 
  }
  
  void d(View paramView) {
    int i;
    int j;
    byte b1;
    byte b2;
    byte b3;
    byte b4;
    View view = paramView;
    boolean bool = isLayoutRtlSupport();
    if (bool) {
      i = getWidth() - getPaddingRight();
    } else {
      i = getPaddingLeft();
    } 
    if (bool) {
      j = getPaddingLeft();
    } else {
      j = getWidth() - getPaddingRight();
    } 
    int k = getPaddingTop();
    int m = getHeight() - getPaddingBottom();
    if (view != null && viewIsOpaque(paramView)) {
      b1 = paramView.getLeft();
      b2 = paramView.getRight();
      b3 = paramView.getTop();
      b4 = paramView.getBottom();
    } else {
      b1 = 0;
      b2 = 0;
      b3 = 0;
      b4 = 0;
    } 
    int n = getChildCount();
    byte b5 = 0;
    while (b5 < n) {
      boolean bool1;
      View view1 = getChildAt(b5);
      if (view1 == view)
        return; 
      if (view1.getVisibility() == 8) {
        bool1 = bool;
      } else {
        int i1;
        int i4;
        boolean bool2;
        if (bool) {
          i1 = j;
        } else {
          i1 = i;
        } 
        int i2 = Math.max(i1, view1.getLeft());
        int i3 = Math.max(k, view1.getTop());
        if (bool) {
          bool1 = bool;
          i4 = i;
        } else {
          bool1 = bool;
          i4 = j;
        } 
        int i5 = Math.min(i4, view1.getRight());
        int i6 = Math.min(m, view1.getBottom());
        if (i2 >= b1 && i3 >= b3 && i5 <= b2 && i6 <= b4) {
          bool2 = true;
        } else {
          bool2 = false;
        } 
        view1.setVisibility(bool2);
      } 
      b5++;
      bool = bool1;
      view = paramView;
    } 
  }
  
  public void draw(Canvas paramCanvas) {
    Drawable drawable;
    View view;
    super.draw(paramCanvas);
    if (isLayoutRtlSupport()) {
      drawable = this.mShadowDrawableRight;
    } else {
      drawable = this.mShadowDrawableLeft;
    } 
    if (getChildCount() > 1) {
      view = getChildAt(1);
    } else {
      view = null;
    } 
    if (view != null) {
      int m;
      int n;
      if (drawable == null)
        return; 
      int i = view.getTop();
      int j = view.getBottom();
      int k = drawable.getIntrinsicWidth();
      if (isLayoutRtlSupport()) {
        n = view.getRight();
        m = k + n;
      } else {
        int i1 = view.getLeft();
        int i2 = i1 - k;
        m = i1;
        n = i2;
      } 
      drawable.setBounds(n, i, m, j);
      drawable.draw(paramCanvas);
      return;
    } 
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = paramCanvas.save();
    if (this.mCanSlide && !layoutParams.a && this.a != null) {
      paramCanvas.getClipBounds(this.mTmpRect);
      if (isLayoutRtlSupport()) {
        this.mTmpRect.left = Math.max(this.mTmpRect.left, this.a.getRight());
      } else {
        this.mTmpRect.right = Math.min(this.mTmpRect.right, this.a.getLeft());
      } 
      paramCanvas.clipRect(this.mTmpRect);
    } 
    boolean bool = super.drawChild(paramCanvas, paramView, paramLong);
    paramCanvas.restoreToCount(i);
    return bool;
  }
  
  void e(View paramView) {
    h.invalidateChildRegion(this, paramView);
  }
  
  boolean f(View paramView) {
    if (paramView == null)
      return false; 
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    boolean bool = this.mCanSlide;
    boolean bool1 = false;
    if (bool) {
      boolean bool2 = layoutParams.b;
      bool1 = false;
      if (bool2) {
        int i = this.b cmp 0.0F;
        bool1 = false;
        if (i > 0)
          bool1 = true; 
      } 
    } 
    return bool1;
  }
  
  protected ViewGroup.LayoutParams generateDefaultLayoutParams() {
    return (ViewGroup.LayoutParams)new LayoutParams();
  }
  
  public ViewGroup.LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return (ViewGroup.LayoutParams)new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (ViewGroup.LayoutParams)((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams));
  }
  
  @ColorInt
  public int getCoveredFadeColor() {
    return this.mCoveredFadeColor;
  }
  
  public int getParallaxDistance() {
    return this.mParallaxBy;
  }
  
  @ColorInt
  public int getSliderFadeColor() {
    return this.mSliderFadeColor;
  }
  
  boolean isLayoutRtlSupport() {
    return (ViewCompat.getLayoutDirection((View)this) == 1);
  }
  
  public boolean isOpen() {
    return (!this.mCanSlide || this.b == 1.0F);
  }
  
  public boolean isSlideable() {
    return this.mCanSlide;
  }
  
  protected void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mFirstLayout = true;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    this.mFirstLayout = true;
    int i = this.g.size();
    for (byte b = 0; b < i; b++)
      ((DisableLayerRunnable)this.g.get(b)).run(); 
    this.g.clear();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield mCanSlide : Z
    //   9: istore_3
    //   10: iconst_1
    //   11: istore #4
    //   13: iload_3
    //   14: ifne -> 69
    //   17: iload_2
    //   18: ifne -> 69
    //   21: aload_0
    //   22: invokevirtual getChildCount : ()I
    //   25: iload #4
    //   27: if_icmple -> 69
    //   30: aload_0
    //   31: iload #4
    //   33: invokevirtual getChildAt : (I)Landroid/view/View;
    //   36: astore #12
    //   38: aload #12
    //   40: ifnull -> 69
    //   43: aload_0
    //   44: iload #4
    //   46: aload_0
    //   47: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   50: aload #12
    //   52: aload_1
    //   53: invokevirtual getX : ()F
    //   56: f2i
    //   57: aload_1
    //   58: invokevirtual getY : ()F
    //   61: f2i
    //   62: invokevirtual isViewUnder : (Landroid/view/View;II)Z
    //   65: ixor
    //   66: putfield f : Z
    //   69: aload_0
    //   70: getfield mCanSlide : Z
    //   73: ifeq -> 292
    //   76: aload_0
    //   77: getfield d : Z
    //   80: ifeq -> 90
    //   83: iload_2
    //   84: ifeq -> 90
    //   87: goto -> 292
    //   90: iload_2
    //   91: iconst_3
    //   92: if_icmpeq -> 283
    //   95: iload_2
    //   96: iload #4
    //   98: if_icmpne -> 104
    //   101: goto -> 283
    //   104: iload_2
    //   105: ifeq -> 189
    //   108: iload_2
    //   109: iconst_2
    //   110: if_icmpeq -> 116
    //   113: goto -> 255
    //   116: aload_1
    //   117: invokevirtual getX : ()F
    //   120: fstore #8
    //   122: aload_1
    //   123: invokevirtual getY : ()F
    //   126: fstore #9
    //   128: fload #8
    //   130: aload_0
    //   131: getfield mInitialMotionX : F
    //   134: fsub
    //   135: invokestatic abs : (F)F
    //   138: fstore #10
    //   140: fload #9
    //   142: aload_0
    //   143: getfield mInitialMotionY : F
    //   146: fsub
    //   147: invokestatic abs : (F)F
    //   150: fstore #11
    //   152: fload #10
    //   154: aload_0
    //   155: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   158: invokevirtual getTouchSlop : ()I
    //   161: i2f
    //   162: fcmpl
    //   163: ifle -> 255
    //   166: fload #11
    //   168: fload #10
    //   170: fcmpl
    //   171: ifle -> 255
    //   174: aload_0
    //   175: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   178: invokevirtual cancel : ()V
    //   181: aload_0
    //   182: iload #4
    //   184: putfield d : Z
    //   187: iconst_0
    //   188: ireturn
    //   189: aload_0
    //   190: iconst_0
    //   191: putfield d : Z
    //   194: aload_1
    //   195: invokevirtual getX : ()F
    //   198: fstore #5
    //   200: aload_1
    //   201: invokevirtual getY : ()F
    //   204: fstore #6
    //   206: aload_0
    //   207: fload #5
    //   209: putfield mInitialMotionX : F
    //   212: aload_0
    //   213: fload #6
    //   215: putfield mInitialMotionY : F
    //   218: aload_0
    //   219: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   222: aload_0
    //   223: getfield a : Landroid/view/View;
    //   226: fload #5
    //   228: f2i
    //   229: fload #6
    //   231: f2i
    //   232: invokevirtual isViewUnder : (Landroid/view/View;II)Z
    //   235: ifeq -> 255
    //   238: aload_0
    //   239: aload_0
    //   240: getfield a : Landroid/view/View;
    //   243: invokevirtual f : (Landroid/view/View;)Z
    //   246: ifeq -> 255
    //   249: iconst_1
    //   250: istore #7
    //   252: goto -> 258
    //   255: iconst_0
    //   256: istore #7
    //   258: aload_0
    //   259: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   262: aload_1
    //   263: invokevirtual shouldInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   266: ifne -> 280
    //   269: iload #7
    //   271: ifeq -> 277
    //   274: iload #4
    //   276: ireturn
    //   277: iconst_0
    //   278: istore #4
    //   280: iload #4
    //   282: ireturn
    //   283: aload_0
    //   284: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   287: invokevirtual cancel : ()V
    //   290: iconst_0
    //   291: ireturn
    //   292: aload_0
    //   293: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   296: invokevirtual cancel : ()V
    //   299: aload_0
    //   300: aload_1
    //   301: invokespecial onInterceptTouchEvent : (Landroid/view/MotionEvent;)Z
    //   304: ireturn
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual isLayoutRtlSupport : ()Z
    //   4: istore #6
    //   6: iload #6
    //   8: ifeq -> 22
    //   11: aload_0
    //   12: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   15: iconst_2
    //   16: invokevirtual setEdgeTrackingEnabled : (I)V
    //   19: goto -> 30
    //   22: aload_0
    //   23: getfield e : Landroid/support/v4/widget/ViewDragHelper;
    //   26: iconst_1
    //   27: invokevirtual setEdgeTrackingEnabled : (I)V
    //   30: iload #4
    //   32: iload_2
    //   33: isub
    //   34: istore #7
    //   36: iload #6
    //   38: ifeq -> 50
    //   41: aload_0
    //   42: invokevirtual getPaddingRight : ()I
    //   45: istore #8
    //   47: goto -> 56
    //   50: aload_0
    //   51: invokevirtual getPaddingLeft : ()I
    //   54: istore #8
    //   56: iload #6
    //   58: ifeq -> 70
    //   61: aload_0
    //   62: invokevirtual getPaddingLeft : ()I
    //   65: istore #9
    //   67: goto -> 76
    //   70: aload_0
    //   71: invokevirtual getPaddingRight : ()I
    //   74: istore #9
    //   76: aload_0
    //   77: invokevirtual getPaddingTop : ()I
    //   80: istore #10
    //   82: aload_0
    //   83: invokevirtual getChildCount : ()I
    //   86: istore #11
    //   88: aload_0
    //   89: getfield mFirstLayout : Z
    //   92: ifeq -> 124
    //   95: aload_0
    //   96: getfield mCanSlide : Z
    //   99: ifeq -> 115
    //   102: aload_0
    //   103: getfield f : Z
    //   106: ifeq -> 115
    //   109: fconst_1
    //   110: fstore #29
    //   112: goto -> 118
    //   115: fconst_0
    //   116: fstore #29
    //   118: aload_0
    //   119: fload #29
    //   121: putfield b : F
    //   124: iload #8
    //   126: istore #12
    //   128: iload #12
    //   130: istore #13
    //   132: iconst_0
    //   133: istore #14
    //   135: iload #14
    //   137: iload #11
    //   139: if_icmpge -> 448
    //   142: aload_0
    //   143: iload #14
    //   145: invokevirtual getChildAt : (I)Landroid/view/View;
    //   148: astore #16
    //   150: aload #16
    //   152: invokevirtual getVisibility : ()I
    //   155: bipush #8
    //   157: if_icmpne -> 163
    //   160: goto -> 442
    //   163: aload #16
    //   165: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   168: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   171: astore #17
    //   173: aload #16
    //   175: invokevirtual getMeasuredWidth : ()I
    //   178: istore #18
    //   180: aload #17
    //   182: getfield a : Z
    //   185: ifeq -> 327
    //   188: aload #17
    //   190: getfield leftMargin : I
    //   193: aload #17
    //   195: getfield rightMargin : I
    //   198: iadd
    //   199: istore #23
    //   201: iload #7
    //   203: iload #9
    //   205: isub
    //   206: istore #24
    //   208: iload #12
    //   210: iload #24
    //   212: aload_0
    //   213: getfield mOverhangSize : I
    //   216: isub
    //   217: invokestatic min : (II)I
    //   220: iload #13
    //   222: isub
    //   223: iload #23
    //   225: isub
    //   226: istore #25
    //   228: aload_0
    //   229: iload #25
    //   231: putfield c : I
    //   234: iload #6
    //   236: ifeq -> 249
    //   239: aload #17
    //   241: getfield rightMargin : I
    //   244: istore #26
    //   246: goto -> 256
    //   249: aload #17
    //   251: getfield leftMargin : I
    //   254: istore #26
    //   256: iload #25
    //   258: iload #13
    //   260: iload #26
    //   262: iadd
    //   263: iadd
    //   264: iload #18
    //   266: iconst_2
    //   267: idiv
    //   268: iadd
    //   269: iload #24
    //   271: if_icmple -> 280
    //   274: iconst_1
    //   275: istore #27
    //   277: goto -> 283
    //   280: iconst_0
    //   281: istore #27
    //   283: aload #17
    //   285: iload #27
    //   287: putfield b : Z
    //   290: iload #25
    //   292: i2f
    //   293: aload_0
    //   294: getfield b : F
    //   297: fmul
    //   298: f2i
    //   299: istore #28
    //   301: iload #13
    //   303: iload #26
    //   305: iload #28
    //   307: iadd
    //   308: iadd
    //   309: istore #19
    //   311: aload_0
    //   312: iload #28
    //   314: i2f
    //   315: aload_0
    //   316: getfield c : I
    //   319: i2f
    //   320: fdiv
    //   321: putfield b : F
    //   324: goto -> 367
    //   327: aload_0
    //   328: getfield mCanSlide : Z
    //   331: ifeq -> 363
    //   334: aload_0
    //   335: getfield mParallaxBy : I
    //   338: ifeq -> 363
    //   341: fconst_1
    //   342: aload_0
    //   343: getfield b : F
    //   346: fsub
    //   347: aload_0
    //   348: getfield mParallaxBy : I
    //   351: i2f
    //   352: fmul
    //   353: f2i
    //   354: istore #20
    //   356: iload #12
    //   358: istore #19
    //   360: goto -> 370
    //   363: iload #12
    //   365: istore #19
    //   367: iconst_0
    //   368: istore #20
    //   370: iload #6
    //   372: ifeq -> 395
    //   375: iload #20
    //   377: iload #7
    //   379: iload #19
    //   381: isub
    //   382: iadd
    //   383: istore #22
    //   385: iload #22
    //   387: iload #18
    //   389: isub
    //   390: istore #21
    //   392: goto -> 409
    //   395: iload #19
    //   397: iload #20
    //   399: isub
    //   400: istore #21
    //   402: iload #21
    //   404: iload #18
    //   406: iadd
    //   407: istore #22
    //   409: aload #16
    //   411: iload #21
    //   413: iload #10
    //   415: iload #22
    //   417: iload #10
    //   419: aload #16
    //   421: invokevirtual getMeasuredHeight : ()I
    //   424: iadd
    //   425: invokevirtual layout : (IIII)V
    //   428: iload #12
    //   430: aload #16
    //   432: invokevirtual getWidth : ()I
    //   435: iadd
    //   436: istore #12
    //   438: iload #19
    //   440: istore #13
    //   442: iinc #14, 1
    //   445: goto -> 135
    //   448: aload_0
    //   449: getfield mFirstLayout : Z
    //   452: ifeq -> 551
    //   455: aload_0
    //   456: getfield mCanSlide : Z
    //   459: ifeq -> 512
    //   462: aload_0
    //   463: getfield mParallaxBy : I
    //   466: ifeq -> 477
    //   469: aload_0
    //   470: aload_0
    //   471: getfield b : F
    //   474: invokespecial parallaxOtherViews : (F)V
    //   477: aload_0
    //   478: getfield a : Landroid/view/View;
    //   481: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   484: checkcast android/support/v4/widget/SlidingPaneLayout$LayoutParams
    //   487: getfield b : Z
    //   490: ifeq -> 543
    //   493: aload_0
    //   494: aload_0
    //   495: getfield a : Landroid/view/View;
    //   498: aload_0
    //   499: getfield b : F
    //   502: aload_0
    //   503: getfield mSliderFadeColor : I
    //   506: invokespecial dimChildView : (Landroid/view/View;FI)V
    //   509: goto -> 543
    //   512: iconst_0
    //   513: istore #15
    //   515: iload #15
    //   517: iload #11
    //   519: if_icmpge -> 543
    //   522: aload_0
    //   523: aload_0
    //   524: iload #15
    //   526: invokevirtual getChildAt : (I)Landroid/view/View;
    //   529: fconst_0
    //   530: aload_0
    //   531: getfield mSliderFadeColor : I
    //   534: invokespecial dimChildView : (Landroid/view/View;FI)V
    //   537: iinc #15, 1
    //   540: goto -> 515
    //   543: aload_0
    //   544: aload_0
    //   545: getfield a : Landroid/view/View;
    //   548: invokevirtual d : (Landroid/view/View;)V
    //   551: aload_0
    //   552: iconst_0
    //   553: putfield mFirstLayout : Z
    //   556: return
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    int n;
    byte b1;
    int i = View.MeasureSpec.getMode(paramInt1);
    int j = View.MeasureSpec.getSize(paramInt1);
    int k = View.MeasureSpec.getMode(paramInt2);
    int m = View.MeasureSpec.getSize(paramInt2);
    if (i != 1073741824) {
      if (isInEditMode()) {
        if (i != Integer.MIN_VALUE && i == 0)
          j = 300; 
      } else {
        throw new IllegalStateException("Width must have an exact value or MATCH_PARENT");
      } 
    } else if (k == 0) {
      if (isInEditMode()) {
        if (k == 0) {
          k = Integer.MIN_VALUE;
          m = 300;
        } 
      } else {
        throw new IllegalStateException("Height must not be UNSPECIFIED");
      } 
    } 
    if (k != Integer.MIN_VALUE) {
      if (k != 1073741824) {
        b1 = 0;
        n = 0;
      } else {
        b1 = m - getPaddingTop() - getPaddingBottom();
        n = b1;
      } 
    } else {
      n = m - getPaddingTop() - getPaddingBottom();
      b1 = 0;
    } 
    int i1 = j - getPaddingLeft() - getPaddingRight();
    int i2 = getChildCount();
    if (i2 > 2)
      Log.e("SlidingPaneLayout", "onMeasure: More than two child views are not supported."); 
    this.a = null;
    int i3 = b1;
    int i4 = i1;
    byte b2 = 0;
    int i5 = 0;
    float f = 0.0F;
    while (true) {
      byte b = 8;
      if (b2 < i2) {
        int i7;
        int i8;
        int i11;
        View view = getChildAt(b2);
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (view.getVisibility() == b) {
          layoutParams.b = false;
          continue;
        } 
        if (layoutParams.weight > 0.0F) {
          f += layoutParams.weight;
          if (layoutParams.width == 0)
            continue; 
        } 
        int i6 = layoutParams.leftMargin + layoutParams.rightMargin;
        if (layoutParams.width == -2) {
          i7 = View.MeasureSpec.makeMeasureSpec(i1 - i6, -2147483648);
        } else if (layoutParams.width == -1) {
          i7 = View.MeasureSpec.makeMeasureSpec(i1 - i6, 1073741824);
        } else {
          i7 = View.MeasureSpec.makeMeasureSpec(layoutParams.width, 1073741824);
        } 
        if (layoutParams.height == -2) {
          i8 = View.MeasureSpec.makeMeasureSpec(n, -2147483648);
        } else if (layoutParams.height == -1) {
          i8 = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
        } else {
          i8 = View.MeasureSpec.makeMeasureSpec(layoutParams.height, 1073741824);
        } 
        view.measure(i7, i8);
        int i9 = view.getMeasuredWidth();
        int i10 = view.getMeasuredHeight();
        if (k == Integer.MIN_VALUE && i10 > i3)
          i3 = Math.min(i10, n); 
        i4 -= i9;
        if (i4 < 0) {
          i11 = 1;
        } else {
          i11 = 0;
        } 
        layoutParams.a = i11;
        int i12 = i11 | i5;
        if (layoutParams.a)
          this.a = view; 
        i5 = i12;
        continue;
      } 
      if (i5 != 0 || f > 0.0F) {
        Object object;
        int i6 = i1 - this.mOverhangSize;
        byte b3 = 0;
        while (b3 < i2) {
          View view = getChildAt(b3);
          if (view.getVisibility() != b) {
            LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
            if (view.getVisibility() != b) {
              boolean bool;
              int i7;
              if (layoutParams.width == 0 && layoutParams.weight > 0.0F) {
                bool = true;
              } else {
                bool = false;
              } 
              if (bool) {
                i7 = 0;
              } else {
                i7 = view.getMeasuredWidth();
              } 
              if (i5 != 0 && view != this.a) {
                if (layoutParams.width < 0 && (i7 > object || layoutParams.weight > 0.0F)) {
                  int i8;
                  int i9;
                  if (bool) {
                    if (layoutParams.height == -2) {
                      i9 = View.MeasureSpec.makeMeasureSpec(n, -2147483648);
                      i8 = 1073741824;
                    } else if (layoutParams.height == -1) {
                      i8 = 1073741824;
                      i9 = View.MeasureSpec.makeMeasureSpec(n, i8);
                    } else {
                      i8 = 1073741824;
                      i9 = View.MeasureSpec.makeMeasureSpec(layoutParams.height, i8);
                    } 
                  } else {
                    i8 = 1073741824;
                    i9 = View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), i8);
                  } 
                  view.measure(View.MeasureSpec.makeMeasureSpec(object, i8), i9);
                } 
              } else if (layoutParams.weight > 0.0F) {
                int i8;
                if (layoutParams.width == 0) {
                  if (layoutParams.height == -2) {
                    i8 = View.MeasureSpec.makeMeasureSpec(n, -2147483648);
                  } else {
                    int i9;
                    if (layoutParams.height == -1) {
                      i9 = View.MeasureSpec.makeMeasureSpec(n, 1073741824);
                    } else {
                      i9 = View.MeasureSpec.makeMeasureSpec(layoutParams.height, 1073741824);
                    } 
                    i8 = i9;
                  } 
                } else {
                  int i9 = View.MeasureSpec.makeMeasureSpec(view.getMeasuredHeight(), 1073741824);
                  i8 = i9;
                } 
                if (i5 != 0) {
                  int i9 = i1 - layoutParams.leftMargin + layoutParams.rightMargin;
                  Object object2 = object;
                  int i10 = View.MeasureSpec.makeMeasureSpec(i9, 1073741824);
                  if (i7 != i9)
                    view.measure(i10, i8); 
                } else {
                  Object object2 = object;
                  int i9 = Math.max(0, i4);
                  view.measure(View.MeasureSpec.makeMeasureSpec(i7 + (int)(layoutParams.weight * i9 / f), 1073741824), i8);
                } 
                continue;
              } 
            } 
          } 
          Object object1 = object;
          continue;
          b3++;
          object = SYNTHETIC_LOCAL_VARIABLE_25;
          b = 8;
        } 
      } 
      setMeasuredDimension(j, i3 + getPaddingTop() + getPaddingBottom());
      this.mCanSlide = i5;
      if (this.e.getViewDragState() != 0 && i5 == 0)
        this.e.abort(); 
      return;
      b2++;
    } 
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    if (savedState.a) {
      openPane();
    } else {
      closePane();
    } 
    this.f = savedState.a;
  }
  
  protected Parcelable onSaveInstanceState() {
    boolean bool;
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    if (isSlideable()) {
      bool = isOpen();
    } else {
      bool = this.f;
    } 
    savedState.a = bool;
    return (Parcelable)savedState;
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (paramInt1 != paramInt3)
      this.mFirstLayout = true; 
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    if (!this.mCanSlide)
      return super.onTouchEvent(paramMotionEvent); 
    this.e.processTouchEvent(paramMotionEvent);
    switch (paramMotionEvent.getActionMasked()) {
      default:
        return true;
      case 1:
        if (f(this.a)) {
          float f3 = paramMotionEvent.getX();
          float f4 = paramMotionEvent.getY();
          float f5 = f3 - this.mInitialMotionX;
          float f6 = f4 - this.mInitialMotionY;
          int i = this.e.getTouchSlop();
          if (f5 * f5 + f6 * f6 < (i * i) && this.e.isViewUnder(this.a, (int)f3, (int)f4)) {
            closePane(this.a, 0);
            return true;
          } 
        } 
        return true;
      case 0:
        break;
    } 
    float f1 = paramMotionEvent.getX();
    float f2 = paramMotionEvent.getY();
    this.mInitialMotionX = f1;
    this.mInitialMotionY = f2;
    return true;
  }
  
  public boolean openPane() {
    return openPane(this.a, 0);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    super.requestChildFocus(paramView1, paramView2);
    if (!isInTouchMode() && !this.mCanSlide) {
      boolean bool;
      if (paramView1 == this.a) {
        bool = true;
      } else {
        bool = false;
      } 
      this.f = bool;
    } 
  }
  
  public void setCoveredFadeColor(@ColorInt int paramInt) {
    this.mCoveredFadeColor = paramInt;
  }
  
  public void setPanelSlideListener(@Nullable PanelSlideListener paramPanelSlideListener) {
    this.mPanelSlideListener = paramPanelSlideListener;
  }
  
  public void setParallaxDistance(int paramInt) {
    this.mParallaxBy = paramInt;
    requestLayout();
  }
  
  @Deprecated
  public void setShadowDrawable(Drawable paramDrawable) {
    setShadowDrawableLeft(paramDrawable);
  }
  
  public void setShadowDrawableLeft(@Nullable Drawable paramDrawable) {
    this.mShadowDrawableLeft = paramDrawable;
  }
  
  public void setShadowDrawableRight(@Nullable Drawable paramDrawable) {
    this.mShadowDrawableRight = paramDrawable;
  }
  
  @Deprecated
  public void setShadowResource(@DrawableRes int paramInt) {
    setShadowDrawable(getResources().getDrawable(paramInt));
  }
  
  public void setShadowResourceLeft(int paramInt) {
    setShadowDrawableLeft(ContextCompat.getDrawable(getContext(), paramInt));
  }
  
  public void setShadowResourceRight(int paramInt) {
    setShadowDrawableRight(ContextCompat.getDrawable(getContext(), paramInt));
  }
  
  public void setSliderFadeColor(@ColorInt int paramInt) {
    this.mSliderFadeColor = paramInt;
  }
  
  @Deprecated
  public void smoothSlideClosed() {
    closePane();
  }
  
  @Deprecated
  public void smoothSlideOpen() {
    openPane();
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 17) {
      h = new SlidingPanelLayoutImplJBMR1();
      return;
    } 
    if (Build.VERSION.SDK_INT >= 16) {
      h = new SlidingPanelLayoutImplJB();
      return;
    } 
  }
  
  class AccessibilityDelegate extends AccessibilityDelegateCompat {
    private final Rect mTmpRect = new Rect();
    
    AccessibilityDelegate(SlidingPaneLayout this$0) {}
    
    private void copyNodeInfoNoChildren(AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat1, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat2) {
      Rect rect = this.mTmpRect;
      param1AccessibilityNodeInfoCompat2.getBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInParent(rect);
      param1AccessibilityNodeInfoCompat2.getBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setBoundsInScreen(rect);
      param1AccessibilityNodeInfoCompat1.setVisibleToUser(param1AccessibilityNodeInfoCompat2.isVisibleToUser());
      param1AccessibilityNodeInfoCompat1.setPackageName(param1AccessibilityNodeInfoCompat2.getPackageName());
      param1AccessibilityNodeInfoCompat1.setClassName(param1AccessibilityNodeInfoCompat2.getClassName());
      param1AccessibilityNodeInfoCompat1.setContentDescription(param1AccessibilityNodeInfoCompat2.getContentDescription());
      param1AccessibilityNodeInfoCompat1.setEnabled(param1AccessibilityNodeInfoCompat2.isEnabled());
      param1AccessibilityNodeInfoCompat1.setClickable(param1AccessibilityNodeInfoCompat2.isClickable());
      param1AccessibilityNodeInfoCompat1.setFocusable(param1AccessibilityNodeInfoCompat2.isFocusable());
      param1AccessibilityNodeInfoCompat1.setFocused(param1AccessibilityNodeInfoCompat2.isFocused());
      param1AccessibilityNodeInfoCompat1.setAccessibilityFocused(param1AccessibilityNodeInfoCompat2.isAccessibilityFocused());
      param1AccessibilityNodeInfoCompat1.setSelected(param1AccessibilityNodeInfoCompat2.isSelected());
      param1AccessibilityNodeInfoCompat1.setLongClickable(param1AccessibilityNodeInfoCompat2.isLongClickable());
      param1AccessibilityNodeInfoCompat1.addAction(param1AccessibilityNodeInfoCompat2.getActions());
      param1AccessibilityNodeInfoCompat1.setMovementGranularities(param1AccessibilityNodeInfoCompat2.getMovementGranularities());
    }
    
    public boolean filter(View param1View) {
      return this.b.f(param1View);
    }
    
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      param1AccessibilityEvent.setClassName(SlidingPaneLayout.class.getName());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      AccessibilityNodeInfoCompat accessibilityNodeInfoCompat = AccessibilityNodeInfoCompat.obtain(param1AccessibilityNodeInfoCompat);
      super.onInitializeAccessibilityNodeInfo(param1View, accessibilityNodeInfoCompat);
      copyNodeInfoNoChildren(param1AccessibilityNodeInfoCompat, accessibilityNodeInfoCompat);
      accessibilityNodeInfoCompat.recycle();
      param1AccessibilityNodeInfoCompat.setClassName(SlidingPaneLayout.class.getName());
      param1AccessibilityNodeInfoCompat.setSource(param1View);
      ViewParent viewParent = ViewCompat.getParentForAccessibility(param1View);
      if (viewParent instanceof View)
        param1AccessibilityNodeInfoCompat.setParent((View)viewParent); 
      int i = this.b.getChildCount();
      for (byte b = 0; b < i; b++) {
        View view = this.b.getChildAt(b);
        if (!filter(view) && view.getVisibility() == 0) {
          ViewCompat.setImportantForAccessibility(view, 1);
          param1AccessibilityNodeInfoCompat.addChild(view);
        } 
      } 
    }
    
    public boolean onRequestSendAccessibilityEvent(ViewGroup param1ViewGroup, View param1View, AccessibilityEvent param1AccessibilityEvent) {
      return !filter(param1View) ? super.onRequestSendAccessibilityEvent(param1ViewGroup, param1View, param1AccessibilityEvent) : false;
    }
  }
  
  private class DisableLayerRunnable implements Runnable {
    final View a;
    
    DisableLayerRunnable(SlidingPaneLayout this$0, View param1View) {
      this.a = param1View;
    }
    
    public void run() {
      if (this.a.getParent() == this.b) {
        this.a.setLayerType(0, null);
        this.b.e(this.a);
      } 
      this.b.g.remove(this);
    }
  }
  
  private class DragHelperCallback extends ViewDragHelper.Callback {
    DragHelperCallback(SlidingPaneLayout this$0) {}
    
    public int clampViewPositionHorizontal(View param1View, int param1Int1, int param1Int2) {
      SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams)this.a.a.getLayoutParams();
      if (this.a.isLayoutRtlSupport()) {
        int k = this.a.getWidth() - this.a.getPaddingRight() + layoutParams.rightMargin + this.a.a.getWidth();
        int m = k - this.a.c;
        return Math.max(Math.min(param1Int1, k), m);
      } 
      int i = this.a.getPaddingLeft() + layoutParams.leftMargin;
      int j = i + this.a.c;
      return Math.min(Math.max(param1Int1, i), j);
    }
    
    public int clampViewPositionVertical(View param1View, int param1Int1, int param1Int2) {
      return param1View.getTop();
    }
    
    public int getViewHorizontalDragRange(View param1View) {
      return this.a.c;
    }
    
    public void onEdgeDragStarted(int param1Int1, int param1Int2) {
      this.a.e.captureChildView(this.a.a, param1Int2);
    }
    
    public void onViewCaptured(View param1View, int param1Int) {
      this.a.a();
    }
    
    public void onViewDragStateChanged(int param1Int) {
      if (this.a.e.getViewDragState() == 0) {
        if (this.a.b == 0.0F) {
          this.a.d(this.a.a);
          this.a.c(this.a.a);
          this.a.f = false;
          return;
        } 
        this.a.b(this.a.a);
        this.a.f = true;
      } 
    }
    
    public void onViewPositionChanged(View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      this.a.a(param1Int1);
      this.a.invalidate();
    }
    
    public void onViewReleased(View param1View, float param1Float1, float param1Float2) {
      int i;
      SlidingPaneLayout.LayoutParams layoutParams = (SlidingPaneLayout.LayoutParams)param1View.getLayoutParams();
      if (this.a.isLayoutRtlSupport()) {
        int j = this.a.getPaddingRight() + layoutParams.rightMargin;
        if (param1Float1 < 0.0F || (param1Float1 == 0.0F && this.a.b > 0.5F))
          j += this.a.c; 
        int k = this.a.a.getWidth();
        i = this.a.getWidth() - j - k;
      } else {
        i = this.a.getPaddingLeft() + layoutParams.leftMargin;
        if (param1Float1 > 0.0F || (param1Float1 == 0.0F && this.a.b > 0.5F))
          i += this.a.c; 
      } 
      this.a.e.settleCapturedViewAt(i, param1View.getTop());
      this.a.invalidate();
    }
    
    public boolean tryCaptureView(View param1View, int param1Int) {
      return this.a.d ? false : ((SlidingPaneLayout.LayoutParams)param1View.getLayoutParams()).a;
    }
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    private static final int[] ATTRS = new int[] { 16843137 };
    
    boolean a;
    
    boolean b;
    
    Paint c;
    
    public float weight = 0.0F;
    
    public LayoutParams() {
      super(-1, -1);
    }
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    public LayoutParams(@NonNull Context param1Context, @Nullable AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, ATTRS);
      this.weight = typedArray.getFloat(0, 0.0F);
      typedArray.recycle();
    }
    
    public LayoutParams(@NonNull LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
      this.weight = param1LayoutParams.weight;
    }
    
    public LayoutParams(@NonNull ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(@NonNull ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
  }
  
  public static interface PanelSlideListener {
    void onPanelClosed(@NonNull View param1View);
    
    void onPanelOpened(@NonNull View param1View);
    
    void onPanelSlide(@NonNull View param1View, float param1Float);
  }
  
  static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public SlidingPaneLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new SlidingPaneLayout.SavedState(param2Parcel, null);
        }
        
        public SlidingPaneLayout.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
          return new SlidingPaneLayout.SavedState(param2Parcel, null);
        }
        
        public SlidingPaneLayout.SavedState[] newArray(int param2Int) {
          return new SlidingPaneLayout.SavedState[param2Int];
        }
      };
    
    boolean a;
    
    SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      boolean bool;
      if (param1Parcel.readInt() != 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.a = bool;
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.a);
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
    public SlidingPaneLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new SlidingPaneLayout.SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new SlidingPaneLayout.SavedState(param1Parcel, null);
    }
    
    public SlidingPaneLayout.SavedState[] newArray(int param1Int) {
      return new SlidingPaneLayout.SavedState[param1Int];
    }
  }
  
  public static class SimplePanelSlideListener implements PanelSlideListener {
    public void onPanelClosed(View param1View) {}
    
    public void onPanelOpened(View param1View) {}
    
    public void onPanelSlide(View param1View, float param1Float) {}
  }
  
  static interface SlidingPanelLayoutImpl {
    void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View);
  }
  
  static class SlidingPanelLayoutImplBase implements SlidingPanelLayoutImpl {
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      ViewCompat.postInvalidateOnAnimation((View)param1SlidingPaneLayout, param1View.getLeft(), param1View.getTop(), param1View.getRight(), param1View.getBottom());
    }
  }
  
  @RequiresApi(16)
  static class SlidingPanelLayoutImplJB extends SlidingPanelLayoutImplBase {
    private Method mGetDisplayList;
    
    private Field mRecreateDisplayList;
    
    SlidingPanelLayoutImplJB() {
      try {
        this.mGetDisplayList = View.class.getDeclaredMethod("getDisplayList", (Class[])null);
      } catch (NoSuchMethodException noSuchMethodException) {
        Log.e("SlidingPaneLayout", "Couldn't fetch getDisplayList method; dimming won't work right.", noSuchMethodException);
      } 
      try {
        this.mRecreateDisplayList = View.class.getDeclaredField("mRecreateDisplayList");
        this.mRecreateDisplayList.setAccessible(true);
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.e("SlidingPaneLayout", "Couldn't fetch mRecreateDisplayList field; dimming will be slow.", noSuchFieldException);
        return;
      } 
    }
    
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      if (this.mGetDisplayList != null && this.mRecreateDisplayList != null) {
        try {
          this.mRecreateDisplayList.setBoolean(param1View, true);
          this.mGetDisplayList.invoke(param1View, (Object[])null);
        } catch (Exception exception) {
          Log.e("SlidingPaneLayout", "Error refreshing display list state", exception);
        } 
        super.invalidateChildRegion(param1SlidingPaneLayout, param1View);
        return;
      } 
      param1View.invalidate();
    }
  }
  
  @RequiresApi(17)
  static class SlidingPanelLayoutImplJBMR1 extends SlidingPanelLayoutImplBase {
    public void invalidateChildRegion(SlidingPaneLayout param1SlidingPaneLayout, View param1View) {
      ViewCompat.setLayerPaint(param1View, ((SlidingPaneLayout.LayoutParams)param1View.getLayoutParams()).c);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\SlidingPaneLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */