package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.os.Build;
import android.support.annotation.ColorInt;
import android.support.annotation.ColorRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.NestedScrollingChild;
import android.support.v4.view.NestedScrollingChildHelper;
import android.support.v4.view.NestedScrollingParent;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.ViewCompat;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.Interpolator;
import android.view.animation.Transformation;
import android.widget.ListView;

public class SwipeRefreshLayout extends ViewGroup implements NestedScrollingChild, NestedScrollingParent {
  private static final int ALPHA_ANIMATION_DURATION = 300;
  
  private static final int ANIMATE_TO_START_DURATION = 200;
  
  private static final int ANIMATE_TO_TRIGGER_DURATION = 200;
  
  private static final int CIRCLE_BG_LIGHT = -328966;
  
  private static final float DECELERATE_INTERPOLATION_FACTOR = 2.0F;
  
  public static final int DEFAULT = 1;
  
  private static final int DEFAULT_CIRCLE_TARGET = 64;
  
  private static final float DRAG_RATE = 0.5F;
  
  private static final int INVALID_POINTER = -1;
  
  public static final int LARGE = 0;
  
  private static final int[] LAYOUT_ATTRS = new int[] { 16842766 };
  
  private static final String LOG_TAG = "SwipeRefreshLayout";
  
  private static final int MAX_ALPHA = 255;
  
  private static final float MAX_PROGRESS_ANGLE = 0.8F;
  
  private static final int SCALE_DOWN_DURATION = 150;
  
  private static final int STARTING_PROGRESS_ALPHA = 76;
  
  OnRefreshListener a;
  
  boolean b = false;
  
  int c;
  
  boolean d;
  
  CircleImageView e;
  
  float f;
  
  int g;
  
  CircularProgressDrawable h;
  
  boolean i;
  
  boolean j;
  
  private int mActivePointerId = -1;
  
  private Animation mAlphaMaxAnimation;
  
  private Animation mAlphaStartAnimation;
  
  private final Animation mAnimateToCorrectPosition = new Animation(this) {
      public void applyTransformation(float param1Float, Transformation param1Transformation) {
        int i;
        if (!this.a.j) {
          i = this.a.g - Math.abs(this.a.mOriginalOffsetTop);
        } else {
          i = this.a.g;
        } 
        int j = this.a.mFrom + (int)(param1Float * (i - this.a.mFrom)) - this.a.e.getTop();
        this.a.setTargetOffsetTopAndBottom(j);
        this.a.h.setArrowScale(1.0F - param1Float);
      }
    };
  
  private final Animation mAnimateToStartPosition = new Animation(this) {
      public void applyTransformation(float param1Float, Transformation param1Transformation) {
        this.a.a(param1Float);
      }
    };
  
  private OnChildScrollUpCallback mChildScrollUpCallback;
  
  private int mCircleDiameter;
  
  private int mCircleViewIndex = -1;
  
  private final DecelerateInterpolator mDecelerateInterpolator;
  
  protected int mFrom;
  
  private float mInitialDownY;
  
  private float mInitialMotionY;
  
  private boolean mIsBeingDragged;
  
  private int mMediumAnimationDuration;
  
  private boolean mNestedScrollInProgress;
  
  private final NestedScrollingChildHelper mNestedScrollingChildHelper;
  
  private final NestedScrollingParentHelper mNestedScrollingParentHelper;
  
  protected int mOriginalOffsetTop;
  
  private final int[] mParentOffsetInWindow = new int[2];
  
  private final int[] mParentScrollConsumed = new int[2];
  
  private Animation.AnimationListener mRefreshListener = new Animation.AnimationListener(this) {
      public void onAnimationEnd(Animation param1Animation) {
        if (this.a.b) {
          this.a.h.setAlpha(255);
          this.a.h.start();
          if (this.a.i && this.a.a != null)
            this.a.a.onRefresh(); 
          this.a.c = this.a.e.getTop();
          return;
        } 
        this.a.a();
      }
      
      public void onAnimationRepeat(Animation param1Animation) {}
      
      public void onAnimationStart(Animation param1Animation) {}
    };
  
  private boolean mReturningToStart;
  
  private Animation mScaleAnimation;
  
  private Animation mScaleDownAnimation;
  
  private Animation mScaleDownToStartAnimation;
  
  private View mTarget;
  
  private float mTotalDragDistance = -1.0F;
  
  private float mTotalUnconsumed;
  
  private int mTouchSlop;
  
  public SwipeRefreshLayout(@NonNull Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public SwipeRefreshLayout(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    super(paramContext, paramAttributeSet);
    this.mTouchSlop = ViewConfiguration.get(paramContext).getScaledTouchSlop();
    this.mMediumAnimationDuration = getResources().getInteger(17694721);
    setWillNotDraw(false);
    this.mDecelerateInterpolator = new DecelerateInterpolator(2.0F);
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    this.mCircleDiameter = (int)(40.0F * displayMetrics.density);
    createProgressView();
    setChildrenDrawingOrderEnabled(true);
    this.g = (int)(64.0F * displayMetrics.density);
    this.mTotalDragDistance = this.g;
    this.mNestedScrollingParentHelper = new NestedScrollingParentHelper(this);
    this.mNestedScrollingChildHelper = new NestedScrollingChildHelper((View)this);
    setNestedScrollingEnabled(true);
    int i = -this.mCircleDiameter;
    this.c = i;
    this.mOriginalOffsetTop = i;
    a(1.0F);
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, LAYOUT_ATTRS);
    setEnabled(typedArray.getBoolean(0, true));
    typedArray.recycle();
  }
  
  private void animateOffsetToCorrectPosition(int paramInt, Animation.AnimationListener paramAnimationListener) {
    this.mFrom = paramInt;
    this.mAnimateToCorrectPosition.reset();
    this.mAnimateToCorrectPosition.setDuration(200L);
    this.mAnimateToCorrectPosition.setInterpolator((Interpolator)this.mDecelerateInterpolator);
    if (paramAnimationListener != null)
      this.e.setAnimationListener(paramAnimationListener); 
    this.e.clearAnimation();
    this.e.startAnimation(this.mAnimateToCorrectPosition);
  }
  
  private void animateOffsetToStartPosition(int paramInt, Animation.AnimationListener paramAnimationListener) {
    if (this.d) {
      startScaleDownReturnToStartAnimation(paramInt, paramAnimationListener);
      return;
    } 
    this.mFrom = paramInt;
    this.mAnimateToStartPosition.reset();
    this.mAnimateToStartPosition.setDuration(200L);
    this.mAnimateToStartPosition.setInterpolator((Interpolator)this.mDecelerateInterpolator);
    if (paramAnimationListener != null)
      this.e.setAnimationListener(paramAnimationListener); 
    this.e.clearAnimation();
    this.e.startAnimation(this.mAnimateToStartPosition);
  }
  
  private void createProgressView() {
    this.e = new CircleImageView(getContext(), -328966);
    this.h = new CircularProgressDrawable(getContext());
    this.h.setStyle(1);
    this.e.setImageDrawable(this.h);
    this.e.setVisibility(8);
    addView((View)this.e);
  }
  
  private void ensureTarget() {
    if (this.mTarget == null)
      for (byte b = 0; b < getChildCount(); b++) {
        View view = getChildAt(b);
        if (!view.equals(this.e)) {
          this.mTarget = view;
          return;
        } 
      }  
  }
  
  private void finishSpinner(float paramFloat) {
    if (paramFloat > this.mTotalDragDistance) {
      setRefreshing(true, true);
      return;
    } 
    this.b = false;
    this.h.setStartEndTrim(0.0F, 0.0F);
    boolean bool = this.d;
    Animation.AnimationListener animationListener = null;
    if (!bool)
      animationListener = new Animation.AnimationListener(this) {
          public void onAnimationEnd(Animation param1Animation) {
            if (!this.a.d)
              this.a.a((Animation.AnimationListener)null); 
          }
          
          public void onAnimationRepeat(Animation param1Animation) {}
          
          public void onAnimationStart(Animation param1Animation) {}
        }; 
    animateOffsetToStartPosition(this.c, animationListener);
    this.h.setArrowEnabled(false);
  }
  
  private boolean isAnimationRunning(Animation paramAnimation) {
    return (paramAnimation != null && paramAnimation.hasStarted() && !paramAnimation.hasEnded());
  }
  
  private void moveSpinner(float paramFloat) {
    int i;
    this.h.setArrowEnabled(true);
    float f1 = Math.min(1.0F, Math.abs(paramFloat / this.mTotalDragDistance));
    double d1 = f1;
    Double.isNaN(d1);
    float f2 = 5.0F * (float)Math.max(d1 - 0.4D, 0.0D) / 3.0F;
    float f3 = Math.abs(paramFloat) - this.mTotalDragDistance;
    if (this.j) {
      i = this.g - this.mOriginalOffsetTop;
    } else {
      i = this.g;
    } 
    float f4 = i;
    double d2 = (Math.max(0.0F, Math.min(f3, f4 * 2.0F) / f4) / 4.0F);
    double d3 = Math.pow(d2, 2.0D);
    Double.isNaN(d2);
    float f5 = 2.0F * (float)(d2 - d3);
    float f6 = 2.0F * f4 * f5;
    int j = this.mOriginalOffsetTop + (int)(f6 + f4 * f1);
    if (this.e.getVisibility() != 0)
      this.e.setVisibility(0); 
    if (!this.d) {
      this.e.setScaleX(1.0F);
      this.e.setScaleY(1.0F);
    } 
    if (this.d)
      setAnimationProgress(Math.min(1.0F, paramFloat / this.mTotalDragDistance)); 
    if (paramFloat < this.mTotalDragDistance) {
      if (this.h.getAlpha() > 76 && !isAnimationRunning(this.mAlphaStartAnimation))
        startProgressAlphaStartAnimation(); 
    } else if (this.h.getAlpha() < 255 && !isAnimationRunning(this.mAlphaMaxAnimation)) {
      startProgressAlphaMaxAnimation();
    } 
    float f7 = f2 * 0.8F;
    this.h.setStartEndTrim(0.0F, Math.min(0.8F, f7));
    this.h.setArrowScale(Math.min(1.0F, f2));
    float f8 = 0.5F * (-0.25F + f2 * 0.4F + f5 * 2.0F);
    this.h.setProgressRotation(f8);
    setTargetOffsetTopAndBottom(j - this.c);
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.mActivePointerId) {
      boolean bool;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mActivePointerId = paramMotionEvent.getPointerId(bool);
    } 
  }
  
  private void setColorViewAlpha(int paramInt) {
    this.e.getBackground().setAlpha(paramInt);
    this.h.setAlpha(paramInt);
  }
  
  private void setRefreshing(boolean paramBoolean1, boolean paramBoolean2) {
    if (this.b != paramBoolean1) {
      this.i = paramBoolean2;
      ensureTarget();
      this.b = paramBoolean1;
      if (this.b) {
        animateOffsetToCorrectPosition(this.c, this.mRefreshListener);
        return;
      } 
      a(this.mRefreshListener);
    } 
  }
  
  private Animation startAlphaAnimation(int paramInt1, int paramInt2) {
    Animation animation = new Animation(this, paramInt1, paramInt2) {
        public void applyTransformation(float param1Float, Transformation param1Transformation) {
          this.c.h.setAlpha((int)(this.a + param1Float * (this.b - this.a)));
        }
      };
    animation.setDuration(300L);
    this.e.setAnimationListener((Animation.AnimationListener)null);
    this.e.clearAnimation();
    this.e.startAnimation(animation);
    return animation;
  }
  
  private void startDragging(float paramFloat) {
    if (paramFloat - this.mInitialDownY > this.mTouchSlop && !this.mIsBeingDragged) {
      this.mInitialMotionY = this.mInitialDownY + this.mTouchSlop;
      this.mIsBeingDragged = true;
      this.h.setAlpha(76);
    } 
  }
  
  private void startProgressAlphaMaxAnimation() {
    this.mAlphaMaxAnimation = startAlphaAnimation(this.h.getAlpha(), 255);
  }
  
  private void startProgressAlphaStartAnimation() {
    this.mAlphaStartAnimation = startAlphaAnimation(this.h.getAlpha(), 76);
  }
  
  private void startScaleDownReturnToStartAnimation(int paramInt, Animation.AnimationListener paramAnimationListener) {
    this.mFrom = paramInt;
    this.f = this.e.getScaleX();
    this.mScaleDownToStartAnimation = new Animation(this) {
        public void applyTransformation(float param1Float, Transformation param1Transformation) {
          float f = this.a.f + param1Float * -this.a.f;
          this.a.setAnimationProgress(f);
          this.a.a(param1Float);
        }
      };
    this.mScaleDownToStartAnimation.setDuration(150L);
    if (paramAnimationListener != null)
      this.e.setAnimationListener(paramAnimationListener); 
    this.e.clearAnimation();
    this.e.startAnimation(this.mScaleDownToStartAnimation);
  }
  
  private void startScaleUpAnimation(Animation.AnimationListener paramAnimationListener) {
    this.e.setVisibility(0);
    this.h.setAlpha(255);
    this.mScaleAnimation = new Animation(this) {
        public void applyTransformation(float param1Float, Transformation param1Transformation) {
          this.a.setAnimationProgress(param1Float);
        }
      };
    this.mScaleAnimation.setDuration(this.mMediumAnimationDuration);
    if (paramAnimationListener != null)
      this.e.setAnimationListener(paramAnimationListener); 
    this.e.clearAnimation();
    this.e.startAnimation(this.mScaleAnimation);
  }
  
  void a() {
    this.e.clearAnimation();
    this.h.stop();
    this.e.setVisibility(8);
    setColorViewAlpha(255);
    if (this.d) {
      setAnimationProgress(0.0F);
    } else {
      setTargetOffsetTopAndBottom(this.mOriginalOffsetTop - this.c);
    } 
    this.c = this.e.getTop();
  }
  
  void a(float paramFloat) {
    setTargetOffsetTopAndBottom(this.mFrom + (int)(paramFloat * (this.mOriginalOffsetTop - this.mFrom)) - this.e.getTop());
  }
  
  void a(Animation.AnimationListener paramAnimationListener) {
    this.mScaleDownAnimation = new Animation(this) {
        public void applyTransformation(float param1Float, Transformation param1Transformation) {
          this.a.setAnimationProgress(1.0F - param1Float);
        }
      };
    this.mScaleDownAnimation.setDuration(150L);
    this.e.setAnimationListener(paramAnimationListener);
    this.e.clearAnimation();
    this.e.startAnimation(this.mScaleDownAnimation);
  }
  
  public boolean canChildScrollUp() {
    return (this.mChildScrollUpCallback != null) ? this.mChildScrollUpCallback.canChildScrollUp(this, this.mTarget) : ((this.mTarget instanceof ListView) ? ListViewCompat.canScrollList((ListView)this.mTarget, -1) : this.mTarget.canScrollVertically(-1));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.mNestedScrollingChildHelper.dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.mNestedScrollingChildHelper.dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return this.mNestedScrollingChildHelper.dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.mNestedScrollingChildHelper.dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  protected int getChildDrawingOrder(int paramInt1, int paramInt2) {
    return (this.mCircleViewIndex < 0) ? paramInt2 : ((paramInt2 == paramInt1 - 1) ? this.mCircleViewIndex : ((paramInt2 >= this.mCircleViewIndex) ? (paramInt2 + 1) : paramInt2));
  }
  
  public int getNestedScrollAxes() {
    return this.mNestedScrollingParentHelper.getNestedScrollAxes();
  }
  
  public int getProgressCircleDiameter() {
    return this.mCircleDiameter;
  }
  
  public int getProgressViewEndOffset() {
    return this.g;
  }
  
  public int getProgressViewStartOffset() {
    return this.mOriginalOffsetTop;
  }
  
  public boolean hasNestedScrollingParent() {
    return this.mNestedScrollingChildHelper.hasNestedScrollingParent();
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.mNestedScrollingChildHelper.isNestedScrollingEnabled();
  }
  
  public boolean isRefreshing() {
    return this.b;
  }
  
  protected void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    a();
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    ensureTarget();
    int i = paramMotionEvent.getActionMasked();
    if (this.mReturningToStart && i == 0)
      this.mReturningToStart = false; 
    if (isEnabled() && !this.mReturningToStart && !canChildScrollUp() && !this.b) {
      if (this.mNestedScrollInProgress)
        return false; 
      if (i != 6) {
        int k;
        switch (i) {
          default:
            return this.mIsBeingDragged;
          case 2:
            if (this.mActivePointerId == -1) {
              Log.e(LOG_TAG, "Got ACTION_MOVE event but don't have an active pointer id.");
              return false;
            } 
            k = paramMotionEvent.findPointerIndex(this.mActivePointerId);
            if (k < 0)
              return false; 
            startDragging(paramMotionEvent.getY(k));
          case 1:
          case 3:
            this.mIsBeingDragged = false;
            this.mActivePointerId = -1;
          case 0:
            break;
        } 
        setTargetOffsetTopAndBottom(this.mOriginalOffsetTop - this.e.getTop());
        this.mActivePointerId = paramMotionEvent.getPointerId(0);
        this.mIsBeingDragged = false;
        int j = paramMotionEvent.findPointerIndex(this.mActivePointerId);
        if (j < 0)
          return false; 
        this.mInitialDownY = paramMotionEvent.getY(j);
      } 
      onSecondaryPointerUp(paramMotionEvent);
    } 
    return false;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getMeasuredWidth();
    int j = getMeasuredHeight();
    if (getChildCount() == 0)
      return; 
    if (this.mTarget == null)
      ensureTarget(); 
    if (this.mTarget == null)
      return; 
    View view = this.mTarget;
    int k = getPaddingLeft();
    int m = getPaddingTop();
    int n = i - getPaddingLeft() - getPaddingRight();
    int i1 = j - getPaddingTop() - getPaddingBottom();
    view.layout(k, m, n + k, i1 + m);
    int i2 = this.e.getMeasuredWidth();
    int i3 = this.e.getMeasuredHeight();
    CircleImageView circleImageView = this.e;
    int i4 = i / 2;
    int i5 = i2 / 2;
    circleImageView.layout(i4 - i5, this.c, i4 + i5, i3 + this.c);
  }
  
  public void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (this.mTarget == null)
      ensureTarget(); 
    if (this.mTarget == null)
      return; 
    this.mTarget.measure(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth() - getPaddingLeft() - getPaddingRight(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight() - getPaddingTop() - getPaddingBottom(), 1073741824));
    this.e.measure(View.MeasureSpec.makeMeasureSpec(this.mCircleDiameter, 1073741824), View.MeasureSpec.makeMeasureSpec(this.mCircleDiameter, 1073741824));
    this.mCircleViewIndex = -1;
    for (byte b = 0; b < getChildCount(); b++) {
      if (getChildAt(b) == this.e) {
        this.mCircleViewIndex = b;
        return;
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    if (paramInt2 > 0 && this.mTotalUnconsumed > 0.0F) {
      float f = paramInt2;
      if (f > this.mTotalUnconsumed) {
        paramArrayOfint[1] = paramInt2 - (int)this.mTotalUnconsumed;
        this.mTotalUnconsumed = 0.0F;
      } else {
        this.mTotalUnconsumed -= f;
        paramArrayOfint[1] = paramInt2;
      } 
      moveSpinner(this.mTotalUnconsumed);
    } 
    if (this.j && paramInt2 > 0 && this.mTotalUnconsumed == 0.0F && Math.abs(paramInt2 - paramArrayOfint[1]) > 0)
      this.e.setVisibility(8); 
    int[] arrayOfInt = this.mParentScrollConsumed;
    if (dispatchNestedPreScroll(paramInt1 - paramArrayOfint[0], paramInt2 - paramArrayOfint[1], arrayOfInt, (int[])null)) {
      paramArrayOfint[0] = paramArrayOfint[0] + arrayOfInt[0];
      paramArrayOfint[1] = paramArrayOfint[1] + arrayOfInt[1];
    } 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, this.mParentOffsetInWindow);
    int i = paramInt4 + this.mParentOffsetInWindow[1];
    if (i < 0 && !canChildScrollUp()) {
      this.mTotalUnconsumed += Math.abs(i);
      moveSpinner(this.mTotalUnconsumed);
    } 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.mNestedScrollingParentHelper.onNestedScrollAccepted(paramView1, paramView2, paramInt);
    startNestedScroll(paramInt & 0x2);
    this.mTotalUnconsumed = 0.0F;
    this.mNestedScrollInProgress = true;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return (isEnabled() && !this.mReturningToStart && !this.b && (paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.mNestedScrollingParentHelper.onStopNestedScroll(paramView);
    this.mNestedScrollInProgress = false;
    if (this.mTotalUnconsumed > 0.0F) {
      finishSpinner(this.mTotalUnconsumed);
      this.mTotalUnconsumed = 0.0F;
    } 
    stopNestedScroll();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (this.mReturningToStart && i == 0)
      this.mReturningToStart = false; 
    if (isEnabled() && !this.mReturningToStart && !canChildScrollUp() && !this.b) {
      int j;
      int k;
      float f;
      int m;
      if (this.mNestedScrollInProgress)
        return false; 
      switch (i) {
        default:
          return true;
        case 6:
          onSecondaryPointerUp(paramMotionEvent);
        case 5:
          m = paramMotionEvent.getActionIndex();
          if (m < 0) {
            Log.e(LOG_TAG, "Got ACTION_POINTER_DOWN event but have an invalid action index.");
            return false;
          } 
          this.mActivePointerId = paramMotionEvent.getPointerId(m);
        case 3:
          return false;
        case 2:
          k = paramMotionEvent.findPointerIndex(this.mActivePointerId);
          if (k < 0) {
            Log.e(LOG_TAG, "Got ACTION_MOVE event but have an invalid active pointer id.");
            return false;
          } 
          f = paramMotionEvent.getY(k);
          startDragging(f);
          if (this.mIsBeingDragged) {
            float f1 = 0.5F * (f - this.mInitialMotionY);
            if (f1 > 0.0F) {
              moveSpinner(f1);
            } else {
              return false;
            } 
          } 
        case 1:
          j = paramMotionEvent.findPointerIndex(this.mActivePointerId);
          if (j < 0) {
            Log.e(LOG_TAG, "Got ACTION_UP event but don't have an active pointer id.");
            return false;
          } 
          if (this.mIsBeingDragged) {
            float f1 = 0.5F * (paramMotionEvent.getY(j) - this.mInitialMotionY);
            this.mIsBeingDragged = false;
            finishSpinner(f1);
          } 
          this.mActivePointerId = -1;
          return false;
        case 0:
          break;
      } 
      this.mActivePointerId = paramMotionEvent.getPointerId(0);
      this.mIsBeingDragged = false;
    } 
    return false;
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (Build.VERSION.SDK_INT >= 21 || !(this.mTarget instanceof android.widget.AbsListView)) {
      if (this.mTarget != null && !ViewCompat.isNestedScrollingEnabled(this.mTarget))
        return; 
      super.requestDisallowInterceptTouchEvent(paramBoolean);
    } 
  }
  
  void setAnimationProgress(float paramFloat) {
    this.e.setScaleX(paramFloat);
    this.e.setScaleY(paramFloat);
  }
  
  @Deprecated
  public void setColorScheme(@ColorRes int... paramVarArgs) {
    setColorSchemeResources(paramVarArgs);
  }
  
  public void setColorSchemeColors(@ColorInt int... paramVarArgs) {
    ensureTarget();
    this.h.setColorSchemeColors(paramVarArgs);
  }
  
  public void setColorSchemeResources(@ColorRes int... paramVarArgs) {
    Context context = getContext();
    int[] arrayOfInt = new int[paramVarArgs.length];
    for (byte b = 0; b < paramVarArgs.length; b++)
      arrayOfInt[b] = ContextCompat.getColor(context, paramVarArgs[b]); 
    setColorSchemeColors(arrayOfInt);
  }
  
  public void setDistanceToTriggerSync(int paramInt) {
    this.mTotalDragDistance = paramInt;
  }
  
  public void setEnabled(boolean paramBoolean) {
    super.setEnabled(paramBoolean);
    if (!paramBoolean)
      a(); 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.mNestedScrollingChildHelper.setNestedScrollingEnabled(paramBoolean);
  }
  
  public void setOnChildScrollUpCallback(@Nullable OnChildScrollUpCallback paramOnChildScrollUpCallback) {
    this.mChildScrollUpCallback = paramOnChildScrollUpCallback;
  }
  
  public void setOnRefreshListener(@Nullable OnRefreshListener paramOnRefreshListener) {
    this.a = paramOnRefreshListener;
  }
  
  @Deprecated
  public void setProgressBackgroundColor(int paramInt) {
    setProgressBackgroundColorSchemeResource(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeColor(@ColorInt int paramInt) {
    this.e.setBackgroundColor(paramInt);
  }
  
  public void setProgressBackgroundColorSchemeResource(@ColorRes int paramInt) {
    setProgressBackgroundColorSchemeColor(ContextCompat.getColor(getContext(), paramInt));
  }
  
  public void setProgressViewEndTarget(boolean paramBoolean, int paramInt) {
    this.g = paramInt;
    this.d = paramBoolean;
    this.e.invalidate();
  }
  
  public void setProgressViewOffset(boolean paramBoolean, int paramInt1, int paramInt2) {
    this.d = paramBoolean;
    this.mOriginalOffsetTop = paramInt1;
    this.g = paramInt2;
    this.j = true;
    a();
    this.b = false;
  }
  
  public void setRefreshing(boolean paramBoolean) {
    if (paramBoolean && this.b != paramBoolean) {
      int i;
      this.b = paramBoolean;
      if (!this.j) {
        i = this.g + this.mOriginalOffsetTop;
      } else {
        i = this.g;
      } 
      setTargetOffsetTopAndBottom(i - this.c);
      this.i = false;
      startScaleUpAnimation(this.mRefreshListener);
      return;
    } 
    setRefreshing(paramBoolean, false);
  }
  
  public void setSize(int paramInt) {
    if (paramInt != 0 && paramInt != 1)
      return; 
    DisplayMetrics displayMetrics = getResources().getDisplayMetrics();
    if (paramInt == 0) {
      this.mCircleDiameter = (int)(56.0F * displayMetrics.density);
    } else {
      this.mCircleDiameter = (int)(40.0F * displayMetrics.density);
    } 
    this.e.setImageDrawable(null);
    this.h.setStyle(paramInt);
    this.e.setImageDrawable(this.h);
  }
  
  void setTargetOffsetTopAndBottom(int paramInt) {
    this.e.bringToFront();
    ViewCompat.offsetTopAndBottom((View)this.e, paramInt);
    this.c = this.e.getTop();
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.mNestedScrollingChildHelper.startNestedScroll(paramInt);
  }
  
  public void stopNestedScroll() {
    this.mNestedScrollingChildHelper.stopNestedScroll();
  }
  
  public static interface OnChildScrollUpCallback {
    boolean canChildScrollUp(@NonNull SwipeRefreshLayout param1SwipeRefreshLayout, @Nullable View param1View);
  }
  
  public static interface OnRefreshListener {
    void onRefresh();
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\SwipeRefreshLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */