package android.support.v4.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.os.Bundle;
import android.os.Parcel;
import android.os.Parcelable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.view.AccessibilityDelegateCompat;
import android.support.v4.view.NestedScrollingChild2;
import android.support.v4.view.NestedScrollingChildHelper;
import android.support.v4.view.NestedScrollingParent;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.ScrollingView;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.accessibility.AccessibilityNodeInfoCompat;
import android.support.v4.view.accessibility.AccessibilityRecordCompat;
import android.util.AttributeSet;
import android.util.Log;
import android.util.TypedValue;
import android.view.FocusFinder;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityRecord;
import android.view.animation.AnimationUtils;
import android.widget.EdgeEffect;
import android.widget.FrameLayout;
import android.widget.OverScroller;
import android.widget.ScrollView;

public class NestedScrollView extends FrameLayout implements NestedScrollingChild2, NestedScrollingParent, ScrollingView {
  private static final AccessibilityDelegate ACCESSIBILITY_DELEGATE = new AccessibilityDelegate();
  
  private static final int INVALID_POINTER = -1;
  
  private static final int[] SCROLLVIEW_STYLEABLE = new int[] { 16843130 };
  
  private static final String TAG = "NestedScrollView";
  
  private int mActivePointerId = -1;
  
  private final NestedScrollingChildHelper mChildHelper;
  
  private View mChildToScrollTo = null;
  
  private EdgeEffect mEdgeGlowBottom;
  
  private EdgeEffect mEdgeGlowTop;
  
  private boolean mFillViewport;
  
  private boolean mIsBeingDragged = false;
  
  private boolean mIsLaidOut = false;
  
  private boolean mIsLayoutDirty = true;
  
  private int mLastMotionY;
  
  private long mLastScroll;
  
  private int mLastScrollerY;
  
  private int mMaximumVelocity;
  
  private int mMinimumVelocity;
  
  private int mNestedYOffset;
  
  private OnScrollChangeListener mOnScrollChangeListener;
  
  private final NestedScrollingParentHelper mParentHelper;
  
  private SavedState mSavedState;
  
  private final int[] mScrollConsumed = new int[2];
  
  private final int[] mScrollOffset = new int[2];
  
  private OverScroller mScroller;
  
  private boolean mSmoothScrollingEnabled = true;
  
  private final Rect mTempRect = new Rect();
  
  private int mTouchSlop;
  
  private VelocityTracker mVelocityTracker;
  
  private float mVerticalScrollFactor;
  
  public NestedScrollView(@NonNull Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public NestedScrollView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, 0);
  }
  
  public NestedScrollView(@NonNull Context paramContext, @Nullable AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    initScrollView();
    TypedArray typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, SCROLLVIEW_STYLEABLE, paramInt, 0);
    setFillViewport(typedArray.getBoolean(0, false));
    typedArray.recycle();
    this.mParentHelper = new NestedScrollingParentHelper((ViewGroup)this);
    this.mChildHelper = new NestedScrollingChildHelper((View)this);
    setNestedScrollingEnabled(true);
    ViewCompat.setAccessibilityDelegate((View)this, ACCESSIBILITY_DELEGATE);
  }
  
  private boolean canScroll() {
    View view = getChildAt(0);
    if (view != null) {
      int i = view.getHeight();
      int j = getHeight();
      int k = i + getPaddingTop() + getPaddingBottom();
      boolean bool = false;
      if (j < k)
        bool = true; 
      return bool;
    } 
    return false;
  }
  
  private static int clamp(int paramInt1, int paramInt2, int paramInt3) {
    return (paramInt2 >= paramInt3 || paramInt1 < 0) ? 0 : ((paramInt2 + paramInt1 > paramInt3) ? (paramInt3 - paramInt2) : paramInt1);
  }
  
  private void doScrollY(int paramInt) {
    if (paramInt != 0) {
      if (this.mSmoothScrollingEnabled) {
        smoothScrollBy(0, paramInt);
        return;
      } 
      scrollBy(0, paramInt);
    } 
  }
  
  private void endDrag() {
    this.mIsBeingDragged = false;
    recycleVelocityTracker();
    stopNestedScroll(0);
    if (this.mEdgeGlowTop != null) {
      this.mEdgeGlowTop.onRelease();
      this.mEdgeGlowBottom.onRelease();
    } 
  }
  
  private void ensureGlows() {
    if (getOverScrollMode() != 2) {
      if (this.mEdgeGlowTop == null) {
        Context context = getContext();
        this.mEdgeGlowTop = new EdgeEffect(context);
        this.mEdgeGlowBottom = new EdgeEffect(context);
        return;
      } 
    } else {
      this.mEdgeGlowTop = null;
      this.mEdgeGlowBottom = null;
    } 
  }
  
  private View findFocusableViewInBounds(boolean paramBoolean, int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: iconst_2
    //   2: invokevirtual getFocusables : (I)Ljava/util/ArrayList;
    //   5: astore #4
    //   7: aload #4
    //   9: invokeinterface size : ()I
    //   14: istore #5
    //   16: aconst_null
    //   17: astore #6
    //   19: iconst_0
    //   20: istore #7
    //   22: iconst_0
    //   23: istore #8
    //   25: iload #7
    //   27: iload #5
    //   29: if_icmpge -> 194
    //   32: aload #4
    //   34: iload #7
    //   36: invokeinterface get : (I)Ljava/lang/Object;
    //   41: checkcast android/view/View
    //   44: astore #9
    //   46: aload #9
    //   48: invokevirtual getTop : ()I
    //   51: istore #10
    //   53: aload #9
    //   55: invokevirtual getBottom : ()I
    //   58: istore #11
    //   60: iload_2
    //   61: iload #11
    //   63: if_icmpge -> 188
    //   66: iload #10
    //   68: iload_3
    //   69: if_icmpge -> 188
    //   72: iload_2
    //   73: iload #10
    //   75: if_icmpge -> 90
    //   78: iload #11
    //   80: iload_3
    //   81: if_icmpge -> 90
    //   84: iconst_1
    //   85: istore #12
    //   87: goto -> 93
    //   90: iconst_0
    //   91: istore #12
    //   93: aload #6
    //   95: ifnonnull -> 109
    //   98: aload #9
    //   100: astore #6
    //   102: iload #12
    //   104: istore #8
    //   106: goto -> 188
    //   109: iload_1
    //   110: ifeq -> 123
    //   113: iload #10
    //   115: aload #6
    //   117: invokevirtual getTop : ()I
    //   120: if_icmplt -> 137
    //   123: iload_1
    //   124: ifne -> 143
    //   127: iload #11
    //   129: aload #6
    //   131: invokevirtual getBottom : ()I
    //   134: if_icmple -> 143
    //   137: iconst_1
    //   138: istore #13
    //   140: goto -> 146
    //   143: iconst_0
    //   144: istore #13
    //   146: iload #8
    //   148: ifeq -> 164
    //   151: iload #12
    //   153: ifeq -> 188
    //   156: iload #13
    //   158: ifeq -> 188
    //   161: goto -> 184
    //   164: iload #12
    //   166: ifeq -> 179
    //   169: aload #9
    //   171: astore #6
    //   173: iconst_1
    //   174: istore #8
    //   176: goto -> 188
    //   179: iload #13
    //   181: ifeq -> 188
    //   184: aload #9
    //   186: astore #6
    //   188: iinc #7, 1
    //   191: goto -> 25
    //   194: aload #6
    //   196: areturn
  }
  
  private void flingWithNestedDispatch(int paramInt) {
    boolean bool;
    int i = getScrollY();
    if ((i > 0 || paramInt > 0) && (i < getScrollRange() || paramInt < 0)) {
      bool = true;
    } else {
      bool = false;
    } 
    float f = paramInt;
    if (!dispatchNestedPreFling(0.0F, f)) {
      dispatchNestedFling(0.0F, f, bool);
      fling(paramInt);
    } 
  }
  
  private float getVerticalScrollFactorCompat() {
    if (this.mVerticalScrollFactor == 0.0F) {
      TypedValue typedValue = new TypedValue();
      Context context = getContext();
      if (context.getTheme().resolveAttribute(16842829, typedValue, true)) {
        this.mVerticalScrollFactor = typedValue.getDimension(context.getResources().getDisplayMetrics());
      } else {
        throw new IllegalStateException("Expected theme to define listPreferredItemHeight.");
      } 
    } 
    return this.mVerticalScrollFactor;
  }
  
  private boolean inChild(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      int i = getScrollY();
      View view = getChildAt(0);
      int j = view.getTop() - i;
      boolean bool = false;
      if (paramInt2 >= j) {
        int k = view.getBottom() - i;
        bool = false;
        if (paramInt2 < k) {
          int m = view.getLeft();
          bool = false;
          if (paramInt1 >= m) {
            int n = view.getRight();
            bool = false;
            if (paramInt1 < n)
              bool = true; 
          } 
        } 
      } 
      return bool;
    } 
    return false;
  }
  
  private void initOrResetVelocityTracker() {
    if (this.mVelocityTracker == null) {
      this.mVelocityTracker = VelocityTracker.obtain();
      return;
    } 
    this.mVelocityTracker.clear();
  }
  
  private void initScrollView() {
    this.mScroller = new OverScroller(getContext());
    setFocusable(true);
    setDescendantFocusability(262144);
    setWillNotDraw(false);
    ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
    this.mTouchSlop = viewConfiguration.getScaledTouchSlop();
    this.mMinimumVelocity = viewConfiguration.getScaledMinimumFlingVelocity();
    this.mMaximumVelocity = viewConfiguration.getScaledMaximumFlingVelocity();
  }
  
  private void initVelocityTrackerIfNotExists() {
    if (this.mVelocityTracker == null)
      this.mVelocityTracker = VelocityTracker.obtain(); 
  }
  
  private boolean isOffScreen(View paramView) {
    return true ^ isWithinDeltaOfScreen(paramView, 0, getHeight());
  }
  
  private static boolean isViewDescendantOf(View paramView1, View paramView2) {
    if (paramView1 == paramView2)
      return true; 
    ViewParent viewParent = paramView1.getParent();
    return (viewParent instanceof ViewGroup && isViewDescendantOf((View)viewParent, paramView2));
  }
  
  private boolean isWithinDeltaOfScreen(View paramView, int paramInt1, int paramInt2) {
    paramView.getDrawingRect(this.mTempRect);
    offsetDescendantRectToMyCoords(paramView, this.mTempRect);
    return (paramInt1 + this.mTempRect.bottom >= getScrollY() && this.mTempRect.top - paramInt1 <= paramInt2 + getScrollY());
  }
  
  private void onSecondaryPointerUp(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionIndex();
    if (paramMotionEvent.getPointerId(i) == this.mActivePointerId) {
      boolean bool;
      if (i == 0) {
        bool = true;
      } else {
        bool = false;
      } 
      this.mLastMotionY = (int)paramMotionEvent.getY(bool);
      this.mActivePointerId = paramMotionEvent.getPointerId(bool);
      if (this.mVelocityTracker != null)
        this.mVelocityTracker.clear(); 
    } 
  }
  
  private void recycleVelocityTracker() {
    if (this.mVelocityTracker != null) {
      this.mVelocityTracker.recycle();
      this.mVelocityTracker = null;
    } 
  }
  
  private boolean scrollAndFocus(int paramInt1, int paramInt2, int paramInt3) {
    boolean bool1;
    NestedScrollView nestedScrollView;
    boolean bool2;
    int i = getHeight();
    int j = getScrollY();
    int k = i + j;
    if (paramInt1 == 33) {
      bool1 = true;
    } else {
      bool1 = false;
    } 
    View view = findFocusableViewInBounds(bool1, paramInt2, paramInt3);
    if (view == null)
      nestedScrollView = this; 
    if (paramInt2 >= j && paramInt3 <= k) {
      bool2 = false;
    } else {
      int m;
      if (bool1) {
        m = paramInt2 - j;
      } else {
        m = paramInt3 - k;
      } 
      doScrollY(m);
      bool2 = true;
    } 
    if (nestedScrollView != findFocus())
      nestedScrollView.requestFocus(paramInt1); 
    return bool2;
  }
  
  private void scrollToChild(View paramView) {
    paramView.getDrawingRect(this.mTempRect);
    offsetDescendantRectToMyCoords(paramView, this.mTempRect);
    int i = computeScrollDeltaToGetChildRectOnScreen(this.mTempRect);
    if (i != 0)
      scrollBy(0, i); 
  }
  
  private boolean scrollToChildRect(Rect paramRect, boolean paramBoolean) {
    boolean bool;
    int i = computeScrollDeltaToGetChildRectOnScreen(paramRect);
    if (i != 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (bool) {
      if (paramBoolean) {
        scrollBy(0, i);
        return bool;
      } 
      smoothScrollBy(0, i);
    } 
    return bool;
  }
  
  boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual getOverScrollMode : ()I
    //   4: istore #10
    //   6: aload_0
    //   7: invokevirtual computeHorizontalScrollRange : ()I
    //   10: aload_0
    //   11: invokevirtual computeHorizontalScrollExtent : ()I
    //   14: if_icmple -> 23
    //   17: iconst_1
    //   18: istore #11
    //   20: goto -> 26
    //   23: iconst_0
    //   24: istore #11
    //   26: aload_0
    //   27: invokevirtual computeVerticalScrollRange : ()I
    //   30: aload_0
    //   31: invokevirtual computeVerticalScrollExtent : ()I
    //   34: if_icmple -> 43
    //   37: iconst_1
    //   38: istore #12
    //   40: goto -> 46
    //   43: iconst_0
    //   44: istore #12
    //   46: iload #10
    //   48: ifeq -> 71
    //   51: iload #10
    //   53: iconst_1
    //   54: if_icmpne -> 65
    //   57: iload #11
    //   59: ifeq -> 65
    //   62: goto -> 71
    //   65: iconst_0
    //   66: istore #13
    //   68: goto -> 74
    //   71: iconst_1
    //   72: istore #13
    //   74: iload #10
    //   76: ifeq -> 99
    //   79: iload #10
    //   81: iconst_1
    //   82: if_icmpne -> 93
    //   85: iload #12
    //   87: ifeq -> 93
    //   90: goto -> 99
    //   93: iconst_0
    //   94: istore #14
    //   96: goto -> 102
    //   99: iconst_1
    //   100: istore #14
    //   102: iload_3
    //   103: iload_1
    //   104: iadd
    //   105: istore #15
    //   107: iload #13
    //   109: ifne -> 118
    //   112: iconst_0
    //   113: istore #16
    //   115: goto -> 122
    //   118: iload #7
    //   120: istore #16
    //   122: iload #4
    //   124: iload_2
    //   125: iadd
    //   126: istore #17
    //   128: iload #14
    //   130: ifne -> 139
    //   133: iconst_0
    //   134: istore #18
    //   136: goto -> 143
    //   139: iload #8
    //   141: istore #18
    //   143: iload #16
    //   145: ineg
    //   146: istore #19
    //   148: iload #16
    //   150: iload #5
    //   152: iadd
    //   153: istore #20
    //   155: iload #18
    //   157: ineg
    //   158: istore #21
    //   160: iload #18
    //   162: iload #6
    //   164: iadd
    //   165: istore #22
    //   167: iload #15
    //   169: iload #20
    //   171: if_icmple -> 184
    //   174: iload #20
    //   176: istore #19
    //   178: iconst_1
    //   179: istore #23
    //   181: goto -> 201
    //   184: iload #15
    //   186: iload #19
    //   188: if_icmpge -> 194
    //   191: goto -> 178
    //   194: iload #15
    //   196: istore #19
    //   198: iconst_0
    //   199: istore #23
    //   201: iload #17
    //   203: iload #22
    //   205: if_icmple -> 218
    //   208: iload #22
    //   210: istore #21
    //   212: iconst_1
    //   213: istore #24
    //   215: goto -> 235
    //   218: iload #17
    //   220: iload #21
    //   222: if_icmpge -> 228
    //   225: goto -> 212
    //   228: iload #17
    //   230: istore #21
    //   232: iconst_0
    //   233: istore #24
    //   235: iload #24
    //   237: ifeq -> 275
    //   240: aload_0
    //   241: iconst_1
    //   242: invokevirtual hasNestedScrollingParent : (I)Z
    //   245: ifne -> 275
    //   248: aload_0
    //   249: getfield mScroller : Landroid/widget/OverScroller;
    //   252: astore #26
    //   254: aload_0
    //   255: invokevirtual getScrollRange : ()I
    //   258: istore #27
    //   260: aload #26
    //   262: iload #19
    //   264: iload #21
    //   266: iconst_0
    //   267: iconst_0
    //   268: iconst_0
    //   269: iload #27
    //   271: invokevirtual springBack : (IIIIII)Z
    //   274: pop
    //   275: aload_0
    //   276: iload #19
    //   278: iload #21
    //   280: iload #23
    //   282: iload #24
    //   284: invokevirtual onOverScrolled : (IIZZ)V
    //   287: iload #23
    //   289: ifne -> 300
    //   292: iconst_0
    //   293: istore #25
    //   295: iload #24
    //   297: ifeq -> 303
    //   300: iconst_1
    //   301: istore #25
    //   303: iload #25
    //   305: ireturn
  }
  
  public void addView(View paramView) {
    if (getChildCount() <= 0) {
      super.addView(paramView);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, int paramInt, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramInt, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public void addView(View paramView, ViewGroup.LayoutParams paramLayoutParams) {
    if (getChildCount() <= 0) {
      super.addView(paramView, paramLayoutParams);
      return;
    } 
    throw new IllegalStateException("ScrollView can host only one direct child");
  }
  
  public boolean arrowScroll(int paramInt) {
    View view1 = findFocus();
    if (view1 == this)
      view1 = null; 
    View view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, paramInt);
    int i = getMaxScrollAmount();
    if (view2 != null && isWithinDeltaOfScreen(view2, i, getHeight())) {
      view2.getDrawingRect(this.mTempRect);
      offsetDescendantRectToMyCoords(view2, this.mTempRect);
      doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
      view2.requestFocus(paramInt);
    } else {
      if (paramInt == 33 && getScrollY() < i) {
        i = getScrollY();
      } else if (paramInt == 130 && getChildCount() > 0) {
        int j = getChildAt(0).getBottom() - getScrollY() + getHeight() - getPaddingBottom();
        if (j < i)
          i = j; 
      } 
      if (i == 0)
        return false; 
      if (paramInt != 130)
        i = -i; 
      doScrollY(i);
    } 
    if (view1 != null && view1.isFocused() && isOffScreen(view1)) {
      int j = getDescendantFocusability();
      setDescendantFocusability(131072);
      requestFocus();
      setDescendantFocusability(j);
    } 
    return true;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeHorizontalScrollExtent() {
    return super.computeHorizontalScrollExtent();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeHorizontalScrollOffset() {
    return super.computeHorizontalScrollOffset();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeHorizontalScrollRange() {
    return super.computeHorizontalScrollRange();
  }
  
  public void computeScroll() {
    if (this.mScroller.computeScrollOffset()) {
      this.mScroller.getCurrX();
      int i = this.mScroller.getCurrY();
      int j = i - this.mLastScrollerY;
      int[] arrayOfInt = this.mScrollConsumed;
      if (dispatchNestedPreScroll(0, j, arrayOfInt, (int[])null, 1))
        j -= this.mScrollConsumed[1]; 
      int k = j;
      if (k != 0) {
        int m = getScrollRange();
        int n = getScrollY();
        a(0, k, getScrollX(), n, 0, m, 0, 0, false);
        int i1 = getScrollY() - n;
        if (!dispatchNestedScroll(0, i1, 0, k - i1, (int[])null, 1)) {
          boolean bool;
          int i2 = getOverScrollMode();
          if (i2 == 0 || (i2 == 1 && m > 0)) {
            bool = true;
          } else {
            bool = false;
          } 
          if (bool) {
            ensureGlows();
            if (i <= 0 && n > 0) {
              this.mEdgeGlowTop.onAbsorb((int)this.mScroller.getCurrVelocity());
            } else if (i >= m && n < m) {
              this.mEdgeGlowBottom.onAbsorb((int)this.mScroller.getCurrVelocity());
            } 
          } 
        } 
      } 
      this.mLastScrollerY = i;
      ViewCompat.postInvalidateOnAnimation((View)this);
      return;
    } 
    if (hasNestedScrollingParent(1))
      stopNestedScroll(1); 
    this.mLastScrollerY = 0;
  }
  
  protected int computeScrollDeltaToGetChildRectOnScreen(Rect paramRect) {
    if (getChildCount() == 0)
      return 0; 
    int i = getHeight();
    int j = getScrollY();
    int k = j + i;
    int m = getVerticalFadingEdgeLength();
    if (paramRect.top > 0)
      j += m; 
    if (paramRect.bottom < getChildAt(0).getHeight())
      k -= m; 
    if (paramRect.bottom > k && paramRect.top > j) {
      int i2;
      if (paramRect.height() > i) {
        i2 = 0 + paramRect.top - j;
      } else {
        i2 = 0 + paramRect.bottom - k;
      } 
      return Math.min(i2, getChildAt(0).getBottom() - k);
    } 
    int n = paramRect.top;
    int i1 = 0;
    if (n < j) {
      int i2 = paramRect.bottom;
      i1 = 0;
      if (i2 < k) {
        int i3;
        if (paramRect.height() > i) {
          i3 = 0 - k - paramRect.bottom;
        } else {
          i3 = 0 - j - paramRect.top;
        } 
        i1 = Math.max(i3, -getScrollY());
      } 
    } 
    return i1;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeVerticalScrollExtent() {
    return super.computeVerticalScrollExtent();
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeVerticalScrollOffset() {
    return Math.max(0, super.computeVerticalScrollOffset());
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public int computeVerticalScrollRange() {
    int i = getChildCount();
    int j = getHeight() - getPaddingBottom() - getPaddingTop();
    if (i == 0)
      return j; 
    int k = getChildAt(0).getBottom();
    int m = getScrollY();
    int n = Math.max(0, k - j);
    if (m < 0)
      return k - m; 
    if (m > n)
      k += m - n; 
    return k;
  }
  
  public boolean dispatchKeyEvent(KeyEvent paramKeyEvent) {
    return (super.dispatchKeyEvent(paramKeyEvent) || executeKeyEvent(paramKeyEvent));
  }
  
  public boolean dispatchNestedFling(float paramFloat1, float paramFloat2, boolean paramBoolean) {
    return this.mChildHelper.dispatchNestedFling(paramFloat1, paramFloat2, paramBoolean);
  }
  
  public boolean dispatchNestedPreFling(float paramFloat1, float paramFloat2) {
    return this.mChildHelper.dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2) {
    return this.mChildHelper.dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2);
  }
  
  public boolean dispatchNestedPreScroll(int paramInt1, int paramInt2, int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt3) {
    return this.mChildHelper.dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint1, paramArrayOfint2, paramInt3);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
    return this.mChildHelper.dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint);
  }
  
  public boolean dispatchNestedScroll(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint, int paramInt5) {
    return this.mChildHelper.dispatchNestedScroll(paramInt1, paramInt2, paramInt3, paramInt4, paramArrayOfint, paramInt5);
  }
  
  public void draw(Canvas paramCanvas) {
    // Byte code:
    //   0: aload_0
    //   1: aload_1
    //   2: invokespecial draw : (Landroid/graphics/Canvas;)V
    //   5: aload_0
    //   6: getfield mEdgeGlowTop : Landroid/widget/EdgeEffect;
    //   9: ifnull -> 355
    //   12: aload_0
    //   13: invokevirtual getScrollY : ()I
    //   16: istore_2
    //   17: aload_0
    //   18: getfield mEdgeGlowTop : Landroid/widget/EdgeEffect;
    //   21: invokevirtual isFinished : ()Z
    //   24: ifne -> 178
    //   27: aload_1
    //   28: invokevirtual save : ()I
    //   31: istore #9
    //   33: aload_0
    //   34: invokevirtual getWidth : ()I
    //   37: istore #10
    //   39: aload_0
    //   40: invokevirtual getHeight : ()I
    //   43: istore #11
    //   45: iconst_0
    //   46: iload_2
    //   47: invokestatic min : (II)I
    //   50: istore #12
    //   52: getstatic android/os/Build$VERSION.SDK_INT : I
    //   55: bipush #21
    //   57: if_icmplt -> 76
    //   60: aload_0
    //   61: invokevirtual getClipToPadding : ()Z
    //   64: ifeq -> 70
    //   67: goto -> 76
    //   70: iconst_0
    //   71: istore #13
    //   73: goto -> 98
    //   76: iload #10
    //   78: aload_0
    //   79: invokevirtual getPaddingLeft : ()I
    //   82: aload_0
    //   83: invokevirtual getPaddingRight : ()I
    //   86: iadd
    //   87: isub
    //   88: istore #10
    //   90: iconst_0
    //   91: aload_0
    //   92: invokevirtual getPaddingLeft : ()I
    //   95: iadd
    //   96: istore #13
    //   98: getstatic android/os/Build$VERSION.SDK_INT : I
    //   101: bipush #21
    //   103: if_icmplt -> 136
    //   106: aload_0
    //   107: invokevirtual getClipToPadding : ()Z
    //   110: ifeq -> 136
    //   113: iload #11
    //   115: aload_0
    //   116: invokevirtual getPaddingTop : ()I
    //   119: aload_0
    //   120: invokevirtual getPaddingBottom : ()I
    //   123: iadd
    //   124: isub
    //   125: istore #11
    //   127: iload #12
    //   129: aload_0
    //   130: invokevirtual getPaddingTop : ()I
    //   133: iadd
    //   134: istore #12
    //   136: aload_1
    //   137: iload #13
    //   139: i2f
    //   140: iload #12
    //   142: i2f
    //   143: invokevirtual translate : (FF)V
    //   146: aload_0
    //   147: getfield mEdgeGlowTop : Landroid/widget/EdgeEffect;
    //   150: iload #10
    //   152: iload #11
    //   154: invokevirtual setSize : (II)V
    //   157: aload_0
    //   158: getfield mEdgeGlowTop : Landroid/widget/EdgeEffect;
    //   161: aload_1
    //   162: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   165: ifeq -> 172
    //   168: aload_0
    //   169: invokestatic postInvalidateOnAnimation : (Landroid/view/View;)V
    //   172: aload_1
    //   173: iload #9
    //   175: invokevirtual restoreToCount : (I)V
    //   178: aload_0
    //   179: getfield mEdgeGlowBottom : Landroid/widget/EdgeEffect;
    //   182: invokevirtual isFinished : ()Z
    //   185: ifne -> 355
    //   188: aload_1
    //   189: invokevirtual save : ()I
    //   192: istore_3
    //   193: aload_0
    //   194: invokevirtual getWidth : ()I
    //   197: istore #4
    //   199: aload_0
    //   200: invokevirtual getHeight : ()I
    //   203: istore #5
    //   205: iload #5
    //   207: aload_0
    //   208: invokevirtual getScrollRange : ()I
    //   211: iload_2
    //   212: invokestatic max : (II)I
    //   215: iadd
    //   216: istore #6
    //   218: getstatic android/os/Build$VERSION.SDK_INT : I
    //   221: bipush #21
    //   223: if_icmplt -> 240
    //   226: aload_0
    //   227: invokevirtual getClipToPadding : ()Z
    //   230: istore #8
    //   232: iconst_0
    //   233: istore #7
    //   235: iload #8
    //   237: ifeq -> 262
    //   240: iload #4
    //   242: aload_0
    //   243: invokevirtual getPaddingLeft : ()I
    //   246: aload_0
    //   247: invokevirtual getPaddingRight : ()I
    //   250: iadd
    //   251: isub
    //   252: istore #4
    //   254: iconst_0
    //   255: aload_0
    //   256: invokevirtual getPaddingLeft : ()I
    //   259: iadd
    //   260: istore #7
    //   262: getstatic android/os/Build$VERSION.SDK_INT : I
    //   265: bipush #21
    //   267: if_icmplt -> 300
    //   270: aload_0
    //   271: invokevirtual getClipToPadding : ()Z
    //   274: ifeq -> 300
    //   277: iload #5
    //   279: aload_0
    //   280: invokevirtual getPaddingTop : ()I
    //   283: aload_0
    //   284: invokevirtual getPaddingBottom : ()I
    //   287: iadd
    //   288: isub
    //   289: istore #5
    //   291: iload #6
    //   293: aload_0
    //   294: invokevirtual getPaddingBottom : ()I
    //   297: isub
    //   298: istore #6
    //   300: aload_1
    //   301: iload #7
    //   303: iload #4
    //   305: isub
    //   306: i2f
    //   307: iload #6
    //   309: i2f
    //   310: invokevirtual translate : (FF)V
    //   313: aload_1
    //   314: ldc_w 180.0
    //   317: iload #4
    //   319: i2f
    //   320: fconst_0
    //   321: invokevirtual rotate : (FFF)V
    //   324: aload_0
    //   325: getfield mEdgeGlowBottom : Landroid/widget/EdgeEffect;
    //   328: iload #4
    //   330: iload #5
    //   332: invokevirtual setSize : (II)V
    //   335: aload_0
    //   336: getfield mEdgeGlowBottom : Landroid/widget/EdgeEffect;
    //   339: aload_1
    //   340: invokevirtual draw : (Landroid/graphics/Canvas;)Z
    //   343: ifeq -> 350
    //   346: aload_0
    //   347: invokestatic postInvalidateOnAnimation : (Landroid/view/View;)V
    //   350: aload_1
    //   351: iload_3
    //   352: invokevirtual restoreToCount : (I)V
    //   355: return
  }
  
  public boolean executeKeyEvent(@NonNull KeyEvent paramKeyEvent) {
    this.mTempRect.setEmpty();
    boolean bool = canScroll();
    char c = '';
    if (!bool) {
      if (isFocused() && paramKeyEvent.getKeyCode() != 4) {
        View view1 = findFocus();
        if (view1 == this)
          view1 = null; 
        View view2 = FocusFinder.getInstance().findNextFocus((ViewGroup)this, view1, c);
        boolean bool1 = false;
        if (view2 != null) {
          bool1 = false;
          if (view2 != this) {
            boolean bool2 = view2.requestFocus(c);
            bool1 = false;
            if (bool2)
              bool1 = true; 
          } 
        } 
        return bool1;
      } 
      return false;
    } 
    if (paramKeyEvent.getAction() == 0) {
      int i = paramKeyEvent.getKeyCode();
      if (i != 62) {
        switch (i) {
          default:
            return false;
          case 20:
            return !paramKeyEvent.isAltPressed() ? arrowScroll(c) : fullScroll(c);
          case 19:
            break;
        } 
        return !paramKeyEvent.isAltPressed() ? arrowScroll(33) : fullScroll(33);
      } 
      if (paramKeyEvent.isShiftPressed())
        c = '!'; 
      pageScroll(c);
    } 
    return false;
  }
  
  public void fling(int paramInt) {
    if (getChildCount() > 0) {
      startNestedScroll(2, 1);
      this.mScroller.fling(getScrollX(), getScrollY(), 0, paramInt, 0, 0, -2147483648, 2147483647, 0, 0);
      this.mLastScrollerY = getScrollY();
      ViewCompat.postInvalidateOnAnimation((View)this);
    } 
  }
  
  public boolean fullScroll(int paramInt) {
    boolean bool;
    if (paramInt == 130) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = getHeight();
    this.mTempRect.top = 0;
    this.mTempRect.bottom = i;
    if (bool) {
      int j = getChildCount();
      if (j > 0) {
        View view = getChildAt(j - 1);
        this.mTempRect.bottom = view.getBottom() + getPaddingBottom();
        this.mTempRect.top = this.mTempRect.bottom - i;
      } 
    } 
    return scrollAndFocus(paramInt, this.mTempRect.top, this.mTempRect.bottom);
  }
  
  protected float getBottomFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getHeight() - getPaddingBottom();
    int k = getChildAt(0).getBottom() - getScrollY() - j;
    return (k < i) ? (k / i) : 1.0F;
  }
  
  public int getMaxScrollAmount() {
    return (int)(0.5F * getHeight());
  }
  
  public int getNestedScrollAxes() {
    return this.mParentHelper.getNestedScrollAxes();
  }
  
  int getScrollRange() {
    int i = getChildCount();
    int j = 0;
    if (i > 0)
      j = Math.max(0, getChildAt(0).getHeight() - getHeight() - getPaddingBottom() - getPaddingTop()); 
    return j;
  }
  
  protected float getTopFadingEdgeStrength() {
    if (getChildCount() == 0)
      return 0.0F; 
    int i = getVerticalFadingEdgeLength();
    int j = getScrollY();
    return (j < i) ? (j / i) : 1.0F;
  }
  
  public boolean hasNestedScrollingParent() {
    return this.mChildHelper.hasNestedScrollingParent();
  }
  
  public boolean hasNestedScrollingParent(int paramInt) {
    return this.mChildHelper.hasNestedScrollingParent(paramInt);
  }
  
  public boolean isFillViewport() {
    return this.mFillViewport;
  }
  
  public boolean isNestedScrollingEnabled() {
    return this.mChildHelper.isNestedScrollingEnabled();
  }
  
  public boolean isSmoothScrollingEnabled() {
    return this.mSmoothScrollingEnabled;
  }
  
  protected void measureChild(View paramView, int paramInt1, int paramInt2) {
    ViewGroup.LayoutParams layoutParams = paramView.getLayoutParams();
    paramView.measure(getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(0, 0));
  }
  
  protected void measureChildWithMargins(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams)paramView.getLayoutParams();
    paramView.measure(getChildMeasureSpec(paramInt1, paramInt2 + getPaddingLeft() + getPaddingRight() + marginLayoutParams.leftMargin + marginLayoutParams.rightMargin, marginLayoutParams.width), View.MeasureSpec.makeMeasureSpec(marginLayoutParams.topMargin + marginLayoutParams.bottomMargin, 0));
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    this.mIsLaidOut = false;
  }
  
  public boolean onGenericMotionEvent(MotionEvent paramMotionEvent) {
    if ((0x2 & paramMotionEvent.getSource()) != 0) {
      if (paramMotionEvent.getAction() != 8)
        return false; 
      if (!this.mIsBeingDragged) {
        float f = paramMotionEvent.getAxisValue(9);
        if (f != 0.0F) {
          int i = (int)(f * getVerticalScrollFactorCompat());
          int j = getScrollRange();
          int k = getScrollY();
          int m = k - i;
          if (m < 0) {
            m = 0;
          } else if (m > j) {
            m = j;
          } 
          if (m != k) {
            super.scrollTo(getScrollX(), m);
            return true;
          } 
        } 
      } 
    } 
    return false;
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getAction();
    if (i == 2 && this.mIsBeingDragged)
      return true; 
    int j = i & 0xFF;
    if (j != 6) {
      int m;
      switch (j) {
        default:
          return this.mIsBeingDragged;
        case 2:
          m = this.mActivePointerId;
          if (m != -1) {
            int n = paramMotionEvent.findPointerIndex(m);
            if (n == -1) {
              StringBuilder stringBuilder = new StringBuilder();
              stringBuilder.append("Invalid pointerId=");
              stringBuilder.append(m);
              stringBuilder.append(" in onInterceptTouchEvent");
              Log.e("NestedScrollView", stringBuilder.toString());
            } else {
              int i1 = (int)paramMotionEvent.getY(n);
              if (Math.abs(i1 - this.mLastMotionY) > this.mTouchSlop && (0x2 & getNestedScrollAxes()) == 0) {
                this.mIsBeingDragged = true;
                this.mLastMotionY = i1;
                initVelocityTrackerIfNotExists();
                this.mVelocityTracker.addMovement(paramMotionEvent);
                this.mNestedYOffset = 0;
                ViewParent viewParent = getParent();
                if (viewParent != null)
                  viewParent.requestDisallowInterceptTouchEvent(true); 
              } 
            } 
          } 
        case 1:
        case 3:
          this.mIsBeingDragged = false;
          this.mActivePointerId = -1;
          recycleVelocityTracker();
          if (this.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
            ViewCompat.postInvalidateOnAnimation((View)this); 
          stopNestedScroll(0);
        case 0:
          break;
      } 
      int k = (int)paramMotionEvent.getY();
      if (!inChild((int)paramMotionEvent.getX(), k)) {
        this.mIsBeingDragged = false;
        recycleVelocityTracker();
      } 
      this.mLastMotionY = k;
      this.mActivePointerId = paramMotionEvent.getPointerId(0);
      initOrResetVelocityTracker();
      this.mVelocityTracker.addMovement(paramMotionEvent);
      this.mScroller.computeScrollOffset();
      this.mIsBeingDragged = true ^ this.mScroller.isFinished();
      startNestedScroll(2, 0);
    } 
    onSecondaryPointerUp(paramMotionEvent);
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onLayout(paramBoolean, paramInt1, paramInt2, paramInt3, paramInt4);
    this.mIsLayoutDirty = false;
    if (this.mChildToScrollTo != null && isViewDescendantOf(this.mChildToScrollTo, (View)this))
      scrollToChild(this.mChildToScrollTo); 
    this.mChildToScrollTo = null;
    if (!this.mIsLaidOut) {
      byte b;
      if (this.mSavedState != null) {
        scrollTo(getScrollX(), this.mSavedState.scrollPosition);
        this.mSavedState = null;
      } 
      if (getChildCount() > 0) {
        b = getChildAt(0).getMeasuredHeight();
      } else {
        b = 0;
      } 
      int i = Math.max(0, b - paramInt4 - paramInt2 - getPaddingBottom() - getPaddingTop());
      if (getScrollY() > i) {
        scrollTo(getScrollX(), i);
      } else if (getScrollY() < 0) {
        scrollTo(getScrollX(), 0);
      } 
    } 
    scrollTo(getScrollX(), getScrollY());
    this.mIsLaidOut = true;
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    super.onMeasure(paramInt1, paramInt2);
    if (!this.mFillViewport)
      return; 
    if (View.MeasureSpec.getMode(paramInt2) == 0)
      return; 
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      int i = getMeasuredHeight();
      if (view.getMeasuredHeight() < i) {
        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams)view.getLayoutParams();
        view.measure(getChildMeasureSpec(paramInt1, getPaddingLeft() + getPaddingRight(), layoutParams.width), View.MeasureSpec.makeMeasureSpec(i - getPaddingTop() - getPaddingBottom(), 1073741824));
      } 
    } 
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    if (!paramBoolean) {
      flingWithNestedDispatch((int)paramFloat2);
      return true;
    } 
    return false;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    return dispatchNestedPreFling(paramFloat1, paramFloat2);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    dispatchNestedPreScroll(paramInt1, paramInt2, paramArrayOfint, (int[])null);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = getScrollY();
    scrollBy(0, paramInt4);
    int j = getScrollY() - i;
    dispatchNestedScroll(0, j, 0, paramInt4 - j, (int[])null);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    this.mParentHelper.onNestedScrollAccepted(paramView1, paramView2, paramInt);
    startNestedScroll(2);
  }
  
  protected void onOverScrolled(int paramInt1, int paramInt2, boolean paramBoolean1, boolean paramBoolean2) {
    super.scrollTo(paramInt1, paramInt2);
  }
  
  protected boolean onRequestFocusInDescendants(int paramInt, Rect paramRect) {
    View view;
    if (paramInt == 2) {
      paramInt = 130;
    } else if (paramInt == 1) {
      paramInt = 33;
    } 
    if (paramRect == null) {
      view = FocusFinder.getInstance().findNextFocus((ViewGroup)this, null, paramInt);
    } else {
      view = FocusFinder.getInstance().findNextFocusFromRect((ViewGroup)this, paramRect, paramInt);
    } 
    return (view == null) ? false : (isOffScreen(view) ? false : view.requestFocus(paramInt, paramRect));
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    this.mSavedState = savedState;
    requestLayout();
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    savedState.scrollPosition = getScrollY();
    return (Parcelable)savedState;
  }
  
  protected void onScrollChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onScrollChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    if (this.mOnScrollChangeListener != null)
      this.mOnScrollChangeListener.onScrollChange(this, paramInt1, paramInt2, paramInt3, paramInt4); 
  }
  
  protected void onSizeChanged(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    super.onSizeChanged(paramInt1, paramInt2, paramInt3, paramInt4);
    View view = findFocus();
    if (view != null) {
      if (this == view)
        return; 
      if (isWithinDeltaOfScreen(view, 0, paramInt4)) {
        view.getDrawingRect(this.mTempRect);
        offsetDescendantRectToMyCoords(view, this.mTempRect);
        doScrollY(computeScrollDeltaToGetChildRectOnScreen(this.mTempRect));
      } 
      return;
    } 
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return ((paramInt & 0x2) != 0);
  }
  
  public void onStopNestedScroll(View paramView) {
    this.mParentHelper.onStopNestedScroll(paramView);
    stopNestedScroll();
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    int j;
    VelocityTracker velocityTracker;
    int k;
    int m;
    int n;
    int i1;
    int[] arrayOfInt1;
    int[] arrayOfInt2;
    int i2;
    int i3;
    initVelocityTrackerIfNotExists();
    MotionEvent motionEvent = MotionEvent.obtain(paramMotionEvent);
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      this.mNestedYOffset = 0; 
    motionEvent.offsetLocation(0.0F, this.mNestedYOffset);
    switch (i) {
      case 6:
        onSecondaryPointerUp(paramMotionEvent);
        this.mLastMotionY = (int)paramMotionEvent.getY(paramMotionEvent.findPointerIndex(this.mActivePointerId));
        break;
      case 5:
        i3 = paramMotionEvent.getActionIndex();
        this.mLastMotionY = (int)paramMotionEvent.getY(i3);
        this.mActivePointerId = paramMotionEvent.getPointerId(i3);
        break;
      case 3:
        if (this.mIsBeingDragged && getChildCount() > 0 && this.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange()))
          ViewCompat.postInvalidateOnAnimation((View)this); 
        this.mActivePointerId = -1;
        endDrag();
        break;
      case 2:
        m = paramMotionEvent.findPointerIndex(this.mActivePointerId);
        if (m == -1) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Invalid pointerId=");
          stringBuilder.append(this.mActivePointerId);
          stringBuilder.append(" in onTouchEvent");
          Log.e("NestedScrollView", stringBuilder.toString());
          break;
        } 
        n = (int)paramMotionEvent.getY(m);
        i1 = this.mLastMotionY - n;
        arrayOfInt1 = this.mScrollConsumed;
        arrayOfInt2 = this.mScrollOffset;
        if (dispatchNestedPreScroll(0, i1, arrayOfInt1, arrayOfInt2, 0)) {
          i1 -= this.mScrollConsumed[1];
          motionEvent.offsetLocation(0.0F, this.mScrollOffset[1]);
          this.mNestedYOffset += this.mScrollOffset[1];
        } 
        if (!this.mIsBeingDragged && Math.abs(i1) > this.mTouchSlop) {
          ViewParent viewParent = getParent();
          if (viewParent != null)
            viewParent.requestDisallowInterceptTouchEvent(true); 
          this.mIsBeingDragged = true;
          if (i1 > 0) {
            i1 -= this.mTouchSlop;
          } else {
            i1 += this.mTouchSlop;
          } 
        } 
        i2 = i1;
        if (this.mIsBeingDragged) {
          boolean bool;
          this.mLastMotionY = n - this.mScrollOffset[1];
          int i4 = getScrollY();
          int i5 = getScrollRange();
          int i6 = getOverScrollMode();
          if (i6 == 0 || (i6 == 1 && i5 > 0)) {
            bool = true;
          } else {
            bool = false;
          } 
          if (a(0, i2, 0, getScrollY(), 0, i5, 0, 0, true) && !hasNestedScrollingParent(0))
            this.mVelocityTracker.clear(); 
          int i7 = getScrollY() - i4;
          if (dispatchNestedScroll(0, i7, 0, i2 - i7, this.mScrollOffset, 0)) {
            this.mLastMotionY -= this.mScrollOffset[1];
            motionEvent.offsetLocation(0.0F, this.mScrollOffset[1]);
            this.mNestedYOffset += this.mScrollOffset[1];
            break;
          } 
          if (bool) {
            ensureGlows();
            int i8 = i4 + i2;
            if (i8 < 0) {
              EdgeEffectCompat.onPull(this.mEdgeGlowTop, i2 / getHeight(), paramMotionEvent.getX(m) / getWidth());
              if (!this.mEdgeGlowBottom.isFinished())
                this.mEdgeGlowBottom.onRelease(); 
            } else if (i8 > i5) {
              EdgeEffectCompat.onPull(this.mEdgeGlowBottom, i2 / getHeight(), 1.0F - paramMotionEvent.getX(m) / getWidth());
              if (!this.mEdgeGlowTop.isFinished())
                this.mEdgeGlowTop.onRelease(); 
            } 
            if (this.mEdgeGlowTop != null && (!this.mEdgeGlowTop.isFinished() || !this.mEdgeGlowBottom.isFinished()))
              ViewCompat.postInvalidateOnAnimation((View)this); 
          } 
        } 
        break;
      case 1:
        velocityTracker = this.mVelocityTracker;
        velocityTracker.computeCurrentVelocity(1000, this.mMaximumVelocity);
        k = (int)velocityTracker.getYVelocity(this.mActivePointerId);
        if (Math.abs(k) > this.mMinimumVelocity) {
          flingWithNestedDispatch(-k);
        } else if (this.mScroller.springBack(getScrollX(), getScrollY(), 0, 0, 0, getScrollRange())) {
          ViewCompat.postInvalidateOnAnimation((View)this);
        } 
        this.mActivePointerId = -1;
        endDrag();
        break;
      case 0:
        if (getChildCount() == 0)
          return false; 
        j = true ^ this.mScroller.isFinished();
        this.mIsBeingDragged = j;
        if (j != 0) {
          ViewParent viewParent = getParent();
          if (viewParent != null)
            viewParent.requestDisallowInterceptTouchEvent(true); 
        } 
        if (!this.mScroller.isFinished())
          this.mScroller.abortAnimation(); 
        this.mLastMotionY = (int)paramMotionEvent.getY();
        this.mActivePointerId = paramMotionEvent.getPointerId(0);
        startNestedScroll(2, 0);
        break;
    } 
    if (this.mVelocityTracker != null)
      this.mVelocityTracker.addMovement(motionEvent); 
    motionEvent.recycle();
    return true;
  }
  
  public boolean pageScroll(int paramInt) {
    boolean bool;
    if (paramInt == 130) {
      bool = true;
    } else {
      bool = false;
    } 
    int i = getHeight();
    if (bool) {
      this.mTempRect.top = i + getScrollY();
      int j = getChildCount();
      if (j > 0) {
        View view = getChildAt(j - 1);
        if (i + this.mTempRect.top > view.getBottom())
          this.mTempRect.top = view.getBottom() - i; 
      } 
    } else {
      this.mTempRect.top = getScrollY() - i;
      if (this.mTempRect.top < 0)
        this.mTempRect.top = 0; 
    } 
    this.mTempRect.bottom = i + this.mTempRect.top;
    return scrollAndFocus(paramInt, this.mTempRect.top, this.mTempRect.bottom);
  }
  
  public void requestChildFocus(View paramView1, View paramView2) {
    if (!this.mIsLayoutDirty) {
      scrollToChild(paramView2);
    } else {
      this.mChildToScrollTo = paramView2;
    } 
    super.requestChildFocus(paramView1, paramView2);
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    paramRect.offset(paramView.getLeft() - paramView.getScrollX(), paramView.getTop() - paramView.getScrollY());
    return scrollToChildRect(paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    if (paramBoolean)
      recycleVelocityTracker(); 
    super.requestDisallowInterceptTouchEvent(paramBoolean);
  }
  
  public void requestLayout() {
    this.mIsLayoutDirty = true;
    super.requestLayout();
  }
  
  public void scrollTo(int paramInt1, int paramInt2) {
    if (getChildCount() > 0) {
      View view = getChildAt(0);
      int i = clamp(paramInt1, getWidth() - getPaddingRight() - getPaddingLeft(), view.getWidth());
      int j = clamp(paramInt2, getHeight() - getPaddingBottom() - getPaddingTop(), view.getHeight());
      if (i != getScrollX() || j != getScrollY())
        super.scrollTo(i, j); 
    } 
  }
  
  public void setFillViewport(boolean paramBoolean) {
    if (paramBoolean != this.mFillViewport) {
      this.mFillViewport = paramBoolean;
      requestLayout();
    } 
  }
  
  public void setNestedScrollingEnabled(boolean paramBoolean) {
    this.mChildHelper.setNestedScrollingEnabled(paramBoolean);
  }
  
  public void setOnScrollChangeListener(@Nullable OnScrollChangeListener paramOnScrollChangeListener) {
    this.mOnScrollChangeListener = paramOnScrollChangeListener;
  }
  
  public void setSmoothScrollingEnabled(boolean paramBoolean) {
    this.mSmoothScrollingEnabled = paramBoolean;
  }
  
  public boolean shouldDelayChildPressedState() {
    return true;
  }
  
  public final void smoothScrollBy(int paramInt1, int paramInt2) {
    if (getChildCount() == 0)
      return; 
    if (AnimationUtils.currentAnimationTimeMillis() - this.mLastScroll > 250L) {
      int i = getHeight() - getPaddingBottom() - getPaddingTop();
      int j = Math.max(0, getChildAt(0).getHeight() - i);
      int k = getScrollY();
      int m = Math.max(0, Math.min(paramInt2 + k, j)) - k;
      this.mScroller.startScroll(getScrollX(), k, 0, m);
      ViewCompat.postInvalidateOnAnimation((View)this);
    } else {
      if (!this.mScroller.isFinished())
        this.mScroller.abortAnimation(); 
      scrollBy(paramInt1, paramInt2);
    } 
    this.mLastScroll = AnimationUtils.currentAnimationTimeMillis();
  }
  
  public final void smoothScrollTo(int paramInt1, int paramInt2) {
    smoothScrollBy(paramInt1 - getScrollX(), paramInt2 - getScrollY());
  }
  
  public boolean startNestedScroll(int paramInt) {
    return this.mChildHelper.startNestedScroll(paramInt);
  }
  
  public boolean startNestedScroll(int paramInt1, int paramInt2) {
    return this.mChildHelper.startNestedScroll(paramInt1, paramInt2);
  }
  
  public void stopNestedScroll() {
    this.mChildHelper.stopNestedScroll();
  }
  
  public void stopNestedScroll(int paramInt) {
    this.mChildHelper.stopNestedScroll(paramInt);
  }
  
  static class AccessibilityDelegate extends AccessibilityDelegateCompat {
    public void onInitializeAccessibilityEvent(View param1View, AccessibilityEvent param1AccessibilityEvent) {
      boolean bool;
      super.onInitializeAccessibilityEvent(param1View, param1AccessibilityEvent);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityEvent.setClassName(ScrollView.class.getName());
      if (nestedScrollView.getScrollRange() > 0) {
        bool = true;
      } else {
        bool = false;
      } 
      param1AccessibilityEvent.setScrollable(bool);
      param1AccessibilityEvent.setScrollX(nestedScrollView.getScrollX());
      param1AccessibilityEvent.setScrollY(nestedScrollView.getScrollY());
      AccessibilityRecordCompat.setMaxScrollX((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollX());
      AccessibilityRecordCompat.setMaxScrollY((AccessibilityRecord)param1AccessibilityEvent, nestedScrollView.getScrollRange());
    }
    
    public void onInitializeAccessibilityNodeInfo(View param1View, AccessibilityNodeInfoCompat param1AccessibilityNodeInfoCompat) {
      super.onInitializeAccessibilityNodeInfo(param1View, param1AccessibilityNodeInfoCompat);
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      param1AccessibilityNodeInfoCompat.setClassName(ScrollView.class.getName());
      if (nestedScrollView.isEnabled()) {
        int i = nestedScrollView.getScrollRange();
        if (i > 0) {
          param1AccessibilityNodeInfoCompat.setScrollable(true);
          if (nestedScrollView.getScrollY() > 0)
            param1AccessibilityNodeInfoCompat.addAction(8192); 
          if (nestedScrollView.getScrollY() < i)
            param1AccessibilityNodeInfoCompat.addAction(4096); 
        } 
      } 
    }
    
    public boolean performAccessibilityAction(View param1View, int param1Int, Bundle param1Bundle) {
      if (super.performAccessibilityAction(param1View, param1Int, param1Bundle))
        return true; 
      NestedScrollView nestedScrollView = (NestedScrollView)param1View;
      if (!nestedScrollView.isEnabled())
        return false; 
      if (param1Int != 4096) {
        if (param1Int != 8192)
          return false; 
        int j = nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom() - nestedScrollView.getPaddingTop();
        int k = Math.max(nestedScrollView.getScrollY() - j, 0);
        if (k != nestedScrollView.getScrollY()) {
          nestedScrollView.smoothScrollTo(0, k);
          return true;
        } 
        return false;
      } 
      int i = Math.min(nestedScrollView.getHeight() - nestedScrollView.getPaddingBottom() - nestedScrollView.getPaddingTop() + nestedScrollView.getScrollY(), nestedScrollView.getScrollRange());
      if (i != nestedScrollView.getScrollY()) {
        nestedScrollView.smoothScrollTo(0, i);
        return true;
      } 
      return false;
    }
  }
  
  public static interface OnScrollChangeListener {
    void onScrollChange(NestedScrollView param1NestedScrollView, int param1Int1, int param1Int2, int param1Int3, int param1Int4);
  }
  
  static class SavedState extends View.BaseSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = new Parcelable.Creator<SavedState>() {
        public NestedScrollView.SavedState createFromParcel(Parcel param2Parcel) {
          return new NestedScrollView.SavedState(param2Parcel);
        }
        
        public NestedScrollView.SavedState[] newArray(int param2Int) {
          return new NestedScrollView.SavedState[param2Int];
        }
      };
    
    public int scrollPosition;
    
    SavedState(Parcel param1Parcel) {
      super(param1Parcel);
      this.scrollPosition = param1Parcel.readInt();
    }
    
    SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public String toString() {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("HorizontalScrollView.SavedState{");
      stringBuilder.append(Integer.toHexString(System.identityHashCode(this)));
      stringBuilder.append(" scrollPosition=");
      stringBuilder.append(this.scrollPosition);
      stringBuilder.append("}");
      return stringBuilder.toString();
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      super.writeToParcel(param1Parcel, param1Int);
      param1Parcel.writeInt(this.scrollPosition);
    }
  }
  
  static final class null implements Parcelable.Creator<SavedState> {
    public NestedScrollView.SavedState createFromParcel(Parcel param1Parcel) {
      return new NestedScrollView.SavedState(param1Parcel);
    }
    
    public NestedScrollView.SavedState[] newArray(int param1Int) {
      return new NestedScrollView.SavedState[param1Int];
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\widget\NestedScrollView.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */