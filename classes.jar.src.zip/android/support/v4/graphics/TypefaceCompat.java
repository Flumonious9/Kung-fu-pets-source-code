package android.support.v4.graphics;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.os.Build;
import android.os.CancellationSignal;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.content.res.ResourcesCompat;
import android.support.v4.provider.FontsContractCompat;
import android.support.v4.util.LruCache;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompat {
  private static final String TAG = "TypefaceCompat";
  
  private static final LruCache<String, Typeface> sTypefaceCache = new LruCache(16);
  
  private static final TypefaceCompatImpl sTypefaceCompatImpl;
  
  @Nullable
  public static Typeface createFromFontInfo(@NonNull Context paramContext, @Nullable CancellationSignal paramCancellationSignal, @NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    return sTypefaceCompatImpl.createFromFontInfo(paramContext, paramCancellationSignal, paramArrayOfFontInfo, paramInt);
  }
  
  @Nullable
  public static Typeface createFromResourcesFamilyXml(@NonNull Context paramContext, @NonNull FontResourcesParserCompat.FamilyResourceEntry paramFamilyResourceEntry, @NonNull Resources paramResources, int paramInt1, int paramInt2, @Nullable ResourcesCompat.FontCallback paramFontCallback, @Nullable Handler paramHandler, boolean paramBoolean) {
    // Byte code:
    //   0: aload_1
    //   1: instanceof android/support/v4/content/res/FontResourcesParserCompat$ProviderResourceEntry
    //   4: ifeq -> 92
    //   7: aload_1
    //   8: checkcast android/support/v4/content/res/FontResourcesParserCompat$ProviderResourceEntry
    //   11: astore #10
    //   13: iload #7
    //   15: ifeq -> 39
    //   18: aload #10
    //   20: invokevirtual getFetchStrategy : ()I
    //   23: istore #13
    //   25: iconst_0
    //   26: istore #11
    //   28: iload #13
    //   30: ifne -> 50
    //   33: iconst_1
    //   34: istore #11
    //   36: goto -> 50
    //   39: iconst_0
    //   40: istore #11
    //   42: aload #5
    //   44: ifnonnull -> 50
    //   47: goto -> 33
    //   50: iload #7
    //   52: ifeq -> 65
    //   55: aload #10
    //   57: invokevirtual getTimeout : ()I
    //   60: istore #12
    //   62: goto -> 68
    //   65: iconst_m1
    //   66: istore #12
    //   68: aload_0
    //   69: aload #10
    //   71: invokevirtual getRequest : ()Landroid/support/v4/provider/FontRequest;
    //   74: aload #5
    //   76: aload #6
    //   78: iload #11
    //   80: iload #12
    //   82: iload #4
    //   84: invokestatic getFontSync : (Landroid/content/Context;Landroid/support/v4/provider/FontRequest;Landroid/support/v4/content/res/ResourcesCompat$FontCallback;Landroid/os/Handler;ZII)Landroid/graphics/Typeface;
    //   87: astore #8
    //   89: goto -> 141
    //   92: getstatic android/support/v4/graphics/TypefaceCompat.sTypefaceCompatImpl : Landroid/support/v4/graphics/TypefaceCompat$TypefaceCompatImpl;
    //   95: aload_0
    //   96: aload_1
    //   97: checkcast android/support/v4/content/res/FontResourcesParserCompat$FontFamilyFilesResourceEntry
    //   100: aload_2
    //   101: iload #4
    //   103: invokeinterface createFromFontFamilyFilesResourceEntry : (Landroid/content/Context;Landroid/support/v4/content/res/FontResourcesParserCompat$FontFamilyFilesResourceEntry;Landroid/content/res/Resources;I)Landroid/graphics/Typeface;
    //   108: astore #8
    //   110: aload #5
    //   112: ifnull -> 141
    //   115: aload #8
    //   117: ifnull -> 132
    //   120: aload #5
    //   122: aload #8
    //   124: aload #6
    //   126: invokevirtual callbackSuccessAsync : (Landroid/graphics/Typeface;Landroid/os/Handler;)V
    //   129: goto -> 141
    //   132: aload #5
    //   134: bipush #-3
    //   136: aload #6
    //   138: invokevirtual callbackFailAsync : (ILandroid/os/Handler;)V
    //   141: aload #8
    //   143: ifnull -> 162
    //   146: getstatic android/support/v4/graphics/TypefaceCompat.sTypefaceCache : Landroid/support/v4/util/LruCache;
    //   149: aload_2
    //   150: iload_3
    //   151: iload #4
    //   153: invokestatic createResourceUid : (Landroid/content/res/Resources;II)Ljava/lang/String;
    //   156: aload #8
    //   158: invokevirtual put : (Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    //   161: pop
    //   162: aload #8
    //   164: areturn
  }
  
  @Nullable
  public static Typeface createFromResourcesFontFile(@NonNull Context paramContext, @NonNull Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    Typeface typeface = sTypefaceCompatImpl.createFromResourcesFontFile(paramContext, paramResources, paramInt1, paramString, paramInt2);
    if (typeface != null) {
      String str = createResourceUid(paramResources, paramInt1, paramInt2);
      sTypefaceCache.put(str, typeface);
    } 
    return typeface;
  }
  
  private static String createResourceUid(Resources paramResources, int paramInt1, int paramInt2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramResources.getResourcePackageName(paramInt1));
    stringBuilder.append("-");
    stringBuilder.append(paramInt1);
    stringBuilder.append("-");
    stringBuilder.append(paramInt2);
    return stringBuilder.toString();
  }
  
  @Nullable
  public static Typeface findFromCache(@NonNull Resources paramResources, int paramInt1, int paramInt2) {
    return (Typeface)sTypefaceCache.get(createResourceUid(paramResources, paramInt1, paramInt2));
  }
  
  static {
    if (Build.VERSION.SDK_INT >= 26) {
      sTypefaceCompatImpl = new TypefaceCompatApi26Impl();
    } else if (Build.VERSION.SDK_INT >= 24 && TypefaceCompatApi24Impl.isUsable()) {
      sTypefaceCompatImpl = new TypefaceCompatApi24Impl();
    } else if (Build.VERSION.SDK_INT >= 21) {
      sTypefaceCompatImpl = new TypefaceCompatApi21Impl();
    } else {
      sTypefaceCompatImpl = new TypefaceCompatBaseImpl();
    } 
  }
  
  static interface TypefaceCompatImpl {
    Typeface createFromFontFamilyFilesResourceEntry(Context param1Context, FontResourcesParserCompat.FontFamilyFilesResourceEntry param1FontFamilyFilesResourceEntry, Resources param1Resources, int param1Int);
    
    Typeface createFromFontInfo(Context param1Context, @Nullable CancellationSignal param1CancellationSignal, @NonNull FontsContractCompat.FontInfo[] param1ArrayOfFontInfo, int param1Int);
    
    Typeface createFromResourcesFontFile(Context param1Context, Resources param1Resources, int param1Int1, String param1String, int param1Int2);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\TypefaceCompat.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */