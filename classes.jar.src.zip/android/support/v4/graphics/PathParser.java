package android.support.v4.graphics;

import android.graphics.Path;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.util.ArrayList;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class PathParser {
  private static final String LOGTAG = "PathParser";
  
  static float[] a(float[] paramArrayOffloat, int paramInt1, int paramInt2) {
    if (paramInt1 <= paramInt2) {
      int i = paramArrayOffloat.length;
      if (paramInt1 >= 0 && paramInt1 <= i) {
        int j = paramInt2 - paramInt1;
        int k = Math.min(j, i - paramInt1);
        float[] arrayOfFloat = new float[j];
        System.arraycopy(paramArrayOffloat, paramInt1, arrayOfFloat, 0, k);
        return arrayOfFloat;
      } 
      throw new ArrayIndexOutOfBoundsException();
    } 
    throw new IllegalArgumentException();
  }
  
  private static void addNode(ArrayList<PathDataNode> paramArrayList, char paramChar, float[] paramArrayOffloat) {
    paramArrayList.add(new PathDataNode(paramChar, paramArrayOffloat));
  }
  
  public static boolean canMorph(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    if (paramArrayOfPathDataNode1 != null) {
      if (paramArrayOfPathDataNode2 == null)
        return false; 
      if (paramArrayOfPathDataNode1.length != paramArrayOfPathDataNode2.length)
        return false; 
      byte b = 0;
      while (b < paramArrayOfPathDataNode1.length) {
        if ((paramArrayOfPathDataNode1[b]).mType == (paramArrayOfPathDataNode2[b]).mType) {
          if ((paramArrayOfPathDataNode1[b]).mParams.length != (paramArrayOfPathDataNode2[b]).mParams.length)
            return false; 
          b++;
          continue;
        } 
        return false;
      } 
      return true;
    } 
    return false;
  }
  
  public static PathDataNode[] createNodesFromPathData(String paramString) {
    if (paramString == null)
      return null; 
    ArrayList<PathDataNode> arrayList = new ArrayList();
    int i = 1;
    int j = 0;
    while (i < paramString.length()) {
      int k = nextStart(paramString, i);
      String str = paramString.substring(j, k).trim();
      if (str.length() > 0) {
        float[] arrayOfFloat = getFloats(str);
        addNode(arrayList, str.charAt(0), arrayOfFloat);
      } 
      int m = k + 1;
      j = k;
      i = m;
    } 
    if (i - j == 1 && j < paramString.length())
      addNode(arrayList, paramString.charAt(j), new float[0]); 
    return arrayList.<PathDataNode>toArray(new PathDataNode[arrayList.size()]);
  }
  
  public static Path createPathFromPathData(String paramString) {
    Path path = new Path();
    PathDataNode[] arrayOfPathDataNode = createNodesFromPathData(paramString);
    if (arrayOfPathDataNode != null)
      try {
        PathDataNode.nodesToPath(arrayOfPathDataNode, path);
        return path;
      } catch (RuntimeException runtimeException) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Error in parsing ");
        stringBuilder.append(paramString);
        throw new RuntimeException(stringBuilder.toString(), runtimeException);
      }  
    return null;
  }
  
  public static PathDataNode[] deepCopyNodes(PathDataNode[] paramArrayOfPathDataNode) {
    if (paramArrayOfPathDataNode == null)
      return null; 
    PathDataNode[] arrayOfPathDataNode = new PathDataNode[paramArrayOfPathDataNode.length];
    for (byte b = 0; b < paramArrayOfPathDataNode.length; b++)
      arrayOfPathDataNode[b] = new PathDataNode(paramArrayOfPathDataNode[b]); 
    return arrayOfPathDataNode;
  }
  
  private static void extract(String paramString, int paramInt, ExtractFloatResult paramExtractFloatResult) {
    paramExtractFloatResult.b = false;
    int i = paramInt;
    boolean bool1 = false;
    boolean bool2 = false;
    boolean bool3 = false;
    while (i < paramString.length()) {
      char c = paramString.charAt(i);
      if (c != ' ') {
        if (c != 'E' && c != 'e') {
          switch (c) {
            default:
              bool1 = false;
              break;
            case '.':
              if (!bool2) {
                bool2 = true;
                bool1 = false;
                break;
              } 
              paramExtractFloatResult.b = true;
            case '-':
            
            case ',':
              bool1 = false;
              bool3 = true;
              break;
          } 
        } else {
          bool1 = true;
        } 
        if (bool3)
          break; 
        continue;
      } 
      i++;
    } 
    paramExtractFloatResult.a = i;
  }
  
  private static float[] getFloats(String paramString) {
    if (paramString.charAt(0) == 'z' || paramString.charAt(0) == 'Z')
      return new float[0]; 
    try {
      float[] arrayOfFloat = new float[paramString.length()];
      ExtractFloatResult extractFloatResult = new ExtractFloatResult();
      int i = paramString.length();
      int j = 1;
      int k = 0;
      while (true) {
        int m;
        if (j < i) {
          extract(paramString, j, extractFloatResult);
          m = extractFloatResult.a;
          if (j < m) {
            int n = k + 1;
            arrayOfFloat[k] = Float.parseFloat(paramString.substring(j, m));
            k = n;
          } 
          if (extractFloatResult.b) {
            j = m;
            continue;
          } 
        } else {
          return a(arrayOfFloat, 0, k);
        } 
        j = m + 1;
      } 
    } catch (NumberFormatException numberFormatException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("error in parsing \"");
      stringBuilder.append(paramString);
      stringBuilder.append("\"");
      throw new RuntimeException(stringBuilder.toString(), numberFormatException);
    } 
  }
  
  private static int nextStart(String paramString, int paramInt) {
    while (paramInt < paramString.length()) {
      char c = paramString.charAt(paramInt);
      if (((c - 65) * (c - 90) <= 0 || (c - 97) * (c - 122) <= 0) && c != 'e' && c != 'E')
        return paramInt; 
      paramInt++;
    } 
    return paramInt;
  }
  
  public static void updateNodes(PathDataNode[] paramArrayOfPathDataNode1, PathDataNode[] paramArrayOfPathDataNode2) {
    for (byte b = 0; b < paramArrayOfPathDataNode2.length; b++) {
      (paramArrayOfPathDataNode1[b]).mType = (paramArrayOfPathDataNode2[b]).mType;
      for (byte b1 = 0; b1 < (paramArrayOfPathDataNode2[b]).mParams.length; b1++)
        (paramArrayOfPathDataNode1[b]).mParams[b1] = (paramArrayOfPathDataNode2[b]).mParams[b1]; 
    } 
  }
  
  private static class ExtractFloatResult {
    int a;
    
    boolean b;
  }
  
  public static class PathDataNode {
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public float[] mParams;
    
    @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
    public char mType;
    
    PathDataNode(char param1Char, float[] param1ArrayOffloat) {
      this.mType = param1Char;
      this.mParams = param1ArrayOffloat;
    }
    
    PathDataNode(PathDataNode param1PathDataNode) {
      this.mType = param1PathDataNode.mType;
      this.mParams = PathParser.a(param1PathDataNode.mParams, 0, param1PathDataNode.mParams.length);
    }
    
    private static void addCommand(Path param1Path, float[] param1ArrayOffloat1, char param1Char1, char param1Char2, float[] param1ArrayOffloat2) {
      // Byte code:
      //   0: aload_1
      //   1: iconst_0
      //   2: faload
      //   3: fstore #5
      //   5: aload_1
      //   6: iconst_1
      //   7: faload
      //   8: fstore #6
      //   10: aload_1
      //   11: iconst_2
      //   12: faload
      //   13: fstore #7
      //   15: aload_1
      //   16: iconst_3
      //   17: faload
      //   18: fstore #8
      //   20: aload_1
      //   21: iconst_4
      //   22: faload
      //   23: fstore #9
      //   25: aload_1
      //   26: iconst_5
      //   27: faload
      //   28: fstore #10
      //   30: iload_3
      //   31: lookupswitch default -> 200, 65 -> 256, 67 -> 249, 72 -> 243, 76 -> 200, 77 -> 200, 81 -> 237, 83 -> 237, 84 -> 200, 86 -> 243, 90 -> 206, 97 -> 256, 99 -> 249, 104 -> 243, 108 -> 200, 109 -> 200, 113 -> 237, 115 -> 237, 116 -> 200, 118 -> 243, 122 -> 206
      //   200: iconst_2
      //   201: istore #11
      //   203: goto -> 260
      //   206: aload_0
      //   207: invokevirtual close : ()V
      //   210: aload_0
      //   211: fload #9
      //   213: fload #10
      //   215: invokevirtual moveTo : (FF)V
      //   218: fload #9
      //   220: fstore #5
      //   222: fload #5
      //   224: fstore #7
      //   226: fload #10
      //   228: fstore #6
      //   230: fload #6
      //   232: fstore #8
      //   234: goto -> 200
      //   237: iconst_4
      //   238: istore #11
      //   240: goto -> 260
      //   243: iconst_1
      //   244: istore #11
      //   246: goto -> 260
      //   249: bipush #6
      //   251: istore #11
      //   253: goto -> 260
      //   256: bipush #7
      //   258: istore #11
      //   260: fload #5
      //   262: fstore #12
      //   264: fload #6
      //   266: fstore #13
      //   268: fload #9
      //   270: fstore #14
      //   272: fload #10
      //   274: fstore #15
      //   276: iconst_0
      //   277: istore #16
      //   279: iload_2
      //   280: istore #17
      //   282: iload #16
      //   284: aload #4
      //   286: arraylength
      //   287: if_icmpge -> 2239
      //   290: iload_3
      //   291: lookupswitch default -> 444, 65 -> 2074, 67 -> 1945, 72 -> 1910, 76 -> 1859, 77 -> 1782, 81 -> 1679, 83 -> 1508, 84 -> 1387, 86 -> 1352, 97 -> 1181, 99 -> 1048, 104 -> 1019, 108 -> 966, 109 -> 887, 113 -> 784, 115 -> 619, 116 -> 486, 118 -> 457
      //   444: fload #13
      //   446: pop
      //   447: fload #12
      //   449: pop
      //   450: iload #16
      //   452: istore #21
      //   454: goto -> 2226
      //   457: iload #16
      //   459: iconst_0
      //   460: iadd
      //   461: istore #134
      //   463: aload_0
      //   464: fconst_0
      //   465: aload #4
      //   467: iload #134
      //   469: faload
      //   470: invokevirtual rLineTo : (FF)V
      //   473: fload #13
      //   475: aload #4
      //   477: iload #134
      //   479: faload
      //   480: fadd
      //   481: fstore #13
      //   483: goto -> 450
      //   486: iload #17
      //   488: bipush #113
      //   490: if_icmpeq -> 526
      //   493: iload #17
      //   495: bipush #116
      //   497: if_icmpeq -> 526
      //   500: iload #17
      //   502: bipush #81
      //   504: if_icmpeq -> 526
      //   507: iload #17
      //   509: bipush #84
      //   511: if_icmpne -> 517
      //   514: goto -> 526
      //   517: fconst_0
      //   518: fstore #128
      //   520: fconst_0
      //   521: fstore #127
      //   523: goto -> 540
      //   526: fload #12
      //   528: fload #7
      //   530: fsub
      //   531: fstore #127
      //   533: fload #13
      //   535: fload #8
      //   537: fsub
      //   538: fstore #128
      //   540: iload #16
      //   542: iconst_0
      //   543: iadd
      //   544: istore #129
      //   546: aload #4
      //   548: iload #129
      //   550: faload
      //   551: fstore #130
      //   553: iload #16
      //   555: iconst_1
      //   556: iadd
      //   557: istore #131
      //   559: aload_0
      //   560: fload #127
      //   562: fload #128
      //   564: fload #130
      //   566: aload #4
      //   568: iload #131
      //   570: faload
      //   571: invokevirtual rQuadTo : (FFFF)V
      //   574: fload #127
      //   576: fload #12
      //   578: fadd
      //   579: fstore #132
      //   581: fload #128
      //   583: fload #13
      //   585: fadd
      //   586: fstore #133
      //   588: fload #12
      //   590: aload #4
      //   592: iload #129
      //   594: faload
      //   595: fadd
      //   596: fstore #12
      //   598: fload #13
      //   600: aload #4
      //   602: iload #131
      //   604: faload
      //   605: fadd
      //   606: fstore #13
      //   608: fload #133
      //   610: fstore #8
      //   612: fload #132
      //   614: fstore #7
      //   616: goto -> 450
      //   619: iload #17
      //   621: bipush #99
      //   623: if_icmpeq -> 659
      //   626: iload #17
      //   628: bipush #115
      //   630: if_icmpeq -> 659
      //   633: iload #17
      //   635: bipush #67
      //   637: if_icmpeq -> 659
      //   640: iload #17
      //   642: bipush #83
      //   644: if_icmpne -> 650
      //   647: goto -> 659
      //   650: fconst_0
      //   651: fstore #119
      //   653: fconst_0
      //   654: fstore #118
      //   656: goto -> 677
      //   659: fload #12
      //   661: fload #7
      //   663: fsub
      //   664: fstore #117
      //   666: fload #13
      //   668: fload #8
      //   670: fsub
      //   671: fstore #118
      //   673: fload #117
      //   675: fstore #119
      //   677: iload #16
      //   679: iconst_0
      //   680: iadd
      //   681: istore #120
      //   683: aload #4
      //   685: iload #120
      //   687: faload
      //   688: fstore #121
      //   690: iload #16
      //   692: iconst_1
      //   693: iadd
      //   694: istore #122
      //   696: aload #4
      //   698: iload #122
      //   700: faload
      //   701: fstore #123
      //   703: iload #16
      //   705: iconst_2
      //   706: iadd
      //   707: istore #124
      //   709: aload #4
      //   711: iload #124
      //   713: faload
      //   714: fstore #125
      //   716: iload #16
      //   718: iconst_3
      //   719: iadd
      //   720: istore #126
      //   722: aload_0
      //   723: fload #119
      //   725: fload #118
      //   727: fload #121
      //   729: fload #123
      //   731: fload #125
      //   733: aload #4
      //   735: iload #126
      //   737: faload
      //   738: invokevirtual rCubicTo : (FFFFFF)V
      //   741: fload #12
      //   743: aload #4
      //   745: iload #120
      //   747: faload
      //   748: fadd
      //   749: fstore #102
      //   751: fload #13
      //   753: aload #4
      //   755: iload #122
      //   757: faload
      //   758: fadd
      //   759: fstore #103
      //   761: fload #12
      //   763: aload #4
      //   765: iload #124
      //   767: faload
      //   768: fadd
      //   769: fstore #12
      //   771: fload #13
      //   773: aload #4
      //   775: iload #126
      //   777: faload
      //   778: fadd
      //   779: fstore #13
      //   781: goto -> 1170
      //   784: iload #16
      //   786: iconst_0
      //   787: iadd
      //   788: istore #110
      //   790: aload #4
      //   792: iload #110
      //   794: faload
      //   795: fstore #111
      //   797: iload #16
      //   799: iconst_1
      //   800: iadd
      //   801: istore #112
      //   803: aload #4
      //   805: iload #112
      //   807: faload
      //   808: fstore #113
      //   810: iload #16
      //   812: iconst_2
      //   813: iadd
      //   814: istore #114
      //   816: aload #4
      //   818: iload #114
      //   820: faload
      //   821: fstore #115
      //   823: iload #16
      //   825: iconst_3
      //   826: iadd
      //   827: istore #116
      //   829: aload_0
      //   830: fload #111
      //   832: fload #113
      //   834: fload #115
      //   836: aload #4
      //   838: iload #116
      //   840: faload
      //   841: invokevirtual rQuadTo : (FFFF)V
      //   844: fload #12
      //   846: aload #4
      //   848: iload #110
      //   850: faload
      //   851: fadd
      //   852: fstore #102
      //   854: fload #13
      //   856: aload #4
      //   858: iload #112
      //   860: faload
      //   861: fadd
      //   862: fstore #103
      //   864: fload #12
      //   866: aload #4
      //   868: iload #114
      //   870: faload
      //   871: fadd
      //   872: fstore #12
      //   874: fload #13
      //   876: aload #4
      //   878: iload #116
      //   880: faload
      //   881: fadd
      //   882: fstore #13
      //   884: goto -> 1170
      //   887: iload #16
      //   889: iconst_0
      //   890: iadd
      //   891: istore #108
      //   893: fload #12
      //   895: aload #4
      //   897: iload #108
      //   899: faload
      //   900: fadd
      //   901: fstore #12
      //   903: iload #16
      //   905: iconst_1
      //   906: iadd
      //   907: istore #109
      //   909: fload #13
      //   911: aload #4
      //   913: iload #109
      //   915: faload
      //   916: fadd
      //   917: fstore #13
      //   919: iload #16
      //   921: ifle -> 941
      //   924: aload_0
      //   925: aload #4
      //   927: iload #108
      //   929: faload
      //   930: aload #4
      //   932: iload #109
      //   934: faload
      //   935: invokevirtual rLineTo : (FF)V
      //   938: goto -> 450
      //   941: aload_0
      //   942: aload #4
      //   944: iload #108
      //   946: faload
      //   947: aload #4
      //   949: iload #109
      //   951: faload
      //   952: invokevirtual rMoveTo : (FF)V
      //   955: fload #13
      //   957: fstore #15
      //   959: fload #12
      //   961: fstore #14
      //   963: goto -> 450
      //   966: iload #16
      //   968: iconst_0
      //   969: iadd
      //   970: istore #105
      //   972: aload #4
      //   974: iload #105
      //   976: faload
      //   977: fstore #106
      //   979: iload #16
      //   981: iconst_1
      //   982: iadd
      //   983: istore #107
      //   985: aload_0
      //   986: fload #106
      //   988: aload #4
      //   990: iload #107
      //   992: faload
      //   993: invokevirtual rLineTo : (FF)V
      //   996: fload #12
      //   998: aload #4
      //   1000: iload #105
      //   1002: faload
      //   1003: fadd
      //   1004: fstore #12
      //   1006: fload #13
      //   1008: aload #4
      //   1010: iload #107
      //   1012: faload
      //   1013: fadd
      //   1014: fstore #13
      //   1016: goto -> 450
      //   1019: iload #16
      //   1021: iconst_0
      //   1022: iadd
      //   1023: istore #104
      //   1025: aload_0
      //   1026: aload #4
      //   1028: iload #104
      //   1030: faload
      //   1031: fconst_0
      //   1032: invokevirtual rLineTo : (FF)V
      //   1035: fload #12
      //   1037: aload #4
      //   1039: iload #104
      //   1041: faload
      //   1042: fadd
      //   1043: fstore #12
      //   1045: goto -> 450
      //   1048: aload #4
      //   1050: iload #16
      //   1052: iconst_0
      //   1053: iadd
      //   1054: faload
      //   1055: fstore #93
      //   1057: aload #4
      //   1059: iload #16
      //   1061: iconst_1
      //   1062: iadd
      //   1063: faload
      //   1064: fstore #94
      //   1066: iload #16
      //   1068: iconst_2
      //   1069: iadd
      //   1070: istore #95
      //   1072: aload #4
      //   1074: iload #95
      //   1076: faload
      //   1077: fstore #96
      //   1079: iload #16
      //   1081: iconst_3
      //   1082: iadd
      //   1083: istore #97
      //   1085: aload #4
      //   1087: iload #97
      //   1089: faload
      //   1090: fstore #98
      //   1092: iload #16
      //   1094: iconst_4
      //   1095: iadd
      //   1096: istore #99
      //   1098: aload #4
      //   1100: iload #99
      //   1102: faload
      //   1103: fstore #100
      //   1105: iload #16
      //   1107: iconst_5
      //   1108: iadd
      //   1109: istore #101
      //   1111: aload_0
      //   1112: fload #93
      //   1114: fload #94
      //   1116: fload #96
      //   1118: fload #98
      //   1120: fload #100
      //   1122: aload #4
      //   1124: iload #101
      //   1126: faload
      //   1127: invokevirtual rCubicTo : (FFFFFF)V
      //   1130: fload #12
      //   1132: aload #4
      //   1134: iload #95
      //   1136: faload
      //   1137: fadd
      //   1138: fstore #102
      //   1140: fload #13
      //   1142: aload #4
      //   1144: iload #97
      //   1146: faload
      //   1147: fadd
      //   1148: fstore #103
      //   1150: fload #12
      //   1152: aload #4
      //   1154: iload #99
      //   1156: faload
      //   1157: fadd
      //   1158: fstore #12
      //   1160: fload #13
      //   1162: aload #4
      //   1164: iload #101
      //   1166: faload
      //   1167: fadd
      //   1168: fstore #13
      //   1170: fload #102
      //   1172: fstore #7
      //   1174: fload #103
      //   1176: fstore #8
      //   1178: goto -> 450
      //   1181: iload #16
      //   1183: iconst_5
      //   1184: iadd
      //   1185: istore #79
      //   1187: fload #12
      //   1189: aload #4
      //   1191: iload #79
      //   1193: faload
      //   1194: fadd
      //   1195: fstore #80
      //   1197: iload #16
      //   1199: bipush #6
      //   1201: iadd
      //   1202: istore #81
      //   1204: fload #13
      //   1206: aload #4
      //   1208: iload #81
      //   1210: faload
      //   1211: fadd
      //   1212: fstore #82
      //   1214: aload #4
      //   1216: iload #16
      //   1218: iconst_0
      //   1219: iadd
      //   1220: faload
      //   1221: fstore #83
      //   1223: aload #4
      //   1225: iload #16
      //   1227: iconst_1
      //   1228: iadd
      //   1229: faload
      //   1230: fstore #84
      //   1232: aload #4
      //   1234: iload #16
      //   1236: iconst_2
      //   1237: iadd
      //   1238: faload
      //   1239: fstore #85
      //   1241: aload #4
      //   1243: iload #16
      //   1245: iconst_3
      //   1246: iadd
      //   1247: faload
      //   1248: fconst_0
      //   1249: fcmpl
      //   1250: ifeq -> 1259
      //   1253: iconst_1
      //   1254: istore #86
      //   1256: goto -> 1262
      //   1259: iconst_0
      //   1260: istore #86
      //   1262: aload #4
      //   1264: iload #16
      //   1266: iconst_4
      //   1267: iadd
      //   1268: faload
      //   1269: fconst_0
      //   1270: fcmpl
      //   1271: ifeq -> 1280
      //   1274: iconst_1
      //   1275: istore #87
      //   1277: goto -> 1283
      //   1280: iconst_0
      //   1281: istore #87
      //   1283: fload #12
      //   1285: fstore #88
      //   1287: fload #13
      //   1289: fstore #89
      //   1291: fload #13
      //   1293: fstore #90
      //   1295: fload #12
      //   1297: fstore #91
      //   1299: iload #86
      //   1301: istore #92
      //   1303: iload #16
      //   1305: istore #21
      //   1307: aload_0
      //   1308: fload #88
      //   1310: fload #89
      //   1312: fload #80
      //   1314: fload #82
      //   1316: fload #83
      //   1318: fload #84
      //   1320: fload #85
      //   1322: iload #92
      //   1324: iload #87
      //   1326: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   1329: fload #91
      //   1331: aload #4
      //   1333: iload #79
      //   1335: faload
      //   1336: fadd
      //   1337: fstore #12
      //   1339: fload #90
      //   1341: aload #4
      //   1343: iload #81
      //   1345: faload
      //   1346: fadd
      //   1347: fstore #13
      //   1349: goto -> 2218
      //   1352: fload #12
      //   1354: fstore #77
      //   1356: iload #16
      //   1358: istore #21
      //   1360: iload #21
      //   1362: iconst_0
      //   1363: iadd
      //   1364: istore #78
      //   1366: aload_0
      //   1367: fload #77
      //   1369: aload #4
      //   1371: iload #78
      //   1373: faload
      //   1374: invokevirtual lineTo : (FF)V
      //   1377: aload #4
      //   1379: iload #78
      //   1381: faload
      //   1382: fstore #13
      //   1384: goto -> 2226
      //   1387: fload #13
      //   1389: fstore #71
      //   1391: fload #12
      //   1393: fstore #72
      //   1395: iload #16
      //   1397: istore #21
      //   1399: iload #17
      //   1401: bipush #113
      //   1403: if_icmpeq -> 1427
      //   1406: iload #17
      //   1408: bipush #116
      //   1410: if_icmpeq -> 1427
      //   1413: iload #17
      //   1415: bipush #81
      //   1417: if_icmpeq -> 1427
      //   1420: iload #17
      //   1422: bipush #84
      //   1424: if_icmpne -> 1449
      //   1427: fload #72
      //   1429: fconst_2
      //   1430: fmul
      //   1431: fload #7
      //   1433: fsub
      //   1434: fstore #73
      //   1436: fload #71
      //   1438: fconst_2
      //   1439: fmul
      //   1440: fload #8
      //   1442: fsub
      //   1443: fstore #71
      //   1445: fload #73
      //   1447: fstore #72
      //   1449: iload #21
      //   1451: iconst_0
      //   1452: iadd
      //   1453: istore #74
      //   1455: aload #4
      //   1457: iload #74
      //   1459: faload
      //   1460: fstore #75
      //   1462: iload #21
      //   1464: iconst_1
      //   1465: iadd
      //   1466: istore #76
      //   1468: aload_0
      //   1469: fload #72
      //   1471: fload #71
      //   1473: fload #75
      //   1475: aload #4
      //   1477: iload #76
      //   1479: faload
      //   1480: invokevirtual quadTo : (FFFF)V
      //   1483: aload #4
      //   1485: iload #74
      //   1487: faload
      //   1488: fstore #12
      //   1490: aload #4
      //   1492: iload #76
      //   1494: faload
      //   1495: fstore #13
      //   1497: fload #72
      //   1499: fstore #7
      //   1501: fload #71
      //   1503: fstore #8
      //   1505: goto -> 2226
      //   1508: fload #13
      //   1510: fstore #59
      //   1512: fload #12
      //   1514: fstore #60
      //   1516: iload #16
      //   1518: istore #21
      //   1520: iload #17
      //   1522: bipush #99
      //   1524: if_icmpeq -> 1562
      //   1527: iload #17
      //   1529: bipush #115
      //   1531: if_icmpeq -> 1562
      //   1534: iload #17
      //   1536: bipush #67
      //   1538: if_icmpeq -> 1562
      //   1541: iload #17
      //   1543: bipush #83
      //   1545: if_icmpne -> 1551
      //   1548: goto -> 1562
      //   1551: fload #60
      //   1553: fstore #63
      //   1555: fload #59
      //   1557: fstore #62
      //   1559: goto -> 1584
      //   1562: fload #60
      //   1564: fconst_2
      //   1565: fmul
      //   1566: fload #7
      //   1568: fsub
      //   1569: fstore #61
      //   1571: fload #59
      //   1573: fconst_2
      //   1574: fmul
      //   1575: fload #8
      //   1577: fsub
      //   1578: fstore #62
      //   1580: fload #61
      //   1582: fstore #63
      //   1584: iload #21
      //   1586: iconst_0
      //   1587: iadd
      //   1588: istore #64
      //   1590: aload #4
      //   1592: iload #64
      //   1594: faload
      //   1595: fstore #65
      //   1597: iload #21
      //   1599: iconst_1
      //   1600: iadd
      //   1601: istore #66
      //   1603: aload #4
      //   1605: iload #66
      //   1607: faload
      //   1608: fstore #67
      //   1610: iload #21
      //   1612: iconst_2
      //   1613: iadd
      //   1614: istore #68
      //   1616: aload #4
      //   1618: iload #68
      //   1620: faload
      //   1621: fstore #69
      //   1623: iload #21
      //   1625: iconst_3
      //   1626: iadd
      //   1627: istore #70
      //   1629: aload_0
      //   1630: fload #63
      //   1632: fload #62
      //   1634: fload #65
      //   1636: fload #67
      //   1638: fload #69
      //   1640: aload #4
      //   1642: iload #70
      //   1644: faload
      //   1645: invokevirtual cubicTo : (FFFFFF)V
      //   1648: aload #4
      //   1650: iload #64
      //   1652: faload
      //   1653: fstore #57
      //   1655: aload #4
      //   1657: iload #66
      //   1659: faload
      //   1660: fstore #58
      //   1662: aload #4
      //   1664: iload #68
      //   1666: faload
      //   1667: fstore #12
      //   1669: aload #4
      //   1671: iload #70
      //   1673: faload
      //   1674: fstore #13
      //   1676: goto -> 1771
      //   1679: iload #16
      //   1681: istore #21
      //   1683: iload #21
      //   1685: iconst_0
      //   1686: iadd
      //   1687: istore #50
      //   1689: aload #4
      //   1691: iload #50
      //   1693: faload
      //   1694: fstore #51
      //   1696: iload #21
      //   1698: iconst_1
      //   1699: iadd
      //   1700: istore #52
      //   1702: aload #4
      //   1704: iload #52
      //   1706: faload
      //   1707: fstore #53
      //   1709: iload #21
      //   1711: iconst_2
      //   1712: iadd
      //   1713: istore #54
      //   1715: aload #4
      //   1717: iload #54
      //   1719: faload
      //   1720: fstore #55
      //   1722: iload #21
      //   1724: iconst_3
      //   1725: iadd
      //   1726: istore #56
      //   1728: aload_0
      //   1729: fload #51
      //   1731: fload #53
      //   1733: fload #55
      //   1735: aload #4
      //   1737: iload #56
      //   1739: faload
      //   1740: invokevirtual quadTo : (FFFF)V
      //   1743: aload #4
      //   1745: iload #50
      //   1747: faload
      //   1748: fstore #57
      //   1750: aload #4
      //   1752: iload #52
      //   1754: faload
      //   1755: fstore #58
      //   1757: aload #4
      //   1759: iload #54
      //   1761: faload
      //   1762: fstore #12
      //   1764: aload #4
      //   1766: iload #56
      //   1768: faload
      //   1769: fstore #13
      //   1771: fload #57
      //   1773: fstore #7
      //   1775: fload #58
      //   1777: fstore #8
      //   1779: goto -> 2226
      //   1782: iload #16
      //   1784: istore #21
      //   1786: iload #21
      //   1788: iconst_0
      //   1789: iadd
      //   1790: istore #48
      //   1792: aload #4
      //   1794: iload #48
      //   1796: faload
      //   1797: fstore #12
      //   1799: iload #21
      //   1801: iconst_1
      //   1802: iadd
      //   1803: istore #49
      //   1805: aload #4
      //   1807: iload #49
      //   1809: faload
      //   1810: fstore #13
      //   1812: iload #21
      //   1814: ifle -> 1834
      //   1817: aload_0
      //   1818: aload #4
      //   1820: iload #48
      //   1822: faload
      //   1823: aload #4
      //   1825: iload #49
      //   1827: faload
      //   1828: invokevirtual lineTo : (FF)V
      //   1831: goto -> 2226
      //   1834: aload_0
      //   1835: aload #4
      //   1837: iload #48
      //   1839: faload
      //   1840: aload #4
      //   1842: iload #49
      //   1844: faload
      //   1845: invokevirtual moveTo : (FF)V
      //   1848: fload #13
      //   1850: fstore #15
      //   1852: fload #12
      //   1854: fstore #14
      //   1856: goto -> 2226
      //   1859: iload #16
      //   1861: istore #21
      //   1863: iload #21
      //   1865: iconst_0
      //   1866: iadd
      //   1867: istore #45
      //   1869: aload #4
      //   1871: iload #45
      //   1873: faload
      //   1874: fstore #46
      //   1876: iload #21
      //   1878: iconst_1
      //   1879: iadd
      //   1880: istore #47
      //   1882: aload_0
      //   1883: fload #46
      //   1885: aload #4
      //   1887: iload #47
      //   1889: faload
      //   1890: invokevirtual lineTo : (FF)V
      //   1893: aload #4
      //   1895: iload #45
      //   1897: faload
      //   1898: fstore #12
      //   1900: aload #4
      //   1902: iload #47
      //   1904: faload
      //   1905: fstore #13
      //   1907: goto -> 2226
      //   1910: fload #13
      //   1912: fstore #43
      //   1914: iload #16
      //   1916: istore #21
      //   1918: iload #21
      //   1920: iconst_0
      //   1921: iadd
      //   1922: istore #44
      //   1924: aload_0
      //   1925: aload #4
      //   1927: iload #44
      //   1929: faload
      //   1930: fload #43
      //   1932: invokevirtual lineTo : (FF)V
      //   1935: aload #4
      //   1937: iload #44
      //   1939: faload
      //   1940: fstore #12
      //   1942: goto -> 2226
      //   1945: iload #16
      //   1947: istore #21
      //   1949: aload #4
      //   1951: iload #21
      //   1953: iconst_0
      //   1954: iadd
      //   1955: faload
      //   1956: fstore #31
      //   1958: aload #4
      //   1960: iload #21
      //   1962: iconst_1
      //   1963: iadd
      //   1964: faload
      //   1965: fstore #32
      //   1967: iload #21
      //   1969: iconst_2
      //   1970: iadd
      //   1971: istore #33
      //   1973: aload #4
      //   1975: iload #33
      //   1977: faload
      //   1978: fstore #34
      //   1980: iload #21
      //   1982: iconst_3
      //   1983: iadd
      //   1984: istore #35
      //   1986: aload #4
      //   1988: iload #35
      //   1990: faload
      //   1991: fstore #36
      //   1993: iload #21
      //   1995: iconst_4
      //   1996: iadd
      //   1997: istore #37
      //   1999: aload #4
      //   2001: iload #37
      //   2003: faload
      //   2004: fstore #38
      //   2006: iload #21
      //   2008: iconst_5
      //   2009: iadd
      //   2010: istore #39
      //   2012: aload_0
      //   2013: fload #31
      //   2015: fload #32
      //   2017: fload #34
      //   2019: fload #36
      //   2021: fload #38
      //   2023: aload #4
      //   2025: iload #39
      //   2027: faload
      //   2028: invokevirtual cubicTo : (FFFFFF)V
      //   2031: aload #4
      //   2033: iload #37
      //   2035: faload
      //   2036: fstore #12
      //   2038: aload #4
      //   2040: iload #39
      //   2042: faload
      //   2043: fstore #40
      //   2045: aload #4
      //   2047: iload #33
      //   2049: faload
      //   2050: fstore #41
      //   2052: aload #4
      //   2054: iload #35
      //   2056: faload
      //   2057: fstore #42
      //   2059: fload #40
      //   2061: fstore #13
      //   2063: fload #42
      //   2065: fstore #8
      //   2067: fload #41
      //   2069: fstore #7
      //   2071: goto -> 2226
      //   2074: fload #13
      //   2076: fstore #19
      //   2078: fload #12
      //   2080: fstore #20
      //   2082: iload #16
      //   2084: istore #21
      //   2086: iload #21
      //   2088: iconst_5
      //   2089: iadd
      //   2090: istore #22
      //   2092: aload #4
      //   2094: iload #22
      //   2096: faload
      //   2097: fstore #23
      //   2099: iload #21
      //   2101: bipush #6
      //   2103: iadd
      //   2104: istore #24
      //   2106: aload #4
      //   2108: iload #24
      //   2110: faload
      //   2111: fstore #25
      //   2113: aload #4
      //   2115: iload #21
      //   2117: iconst_0
      //   2118: iadd
      //   2119: faload
      //   2120: fstore #26
      //   2122: aload #4
      //   2124: iload #21
      //   2126: iconst_1
      //   2127: iadd
      //   2128: faload
      //   2129: fstore #27
      //   2131: aload #4
      //   2133: iload #21
      //   2135: iconst_2
      //   2136: iadd
      //   2137: faload
      //   2138: fstore #28
      //   2140: aload #4
      //   2142: iload #21
      //   2144: iconst_3
      //   2145: iadd
      //   2146: faload
      //   2147: fconst_0
      //   2148: fcmpl
      //   2149: ifeq -> 2158
      //   2152: iconst_1
      //   2153: istore #29
      //   2155: goto -> 2161
      //   2158: iconst_0
      //   2159: istore #29
      //   2161: aload #4
      //   2163: iload #21
      //   2165: iconst_4
      //   2166: iadd
      //   2167: faload
      //   2168: fconst_0
      //   2169: fcmpl
      //   2170: ifeq -> 2179
      //   2173: iconst_1
      //   2174: istore #30
      //   2176: goto -> 2182
      //   2179: iconst_0
      //   2180: istore #30
      //   2182: aload_0
      //   2183: fload #20
      //   2185: fload #19
      //   2187: fload #23
      //   2189: fload #25
      //   2191: fload #26
      //   2193: fload #27
      //   2195: fload #28
      //   2197: iload #29
      //   2199: iload #30
      //   2201: invokestatic drawArc : (Landroid/graphics/Path;FFFFFFFZZ)V
      //   2204: aload #4
      //   2206: iload #22
      //   2208: faload
      //   2209: fstore #12
      //   2211: aload #4
      //   2213: iload #24
      //   2215: faload
      //   2216: fstore #13
      //   2218: fload #13
      //   2220: fstore #8
      //   2222: fload #12
      //   2224: fstore #7
      //   2226: iload #21
      //   2228: iload #11
      //   2230: iadd
      //   2231: istore #16
      //   2233: iload_3
      //   2234: istore #17
      //   2236: goto -> 282
      //   2239: fload #13
      //   2241: fstore #18
      //   2243: aload_1
      //   2244: iconst_0
      //   2245: fload #12
      //   2247: fastore
      //   2248: aload_1
      //   2249: iconst_1
      //   2250: fload #18
      //   2252: fastore
      //   2253: aload_1
      //   2254: iconst_2
      //   2255: fload #7
      //   2257: fastore
      //   2258: aload_1
      //   2259: iconst_3
      //   2260: fload #8
      //   2262: fastore
      //   2263: aload_1
      //   2264: iconst_4
      //   2265: fload #14
      //   2267: fastore
      //   2268: aload_1
      //   2269: iconst_5
      //   2270: fload #15
      //   2272: fastore
      //   2273: return
    }
    
    private static void arcToBezier(Path param1Path, double param1Double1, double param1Double2, double param1Double3, double param1Double4, double param1Double5, double param1Double6, double param1Double7, double param1Double8, double param1Double9) {
      double d1 = param1Double3;
      int i = (int)Math.ceil(Math.abs(param1Double9 * 4.0D / Math.PI));
      double d2 = Math.cos(param1Double7);
      double d3 = Math.sin(param1Double7);
      double d4 = Math.cos(param1Double8);
      double d5 = Math.sin(param1Double8);
      double d6 = -d1;
      double d7 = d6 * d2;
      double d8 = d7 * d5;
      double d9 = param1Double4 * d3;
      double d10 = d8 - d9 * d4;
      double d11 = d6 * d3;
      double d12 = d5 * d11;
      double d13 = param1Double4 * d2;
      double d14 = d12 + d4 * d13;
      double d15 = i;
      Double.isNaN(d15);
      double d16 = param1Double9 / d15;
      byte b = 0;
      double d17 = param1Double6;
      double d18 = d14;
      double d19 = d10;
      double d20 = param1Double5;
      double d21 = param1Double8;
      while (b < i) {
        double d22 = d21 + d16;
        double d23 = Math.sin(d22);
        double d24 = Math.cos(d22);
        double d25 = param1Double1 + d24 * d1 * d2;
        double d26 = d9 * d23;
        double d27 = d16;
        double d28 = d25 - d26;
        double d29 = param1Double2 + d24 * d1 * d3 + d13 * d23;
        double d30 = d7 * d23 - d9 * d24;
        double d31 = d23 * d11 + d24 * d13;
        double d32 = d22 - d21;
        double d33 = Math.tan(d32 / 2.0D);
        double d34 = Math.sin(d32) * (Math.sqrt(4.0D + d33 * d33 * 3.0D) - 1.0D) / 3.0D;
        double d35 = d19 * d34;
        double d36 = d13;
        double d37 = d20 + d35;
        double d38 = d18 * d34;
        double d39 = d11;
        double d40 = d17 + d38;
        double d41 = d34 * d30;
        int j = i;
        double d42 = d2;
        double d43 = d28 - d41;
        double d44 = d29 - d34 * d31;
        double d45 = d3;
        param1Path.rLineTo(0.0F, 0.0F);
        param1Path.cubicTo((float)d37, (float)d40, (float)d43, (float)d44, (float)d28, (float)d29);
        b++;
        d17 = d29;
        d20 = d28;
        d21 = d22;
        d18 = d31;
        d19 = d30;
        d16 = d27;
        d13 = d36;
        d11 = d39;
        i = j;
        d2 = d42;
        d3 = d45;
        d1 = param1Double3;
      } 
    }
    
    private static void drawArc(Path param1Path, float param1Float1, float param1Float2, float param1Float3, float param1Float4, float param1Float5, float param1Float6, float param1Float7, boolean param1Boolean1, boolean param1Boolean2) {
      double d33;
      double d34;
      boolean bool;
      double d1 = Math.toRadians(param1Float7);
      double d2 = Math.cos(d1);
      double d3 = Math.sin(d1);
      double d4 = param1Float1;
      Double.isNaN(d4);
      double d5 = d4 * d2;
      double d6 = param1Float2;
      Double.isNaN(d6);
      double d7 = d5 + d6 * d3;
      double d8 = param1Float5;
      Double.isNaN(d8);
      double d9 = d7 / d8;
      double d10 = -param1Float1;
      Double.isNaN(d10);
      double d11 = d10 * d3;
      Double.isNaN(d6);
      double d12 = d11 + d6 * d2;
      double d13 = param1Float6;
      Double.isNaN(d13);
      double d14 = d12 / d13;
      double d15 = param1Float3;
      Double.isNaN(d15);
      double d16 = d15 * d2;
      double d17 = param1Float4;
      Double.isNaN(d17);
      double d18 = d16 + d17 * d3;
      Double.isNaN(d8);
      double d19 = d18 / d8;
      double d20 = -param1Float3;
      Double.isNaN(d20);
      double d21 = d20 * d3;
      Double.isNaN(d17);
      double d22 = d21 + d17 * d2;
      Double.isNaN(d13);
      double d23 = d22 / d13;
      double d24 = d9 - d19;
      double d25 = d14 - d23;
      double d26 = (d9 + d19) / 2.0D;
      double d27 = (d14 + d23) / 2.0D;
      double d28 = d24 * d24 + d25 * d25;
      if (d28 == 0.0D) {
        Log.w("PathParser", " Points are coincident");
        return;
      } 
      double d29 = 1.0D / d28 - 0.25D;
      if (d29 < 0.0D) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Points are too far apart ");
        stringBuilder.append(d28);
        Log.w("PathParser", stringBuilder.toString());
        float f = (float)(Math.sqrt(d28) / 1.99999D);
        drawArc(param1Path, param1Float1, param1Float2, param1Float3, param1Float4, param1Float5 * f, param1Float6 * f, param1Float7, param1Boolean1, param1Boolean2);
        return;
      } 
      double d30 = Math.sqrt(d29);
      double d31 = d24 * d30;
      double d32 = d30 * d25;
      if (param1Boolean1 == param1Boolean2) {
        d33 = d26 - d32;
        d34 = d27 + d31;
      } else {
        d33 = d26 + d32;
        d34 = d27 - d31;
      } 
      double d35 = Math.atan2(d14 - d34, d9 - d33);
      double d36 = Math.atan2(d23 - d34, d19 - d33) - d35;
      if (d36 >= 0.0D) {
        bool = true;
      } else {
        bool = false;
      } 
      if (param1Boolean2 != bool)
        if (d36 > 0.0D) {
          d36 -= 6.283185307179586D;
        } else {
          d36 += 6.283185307179586D;
        }  
      double d37 = d36;
      Double.isNaN(d8);
      double d38 = d33 * d8;
      Double.isNaN(d13);
      double d39 = d34 * d13;
      arcToBezier(param1Path, d38 * d2 - d39 * d3, d38 * d3 + d39 * d2, d8, d13, d4, d6, d1, d35, d37);
    }
    
    public static void nodesToPath(PathDataNode[] param1ArrayOfPathDataNode, Path param1Path) {
      float[] arrayOfFloat = new float[6];
      char c = 'm';
      for (byte b = 0; b < param1ArrayOfPathDataNode.length; b++) {
        addCommand(param1Path, arrayOfFloat, c, (param1ArrayOfPathDataNode[b]).mType, (param1ArrayOfPathDataNode[b]).mParams);
        c = (param1ArrayOfPathDataNode[b]).mType;
      } 
    }
    
    public void interpolatePathDataNode(PathDataNode param1PathDataNode1, PathDataNode param1PathDataNode2, float param1Float) {
      for (byte b = 0; b < param1PathDataNode1.mParams.length; b++)
        this.mParams[b] = param1PathDataNode1.mParams[b] * (1.0F - param1Float) + param1Float * param1PathDataNode2.mParams[b]; 
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\PathParser.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */