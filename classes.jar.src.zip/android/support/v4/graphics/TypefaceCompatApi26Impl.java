package android.support.v4.graphics;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.Typeface;
import android.graphics.fonts.FontVariationAxis;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.content.res.FontResourcesParserCompat;
import android.support.v4.provider.FontsContractCompat;
import android.util.Log;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.util.Map;

@RequiresApi(26)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatApi26Impl extends TypefaceCompatApi21Impl {
  private static final String ABORT_CREATION_METHOD = "abortCreation";
  
  private static final String ADD_FONT_FROM_ASSET_MANAGER_METHOD = "addFontFromAssetManager";
  
  private static final String ADD_FONT_FROM_BUFFER_METHOD = "addFontFromBuffer";
  
  private static final String CREATE_FROM_FAMILIES_WITH_DEFAULT_METHOD = "createFromFamiliesWithDefault";
  
  private static final String FONT_FAMILY_CLASS = "android.graphics.FontFamily";
  
  private static final String FREEZE_METHOD = "freeze";
  
  private static final int RESOLVE_BY_FONT_TABLE = -1;
  
  private static final String TAG = "TypefaceCompatApi26Impl";
  
  private static final Method sAbortCreation;
  
  private static final Method sAddFontFromAssetManager;
  
  private static final Method sAddFontFromBuffer;
  
  private static final Method sCreateFromFamiliesWithDefault;
  
  private static final Class sFontFamily;
  
  private static final Constructor sFontFamilyCtor;
  
  private static final Method sFreeze;
  
  static {
    Class clazz;
    Method method1;
    Method method2;
    Method method3;
    Method method4;
    Method method5;
    Constructor<?> constructor = null;
    try {
      clazz = Class.forName("android.graphics.FontFamily");
      Constructor<?> constructor1 = clazz.getConstructor(new Class[0]);
      Class[] arrayOfClass1 = new Class[8];
      arrayOfClass1[0] = AssetManager.class;
      arrayOfClass1[1] = String.class;
      arrayOfClass1[2] = int.class;
      arrayOfClass1[3] = boolean.class;
      arrayOfClass1[4] = int.class;
      arrayOfClass1[5] = int.class;
      arrayOfClass1[6] = int.class;
      arrayOfClass1[7] = FontVariationAxis[].class;
      method2 = clazz.getMethod("addFontFromAssetManager", arrayOfClass1);
      Class[] arrayOfClass2 = new Class[5];
      arrayOfClass2[0] = ByteBuffer.class;
      arrayOfClass2[1] = int.class;
      arrayOfClass2[2] = FontVariationAxis[].class;
      arrayOfClass2[3] = int.class;
      arrayOfClass2[4] = int.class;
      method3 = clazz.getMethod("addFontFromBuffer", arrayOfClass2);
      method4 = clazz.getMethod("freeze", new Class[0]);
      method5 = clazz.getMethod("abortCreation", new Class[0]);
      Object object = Array.newInstance(clazz, 1);
      Class[] arrayOfClass3 = new Class[3];
      arrayOfClass3[0] = object.getClass();
      arrayOfClass3[1] = int.class;
      arrayOfClass3[2] = int.class;
      method1 = Typeface.class.getDeclaredMethod("createFromFamiliesWithDefault", arrayOfClass3);
      method1.setAccessible(true);
      constructor = constructor1;
    } catch (ClassNotFoundException|NoSuchMethodException classNotFoundException) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Unable to collect necessary methods for class ");
      stringBuilder.append(classNotFoundException.getClass().getName());
      Log.e("TypefaceCompatApi26Impl", stringBuilder.toString(), classNotFoundException);
      clazz = null;
      method1 = null;
      method2 = null;
      method3 = null;
      method4 = null;
      method5 = null;
    } 
    sFontFamilyCtor = constructor;
    sFontFamily = clazz;
    sAddFontFromAssetManager = method2;
    sAddFontFromBuffer = method3;
    sFreeze = method4;
    sAbortCreation = method5;
    sCreateFromFamiliesWithDefault = method1;
  }
  
  private static void abortCreation(Object paramObject) {
    try {
      sAbortCreation.invoke(paramObject, new Object[0]);
      return;
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean addFontFromAssetManager(Context paramContext, Object paramObject, String paramString, int paramInt1, int paramInt2, int paramInt3) {
    try {
      Method method = sAddFontFromAssetManager;
      Object[] arrayOfObject = new Object[8];
      arrayOfObject[0] = paramContext.getAssets();
      arrayOfObject[1] = paramString;
      arrayOfObject[2] = Integer.valueOf(0);
      arrayOfObject[3] = Boolean.valueOf(false);
      arrayOfObject[4] = Integer.valueOf(paramInt1);
      arrayOfObject[5] = Integer.valueOf(paramInt2);
      arrayOfObject[6] = Integer.valueOf(paramInt3);
      arrayOfObject[7] = null;
      return ((Boolean)method.invoke(paramObject, arrayOfObject)).booleanValue();
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean addFontFromBuffer(Object paramObject, ByteBuffer paramByteBuffer, int paramInt1, int paramInt2, int paramInt3) {
    try {
      Method method = sAddFontFromBuffer;
      Object[] arrayOfObject = new Object[5];
      arrayOfObject[0] = paramByteBuffer;
      arrayOfObject[1] = Integer.valueOf(paramInt1);
      arrayOfObject[2] = null;
      arrayOfObject[3] = Integer.valueOf(paramInt2);
      arrayOfObject[4] = Integer.valueOf(paramInt3);
      return ((Boolean)method.invoke(paramObject, arrayOfObject)).booleanValue();
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static Typeface createFromFamiliesWithDefault(Object paramObject) {
    try {
      Object object = Array.newInstance(sFontFamily, 1);
      Array.set(object, 0, paramObject);
      Method method = sCreateFromFamiliesWithDefault;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = object;
      arrayOfObject[1] = Integer.valueOf(-1);
      arrayOfObject[2] = Integer.valueOf(-1);
      return (Typeface)method.invoke((Object)null, arrayOfObject);
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean freeze(Object paramObject) {
    try {
      return ((Boolean)sFreeze.invoke(paramObject, new Object[0])).booleanValue();
    } catch (IllegalAccessException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  private static boolean isFontFamilyPrivateAPIAvailable() {
    if (sAddFontFromAssetManager == null)
      Log.w("TypefaceCompatApi26Impl", "Unable to collect necessary private methods. Fallback to legacy implementation."); 
    return (sAddFontFromAssetManager != null);
  }
  
  private static Object newFamily() {
    try {
      return sFontFamilyCtor.newInstance(new Object[0]);
    } catch (IllegalAccessException|InstantiationException|java.lang.reflect.InvocationTargetException illegalAccessException) {
      throw new RuntimeException(illegalAccessException);
    } 
  }
  
  public Typeface createFromFontFamilyFilesResourceEntry(Context paramContext, FontResourcesParserCompat.FontFamilyFilesResourceEntry paramFontFamilyFilesResourceEntry, Resources paramResources, int paramInt) {
    if (!isFontFamilyPrivateAPIAvailable())
      return super.createFromFontFamilyFilesResourceEntry(paramContext, paramFontFamilyFilesResourceEntry, paramResources, paramInt); 
    Object object = newFamily();
    for (FontResourcesParserCompat.FontFileResourceEntry fontFileResourceEntry : paramFontFamilyFilesResourceEntry.getEntries()) {
      if (!addFontFromAssetManager(paramContext, object, fontFileResourceEntry.getFileName(), 0, fontFileResourceEntry.getWeight(), fontFileResourceEntry.isItalic())) {
        abortCreation(object);
        return null;
      } 
    } 
    return !freeze(object) ? null : createFromFamiliesWithDefault(object);
  }
  
  public Typeface createFromFontInfo(Context paramContext, @Nullable CancellationSignal paramCancellationSignal, @NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    if (paramArrayOfFontInfo.length < 1)
      return null; 
    if (!isFontFamilyPrivateAPIAvailable()) {
      FontsContractCompat.FontInfo fontInfo = findBestInfo(paramArrayOfFontInfo, paramInt);
      ContentResolver contentResolver = paramContext.getContentResolver();
      try {
        Throwable throwable;
        Exception exception;
        ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(fontInfo.getUri(), "r", paramCancellationSignal);
        if (parcelFileDescriptor == null) {
          if (parcelFileDescriptor != null)
            parcelFileDescriptor.close(); 
          return null;
        } 
        try {
          return (new Typeface.Builder(parcelFileDescriptor.getFileDescriptor())).setWeight(fontInfo.getWeight()).setItalic(fontInfo.isItalic()).build();
        } catch (Throwable throwable1) {
          try {
            throw throwable1;
          } finally {
            Exception exception1 = null;
            throwable = throwable1;
          } 
        } finally {
          exception = null;
        } 
        if (parcelFileDescriptor != null)
          if (throwable != null) {
            try {
              parcelFileDescriptor.close();
            } catch (Throwable throwable1) {
              throwable.addSuppressed(throwable1);
            } 
          } else {
            parcelFileDescriptor.close();
          }  
        throw exception;
      } catch (IOException iOException) {
        return null;
      } 
    } 
    Map map = FontsContractCompat.prepareFontData(paramContext, paramArrayOfFontInfo, paramCancellationSignal);
    Object object = newFamily();
    int i = paramArrayOfFontInfo.length;
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      FontsContractCompat.FontInfo fontInfo = paramArrayOfFontInfo[b];
      ByteBuffer byteBuffer = (ByteBuffer)map.get(fontInfo.getUri());
      if (byteBuffer != null) {
        if (!addFontFromBuffer(object, byteBuffer, fontInfo.getTtcIndex(), fontInfo.getWeight(), fontInfo.isItalic())) {
          abortCreation(object);
          return null;
        } 
        bool = true;
      } 
      b++;
    } 
    if (!bool) {
      abortCreation(object);
      return null;
    } 
    return !freeze(object) ? null : Typeface.create(createFromFamiliesWithDefault(object), paramInt);
  }
  
  @Nullable
  public Typeface createFromResourcesFontFile(Context paramContext, Resources paramResources, int paramInt1, String paramString, int paramInt2) {
    if (!isFontFamilyPrivateAPIAvailable())
      return super.createFromResourcesFontFile(paramContext, paramResources, paramInt1, paramString, paramInt2); 
    Object object = newFamily();
    if (!addFontFromAssetManager(paramContext, object, paramString, 0, -1, -1)) {
      abortCreation(object);
      return null;
    } 
    return !freeze(object) ? null : createFromFamiliesWithDefault(object);
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\TypefaceCompatApi26Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */