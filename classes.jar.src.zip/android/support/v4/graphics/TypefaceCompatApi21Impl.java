package android.support.v4.graphics;

import android.content.ContentResolver;
import android.content.Context;
import android.graphics.Typeface;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.support.annotation.NonNull;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.support.v4.provider.FontsContractCompat;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

@RequiresApi(21)
@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
class TypefaceCompatApi21Impl extends TypefaceCompatBaseImpl {
  private static final String TAG = "TypefaceCompatApi21Impl";
  
  private File getFile(ParcelFileDescriptor paramParcelFileDescriptor) {
    try {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("/proc/self/fd/");
      stringBuilder.append(paramParcelFileDescriptor.getFd());
      String str = Os.readlink(stringBuilder.toString());
      return OsConstants.S_ISREG((Os.stat(str)).st_mode) ? new File(str) : null;
    } catch (ErrnoException errnoException) {
      return null;
    } 
  }
  
  public Typeface createFromFontInfo(Context paramContext, CancellationSignal paramCancellationSignal, @NonNull FontsContractCompat.FontInfo[] paramArrayOfFontInfo, int paramInt) {
    if (paramArrayOfFontInfo.length < 1)
      return null; 
    FontsContractCompat.FontInfo fontInfo = findBestInfo(paramArrayOfFontInfo, paramInt);
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      Throwable throwable;
      Exception exception;
      ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(fontInfo.getUri(), "r", paramCancellationSignal);
      try {
        File file = getFile(parcelFileDescriptor);
        if (file == null || !file.canRead()) {
          Throwable throwable1;
          Exception exception1;
          FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptor.getFileDescriptor());
          try {
            return createFromInputStream(paramContext, fileInputStream);
          } catch (Throwable throwable2) {
            try {
              throw throwable2;
            } finally {
              Exception exception2 = null;
              throwable1 = throwable2;
            } 
          } finally {
            exception1 = null;
          } 
          if (throwable1 != null) {
            try {
              fileInputStream.close();
            } catch (Throwable throwable2) {
              throwable1.addSuppressed(throwable2);
            } 
          } else {
            fileInputStream.close();
          } 
          throw exception1;
        } 
        return Typeface.createFromFile(file);
      } catch (Throwable throwable1) {
        try {
          throw throwable1;
        } finally {
          Exception exception1 = null;
          throwable = throwable1;
        } 
      } finally {
        exception = null;
      } 
      if (parcelFileDescriptor != null)
        if (throwable != null) {
          try {
            parcelFileDescriptor.close();
          } catch (Throwable throwable1) {
            throwable.addSuppressed(throwable1);
          } 
        } else {
          parcelFileDescriptor.close();
        }  
      throw exception;
    } catch (IOException iOException) {
      return null;
    } 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\TypefaceCompatApi21Impl.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */