package android.support.v4.graphics.drawable;

import android.content.res.ColorStateList;
import android.content.res.Resources;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.PorterDuff;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.Drawable;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;

class WrappedDrawableApi14 extends Drawable implements Drawable.Callback, TintAwareDrawable, WrappedDrawable {
  static final PorterDuff.Mode a = PorterDuff.Mode.SRC_IN;
  
  DrawableWrapperState b = a();
  
  Drawable c;
  
  private boolean mColorFilterSet;
  
  private int mCurrentColor;
  
  private PorterDuff.Mode mCurrentMode;
  
  private boolean mMutated;
  
  WrappedDrawableApi14(@Nullable Drawable paramDrawable) {
    setWrappedDrawable(paramDrawable);
  }
  
  WrappedDrawableApi14(@NonNull DrawableWrapperState paramDrawableWrapperState, @Nullable Resources paramResources) {
    updateLocalState(paramResources);
  }
  
  private void updateLocalState(@Nullable Resources paramResources) {
    if (this.b != null && this.b.b != null)
      setWrappedDrawable(this.b.b.newDrawable(paramResources)); 
  }
  
  private boolean updateTint(int[] paramArrayOfint) {
    if (!isCompatTintEnabled())
      return false; 
    ColorStateList colorStateList = this.b.c;
    PorterDuff.Mode mode = this.b.d;
    if (colorStateList != null && mode != null) {
      int i = colorStateList.getColorForState(paramArrayOfint, colorStateList.getDefaultColor());
      if (!this.mColorFilterSet || i != this.mCurrentColor || mode != this.mCurrentMode) {
        setColorFilter(i, mode);
        this.mCurrentColor = i;
        this.mCurrentMode = mode;
        this.mColorFilterSet = true;
        return true;
      } 
    } else {
      this.mColorFilterSet = false;
      clearColorFilter();
    } 
    return false;
  }
  
  @NonNull
  DrawableWrapperState a() {
    return new DrawableWrapperStateBase(this.b, null);
  }
  
  public void draw(@NonNull Canvas paramCanvas) {
    this.c.draw(paramCanvas);
  }
  
  public int getChangingConfigurations() {
    byte b;
    int i = super.getChangingConfigurations();
    if (this.b != null) {
      b = this.b.getChangingConfigurations();
    } else {
      b = 0;
    } 
    return i | b | this.c.getChangingConfigurations();
  }
  
  @Nullable
  public Drawable.ConstantState getConstantState() {
    if (this.b != null && this.b.a()) {
      this.b.a = getChangingConfigurations();
      return this.b;
    } 
    return null;
  }
  
  @NonNull
  public Drawable getCurrent() {
    return this.c.getCurrent();
  }
  
  public int getIntrinsicHeight() {
    return this.c.getIntrinsicHeight();
  }
  
  public int getIntrinsicWidth() {
    return this.c.getIntrinsicWidth();
  }
  
  public int getMinimumHeight() {
    return this.c.getMinimumHeight();
  }
  
  public int getMinimumWidth() {
    return this.c.getMinimumWidth();
  }
  
  public int getOpacity() {
    return this.c.getOpacity();
  }
  
  public boolean getPadding(@NonNull Rect paramRect) {
    return this.c.getPadding(paramRect);
  }
  
  @NonNull
  public int[] getState() {
    return this.c.getState();
  }
  
  public Region getTransparentRegion() {
    return this.c.getTransparentRegion();
  }
  
  public final Drawable getWrappedDrawable() {
    return this.c;
  }
  
  public void invalidateDrawable(@NonNull Drawable paramDrawable) {
    invalidateSelf();
  }
  
  protected boolean isCompatTintEnabled() {
    return true;
  }
  
  public boolean isStateful() {
    ColorStateList colorStateList;
    if (isCompatTintEnabled() && this.b != null) {
      colorStateList = this.b.c;
    } else {
      colorStateList = null;
    } 
    return ((colorStateList != null && colorStateList.isStateful()) || this.c.isStateful());
  }
  
  public void jumpToCurrentState() {
    this.c.jumpToCurrentState();
  }
  
  @NonNull
  public Drawable mutate() {
    if (!this.mMutated && super.mutate() == this) {
      this.b = a();
      if (this.c != null)
        this.c.mutate(); 
      if (this.b != null) {
        Drawable.ConstantState constantState;
        DrawableWrapperState drawableWrapperState = this.b;
        if (this.c != null) {
          constantState = this.c.getConstantState();
        } else {
          constantState = null;
        } 
        drawableWrapperState.b = constantState;
      } 
      this.mMutated = true;
    } 
    return this;
  }
  
  protected void onBoundsChange(Rect paramRect) {
    if (this.c != null)
      this.c.setBounds(paramRect); 
  }
  
  protected boolean onLevelChange(int paramInt) {
    return this.c.setLevel(paramInt);
  }
  
  public void scheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable, long paramLong) {
    scheduleSelf(paramRunnable, paramLong);
  }
  
  public void setAlpha(int paramInt) {
    this.c.setAlpha(paramInt);
  }
  
  public void setChangingConfigurations(int paramInt) {
    this.c.setChangingConfigurations(paramInt);
  }
  
  public void setColorFilter(ColorFilter paramColorFilter) {
    this.c.setColorFilter(paramColorFilter);
  }
  
  public void setDither(boolean paramBoolean) {
    this.c.setDither(paramBoolean);
  }
  
  public void setFilterBitmap(boolean paramBoolean) {
    this.c.setFilterBitmap(paramBoolean);
  }
  
  public boolean setState(@NonNull int[] paramArrayOfint) {
    boolean bool = this.c.setState(paramArrayOfint);
    return (updateTint(paramArrayOfint) || bool);
  }
  
  public void setTint(int paramInt) {
    setTintList(ColorStateList.valueOf(paramInt));
  }
  
  public void setTintList(ColorStateList paramColorStateList) {
    this.b.c = paramColorStateList;
    updateTint(getState());
  }
  
  public void setTintMode(@NonNull PorterDuff.Mode paramMode) {
    this.b.d = paramMode;
    updateTint(getState());
  }
  
  public boolean setVisible(boolean paramBoolean1, boolean paramBoolean2) {
    return (super.setVisible(paramBoolean1, paramBoolean2) || this.c.setVisible(paramBoolean1, paramBoolean2));
  }
  
  public final void setWrappedDrawable(Drawable paramDrawable) {
    if (this.c != null)
      this.c.setCallback(null); 
    this.c = paramDrawable;
    if (paramDrawable != null) {
      paramDrawable.setCallback(this);
      setVisible(paramDrawable.isVisible(), true);
      setState(paramDrawable.getState());
      setLevel(paramDrawable.getLevel());
      setBounds(paramDrawable.getBounds());
      if (this.b != null)
        this.b.b = paramDrawable.getConstantState(); 
    } 
    invalidateSelf();
  }
  
  public void unscheduleDrawable(@NonNull Drawable paramDrawable, @NonNull Runnable paramRunnable) {
    unscheduleSelf(paramRunnable);
  }
  
  protected static abstract class DrawableWrapperState extends Drawable.ConstantState {
    int a;
    
    Drawable.ConstantState b;
    
    ColorStateList c = null;
    
    PorterDuff.Mode d = WrappedDrawableApi14.a;
    
    DrawableWrapperState(@Nullable DrawableWrapperState param1DrawableWrapperState, @Nullable Resources param1Resources) {
      if (param1DrawableWrapperState != null) {
        this.a = param1DrawableWrapperState.a;
        this.b = param1DrawableWrapperState.b;
        this.c = param1DrawableWrapperState.c;
        this.d = param1DrawableWrapperState.d;
      } 
    }
    
    boolean a() {
      return (this.b != null);
    }
    
    public int getChangingConfigurations() {
      byte b;
      int i = this.a;
      if (this.b != null) {
        b = this.b.getChangingConfigurations();
      } else {
        b = 0;
      } 
      return i | b;
    }
    
    @NonNull
    public Drawable newDrawable() {
      return newDrawable(null);
    }
    
    @NonNull
    public abstract Drawable newDrawable(@Nullable Resources param1Resources);
  }
  
  private static class DrawableWrapperStateBase extends DrawableWrapperState {
    DrawableWrapperStateBase(@Nullable WrappedDrawableApi14.DrawableWrapperState param1DrawableWrapperState, @Nullable Resources param1Resources) {
      super(param1DrawableWrapperState, param1Resources);
    }
    
    @NonNull
    public Drawable newDrawable(@Nullable Resources param1Resources) {
      return new WrappedDrawableApi14(this, param1Resources);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\drawable\WrappedDrawableApi14.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */