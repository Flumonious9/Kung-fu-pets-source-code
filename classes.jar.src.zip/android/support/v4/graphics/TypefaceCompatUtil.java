package android.support.v4.graphics;

import android.content.ContentResolver;
import android.content.Context;
import android.content.res.Resources;
import android.net.Uri;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.os.Process;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.annotation.RestrictTo;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

@RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
public class TypefaceCompatUtil {
  private static final String CACHE_FILE_PREFIX = ".font";
  
  private static final String TAG = "TypefaceCompatUtil";
  
  public static void closeQuietly(Closeable paramCloseable) {
    // Byte code:
    //   0: aload_0
    //   1: ifnull -> 13
    //   4: aload_0
    //   5: invokeinterface close : ()V
    //   10: goto -> 14
    //   13: pop
    //   14: return
    // Exception table:
    //   from	to	target	type
    //   4	10	13	java/io/IOException
  }
  
  @Nullable
  @RequiresApi(19)
  public static ByteBuffer copyToDirectBuffer(Context paramContext, Resources paramResources, int paramInt) {
    File file = getTempFile(paramContext);
    if (file == null)
      return null; 
    try {
      boolean bool = copyToFile(file, paramResources, paramInt);
      if (!bool)
        return null; 
      return mmap(file);
    } finally {
      file.delete();
    } 
  }
  
  public static boolean copyToFile(File paramFile, Resources paramResources, int paramInt) {
    Exception exception;
    Closeable closeable;
    try {
      closeable = paramResources.openRawResource(paramInt);
    } finally {
      exception = null;
    } 
    closeQuietly(closeable);
    throw exception;
  }
  
  public static boolean copyToFile(File paramFile, InputStream paramInputStream) {
    FileOutputStream fileOutputStream = null;
    try {
      FileOutputStream fileOutputStream1 = new FileOutputStream(paramFile, false);
      try {
        byte[] arrayOfByte = new byte[1024];
        while (true) {
          int i = paramInputStream.read(arrayOfByte);
          if (i != -1) {
            fileOutputStream1.write(arrayOfByte, 0, i);
            continue;
          } 
          return true;
        } 
      } catch (IOException null) {
      
      } finally {
        Exception exception = null;
      } 
    } catch (IOException iOException) {
    
    } finally {
      Exception exception;
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Error copying resource contents to temp file: ");
    stringBuilder.append(iOException.getMessage());
    Log.e("TypefaceCompatUtil", stringBuilder.toString());
    closeQuietly(fileOutputStream);
    return false;
  }
  
  @Nullable
  public static File getTempFile(Context paramContext) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(".font");
    stringBuilder.append(Process.myPid());
    stringBuilder.append("-");
    stringBuilder.append(Process.myTid());
    stringBuilder.append("-");
    String str = stringBuilder.toString();
    for (byte b = 0; b < 100; b++) {
      File file1 = paramContext.getCacheDir();
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(str);
      stringBuilder1.append(b);
      File file2 = new File(file1, stringBuilder1.toString());
      boolean bool = file2.createNewFile();
      if (bool)
        return file2; 
    } 
    return null;
  }
  
  @Nullable
  @RequiresApi(19)
  public static ByteBuffer mmap(Context paramContext, CancellationSignal paramCancellationSignal, Uri paramUri) {
    ContentResolver contentResolver = paramContext.getContentResolver();
    try {
      Throwable throwable;
      Exception exception;
      ParcelFileDescriptor parcelFileDescriptor = contentResolver.openFileDescriptor(paramUri, "r", paramCancellationSignal);
      if (parcelFileDescriptor == null) {
        if (parcelFileDescriptor != null)
          parcelFileDescriptor.close(); 
        return null;
      } 
      try {
        Throwable throwable1;
        Exception exception1;
        FileInputStream fileInputStream = new FileInputStream(parcelFileDescriptor.getFileDescriptor());
        try {
          FileChannel fileChannel = fileInputStream.getChannel();
          long l = fileChannel.size();
          return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0L, l);
        } catch (Throwable throwable2) {
          try {
            throw throwable2;
          } finally {
            Exception exception2 = null;
            throwable1 = throwable2;
          } 
        } finally {
          exception1 = null;
        } 
        if (throwable1 != null) {
          try {
            fileInputStream.close();
          } catch (Throwable throwable2) {
            throwable1.addSuppressed(throwable2);
          } 
        } else {
          fileInputStream.close();
        } 
        throw exception1;
      } catch (Throwable throwable1) {
        try {
          throw throwable1;
        } finally {
          Exception exception1 = null;
          throwable = throwable1;
        } 
      } finally {
        exception = null;
      } 
      if (parcelFileDescriptor != null)
        if (throwable != null) {
          try {
            parcelFileDescriptor.close();
          } catch (Throwable throwable1) {
            throwable.addSuppressed(throwable1);
          } 
        } else {
          parcelFileDescriptor.close();
        }  
      throw exception;
    } catch (IOException iOException) {
      return null;
    } 
  }
  
  @Nullable
  @RequiresApi(19)
  private static ByteBuffer mmap(File paramFile) {
    try {
      Throwable throwable;
      Exception exception;
      FileInputStream fileInputStream = new FileInputStream(paramFile);
      try {
        FileChannel fileChannel = fileInputStream.getChannel();
        long l = fileChannel.size();
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, 0L, l);
      } catch (Throwable throwable1) {
        try {
          throw throwable1;
        } finally {
          Exception exception1 = null;
          throwable = throwable1;
        } 
      } finally {
        exception = null;
      } 
      if (throwable != null) {
        try {
          fileInputStream.close();
        } catch (Throwable throwable1) {
          throwable.addSuppressed(throwable1);
        } 
      } else {
        fileInputStream.close();
      } 
      throw exception;
    } catch (IOException iOException) {
      return null;
    } 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\graphics\TypefaceCompatUtil.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */