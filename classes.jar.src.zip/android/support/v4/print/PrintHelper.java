package android.support.v4.print;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.ColorFilter;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PageRange;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PrintManager;
import android.support.annotation.RequiresApi;
import android.util.Log;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

public final class PrintHelper {
  public static final int COLOR_MODE_COLOR = 2;
  
  public static final int COLOR_MODE_MONOCHROME = 1;
  
  public static final int ORIENTATION_LANDSCAPE = 1;
  
  public static final int ORIENTATION_PORTRAIT = 2;
  
  public static final int SCALE_MODE_FILL = 2;
  
  public static final int SCALE_MODE_FIT = 1;
  
  private final PrintHelperVersionImpl mImpl;
  
  public PrintHelper(Context paramContext) {
    if (Build.VERSION.SDK_INT >= 24) {
      this.mImpl = new PrintHelperApi24(paramContext);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 23) {
      this.mImpl = new PrintHelperApi23(paramContext);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 20) {
      this.mImpl = new PrintHelperApi20(paramContext);
      return;
    } 
    if (Build.VERSION.SDK_INT >= 19) {
      this.mImpl = new PrintHelperApi19(paramContext);
      return;
    } 
    this.mImpl = new PrintHelperStub();
  }
  
  public static boolean systemSupportsPrint() {
    return (Build.VERSION.SDK_INT >= 19);
  }
  
  public int getColorMode() {
    return this.mImpl.getColorMode();
  }
  
  public int getOrientation() {
    return this.mImpl.getOrientation();
  }
  
  public int getScaleMode() {
    return this.mImpl.getScaleMode();
  }
  
  public void printBitmap(String paramString, Bitmap paramBitmap) {
    this.mImpl.printBitmap(paramString, paramBitmap, (OnPrintFinishCallback)null);
  }
  
  public void printBitmap(String paramString, Bitmap paramBitmap, OnPrintFinishCallback paramOnPrintFinishCallback) {
    this.mImpl.printBitmap(paramString, paramBitmap, paramOnPrintFinishCallback);
  }
  
  public void printBitmap(String paramString, Uri paramUri) {
    this.mImpl.printBitmap(paramString, paramUri, (OnPrintFinishCallback)null);
  }
  
  public void printBitmap(String paramString, Uri paramUri, OnPrintFinishCallback paramOnPrintFinishCallback) {
    this.mImpl.printBitmap(paramString, paramUri, paramOnPrintFinishCallback);
  }
  
  public void setColorMode(int paramInt) {
    this.mImpl.setColorMode(paramInt);
  }
  
  public void setOrientation(int paramInt) {
    this.mImpl.setOrientation(paramInt);
  }
  
  public void setScaleMode(int paramInt) {
    this.mImpl.setScaleMode(paramInt);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface ColorMode {}
  
  public static interface OnPrintFinishCallback {
    void onFinish();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface Orientation {}
  
  @RequiresApi(19)
  private static class PrintHelperApi19 implements PrintHelperVersionImpl {
    private static final String LOG_TAG = "PrintHelperApi19";
    
    private static final int MAX_PRINT_SIZE = 3500;
    
    final Context a;
    
    BitmapFactory.Options b = null;
    
    protected boolean c = true;
    
    protected boolean d = true;
    
    int e = 2;
    
    int f = 2;
    
    int g;
    
    private final Object mLock = new Object();
    
    PrintHelperApi19(Context param1Context) {
      this.a = param1Context;
    }
    
    private Bitmap convertBitmapForColorMode(Bitmap param1Bitmap, int param1Int) {
      if (param1Int != 1)
        return param1Bitmap; 
      Bitmap bitmap = Bitmap.createBitmap(param1Bitmap.getWidth(), param1Bitmap.getHeight(), Bitmap.Config.ARGB_8888);
      Canvas canvas = new Canvas(bitmap);
      Paint paint = new Paint();
      ColorMatrix colorMatrix = new ColorMatrix();
      colorMatrix.setSaturation(0.0F);
      paint.setColorFilter((ColorFilter)new ColorMatrixColorFilter(colorMatrix));
      canvas.drawBitmap(param1Bitmap, 0.0F, 0.0F, paint);
      canvas.setBitmap(null);
      return bitmap;
    }
    
    private Matrix getMatrix(int param1Int1, int param1Int2, RectF param1RectF, int param1Int3) {
      float f4;
      Matrix matrix = new Matrix();
      float f1 = param1RectF.width();
      float f2 = param1Int1;
      float f3 = f1 / f2;
      if (param1Int3 == 2) {
        f4 = Math.max(f3, param1RectF.height() / param1Int2);
      } else {
        f4 = Math.min(f3, param1RectF.height() / param1Int2);
      } 
      matrix.postScale(f4, f4);
      matrix.postTranslate((param1RectF.width() - f2 * f4) / 2.0F, (param1RectF.height() - f4 * param1Int2) / 2.0F);
      return matrix;
    }
    
    private static boolean isPortrait(Bitmap param1Bitmap) {
      return (param1Bitmap.getWidth() <= param1Bitmap.getHeight());
    }
    
    private Bitmap loadBitmap(Uri param1Uri, BitmapFactory.Options param1Options) {
      if (param1Uri != null && this.a != null) {
        Exception exception;
        InputStream inputStream = null;
        try {
          InputStream inputStream1 = this.a.getContentResolver().openInputStream(param1Uri);
          try {
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream1, null, param1Options);
            return bitmap;
          } finally {
            exception = null;
          } 
        } finally {}
        if (inputStream != null)
          try {
            inputStream.close();
          } catch (IOException iOException) {
            Log.w("PrintHelperApi19", "close fail ", iOException);
          }  
        throw exception;
      } 
      throw new IllegalArgumentException("bad argument to loadBitmap");
    }
    
    private Bitmap loadConstrainedBitmap(Uri param1Uri) {
      if (param1Uri != null && this.a != null) {
        BitmapFactory.Options options = new BitmapFactory.Options();
        options.inJustDecodeBounds = true;
        loadBitmap(param1Uri, options);
        int i = options.outWidth;
        int j = options.outHeight;
        if (i > 0) {
          if (j <= 0)
            return null; 
          int k = Math.max(i, j);
          int m;
          for (m = 1; k > 3500; m <<= 1)
            k >>>= 1; 
          if (m > 0) {
            if (Math.min(i, j) / m <= 0)
              return null; 
            synchronized (this.mLock) {
              this.b = new BitmapFactory.Options();
              this.b.inMutable = true;
              this.b.inSampleSize = m;
              BitmapFactory.Options options1 = this.b;
              try {
                Bitmap bitmap = loadBitmap(param1Uri, options1);
              } finally {
                Exception exception = null;
              } 
            } 
          } 
          return null;
        } 
        return null;
      } 
      throw new IllegalArgumentException("bad argument to getScaledBitmap");
    }
    
    private void writeBitmap(PrintAttributes param1PrintAttributes, int param1Int, Bitmap param1Bitmap, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
      PrintAttributes printAttributes;
      if (this.d) {
        printAttributes = param1PrintAttributes;
      } else {
        printAttributes = a(param1PrintAttributes).setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0)).build();
      } 
      AsyncTask<Void, Void, Throwable> asyncTask = new AsyncTask<Void, Void, Throwable>(this, param1CancellationSignal, printAttributes, param1Bitmap, param1PrintAttributes, param1Int, param1ParcelFileDescriptor, param1WriteResultCallback) {
          protected Throwable a(Void... param2VarArgs) {
            // Byte code:
            //   0: aload_0
            //   1: getfield a : Landroid/os/CancellationSignal;
            //   4: invokevirtual isCanceled : ()Z
            //   7: ifeq -> 12
            //   10: aconst_null
            //   11: areturn
            //   12: new android/print/pdf/PrintedPdfDocument
            //   15: dup
            //   16: aload_0
            //   17: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   20: getfield a : Landroid/content/Context;
            //   23: aload_0
            //   24: getfield b : Landroid/print/PrintAttributes;
            //   27: invokespecial <init> : (Landroid/content/Context;Landroid/print/PrintAttributes;)V
            //   30: astore_3
            //   31: aload_0
            //   32: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   35: aload_0
            //   36: getfield c : Landroid/graphics/Bitmap;
            //   39: aload_0
            //   40: getfield b : Landroid/print/PrintAttributes;
            //   43: invokevirtual getColorMode : ()I
            //   46: invokestatic a : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19;Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
            //   49: astore #4
            //   51: aload_0
            //   52: getfield a : Landroid/os/CancellationSignal;
            //   55: invokevirtual isCanceled : ()Z
            //   58: istore #5
            //   60: iload #5
            //   62: ifeq -> 67
            //   65: aconst_null
            //   66: areturn
            //   67: aload_3
            //   68: iconst_1
            //   69: invokevirtual startPage : (I)Landroid/graphics/pdf/PdfDocument$Page;
            //   72: astore #9
            //   74: aload_0
            //   75: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   78: getfield d : Z
            //   81: ifeq -> 104
            //   84: new android/graphics/RectF
            //   87: dup
            //   88: aload #9
            //   90: invokevirtual getInfo : ()Landroid/graphics/pdf/PdfDocument$PageInfo;
            //   93: invokevirtual getContentRect : ()Landroid/graphics/Rect;
            //   96: invokespecial <init> : (Landroid/graphics/Rect;)V
            //   99: astore #10
            //   101: goto -> 165
            //   104: new android/print/pdf/PrintedPdfDocument
            //   107: dup
            //   108: aload_0
            //   109: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   112: getfield a : Landroid/content/Context;
            //   115: aload_0
            //   116: getfield d : Landroid/print/PrintAttributes;
            //   119: invokespecial <init> : (Landroid/content/Context;Landroid/print/PrintAttributes;)V
            //   122: astore #19
            //   124: aload #19
            //   126: iconst_1
            //   127: invokevirtual startPage : (I)Landroid/graphics/pdf/PdfDocument$Page;
            //   130: astore #20
            //   132: new android/graphics/RectF
            //   135: dup
            //   136: aload #20
            //   138: invokevirtual getInfo : ()Landroid/graphics/pdf/PdfDocument$PageInfo;
            //   141: invokevirtual getContentRect : ()Landroid/graphics/Rect;
            //   144: invokespecial <init> : (Landroid/graphics/Rect;)V
            //   147: astore #21
            //   149: aload #19
            //   151: aload #20
            //   153: invokevirtual finishPage : (Landroid/graphics/pdf/PdfDocument$Page;)V
            //   156: aload #19
            //   158: invokevirtual close : ()V
            //   161: aload #21
            //   163: astore #10
            //   165: aload_0
            //   166: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   169: aload #4
            //   171: invokevirtual getWidth : ()I
            //   174: aload #4
            //   176: invokevirtual getHeight : ()I
            //   179: aload #10
            //   181: aload_0
            //   182: getfield e : I
            //   185: invokestatic a : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19;IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
            //   188: astore #11
            //   190: aload_0
            //   191: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
            //   194: getfield d : Z
            //   197: ifeq -> 203
            //   200: goto -> 230
            //   203: aload #11
            //   205: aload #10
            //   207: getfield left : F
            //   210: aload #10
            //   212: getfield top : F
            //   215: invokevirtual postTranslate : (FF)Z
            //   218: pop
            //   219: aload #9
            //   221: invokevirtual getCanvas : ()Landroid/graphics/Canvas;
            //   224: aload #10
            //   226: invokevirtual clipRect : (Landroid/graphics/RectF;)Z
            //   229: pop
            //   230: aload #9
            //   232: invokevirtual getCanvas : ()Landroid/graphics/Canvas;
            //   235: aload #4
            //   237: aload #11
            //   239: aconst_null
            //   240: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
            //   243: aload_3
            //   244: aload #9
            //   246: invokevirtual finishPage : (Landroid/graphics/pdf/PdfDocument$Page;)V
            //   249: aload_0
            //   250: getfield a : Landroid/os/CancellationSignal;
            //   253: invokevirtual isCanceled : ()Z
            //   256: istore #12
            //   258: iload #12
            //   260: ifeq -> 305
            //   263: aload_3
            //   264: invokevirtual close : ()V
            //   267: aload_0
            //   268: getfield f : Landroid/os/ParcelFileDescriptor;
            //   271: astore #15
            //   273: aload #15
            //   275: ifnull -> 288
            //   278: aload_0
            //   279: getfield f : Landroid/os/ParcelFileDescriptor;
            //   282: invokevirtual close : ()V
            //   285: goto -> 289
            //   288: pop
            //   289: aload #4
            //   291: aload_0
            //   292: getfield c : Landroid/graphics/Bitmap;
            //   295: if_acmpeq -> 303
            //   298: aload #4
            //   300: invokevirtual recycle : ()V
            //   303: aconst_null
            //   304: areturn
            //   305: aload_3
            //   306: new java/io/FileOutputStream
            //   309: dup
            //   310: aload_0
            //   311: getfield f : Landroid/os/ParcelFileDescriptor;
            //   314: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
            //   317: invokespecial <init> : (Ljava/io/FileDescriptor;)V
            //   320: invokevirtual writeTo : (Ljava/io/OutputStream;)V
            //   323: aload_3
            //   324: invokevirtual close : ()V
            //   327: aload_0
            //   328: getfield f : Landroid/os/ParcelFileDescriptor;
            //   331: astore #13
            //   333: aload #13
            //   335: ifnull -> 348
            //   338: aload_0
            //   339: getfield f : Landroid/os/ParcelFileDescriptor;
            //   342: invokevirtual close : ()V
            //   345: goto -> 349
            //   348: pop
            //   349: aload #4
            //   351: aload_0
            //   352: getfield c : Landroid/graphics/Bitmap;
            //   355: if_acmpeq -> 413
            //   358: aload #4
            //   360: invokevirtual recycle : ()V
            //   363: aconst_null
            //   364: areturn
            //   365: astore #6
            //   367: aload_3
            //   368: invokevirtual close : ()V
            //   371: aload_0
            //   372: getfield f : Landroid/os/ParcelFileDescriptor;
            //   375: astore #7
            //   377: aload #7
            //   379: ifnull -> 392
            //   382: aload_0
            //   383: getfield f : Landroid/os/ParcelFileDescriptor;
            //   386: invokevirtual close : ()V
            //   389: goto -> 393
            //   392: pop
            //   393: aload #4
            //   395: aload_0
            //   396: getfield c : Landroid/graphics/Bitmap;
            //   399: if_acmpeq -> 407
            //   402: aload #4
            //   404: invokevirtual recycle : ()V
            //   407: aload #6
            //   409: athrow
            //   410: astore_2
            //   411: aload_2
            //   412: areturn
            //   413: aconst_null
            //   414: areturn
            // Exception table:
            //   from	to	target	type
            //   0	10	410	java/lang/Throwable
            //   12	60	410	java/lang/Throwable
            //   67	101	365	finally
            //   104	161	365	finally
            //   165	200	365	finally
            //   203	230	365	finally
            //   230	258	365	finally
            //   263	273	410	java/lang/Throwable
            //   278	285	288	java/io/IOException
            //   278	285	410	java/lang/Throwable
            //   288	289	410	java/lang/Throwable
            //   289	303	410	java/lang/Throwable
            //   305	323	365	finally
            //   323	333	410	java/lang/Throwable
            //   338	345	348	java/io/IOException
            //   338	345	410	java/lang/Throwable
            //   348	349	410	java/lang/Throwable
            //   349	363	410	java/lang/Throwable
            //   367	377	410	java/lang/Throwable
            //   382	389	392	java/io/IOException
            //   382	389	410	java/lang/Throwable
            //   392	393	410	java/lang/Throwable
            //   393	407	410	java/lang/Throwable
            //   407	410	410	java/lang/Throwable
          }
          
          protected void a(Throwable param2Throwable) {
            if (this.a.isCanceled()) {
              this.g.onWriteCancelled();
              return;
            } 
            if (param2Throwable == null) {
              PrintDocumentAdapter.WriteResultCallback writeResultCallback = this.g;
              PageRange[] arrayOfPageRange = new PageRange[1];
              arrayOfPageRange[0] = PageRange.ALL_PAGES;
              writeResultCallback.onWriteFinished(arrayOfPageRange);
              return;
            } 
            Log.e("PrintHelperApi19", "Error writing printed content", param2Throwable);
            this.g.onWriteFailed(null);
          }
        };
      asyncTask.execute((Object[])new Void[0]);
    }
    
    protected PrintAttributes.Builder a(PrintAttributes param1PrintAttributes) {
      PrintAttributes.Builder builder = (new PrintAttributes.Builder()).setMediaSize(param1PrintAttributes.getMediaSize()).setResolution(param1PrintAttributes.getResolution()).setMinMargins(param1PrintAttributes.getMinMargins());
      if (param1PrintAttributes.getColorMode() != 0)
        builder.setColorMode(param1PrintAttributes.getColorMode()); 
      return builder;
    }
    
    public int getColorMode() {
      return this.f;
    }
    
    public int getOrientation() {
      return (this.g == 0) ? 1 : this.g;
    }
    
    public int getScaleMode() {
      return this.e;
    }
    
    public void printBitmap(String param1String, Bitmap param1Bitmap, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback) {
      PrintAttributes.MediaSize mediaSize;
      if (param1Bitmap == null)
        return; 
      int i = this.e;
      PrintManager printManager = (PrintManager)this.a.getSystemService("print");
      if (isPortrait(param1Bitmap)) {
        mediaSize = PrintAttributes.MediaSize.UNKNOWN_PORTRAIT;
      } else {
        mediaSize = PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE;
      } 
      PrintAttributes printAttributes = (new PrintAttributes.Builder()).setMediaSize(mediaSize).setColorMode(this.f).build();
      PrintDocumentAdapter printDocumentAdapter = new PrintDocumentAdapter(this, param1String, i, param1Bitmap, param1OnPrintFinishCallback) {
          private PrintAttributes mAttributes;
          
          public void onFinish() {
            if (this.d != null)
              this.d.onFinish(); 
          }
          
          public void onLayout(PrintAttributes param2PrintAttributes1, PrintAttributes param2PrintAttributes2, CancellationSignal param2CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param2LayoutResultCallback, Bundle param2Bundle) {
            this.mAttributes = param2PrintAttributes2;
            param2LayoutResultCallback.onLayoutFinished((new PrintDocumentInfo.Builder(this.a)).setContentType(1).setPageCount(1).build(), true ^ param2PrintAttributes2.equals(param2PrintAttributes1));
          }
          
          public void onWrite(PageRange[] param2ArrayOfPageRange, ParcelFileDescriptor param2ParcelFileDescriptor, CancellationSignal param2CancellationSignal, PrintDocumentAdapter.WriteResultCallback param2WriteResultCallback) {
            PrintHelper.PrintHelperApi19.a(this.e, this.mAttributes, this.b, this.c, param2ParcelFileDescriptor, param2CancellationSignal, param2WriteResultCallback);
          }
        };
      printManager.print(param1String, printDocumentAdapter, printAttributes);
    }
    
    public void printBitmap(String param1String, Uri param1Uri, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback) {
      int i = this.e;
      PrintDocumentAdapter printDocumentAdapter = new PrintDocumentAdapter(this, param1String, param1Uri, param1OnPrintFinishCallback, i) {
          AsyncTask<Uri, Boolean, Bitmap> a;
          
          Bitmap b = null;
          
          private PrintAttributes mAttributes;
          
          private void cancelLoad() {
            synchronized (PrintHelper.PrintHelperApi19.a(this.g)) {
              if (this.g.b != null) {
                this.g.b.requestCancelDecode();
                this.g.b = null;
              } 
              return;
            } 
          }
          
          public void onFinish() {
            super.onFinish();
            cancelLoad();
            if (this.a != null)
              this.a.cancel(true); 
            if (this.e != null)
              this.e.onFinish(); 
            if (this.b != null) {
              this.b.recycle();
              this.b = null;
            } 
          }
          
          public void onLayout(PrintAttributes param2PrintAttributes1, PrintAttributes param2PrintAttributes2, CancellationSignal param2CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param2LayoutResultCallback, Bundle param2Bundle) {
            // Byte code:
            //   0: aload_0
            //   1: monitorenter
            //   2: aload_0
            //   3: aload_2
            //   4: putfield mAttributes : Landroid/print/PrintAttributes;
            //   7: aload_0
            //   8: monitorexit
            //   9: aload_3
            //   10: invokevirtual isCanceled : ()Z
            //   13: ifeq -> 22
            //   16: aload #4
            //   18: invokevirtual onLayoutCancelled : ()V
            //   21: return
            //   22: aload_0
            //   23: getfield b : Landroid/graphics/Bitmap;
            //   26: ifnull -> 64
            //   29: aload #4
            //   31: new android/print/PrintDocumentInfo$Builder
            //   34: dup
            //   35: aload_0
            //   36: getfield c : Ljava/lang/String;
            //   39: invokespecial <init> : (Ljava/lang/String;)V
            //   42: iconst_1
            //   43: invokevirtual setContentType : (I)Landroid/print/PrintDocumentInfo$Builder;
            //   46: iconst_1
            //   47: invokevirtual setPageCount : (I)Landroid/print/PrintDocumentInfo$Builder;
            //   50: invokevirtual build : ()Landroid/print/PrintDocumentInfo;
            //   53: iconst_1
            //   54: aload_2
            //   55: aload_1
            //   56: invokevirtual equals : (Ljava/lang/Object;)Z
            //   59: ixor
            //   60: invokevirtual onLayoutFinished : (Landroid/print/PrintDocumentInfo;Z)V
            //   63: return
            //   64: new android/support/v4/print/PrintHelper$PrintHelperApi19$3$1
            //   67: dup
            //   68: aload_0
            //   69: aload_3
            //   70: aload_2
            //   71: aload_1
            //   72: aload #4
            //   74: invokespecial <init> : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;Landroid/os/CancellationSignal;Landroid/print/PrintAttributes;Landroid/print/PrintAttributes;Landroid/print/PrintDocumentAdapter$LayoutResultCallback;)V
            //   77: astore #7
            //   79: aload_0
            //   80: aload #7
            //   82: iconst_0
            //   83: anewarray android/net/Uri
            //   86: invokevirtual execute : ([Ljava/lang/Object;)Landroid/os/AsyncTask;
            //   89: putfield a : Landroid/os/AsyncTask;
            //   92: return
            //   93: astore #6
            //   95: aload_0
            //   96: monitorexit
            //   97: aload #6
            //   99: athrow
            // Exception table:
            //   from	to	target	type
            //   2	9	93	finally
            //   95	97	93	finally
          }
          
          public void onWrite(PageRange[] param2ArrayOfPageRange, ParcelFileDescriptor param2ParcelFileDescriptor, CancellationSignal param2CancellationSignal, PrintDocumentAdapter.WriteResultCallback param2WriteResultCallback) {
            PrintHelper.PrintHelperApi19.a(this.g, this.mAttributes, this.f, this.b, param2ParcelFileDescriptor, param2CancellationSignal, param2WriteResultCallback);
          }
        };
      PrintManager printManager = (PrintManager)this.a.getSystemService("print");
      PrintAttributes.Builder builder = new PrintAttributes.Builder();
      builder.setColorMode(this.f);
      if (this.g == 1 || this.g == 0) {
        builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_LANDSCAPE);
      } else if (this.g == 2) {
        builder.setMediaSize(PrintAttributes.MediaSize.UNKNOWN_PORTRAIT);
      } 
      printManager.print(param1String, printDocumentAdapter, builder.build());
    }
    
    public void setColorMode(int param1Int) {
      this.f = param1Int;
    }
    
    public void setOrientation(int param1Int) {
      this.g = param1Int;
    }
    
    public void setScaleMode(int param1Int) {
      this.e = param1Int;
    }
  }
  
  class null extends PrintDocumentAdapter {
    private PrintAttributes mAttributes;
    
    null(PrintHelper this$0, String param1String, int param1Int, Bitmap param1Bitmap, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback) {}
    
    public void onFinish() {
      if (this.d != null)
        this.d.onFinish(); 
    }
    
    public void onLayout(PrintAttributes param1PrintAttributes1, PrintAttributes param1PrintAttributes2, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param1LayoutResultCallback, Bundle param1Bundle) {
      this.mAttributes = param1PrintAttributes2;
      param1LayoutResultCallback.onLayoutFinished((new PrintDocumentInfo.Builder(this.a)).setContentType(1).setPageCount(1).build(), true ^ param1PrintAttributes2.equals(param1PrintAttributes1));
    }
    
    public void onWrite(PageRange[] param1ArrayOfPageRange, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
      PrintHelper.PrintHelperApi19.a(this.e, this.mAttributes, this.b, this.c, param1ParcelFileDescriptor, param1CancellationSignal, param1WriteResultCallback);
    }
  }
  
  class null extends AsyncTask<Void, Void, Throwable> {
    null(PrintHelper this$0, CancellationSignal param1CancellationSignal, PrintAttributes param1PrintAttributes1, Bitmap param1Bitmap, PrintAttributes param1PrintAttributes2, int param1Int, ParcelFileDescriptor param1ParcelFileDescriptor, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {}
    
    protected Throwable a(Void... param1VarArgs) {
      // Byte code:
      //   0: aload_0
      //   1: getfield a : Landroid/os/CancellationSignal;
      //   4: invokevirtual isCanceled : ()Z
      //   7: ifeq -> 12
      //   10: aconst_null
      //   11: areturn
      //   12: new android/print/pdf/PrintedPdfDocument
      //   15: dup
      //   16: aload_0
      //   17: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   20: getfield a : Landroid/content/Context;
      //   23: aload_0
      //   24: getfield b : Landroid/print/PrintAttributes;
      //   27: invokespecial <init> : (Landroid/content/Context;Landroid/print/PrintAttributes;)V
      //   30: astore_3
      //   31: aload_0
      //   32: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   35: aload_0
      //   36: getfield c : Landroid/graphics/Bitmap;
      //   39: aload_0
      //   40: getfield b : Landroid/print/PrintAttributes;
      //   43: invokevirtual getColorMode : ()I
      //   46: invokestatic a : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19;Landroid/graphics/Bitmap;I)Landroid/graphics/Bitmap;
      //   49: astore #4
      //   51: aload_0
      //   52: getfield a : Landroid/os/CancellationSignal;
      //   55: invokevirtual isCanceled : ()Z
      //   58: istore #5
      //   60: iload #5
      //   62: ifeq -> 67
      //   65: aconst_null
      //   66: areturn
      //   67: aload_3
      //   68: iconst_1
      //   69: invokevirtual startPage : (I)Landroid/graphics/pdf/PdfDocument$Page;
      //   72: astore #9
      //   74: aload_0
      //   75: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   78: getfield d : Z
      //   81: ifeq -> 104
      //   84: new android/graphics/RectF
      //   87: dup
      //   88: aload #9
      //   90: invokevirtual getInfo : ()Landroid/graphics/pdf/PdfDocument$PageInfo;
      //   93: invokevirtual getContentRect : ()Landroid/graphics/Rect;
      //   96: invokespecial <init> : (Landroid/graphics/Rect;)V
      //   99: astore #10
      //   101: goto -> 165
      //   104: new android/print/pdf/PrintedPdfDocument
      //   107: dup
      //   108: aload_0
      //   109: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   112: getfield a : Landroid/content/Context;
      //   115: aload_0
      //   116: getfield d : Landroid/print/PrintAttributes;
      //   119: invokespecial <init> : (Landroid/content/Context;Landroid/print/PrintAttributes;)V
      //   122: astore #19
      //   124: aload #19
      //   126: iconst_1
      //   127: invokevirtual startPage : (I)Landroid/graphics/pdf/PdfDocument$Page;
      //   130: astore #20
      //   132: new android/graphics/RectF
      //   135: dup
      //   136: aload #20
      //   138: invokevirtual getInfo : ()Landroid/graphics/pdf/PdfDocument$PageInfo;
      //   141: invokevirtual getContentRect : ()Landroid/graphics/Rect;
      //   144: invokespecial <init> : (Landroid/graphics/Rect;)V
      //   147: astore #21
      //   149: aload #19
      //   151: aload #20
      //   153: invokevirtual finishPage : (Landroid/graphics/pdf/PdfDocument$Page;)V
      //   156: aload #19
      //   158: invokevirtual close : ()V
      //   161: aload #21
      //   163: astore #10
      //   165: aload_0
      //   166: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   169: aload #4
      //   171: invokevirtual getWidth : ()I
      //   174: aload #4
      //   176: invokevirtual getHeight : ()I
      //   179: aload #10
      //   181: aload_0
      //   182: getfield e : I
      //   185: invokestatic a : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19;IILandroid/graphics/RectF;I)Landroid/graphics/Matrix;
      //   188: astore #11
      //   190: aload_0
      //   191: getfield h : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   194: getfield d : Z
      //   197: ifeq -> 203
      //   200: goto -> 230
      //   203: aload #11
      //   205: aload #10
      //   207: getfield left : F
      //   210: aload #10
      //   212: getfield top : F
      //   215: invokevirtual postTranslate : (FF)Z
      //   218: pop
      //   219: aload #9
      //   221: invokevirtual getCanvas : ()Landroid/graphics/Canvas;
      //   224: aload #10
      //   226: invokevirtual clipRect : (Landroid/graphics/RectF;)Z
      //   229: pop
      //   230: aload #9
      //   232: invokevirtual getCanvas : ()Landroid/graphics/Canvas;
      //   235: aload #4
      //   237: aload #11
      //   239: aconst_null
      //   240: invokevirtual drawBitmap : (Landroid/graphics/Bitmap;Landroid/graphics/Matrix;Landroid/graphics/Paint;)V
      //   243: aload_3
      //   244: aload #9
      //   246: invokevirtual finishPage : (Landroid/graphics/pdf/PdfDocument$Page;)V
      //   249: aload_0
      //   250: getfield a : Landroid/os/CancellationSignal;
      //   253: invokevirtual isCanceled : ()Z
      //   256: istore #12
      //   258: iload #12
      //   260: ifeq -> 305
      //   263: aload_3
      //   264: invokevirtual close : ()V
      //   267: aload_0
      //   268: getfield f : Landroid/os/ParcelFileDescriptor;
      //   271: astore #15
      //   273: aload #15
      //   275: ifnull -> 288
      //   278: aload_0
      //   279: getfield f : Landroid/os/ParcelFileDescriptor;
      //   282: invokevirtual close : ()V
      //   285: goto -> 289
      //   288: pop
      //   289: aload #4
      //   291: aload_0
      //   292: getfield c : Landroid/graphics/Bitmap;
      //   295: if_acmpeq -> 303
      //   298: aload #4
      //   300: invokevirtual recycle : ()V
      //   303: aconst_null
      //   304: areturn
      //   305: aload_3
      //   306: new java/io/FileOutputStream
      //   309: dup
      //   310: aload_0
      //   311: getfield f : Landroid/os/ParcelFileDescriptor;
      //   314: invokevirtual getFileDescriptor : ()Ljava/io/FileDescriptor;
      //   317: invokespecial <init> : (Ljava/io/FileDescriptor;)V
      //   320: invokevirtual writeTo : (Ljava/io/OutputStream;)V
      //   323: aload_3
      //   324: invokevirtual close : ()V
      //   327: aload_0
      //   328: getfield f : Landroid/os/ParcelFileDescriptor;
      //   331: astore #13
      //   333: aload #13
      //   335: ifnull -> 348
      //   338: aload_0
      //   339: getfield f : Landroid/os/ParcelFileDescriptor;
      //   342: invokevirtual close : ()V
      //   345: goto -> 349
      //   348: pop
      //   349: aload #4
      //   351: aload_0
      //   352: getfield c : Landroid/graphics/Bitmap;
      //   355: if_acmpeq -> 413
      //   358: aload #4
      //   360: invokevirtual recycle : ()V
      //   363: aconst_null
      //   364: areturn
      //   365: astore #6
      //   367: aload_3
      //   368: invokevirtual close : ()V
      //   371: aload_0
      //   372: getfield f : Landroid/os/ParcelFileDescriptor;
      //   375: astore #7
      //   377: aload #7
      //   379: ifnull -> 392
      //   382: aload_0
      //   383: getfield f : Landroid/os/ParcelFileDescriptor;
      //   386: invokevirtual close : ()V
      //   389: goto -> 393
      //   392: pop
      //   393: aload #4
      //   395: aload_0
      //   396: getfield c : Landroid/graphics/Bitmap;
      //   399: if_acmpeq -> 407
      //   402: aload #4
      //   404: invokevirtual recycle : ()V
      //   407: aload #6
      //   409: athrow
      //   410: astore_2
      //   411: aload_2
      //   412: areturn
      //   413: aconst_null
      //   414: areturn
      // Exception table:
      //   from	to	target	type
      //   0	10	410	java/lang/Throwable
      //   12	60	410	java/lang/Throwable
      //   67	101	365	finally
      //   104	161	365	finally
      //   165	200	365	finally
      //   203	230	365	finally
      //   230	258	365	finally
      //   263	273	410	java/lang/Throwable
      //   278	285	288	java/io/IOException
      //   278	285	410	java/lang/Throwable
      //   288	289	410	java/lang/Throwable
      //   289	303	410	java/lang/Throwable
      //   305	323	365	finally
      //   323	333	410	java/lang/Throwable
      //   338	345	348	java/io/IOException
      //   338	345	410	java/lang/Throwable
      //   348	349	410	java/lang/Throwable
      //   349	363	410	java/lang/Throwable
      //   367	377	410	java/lang/Throwable
      //   382	389	392	java/io/IOException
      //   382	389	410	java/lang/Throwable
      //   392	393	410	java/lang/Throwable
      //   393	407	410	java/lang/Throwable
      //   407	410	410	java/lang/Throwable
    }
    
    protected void a(Throwable param1Throwable) {
      if (this.a.isCanceled()) {
        this.g.onWriteCancelled();
        return;
      } 
      if (param1Throwable == null) {
        PrintDocumentAdapter.WriteResultCallback writeResultCallback = this.g;
        PageRange[] arrayOfPageRange = new PageRange[1];
        arrayOfPageRange[0] = PageRange.ALL_PAGES;
        writeResultCallback.onWriteFinished(arrayOfPageRange);
        return;
      } 
      Log.e("PrintHelperApi19", "Error writing printed content", param1Throwable);
      this.g.onWriteFailed(null);
    }
  }
  
  class null extends PrintDocumentAdapter {
    AsyncTask<Uri, Boolean, Bitmap> a;
    
    Bitmap b = null;
    
    private PrintAttributes mAttributes;
    
    null(PrintHelper this$0, String param1String, Uri param1Uri, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback, int param1Int) {}
    
    private void cancelLoad() {
      synchronized (PrintHelper.PrintHelperApi19.a(this.g)) {
        if (this.g.b != null) {
          this.g.b.requestCancelDecode();
          this.g.b = null;
        } 
        return;
      } 
    }
    
    public void onFinish() {
      super.onFinish();
      cancelLoad();
      if (this.a != null)
        this.a.cancel(true); 
      if (this.e != null)
        this.e.onFinish(); 
      if (this.b != null) {
        this.b.recycle();
        this.b = null;
      } 
    }
    
    public void onLayout(PrintAttributes param1PrintAttributes1, PrintAttributes param1PrintAttributes2, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.LayoutResultCallback param1LayoutResultCallback, Bundle param1Bundle) {
      // Byte code:
      //   0: aload_0
      //   1: monitorenter
      //   2: aload_0
      //   3: aload_2
      //   4: putfield mAttributes : Landroid/print/PrintAttributes;
      //   7: aload_0
      //   8: monitorexit
      //   9: aload_3
      //   10: invokevirtual isCanceled : ()Z
      //   13: ifeq -> 22
      //   16: aload #4
      //   18: invokevirtual onLayoutCancelled : ()V
      //   21: return
      //   22: aload_0
      //   23: getfield b : Landroid/graphics/Bitmap;
      //   26: ifnull -> 64
      //   29: aload #4
      //   31: new android/print/PrintDocumentInfo$Builder
      //   34: dup
      //   35: aload_0
      //   36: getfield c : Ljava/lang/String;
      //   39: invokespecial <init> : (Ljava/lang/String;)V
      //   42: iconst_1
      //   43: invokevirtual setContentType : (I)Landroid/print/PrintDocumentInfo$Builder;
      //   46: iconst_1
      //   47: invokevirtual setPageCount : (I)Landroid/print/PrintDocumentInfo$Builder;
      //   50: invokevirtual build : ()Landroid/print/PrintDocumentInfo;
      //   53: iconst_1
      //   54: aload_2
      //   55: aload_1
      //   56: invokevirtual equals : (Ljava/lang/Object;)Z
      //   59: ixor
      //   60: invokevirtual onLayoutFinished : (Landroid/print/PrintDocumentInfo;Z)V
      //   63: return
      //   64: new android/support/v4/print/PrintHelper$PrintHelperApi19$3$1
      //   67: dup
      //   68: aload_0
      //   69: aload_3
      //   70: aload_2
      //   71: aload_1
      //   72: aload #4
      //   74: invokespecial <init> : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;Landroid/os/CancellationSignal;Landroid/print/PrintAttributes;Landroid/print/PrintAttributes;Landroid/print/PrintDocumentAdapter$LayoutResultCallback;)V
      //   77: astore #7
      //   79: aload_0
      //   80: aload #7
      //   82: iconst_0
      //   83: anewarray android/net/Uri
      //   86: invokevirtual execute : ([Ljava/lang/Object;)Landroid/os/AsyncTask;
      //   89: putfield a : Landroid/os/AsyncTask;
      //   92: return
      //   93: astore #6
      //   95: aload_0
      //   96: monitorexit
      //   97: aload #6
      //   99: athrow
      // Exception table:
      //   from	to	target	type
      //   2	9	93	finally
      //   95	97	93	finally
    }
    
    public void onWrite(PageRange[] param1ArrayOfPageRange, ParcelFileDescriptor param1ParcelFileDescriptor, CancellationSignal param1CancellationSignal, PrintDocumentAdapter.WriteResultCallback param1WriteResultCallback) {
      PrintHelper.PrintHelperApi19.a(this.g, this.mAttributes, this.f, this.b, param1ParcelFileDescriptor, param1CancellationSignal, param1WriteResultCallback);
    }
  }
  
  class null extends AsyncTask<Uri, Boolean, Bitmap> {
    protected Bitmap a(Uri... param1VarArgs) {
      try {
        return PrintHelper.PrintHelperApi19.a(this.e.g, this.e.d);
      } catch (FileNotFoundException fileNotFoundException) {
        return null;
      } 
    }
    
    protected void a(Bitmap param1Bitmap) {
      // Byte code:
      //   0: aload_0
      //   1: aload_1
      //   2: invokespecial onPostExecute : (Ljava/lang/Object;)V
      //   5: aload_1
      //   6: ifnull -> 121
      //   9: aload_0
      //   10: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   13: getfield g : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   16: getfield c : Z
      //   19: ifeq -> 35
      //   22: aload_0
      //   23: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   26: getfield g : Landroid/support/v4/print/PrintHelper$PrintHelperApi19;
      //   29: getfield g : I
      //   32: ifne -> 121
      //   35: aload_0
      //   36: monitorenter
      //   37: aload_0
      //   38: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   41: invokestatic b : (Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;)Landroid/print/PrintAttributes;
      //   44: invokevirtual getMediaSize : ()Landroid/print/PrintAttributes$MediaSize;
      //   47: astore #5
      //   49: aload_0
      //   50: monitorexit
      //   51: aload #5
      //   53: ifnull -> 121
      //   56: aload #5
      //   58: invokevirtual isPortrait : ()Z
      //   61: aload_1
      //   62: invokestatic a : (Landroid/graphics/Bitmap;)Z
      //   65: if_icmpeq -> 121
      //   68: new android/graphics/Matrix
      //   71: dup
      //   72: invokespecial <init> : ()V
      //   75: astore #6
      //   77: aload #6
      //   79: ldc 90.0
      //   81: invokevirtual postRotate : (F)Z
      //   84: pop
      //   85: aload_1
      //   86: invokevirtual getWidth : ()I
      //   89: istore #8
      //   91: aload_1
      //   92: invokevirtual getHeight : ()I
      //   95: istore #9
      //   97: aload_1
      //   98: iconst_0
      //   99: iconst_0
      //   100: iload #8
      //   102: iload #9
      //   104: aload #6
      //   106: iconst_1
      //   107: invokestatic createBitmap : (Landroid/graphics/Bitmap;IIIILandroid/graphics/Matrix;Z)Landroid/graphics/Bitmap;
      //   110: astore_1
      //   111: goto -> 121
      //   114: astore #4
      //   116: aload_0
      //   117: monitorexit
      //   118: aload #4
      //   120: athrow
      //   121: aload_0
      //   122: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   125: aload_1
      //   126: putfield b : Landroid/graphics/Bitmap;
      //   129: aload_1
      //   130: ifnull -> 185
      //   133: new android/print/PrintDocumentInfo$Builder
      //   136: dup
      //   137: aload_0
      //   138: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   141: getfield c : Ljava/lang/String;
      //   144: invokespecial <init> : (Ljava/lang/String;)V
      //   147: iconst_1
      //   148: invokevirtual setContentType : (I)Landroid/print/PrintDocumentInfo$Builder;
      //   151: iconst_1
      //   152: invokevirtual setPageCount : (I)Landroid/print/PrintDocumentInfo$Builder;
      //   155: invokevirtual build : ()Landroid/print/PrintDocumentInfo;
      //   158: astore_2
      //   159: iconst_1
      //   160: aload_0
      //   161: getfield b : Landroid/print/PrintAttributes;
      //   164: aload_0
      //   165: getfield c : Landroid/print/PrintAttributes;
      //   168: invokevirtual equals : (Ljava/lang/Object;)Z
      //   171: ixor
      //   172: istore_3
      //   173: aload_0
      //   174: getfield d : Landroid/print/PrintDocumentAdapter$LayoutResultCallback;
      //   177: aload_2
      //   178: iload_3
      //   179: invokevirtual onLayoutFinished : (Landroid/print/PrintDocumentInfo;Z)V
      //   182: goto -> 193
      //   185: aload_0
      //   186: getfield d : Landroid/print/PrintDocumentAdapter$LayoutResultCallback;
      //   189: aconst_null
      //   190: invokevirtual onLayoutFailed : (Ljava/lang/CharSequence;)V
      //   193: aload_0
      //   194: getfield e : Landroid/support/v4/print/PrintHelper$PrintHelperApi19$3;
      //   197: aconst_null
      //   198: putfield a : Landroid/os/AsyncTask;
      //   201: return
      // Exception table:
      //   from	to	target	type
      //   37	51	114	finally
      //   116	118	114	finally
    }
    
    protected void b(Bitmap param1Bitmap) {
      this.d.onLayoutCancelled();
      this.e.a = null;
    }
    
    protected void onPreExecute() {
      this.a.setOnCancelListener(new CancellationSignal.OnCancelListener(this) {
            public void onCancel() {
              PrintHelper.PrintHelperApi19.null.a(this.a.e);
              this.a.cancel(false);
            }
          });
    }
  }
  
  class null implements CancellationSignal.OnCancelListener {
    public void onCancel() {
      PrintHelper.PrintHelperApi19.null.a(this.a.e);
      this.a.cancel(false);
    }
  }
  
  @RequiresApi(20)
  private static class PrintHelperApi20 extends PrintHelperApi19 {
    PrintHelperApi20(Context param1Context) {
      super(param1Context);
    }
  }
  
  @RequiresApi(23)
  private static class PrintHelperApi23 extends PrintHelperApi20 {
    PrintHelperApi23(Context param1Context) {
      super(param1Context);
    }
    
    protected PrintAttributes.Builder a(PrintAttributes param1PrintAttributes) {
      PrintAttributes.Builder builder = super.a(param1PrintAttributes);
      if (param1PrintAttributes.getDuplexMode() != 0)
        builder.setDuplexMode(param1PrintAttributes.getDuplexMode()); 
      return builder;
    }
  }
  
  @RequiresApi(24)
  private static class PrintHelperApi24 extends PrintHelperApi23 {
    PrintHelperApi24(Context param1Context) {
      super(param1Context);
    }
  }
  
  private static final class PrintHelperStub implements PrintHelperVersionImpl {
    int a = 2;
    
    int b = 2;
    
    int c = 1;
    
    private PrintHelperStub() {}
    
    public int getColorMode() {
      return this.b;
    }
    
    public int getOrientation() {
      return this.c;
    }
    
    public int getScaleMode() {
      return this.a;
    }
    
    public void printBitmap(String param1String, Bitmap param1Bitmap, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback) {}
    
    public void printBitmap(String param1String, Uri param1Uri, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback) {}
    
    public void setColorMode(int param1Int) {
      this.b = param1Int;
    }
    
    public void setOrientation(int param1Int) {
      this.c = param1Int;
    }
    
    public void setScaleMode(int param1Int) {
      this.a = param1Int;
    }
  }
  
  static interface PrintHelperVersionImpl {
    int getColorMode();
    
    int getOrientation();
    
    int getScaleMode();
    
    void printBitmap(String param1String, Bitmap param1Bitmap, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback);
    
    void printBitmap(String param1String, Uri param1Uri, PrintHelper.OnPrintFinishCallback param1OnPrintFinishCallback);
    
    void setColorMode(int param1Int);
    
    void setOrientation(int param1Int);
    
    void setScaleMode(int param1Int);
  }
  
  @Retention(RetentionPolicy.SOURCE)
  private static @interface ScaleMode {}
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\v4\print\PrintHelper.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */