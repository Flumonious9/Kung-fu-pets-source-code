package android.support.design.widget;

import android.content.Context;
import android.content.res.Resources;
import android.content.res.TypedArray;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Region;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Parcel;
import android.os.Parcelable;
import android.os.SystemClock;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.FloatRange;
import android.support.annotation.IdRes;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.support.annotation.VisibleForTesting;
import android.support.coreui.R;
import android.support.v4.content.ContextCompat;
import android.support.v4.graphics.drawable.DrawableCompat;
import android.support.v4.math.MathUtils;
import android.support.v4.util.ObjectsCompat;
import android.support.v4.util.Pools;
import android.support.v4.view.AbsSavedState;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.NestedScrollingParent2;
import android.support.v4.view.NestedScrollingParentHelper;
import android.support.v4.view.OnApplyWindowInsetsListener;
import android.support.v4.view.ViewCompat;
import android.support.v4.view.WindowInsetsCompat;
import android.support.v4.widget.DirectedAcyclicGraph;
import android.support.v4.widget.ViewGroupUtils;
import android.text.TextUtils;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.ViewTreeObserver;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CoordinatorLayout extends ViewGroup implements NestedScrollingParent2 {
  private static final int TYPE_ON_INTERCEPT = 0;
  
  private static final int TYPE_ON_TOUCH = 1;
  
  static final String a;
  
  static final Class<?>[] b = new Class[] { Context.class, AttributeSet.class };
  
  static final ThreadLocal<Map<String, Constructor<Behavior>>> c = new ThreadLocal<Map<String, Constructor<Behavior>>>();
  
  static final Comparator<View> d;
  
  private static final Pools.Pool<Rect> sRectPool = (Pools.Pool<Rect>)new Pools.SynchronizedPool(12);
  
  ViewGroup.OnHierarchyChangeListener e;
  
  private OnApplyWindowInsetsListener mApplyWindowInsetsListener;
  
  private View mBehaviorTouchView;
  
  private final DirectedAcyclicGraph<View> mChildDag;
  
  private final List<View> mDependencySortedChildren;
  
  private boolean mDisallowInterceptReset;
  
  private boolean mDrawStatusBarBackground;
  
  private boolean mIsAttachedToWindow;
  
  private int[] mKeylines;
  
  private WindowInsetsCompat mLastInsets;
  
  private boolean mNeedsPreDrawListener;
  
  private final NestedScrollingParentHelper mNestedScrollingParentHelper;
  
  private View mNestedScrollingTarget;
  
  private OnPreDrawListener mOnPreDrawListener;
  
  private Paint mScrimPaint;
  
  private Drawable mStatusBarBackground;
  
  private final List<View> mTempDependenciesList;
  
  private final int[] mTempIntPair;
  
  private final List<View> mTempList1;
  
  public CoordinatorLayout(Context paramContext) {
    this(paramContext, (AttributeSet)null);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet) {
    this(paramContext, paramAttributeSet, R.attr.coordinatorLayoutStyle);
  }
  
  public CoordinatorLayout(Context paramContext, AttributeSet paramAttributeSet, int paramInt) {
    super(paramContext, paramAttributeSet, paramInt);
    TypedArray typedArray;
    this.mDependencySortedChildren = new ArrayList<View>();
    this.mChildDag = new DirectedAcyclicGraph();
    this.mTempList1 = new ArrayList<View>();
    this.mTempDependenciesList = new ArrayList<View>();
    this.mTempIntPair = new int[2];
    this.mNestedScrollingParentHelper = new NestedScrollingParentHelper(this);
    byte b = 0;
    if (paramInt == 0) {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.CoordinatorLayout, 0, R.style.Widget_Support_CoordinatorLayout);
    } else {
      typedArray = paramContext.obtainStyledAttributes(paramAttributeSet, R.styleable.CoordinatorLayout, paramInt, 0);
    } 
    int i = typedArray.getResourceId(R.styleable.CoordinatorLayout_keylines, 0);
    if (i != 0) {
      Resources resources = paramContext.getResources();
      this.mKeylines = resources.getIntArray(i);
      float f = (resources.getDisplayMetrics()).density;
      int j = this.mKeylines.length;
      while (b < j) {
        this.mKeylines[b] = (int)(f * this.mKeylines[b]);
        b++;
      } 
    } 
    this.mStatusBarBackground = typedArray.getDrawable(R.styleable.CoordinatorLayout_statusBarBackground);
    typedArray.recycle();
    setupForInsets();
    super.setOnHierarchyChangeListener(new HierarchyChangeListener(this));
  }
  
  static Behavior a(Context paramContext, AttributeSet paramAttributeSet, String paramString) {
    if (TextUtils.isEmpty(paramString))
      return null; 
    if (paramString.startsWith(".")) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(paramContext.getPackageName());
      stringBuilder.append(paramString);
      paramString = stringBuilder.toString();
    } else if (paramString.indexOf('.') < 0 && !TextUtils.isEmpty(a)) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(a);
      stringBuilder.append('.');
      stringBuilder.append(paramString);
      paramString = stringBuilder.toString();
    } 
    try {
      Map<Object, Object> map = (Map)c.get();
      if (map == null) {
        map = new HashMap<Object, Object>();
        c.set(map);
      } 
      Constructor<?> constructor = (Constructor)map.get(paramString);
      if (constructor == null) {
        constructor = paramContext.getClassLoader().loadClass(paramString).getConstructor(b);
        constructor.setAccessible(true);
        map.put(paramString, constructor);
      } 
      return (Behavior)constructor.newInstance(new Object[] { paramContext, paramAttributeSet });
    } catch (Exception exception) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not inflate Behavior subclass ");
      stringBuilder.append(paramString);
      throw new RuntimeException(stringBuilder.toString(), exception);
    } 
  }
  
  @NonNull
  private static Rect acquireTempRect() {
    Rect rect = (Rect)sRectPool.acquire();
    if (rect == null)
      rect = new Rect(); 
    return rect;
  }
  
  private void constrainChildRect(LayoutParams paramLayoutParams, Rect paramRect, int paramInt1, int paramInt2) {
    int i = getWidth();
    int j = getHeight();
    int k = Math.max(getPaddingLeft() + paramLayoutParams.leftMargin, Math.min(paramRect.left, i - getPaddingRight() - paramInt1 - paramLayoutParams.rightMargin));
    int m = Math.max(getPaddingTop() + paramLayoutParams.topMargin, Math.min(paramRect.top, j - getPaddingBottom() - paramInt2 - paramLayoutParams.bottomMargin));
    paramRect.set(k, m, paramInt1 + k, paramInt2 + m);
  }
  
  private WindowInsetsCompat dispatchApplyWindowInsetsToBehaviors(WindowInsetsCompat paramWindowInsetsCompat) {
    if (paramWindowInsetsCompat.isConsumed())
      return paramWindowInsetsCompat; 
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      if (ViewCompat.getFitsSystemWindows(view)) {
        Behavior<View> behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
        if (behavior != null) {
          paramWindowInsetsCompat = behavior.onApplyWindowInsets(this, view, paramWindowInsetsCompat);
          if (paramWindowInsetsCompat.isConsumed())
            return paramWindowInsetsCompat; 
        } 
      } 
      b++;
    } 
    return paramWindowInsetsCompat;
  }
  
  private void getDesiredAnchoredChildRectWithoutConstraints(View paramView, int paramInt1, Rect paramRect1, Rect paramRect2, LayoutParams paramLayoutParams, int paramInt2, int paramInt3) {
    int i2;
    int i3;
    int i = GravityCompat.getAbsoluteGravity(resolveAnchoredChildGravity(paramLayoutParams.gravity), paramInt1);
    int j = GravityCompat.getAbsoluteGravity(resolveGravity(paramLayoutParams.anchorGravity), paramInt1);
    int k = i & 0x7;
    int m = i & 0x70;
    int n = j & 0x7;
    int i1 = j & 0x70;
    if (n != 1) {
      if (n != 5) {
        i2 = paramRect1.left;
      } else {
        i2 = paramRect1.right;
      } 
    } else {
      i2 = paramRect1.left + paramRect1.width() / 2;
    } 
    if (i1 != 16) {
      if (i1 != 80) {
        i3 = paramRect1.top;
      } else {
        i3 = paramRect1.bottom;
      } 
    } else {
      i3 = paramRect1.top + paramRect1.height() / 2;
    } 
    if (k != 1) {
      if (k != 5)
        i2 -= paramInt2; 
    } else {
      i2 -= paramInt2 / 2;
    } 
    if (m != 16) {
      if (m != 80)
        i3 -= paramInt3; 
    } else {
      i3 -= paramInt3 / 2;
    } 
    paramRect2.set(i2, i3, paramInt2 + i2, paramInt3 + i3);
  }
  
  private int getKeyline(int paramInt) {
    if (this.mKeylines == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("No keylines defined for ");
      stringBuilder.append(this);
      stringBuilder.append(" - attempted index lookup ");
      stringBuilder.append(paramInt);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    if (paramInt < 0 || paramInt >= this.mKeylines.length) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Keyline index ");
      stringBuilder.append(paramInt);
      stringBuilder.append(" out of range for ");
      stringBuilder.append(this);
      Log.e("CoordinatorLayout", stringBuilder.toString());
      return 0;
    } 
    return this.mKeylines[paramInt];
  }
  
  private void getTopSortedChildren(List<View> paramList) {
    paramList.clear();
    boolean bool = isChildrenDrawingOrderEnabled();
    int i = getChildCount();
    for (int j = i - 1; j >= 0; j--) {
      int k;
      if (bool) {
        k = getChildDrawingOrder(i, j);
      } else {
        k = j;
      } 
      paramList.add(getChildAt(k));
    } 
    if (d != null)
      Collections.sort(paramList, d); 
  }
  
  private boolean hasDependencies(View paramView) {
    return this.mChildDag.hasOutgoingEdges(paramView);
  }
  
  private void layoutChild(View paramView, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    Rect rect1 = acquireTempRect();
    rect1.set(getPaddingLeft() + layoutParams.leftMargin, getPaddingTop() + layoutParams.topMargin, getWidth() - getPaddingRight() - layoutParams.rightMargin, getHeight() - getPaddingBottom() - layoutParams.bottomMargin);
    if (this.mLastInsets != null && ViewCompat.getFitsSystemWindows((View)this) && !ViewCompat.getFitsSystemWindows(paramView)) {
      rect1.left += this.mLastInsets.getSystemWindowInsetLeft();
      rect1.top += this.mLastInsets.getSystemWindowInsetTop();
      rect1.right -= this.mLastInsets.getSystemWindowInsetRight();
      rect1.bottom -= this.mLastInsets.getSystemWindowInsetBottom();
    } 
    Rect rect2 = acquireTempRect();
    GravityCompat.apply(resolveGravity(layoutParams.gravity), paramView.getMeasuredWidth(), paramView.getMeasuredHeight(), rect1, rect2, paramInt);
    paramView.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
    releaseTempRect(rect1);
    releaseTempRect(rect2);
  }
  
  private void layoutChildWithAnchor(View paramView1, View paramView2, int paramInt) {
    (LayoutParams)paramView1.getLayoutParams();
    Rect rect1 = acquireTempRect();
    Rect rect2 = acquireTempRect();
    try {
      a(paramView2, rect1);
      a(paramView1, paramInt, rect1, rect2);
      paramView1.layout(rect2.left, rect2.top, rect2.right, rect2.bottom);
      return;
    } finally {
      releaseTempRect(rect1);
      releaseTempRect(rect2);
    } 
  }
  
  private void layoutChildWithKeyline(View paramView, int paramInt1, int paramInt2) {
    int i4;
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = GravityCompat.getAbsoluteGravity(resolveKeylineGravity(layoutParams.gravity), paramInt2);
    int j = i & 0x7;
    int k = i & 0x70;
    int m = getWidth();
    int n = getHeight();
    int i1 = paramView.getMeasuredWidth();
    int i2 = paramView.getMeasuredHeight();
    if (paramInt2 == 1)
      paramInt1 = m - paramInt1; 
    int i3 = getKeyline(paramInt1) - i1;
    if (j != 1) {
      if (j == 5)
        i3 += i1; 
    } else {
      i3 += i1 / 2;
    } 
    if (k != 16) {
      if (k != 80) {
        i4 = 0;
      } else {
        i4 = i2 + 0;
      } 
    } else {
      i4 = 0 + i2 / 2;
    } 
    int i5 = Math.max(getPaddingLeft() + layoutParams.leftMargin, Math.min(i3, m - getPaddingRight() - i1 - layoutParams.rightMargin));
    int i6 = Math.max(getPaddingTop() + layoutParams.topMargin, Math.min(i4, n - getPaddingBottom() - i2 - layoutParams.bottomMargin));
    paramView.layout(i5, i6, i1 + i5, i2 + i6);
  }
  
  private void offsetChildByInset(View paramView, Rect paramRect, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic isLaidOut : (Landroid/view/View;)Z
    //   4: ifne -> 8
    //   7: return
    //   8: aload_1
    //   9: invokevirtual getWidth : ()I
    //   12: ifle -> 457
    //   15: aload_1
    //   16: invokevirtual getHeight : ()I
    //   19: ifgt -> 23
    //   22: return
    //   23: aload_1
    //   24: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   27: checkcast android/support/design/widget/CoordinatorLayout$LayoutParams
    //   30: astore #4
    //   32: aload #4
    //   34: invokevirtual getBehavior : ()Landroid/support/design/widget/CoordinatorLayout$Behavior;
    //   37: astore #5
    //   39: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   42: astore #6
    //   44: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   47: astore #7
    //   49: aload #7
    //   51: aload_1
    //   52: invokevirtual getLeft : ()I
    //   55: aload_1
    //   56: invokevirtual getTop : ()I
    //   59: aload_1
    //   60: invokevirtual getRight : ()I
    //   63: aload_1
    //   64: invokevirtual getBottom : ()I
    //   67: invokevirtual set : (IIII)V
    //   70: aload #5
    //   72: ifnull -> 162
    //   75: aload #5
    //   77: aload_0
    //   78: aload_1
    //   79: aload #6
    //   81: invokevirtual getInsetDodgeRect : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;Landroid/graphics/Rect;)Z
    //   84: ifeq -> 162
    //   87: aload #7
    //   89: aload #6
    //   91: invokevirtual contains : (Landroid/graphics/Rect;)Z
    //   94: ifeq -> 100
    //   97: goto -> 169
    //   100: new java/lang/StringBuilder
    //   103: dup
    //   104: invokespecial <init> : ()V
    //   107: astore #15
    //   109: aload #15
    //   111: ldc_w 'Rect should be within the child's bounds. Rect:'
    //   114: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   117: pop
    //   118: aload #15
    //   120: aload #6
    //   122: invokevirtual toShortString : ()Ljava/lang/String;
    //   125: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   128: pop
    //   129: aload #15
    //   131: ldc_w ' | Bounds:'
    //   134: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   137: pop
    //   138: aload #15
    //   140: aload #7
    //   142: invokevirtual toShortString : ()Ljava/lang/String;
    //   145: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   148: pop
    //   149: new java/lang/IllegalArgumentException
    //   152: dup
    //   153: aload #15
    //   155: invokevirtual toString : ()Ljava/lang/String;
    //   158: invokespecial <init> : (Ljava/lang/String;)V
    //   161: athrow
    //   162: aload #6
    //   164: aload #7
    //   166: invokevirtual set : (Landroid/graphics/Rect;)V
    //   169: aload #7
    //   171: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   174: aload #6
    //   176: invokevirtual isEmpty : ()Z
    //   179: ifeq -> 188
    //   182: aload #6
    //   184: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   187: return
    //   188: aload #4
    //   190: getfield dodgeInsetEdges : I
    //   193: iload_3
    //   194: invokestatic getAbsoluteGravity : (II)I
    //   197: istore #8
    //   199: iload #8
    //   201: bipush #48
    //   203: iand
    //   204: bipush #48
    //   206: if_icmpne -> 255
    //   209: aload #6
    //   211: getfield top : I
    //   214: aload #4
    //   216: getfield topMargin : I
    //   219: isub
    //   220: aload #4
    //   222: getfield e : I
    //   225: isub
    //   226: istore #14
    //   228: iload #14
    //   230: aload_2
    //   231: getfield top : I
    //   234: if_icmpge -> 255
    //   237: aload_0
    //   238: aload_1
    //   239: aload_2
    //   240: getfield top : I
    //   243: iload #14
    //   245: isub
    //   246: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   249: iconst_1
    //   250: istore #9
    //   252: goto -> 258
    //   255: iconst_0
    //   256: istore #9
    //   258: iload #8
    //   260: bipush #80
    //   262: iand
    //   263: bipush #80
    //   265: if_icmpne -> 316
    //   268: aload_0
    //   269: invokevirtual getHeight : ()I
    //   272: aload #6
    //   274: getfield bottom : I
    //   277: isub
    //   278: aload #4
    //   280: getfield bottomMargin : I
    //   283: isub
    //   284: aload #4
    //   286: getfield e : I
    //   289: iadd
    //   290: istore #13
    //   292: iload #13
    //   294: aload_2
    //   295: getfield bottom : I
    //   298: if_icmpge -> 316
    //   301: aload_0
    //   302: aload_1
    //   303: iload #13
    //   305: aload_2
    //   306: getfield bottom : I
    //   309: isub
    //   310: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   313: iconst_1
    //   314: istore #9
    //   316: iload #9
    //   318: ifne -> 327
    //   321: aload_0
    //   322: aload_1
    //   323: iconst_0
    //   324: invokespecial setInsetOffsetY : (Landroid/view/View;I)V
    //   327: iload #8
    //   329: iconst_3
    //   330: iand
    //   331: iconst_3
    //   332: if_icmpne -> 381
    //   335: aload #6
    //   337: getfield left : I
    //   340: aload #4
    //   342: getfield leftMargin : I
    //   345: isub
    //   346: aload #4
    //   348: getfield d : I
    //   351: isub
    //   352: istore #12
    //   354: iload #12
    //   356: aload_2
    //   357: getfield left : I
    //   360: if_icmpge -> 381
    //   363: aload_0
    //   364: aload_1
    //   365: aload_2
    //   366: getfield left : I
    //   369: iload #12
    //   371: isub
    //   372: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   375: iconst_1
    //   376: istore #10
    //   378: goto -> 384
    //   381: iconst_0
    //   382: istore #10
    //   384: iload #8
    //   386: iconst_5
    //   387: iand
    //   388: iconst_5
    //   389: if_icmpne -> 440
    //   392: aload_0
    //   393: invokevirtual getWidth : ()I
    //   396: aload #6
    //   398: getfield right : I
    //   401: isub
    //   402: aload #4
    //   404: getfield rightMargin : I
    //   407: isub
    //   408: aload #4
    //   410: getfield d : I
    //   413: iadd
    //   414: istore #11
    //   416: iload #11
    //   418: aload_2
    //   419: getfield right : I
    //   422: if_icmpge -> 440
    //   425: aload_0
    //   426: aload_1
    //   427: iload #11
    //   429: aload_2
    //   430: getfield right : I
    //   433: isub
    //   434: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   437: iconst_1
    //   438: istore #10
    //   440: iload #10
    //   442: ifne -> 451
    //   445: aload_0
    //   446: aload_1
    //   447: iconst_0
    //   448: invokespecial setInsetOffsetX : (Landroid/view/View;I)V
    //   451: aload #6
    //   453: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   456: return
    //   457: return
  }
  
  private boolean performIntercept(MotionEvent paramMotionEvent, int paramInt) {
    int i = paramMotionEvent.getActionMasked();
    List<View> list = this.mTempList1;
    getTopSortedChildren(list);
    int j = list.size();
    MotionEvent motionEvent = null;
    byte b = 0;
    boolean bool = false;
    boolean bool1 = false;
    while (b < j) {
      View view = list.get(b);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      Behavior<View> behavior = layoutParams.getBehavior();
      if ((bool || bool1) && i != 0) {
        if (behavior != null) {
          if (motionEvent == null) {
            long l = SystemClock.uptimeMillis();
            motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
          } 
          switch (paramInt) {
            case 1:
              behavior.onTouchEvent(this, view, motionEvent);
              break;
            case 0:
              behavior.onInterceptTouchEvent(this, view, motionEvent);
              break;
          } 
        } 
      } else {
        if (!bool && behavior != null) {
          switch (paramInt) {
            case 1:
              bool = behavior.onTouchEvent(this, view, paramMotionEvent);
              break;
            case 0:
              bool = behavior.onInterceptTouchEvent(this, view, paramMotionEvent);
              break;
          } 
          if (bool)
            this.mBehaviorTouchView = view; 
        } 
        boolean bool2 = layoutParams.b();
        boolean bool3 = layoutParams.a(this, view);
        if (bool3 && !bool2) {
          bool1 = true;
        } else {
          bool1 = false;
        } 
        if (bool3 && !bool1)
          break; 
      } 
      b++;
    } 
    list.clear();
    return bool;
  }
  
  private void prepareChildren() {
    this.mDependencySortedChildren.clear();
    this.mChildDag.clear();
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      LayoutParams layoutParams = a(view);
      layoutParams.b(this, view);
      this.mChildDag.addNode(view);
      for (byte b1 = 0; b1 < i; b1++) {
        if (b1 != b) {
          View view1 = getChildAt(b1);
          if (layoutParams.a(this, view, view1)) {
            if (!this.mChildDag.contains(view1))
              this.mChildDag.addNode(view1); 
            this.mChildDag.addEdge(view1, view);
          } 
        } 
      } 
    } 
    this.mDependencySortedChildren.addAll(this.mChildDag.getSortedList());
    Collections.reverse(this.mDependencySortedChildren);
  }
  
  private static void releaseTempRect(@NonNull Rect paramRect) {
    paramRect.setEmpty();
    sRectPool.release(paramRect);
  }
  
  private void resetTouchBehaviors(boolean paramBoolean) {
    int i = getChildCount();
    for (byte b1 = 0; b1 < i; b1++) {
      View view = getChildAt(b1);
      Behavior<View> behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
      if (behavior != null) {
        long l = SystemClock.uptimeMillis();
        MotionEvent motionEvent = MotionEvent.obtain(l, l, 3, 0.0F, 0.0F, 0);
        if (paramBoolean) {
          behavior.onInterceptTouchEvent(this, view, motionEvent);
        } else {
          behavior.onTouchEvent(this, view, motionEvent);
        } 
        motionEvent.recycle();
      } 
    } 
    for (byte b2 = 0; b2 < i; b2++)
      ((LayoutParams)getChildAt(b2).getLayoutParams()).c(); 
    this.mBehaviorTouchView = null;
    this.mDisallowInterceptReset = false;
  }
  
  private static int resolveAnchoredChildGravity(int paramInt) {
    if (paramInt == 0)
      paramInt = 17; 
    return paramInt;
  }
  
  private static int resolveGravity(int paramInt) {
    if ((paramInt & 0x7) == 0)
      paramInt |= 0x800003; 
    if ((paramInt & 0x70) == 0)
      paramInt |= 0x30; 
    return paramInt;
  }
  
  private static int resolveKeylineGravity(int paramInt) {
    if (paramInt == 0)
      paramInt = 8388661; 
    return paramInt;
  }
  
  private void setInsetOffsetX(View paramView, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (layoutParams.d != paramInt) {
      ViewCompat.offsetLeftAndRight(paramView, paramInt - layoutParams.d);
      layoutParams.d = paramInt;
    } 
  }
  
  private void setInsetOffsetY(View paramView, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (layoutParams.e != paramInt) {
      ViewCompat.offsetTopAndBottom(paramView, paramInt - layoutParams.e);
      layoutParams.e = paramInt;
    } 
  }
  
  private void setupForInsets() {
    if (Build.VERSION.SDK_INT < 21)
      return; 
    if (ViewCompat.getFitsSystemWindows((View)this)) {
      if (this.mApplyWindowInsetsListener == null)
        this.mApplyWindowInsetsListener = new OnApplyWindowInsetsListener(this) {
            public WindowInsetsCompat onApplyWindowInsets(View param1View, WindowInsetsCompat param1WindowInsetsCompat) {
              return this.a.a(param1WindowInsetsCompat);
            }
          }; 
      ViewCompat.setOnApplyWindowInsetsListener((View)this, this.mApplyWindowInsetsListener);
      setSystemUiVisibility(1280);
      return;
    } 
    ViewCompat.setOnApplyWindowInsetsListener((View)this, null);
  }
  
  LayoutParams a(View paramView) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (!layoutParams.b) {
      if (paramView instanceof AttachedBehavior) {
        Behavior behavior = ((AttachedBehavior)paramView).getBehavior();
        if (behavior == null)
          Log.e("CoordinatorLayout", "Attached behavior class is null"); 
        layoutParams.setBehavior(behavior);
        layoutParams.b = true;
        return layoutParams;
      } 
      Class<?> clazz = paramView.getClass();
      DefaultBehavior defaultBehavior = null;
      while (clazz != null) {
        defaultBehavior = clazz.<DefaultBehavior>getAnnotation(DefaultBehavior.class);
        if (defaultBehavior == null)
          clazz = clazz.getSuperclass(); 
      } 
      if (defaultBehavior != null)
        try {
          layoutParams.setBehavior(defaultBehavior.value().getDeclaredConstructor(new Class[0]).newInstance(new Object[0]));
        } catch (Exception exception) {
          StringBuilder stringBuilder = new StringBuilder();
          stringBuilder.append("Default behavior class ");
          stringBuilder.append(defaultBehavior.value().getName());
          stringBuilder.append(" could not be instantiated. Did you forget");
          stringBuilder.append(" a default constructor?");
          Log.e("CoordinatorLayout", stringBuilder.toString(), exception);
        }  
      layoutParams.b = true;
    } 
    return layoutParams;
  }
  
  final WindowInsetsCompat a(WindowInsetsCompat paramWindowInsetsCompat) {
    if (!ObjectsCompat.equals(this.mLastInsets, paramWindowInsetsCompat)) {
      boolean bool2;
      this.mLastInsets = paramWindowInsetsCompat;
      boolean bool1 = true;
      if (paramWindowInsetsCompat != null && paramWindowInsetsCompat.getSystemWindowInsetTop() > 0) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      this.mDrawStatusBarBackground = bool2;
      if (this.mDrawStatusBarBackground || getBackground() != null)
        bool1 = false; 
      setWillNotDraw(bool1);
      paramWindowInsetsCompat = dispatchApplyWindowInsetsToBehaviors(paramWindowInsetsCompat);
      requestLayout();
    } 
    return paramWindowInsetsCompat;
  }
  
  void a() {
    boolean bool;
    int i = getChildCount();
    byte b = 0;
    while (true) {
      bool = false;
      if (b < i) {
        if (hasDependencies(getChildAt(b))) {
          bool = true;
          break;
        } 
        b++;
        continue;
      } 
      break;
    } 
    if (bool != this.mNeedsPreDrawListener) {
      if (bool) {
        b();
        return;
      } 
      c();
    } 
  }
  
  final void a(int paramInt) {
    int i = ViewCompat.getLayoutDirection((View)this);
    int j = this.mDependencySortedChildren.size();
    Rect rect1 = acquireTempRect();
    Rect rect2 = acquireTempRect();
    Rect rect3 = acquireTempRect();
    for (byte b = 0; b < j; b++) {
      View view = this.mDependencySortedChildren.get(b);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (paramInt == 0 && view.getVisibility() == 8)
        continue; 
      for (byte b1 = 0; b1 < b; b1++) {
        View view1 = this.mDependencySortedChildren.get(b1);
        if (layoutParams.g == view1)
          a(view, i); 
      } 
      a(view, true, rect2);
      if (layoutParams.insetEdge != 0 && !rect2.isEmpty()) {
        int m = GravityCompat.getAbsoluteGravity(layoutParams.insetEdge, i);
        int n = m & 0x70;
        if (n != 48) {
          if (n == 80)
            rect1.bottom = Math.max(rect1.bottom, getHeight() - rect2.top); 
        } else {
          rect1.top = Math.max(rect1.top, rect2.bottom);
        } 
        int i1 = m & 0x7;
        if (i1 != 3) {
          if (i1 == 5)
            rect1.right = Math.max(rect1.right, getWidth() - rect2.left); 
        } else {
          rect1.left = Math.max(rect1.left, rect2.right);
        } 
      } 
      if (layoutParams.dodgeInsetEdges != 0 && view.getVisibility() == 0)
        offsetChildByInset(view, rect1, i); 
      if (paramInt != 2) {
        c(view, rect3);
        if (rect3.equals(rect2))
          continue; 
        b(view, rect2);
      } 
      for (int k = b + 1; k < j; k++) {
        View view1 = this.mDependencySortedChildren.get(k);
        LayoutParams layoutParams1 = (LayoutParams)view1.getLayoutParams();
        Behavior<View> behavior = layoutParams1.getBehavior();
        if (behavior != null && behavior.layoutDependsOn(this, view1, view))
          if (paramInt == 0 && layoutParams1.getChangedAfterNestedScroll()) {
            layoutParams1.d();
          } else {
            boolean bool;
            if (paramInt != 2) {
              bool = behavior.onDependentViewChanged(this, view1, view);
            } else {
              behavior.onDependentViewRemoved(this, view1, view);
              bool = true;
            } 
            if (paramInt == 1)
              layoutParams1.setChangedAfterNestedScroll(bool); 
          }  
      } 
      continue;
    } 
    releaseTempRect(rect1);
    releaseTempRect(rect2);
    releaseTempRect(rect3);
  }
  
  void a(View paramView, int paramInt) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   4: checkcast android/support/design/widget/CoordinatorLayout$LayoutParams
    //   7: astore_3
    //   8: aload_3
    //   9: getfield f : Landroid/view/View;
    //   12: ifnull -> 217
    //   15: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   18: astore #4
    //   20: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   23: astore #5
    //   25: invokestatic acquireTempRect : ()Landroid/graphics/Rect;
    //   28: astore #6
    //   30: aload_0
    //   31: aload_3
    //   32: getfield f : Landroid/view/View;
    //   35: aload #4
    //   37: invokevirtual a : (Landroid/view/View;Landroid/graphics/Rect;)V
    //   40: aload_0
    //   41: aload_1
    //   42: iconst_0
    //   43: aload #5
    //   45: invokevirtual a : (Landroid/view/View;ZLandroid/graphics/Rect;)V
    //   48: aload_1
    //   49: invokevirtual getMeasuredWidth : ()I
    //   52: istore #7
    //   54: aload_1
    //   55: invokevirtual getMeasuredHeight : ()I
    //   58: istore #8
    //   60: aload_0
    //   61: aload_1
    //   62: iload_2
    //   63: aload #4
    //   65: aload #6
    //   67: aload_3
    //   68: iload #7
    //   70: iload #8
    //   72: invokespecial getDesiredAnchoredChildRectWithoutConstraints : (Landroid/view/View;ILandroid/graphics/Rect;Landroid/graphics/Rect;Landroid/support/design/widget/CoordinatorLayout$LayoutParams;II)V
    //   75: aload #6
    //   77: getfield left : I
    //   80: aload #5
    //   82: getfield left : I
    //   85: if_icmpne -> 112
    //   88: aload #6
    //   90: getfield top : I
    //   93: istore #14
    //   95: aload #5
    //   97: getfield top : I
    //   100: istore #15
    //   102: iconst_0
    //   103: istore #9
    //   105: iload #14
    //   107: iload #15
    //   109: if_icmpeq -> 115
    //   112: iconst_1
    //   113: istore #9
    //   115: aload_0
    //   116: aload_3
    //   117: aload #6
    //   119: iload #7
    //   121: iload #8
    //   123: invokespecial constrainChildRect : (Landroid/support/design/widget/CoordinatorLayout$LayoutParams;Landroid/graphics/Rect;II)V
    //   126: aload #6
    //   128: getfield left : I
    //   131: aload #5
    //   133: getfield left : I
    //   136: isub
    //   137: istore #10
    //   139: aload #6
    //   141: getfield top : I
    //   144: aload #5
    //   146: getfield top : I
    //   149: isub
    //   150: istore #11
    //   152: iload #10
    //   154: ifeq -> 163
    //   157: aload_1
    //   158: iload #10
    //   160: invokestatic offsetLeftAndRight : (Landroid/view/View;I)V
    //   163: iload #11
    //   165: ifeq -> 174
    //   168: aload_1
    //   169: iload #11
    //   171: invokestatic offsetTopAndBottom : (Landroid/view/View;I)V
    //   174: iload #9
    //   176: ifeq -> 202
    //   179: aload_3
    //   180: invokevirtual getBehavior : ()Landroid/support/design/widget/CoordinatorLayout$Behavior;
    //   183: astore #12
    //   185: aload #12
    //   187: ifnull -> 202
    //   190: aload #12
    //   192: aload_0
    //   193: aload_1
    //   194: aload_3
    //   195: getfield f : Landroid/view/View;
    //   198: invokevirtual onDependentViewChanged : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/View;)Z
    //   201: pop
    //   202: aload #4
    //   204: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   207: aload #5
    //   209: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   212: aload #6
    //   214: invokestatic releaseTempRect : (Landroid/graphics/Rect;)V
    //   217: return
  }
  
  void a(View paramView, int paramInt, Rect paramRect1, Rect paramRect2) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    int i = paramView.getMeasuredWidth();
    int j = paramView.getMeasuredHeight();
    getDesiredAnchoredChildRectWithoutConstraints(paramView, paramInt, paramRect1, paramRect2, layoutParams, i, j);
    constrainChildRect(layoutParams, paramRect2, i, j);
  }
  
  void a(View paramView, Rect paramRect) {
    ViewGroupUtils.getDescendantRect(this, paramView, paramRect);
  }
  
  void a(View paramView, boolean paramBoolean, Rect paramRect) {
    if (paramView.isLayoutRequested() || paramView.getVisibility() == 8) {
      paramRect.setEmpty();
      return;
    } 
    if (paramBoolean) {
      a(paramView, paramRect);
      return;
    } 
    paramRect.set(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom());
  }
  
  void b() {
    if (this.mIsAttachedToWindow) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new OnPreDrawListener(this); 
      getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
    } 
    this.mNeedsPreDrawListener = true;
  }
  
  void b(View paramView, Rect paramRect) {
    ((LayoutParams)paramView.getLayoutParams()).setLastChildRect(paramRect);
  }
  
  void c() {
    if (this.mIsAttachedToWindow && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener); 
    this.mNeedsPreDrawListener = false;
  }
  
  void c(View paramView, Rect paramRect) {
    paramRect.set(((LayoutParams)paramView.getLayoutParams()).getLastChildRect());
  }
  
  protected boolean checkLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams && super.checkLayoutParams(paramLayoutParams));
  }
  
  public void dispatchDependentViewsChanged(View paramView) {
    List<View> list = this.mChildDag.getIncomingEdges(paramView);
    if (list != null && !list.isEmpty())
      for (byte b = 0; b < list.size(); b++) {
        View view = list.get(b);
        Behavior<View> behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
        if (behavior != null)
          behavior.onDependentViewChanged(this, view, paramView); 
      }  
  }
  
  public boolean doViewsOverlap(View paramView1, View paramView2) {
    if (paramView1.getVisibility() == 0 && paramView2.getVisibility() == 0) {
      boolean bool1;
      boolean bool2;
      Rect rect1 = acquireTempRect();
      if (paramView1.getParent() != this) {
        bool1 = true;
      } else {
        bool1 = false;
      } 
      a(paramView1, bool1, rect1);
      Rect rect2 = acquireTempRect();
      if (paramView2.getParent() != this) {
        bool2 = true;
      } else {
        bool2 = false;
      } 
      a(paramView2, bool2, rect2);
      try {
        int i = rect1.left;
        int j = rect2.right;
        boolean bool = false;
        if (i <= j) {
          int k = rect1.top;
          int m = rect2.bottom;
          bool = false;
          if (k <= m) {
            int n = rect1.right;
            int i1 = rect2.left;
            bool = false;
            if (n >= i1) {
              int i2 = rect1.bottom;
              int i3 = rect2.top;
              bool = false;
              if (i2 >= i3)
                bool = true; 
            } 
          } 
        } 
        return bool;
      } finally {
        releaseTempRect(rect1);
        releaseTempRect(rect2);
      } 
    } 
    return false;
  }
  
  protected boolean drawChild(Canvas paramCanvas, View paramView, long paramLong) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (layoutParams.a != null) {
      float f = layoutParams.a.getScrimOpacity(this, paramView);
      if (f > 0.0F) {
        if (this.mScrimPaint == null)
          this.mScrimPaint = new Paint(); 
        this.mScrimPaint.setColor(layoutParams.a.getScrimColor(this, paramView));
        this.mScrimPaint.setAlpha(MathUtils.clamp(Math.round(f * 255.0F), 0, 255));
        int i = paramCanvas.save();
        if (paramView.isOpaque())
          paramCanvas.clipRect(paramView.getLeft(), paramView.getTop(), paramView.getRight(), paramView.getBottom(), Region.Op.DIFFERENCE); 
        paramCanvas.drawRect(getPaddingLeft(), getPaddingTop(), (getWidth() - getPaddingRight()), (getHeight() - getPaddingBottom()), this.mScrimPaint);
        paramCanvas.restoreToCount(i);
      } 
    } 
    return super.drawChild(paramCanvas, paramView, paramLong);
  }
  
  protected void drawableStateChanged() {
    super.drawableStateChanged();
    int[] arrayOfInt = getDrawableState();
    Drawable drawable = this.mStatusBarBackground;
    int i = 0;
    if (drawable != null) {
      boolean bool = drawable.isStateful();
      i = 0;
      if (bool)
        i = false | drawable.setState(arrayOfInt); 
    } 
    if (i != 0)
      invalidate(); 
  }
  
  protected LayoutParams generateDefaultLayoutParams() {
    return new LayoutParams(-2, -2);
  }
  
  public LayoutParams generateLayoutParams(AttributeSet paramAttributeSet) {
    return new LayoutParams(getContext(), paramAttributeSet);
  }
  
  protected LayoutParams generateLayoutParams(ViewGroup.LayoutParams paramLayoutParams) {
    return (paramLayoutParams instanceof LayoutParams) ? new LayoutParams((LayoutParams)paramLayoutParams) : ((paramLayoutParams instanceof ViewGroup.MarginLayoutParams) ? new LayoutParams((ViewGroup.MarginLayoutParams)paramLayoutParams) : new LayoutParams(paramLayoutParams));
  }
  
  @NonNull
  public List<View> getDependencies(@NonNull View paramView) {
    List<? extends View> list = this.mChildDag.getOutgoingEdges(paramView);
    this.mTempDependenciesList.clear();
    if (list != null)
      this.mTempDependenciesList.addAll(list); 
    return this.mTempDependenciesList;
  }
  
  @VisibleForTesting
  final List<View> getDependencySortedChildren() {
    prepareChildren();
    return Collections.unmodifiableList(this.mDependencySortedChildren);
  }
  
  @NonNull
  public List<View> getDependents(@NonNull View paramView) {
    List<? extends View> list = this.mChildDag.getIncomingEdges(paramView);
    this.mTempDependenciesList.clear();
    if (list != null)
      this.mTempDependenciesList.addAll(list); 
    return this.mTempDependenciesList;
  }
  
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public final WindowInsetsCompat getLastWindowInsets() {
    return this.mLastInsets;
  }
  
  public int getNestedScrollAxes() {
    return this.mNestedScrollingParentHelper.getNestedScrollAxes();
  }
  
  @Nullable
  public Drawable getStatusBarBackground() {
    return this.mStatusBarBackground;
  }
  
  protected int getSuggestedMinimumHeight() {
    return Math.max(super.getSuggestedMinimumHeight(), getPaddingTop() + getPaddingBottom());
  }
  
  protected int getSuggestedMinimumWidth() {
    return Math.max(super.getSuggestedMinimumWidth(), getPaddingLeft() + getPaddingRight());
  }
  
  public boolean isPointInChildBounds(View paramView, int paramInt1, int paramInt2) {
    Rect rect = acquireTempRect();
    a(paramView, rect);
    try {
      return rect.contains(paramInt1, paramInt2);
    } finally {
      releaseTempRect(rect);
    } 
  }
  
  public void onAttachedToWindow() {
    super.onAttachedToWindow();
    resetTouchBehaviors(false);
    if (this.mNeedsPreDrawListener) {
      if (this.mOnPreDrawListener == null)
        this.mOnPreDrawListener = new OnPreDrawListener(this); 
      getViewTreeObserver().addOnPreDrawListener(this.mOnPreDrawListener);
    } 
    if (this.mLastInsets == null && ViewCompat.getFitsSystemWindows((View)this))
      ViewCompat.requestApplyInsets((View)this); 
    this.mIsAttachedToWindow = true;
  }
  
  public void onDetachedFromWindow() {
    super.onDetachedFromWindow();
    resetTouchBehaviors(false);
    if (this.mNeedsPreDrawListener && this.mOnPreDrawListener != null)
      getViewTreeObserver().removeOnPreDrawListener(this.mOnPreDrawListener); 
    if (this.mNestedScrollingTarget != null)
      onStopNestedScroll(this.mNestedScrollingTarget); 
    this.mIsAttachedToWindow = false;
  }
  
  public void onDraw(Canvas paramCanvas) {
    super.onDraw(paramCanvas);
    if (this.mDrawStatusBarBackground && this.mStatusBarBackground != null) {
      boolean bool;
      if (this.mLastInsets != null) {
        bool = this.mLastInsets.getSystemWindowInsetTop();
      } else {
        bool = false;
      } 
      if (bool) {
        this.mStatusBarBackground.setBounds(0, 0, getWidth(), bool);
        this.mStatusBarBackground.draw(paramCanvas);
      } 
    } 
  }
  
  public boolean onInterceptTouchEvent(MotionEvent paramMotionEvent) {
    int i = paramMotionEvent.getActionMasked();
    if (i == 0)
      resetTouchBehaviors(true); 
    boolean bool = performIntercept(paramMotionEvent, 0);
    if (i == 1 || i == 3)
      resetTouchBehaviors(true); 
    return bool;
  }
  
  protected void onLayout(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    int i = ViewCompat.getLayoutDirection((View)this);
    int j = this.mDependencySortedChildren.size();
    for (byte b = 0; b < j; b++) {
      View view = this.mDependencySortedChildren.get(b);
      if (view.getVisibility() != 8) {
        Behavior<View> behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
        if (behavior == null || !behavior.onLayoutChild(this, view, i))
          onLayoutChild(view, i); 
      } 
    } 
  }
  
  public void onLayoutChild(View paramView, int paramInt) {
    LayoutParams layoutParams = (LayoutParams)paramView.getLayoutParams();
    if (!layoutParams.a()) {
      if (layoutParams.f != null) {
        layoutChildWithAnchor(paramView, layoutParams.f, paramInt);
        return;
      } 
      if (layoutParams.keyline >= 0) {
        layoutChildWithKeyline(paramView, layoutParams.keyline, paramInt);
        return;
      } 
      layoutChild(paramView, paramInt);
      return;
    } 
    throw new IllegalStateException("An anchor may not be changed after CoordinatorLayout measurement begins before layout is complete.");
  }
  
  protected void onMeasure(int paramInt1, int paramInt2) {
    // Byte code:
    //   0: aload_0
    //   1: invokespecial prepareChildren : ()V
    //   4: aload_0
    //   5: invokevirtual a : ()V
    //   8: aload_0
    //   9: invokevirtual getPaddingLeft : ()I
    //   12: istore_3
    //   13: aload_0
    //   14: invokevirtual getPaddingTop : ()I
    //   17: istore #4
    //   19: aload_0
    //   20: invokevirtual getPaddingRight : ()I
    //   23: istore #5
    //   25: aload_0
    //   26: invokevirtual getPaddingBottom : ()I
    //   29: istore #6
    //   31: aload_0
    //   32: invokestatic getLayoutDirection : (Landroid/view/View;)I
    //   35: istore #7
    //   37: iload #7
    //   39: iconst_1
    //   40: if_icmpne -> 49
    //   43: iconst_1
    //   44: istore #8
    //   46: goto -> 52
    //   49: iconst_0
    //   50: istore #8
    //   52: iload_1
    //   53: invokestatic getMode : (I)I
    //   56: istore #9
    //   58: iload_1
    //   59: invokestatic getSize : (I)I
    //   62: istore #10
    //   64: iload_2
    //   65: invokestatic getMode : (I)I
    //   68: istore #11
    //   70: iload_2
    //   71: invokestatic getSize : (I)I
    //   74: istore #12
    //   76: iload_3
    //   77: iload #5
    //   79: iadd
    //   80: istore #13
    //   82: iload #4
    //   84: iload #6
    //   86: iadd
    //   87: istore #14
    //   89: aload_0
    //   90: invokevirtual getSuggestedMinimumWidth : ()I
    //   93: istore #15
    //   95: aload_0
    //   96: invokevirtual getSuggestedMinimumHeight : ()I
    //   99: istore #16
    //   101: aload_0
    //   102: getfield mLastInsets : Landroid/support/v4/view/WindowInsetsCompat;
    //   105: ifnull -> 121
    //   108: aload_0
    //   109: invokestatic getFitsSystemWindows : (Landroid/view/View;)Z
    //   112: ifeq -> 121
    //   115: iconst_1
    //   116: istore #17
    //   118: goto -> 124
    //   121: iconst_0
    //   122: istore #17
    //   124: aload_0
    //   125: getfield mDependencySortedChildren : Ljava/util/List;
    //   128: invokeinterface size : ()I
    //   133: istore #18
    //   135: iload #15
    //   137: istore #19
    //   139: iload #16
    //   141: istore #20
    //   143: iconst_0
    //   144: istore #21
    //   146: iconst_0
    //   147: istore #22
    //   149: iload #22
    //   151: iload #18
    //   153: if_icmpge -> 635
    //   156: aload_0
    //   157: getfield mDependencySortedChildren : Ljava/util/List;
    //   160: iload #22
    //   162: invokeinterface get : (I)Ljava/lang/Object;
    //   167: checkcast android/view/View
    //   170: astore #25
    //   172: aload #25
    //   174: invokevirtual getVisibility : ()I
    //   177: bipush #8
    //   179: if_icmpne -> 193
    //   182: iload #22
    //   184: istore #37
    //   186: iload #18
    //   188: istore #35
    //   190: goto -> 622
    //   193: aload #25
    //   195: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   198: checkcast android/support/design/widget/CoordinatorLayout$LayoutParams
    //   201: astore #26
    //   203: aload #26
    //   205: getfield keyline : I
    //   208: iflt -> 323
    //   211: iload #9
    //   213: ifeq -> 323
    //   216: aload_0
    //   217: aload #26
    //   219: getfield keyline : I
    //   222: invokespecial getKeyline : (I)I
    //   225: istore #53
    //   227: bipush #7
    //   229: aload #26
    //   231: getfield gravity : I
    //   234: invokestatic resolveKeylineGravity : (I)I
    //   237: iload #7
    //   239: invokestatic getAbsoluteGravity : (II)I
    //   242: iand
    //   243: istore #54
    //   245: iload #20
    //   247: istore #27
    //   249: iload #54
    //   251: iconst_3
    //   252: if_icmpne -> 260
    //   255: iload #8
    //   257: ifeq -> 271
    //   260: iload #54
    //   262: iconst_5
    //   263: if_icmpne -> 288
    //   266: iload #8
    //   268: ifeq -> 288
    //   271: iconst_0
    //   272: iload #10
    //   274: iload #5
    //   276: isub
    //   277: iload #53
    //   279: isub
    //   280: invokestatic max : (II)I
    //   283: istore #28
    //   285: goto -> 330
    //   288: iload #54
    //   290: iconst_5
    //   291: if_icmpne -> 299
    //   294: iload #8
    //   296: ifeq -> 310
    //   299: iload #54
    //   301: iconst_3
    //   302: if_icmpne -> 327
    //   305: iload #8
    //   307: ifeq -> 327
    //   310: iconst_0
    //   311: iload #53
    //   313: iload_3
    //   314: isub
    //   315: invokestatic max : (II)I
    //   318: istore #28
    //   320: goto -> 330
    //   323: iload #20
    //   325: istore #27
    //   327: iconst_0
    //   328: istore #28
    //   330: iload #17
    //   332: ifeq -> 412
    //   335: aload #25
    //   337: invokestatic getFitsSystemWindows : (Landroid/view/View;)Z
    //   340: ifne -> 412
    //   343: aload_0
    //   344: getfield mLastInsets : Landroid/support/v4/view/WindowInsetsCompat;
    //   347: invokevirtual getSystemWindowInsetLeft : ()I
    //   350: aload_0
    //   351: getfield mLastInsets : Landroid/support/v4/view/WindowInsetsCompat;
    //   354: invokevirtual getSystemWindowInsetRight : ()I
    //   357: iadd
    //   358: istore #49
    //   360: aload_0
    //   361: getfield mLastInsets : Landroid/support/v4/view/WindowInsetsCompat;
    //   364: invokevirtual getSystemWindowInsetTop : ()I
    //   367: aload_0
    //   368: getfield mLastInsets : Landroid/support/v4/view/WindowInsetsCompat;
    //   371: invokevirtual getSystemWindowInsetBottom : ()I
    //   374: iadd
    //   375: istore #50
    //   377: iload #10
    //   379: iload #49
    //   381: isub
    //   382: iload #9
    //   384: invokestatic makeMeasureSpec : (II)I
    //   387: istore #51
    //   389: iload #12
    //   391: iload #50
    //   393: isub
    //   394: iload #11
    //   396: invokestatic makeMeasureSpec : (II)I
    //   399: istore #52
    //   401: iload #51
    //   403: istore #29
    //   405: iload #52
    //   407: istore #30
    //   409: goto -> 418
    //   412: iload_1
    //   413: istore #29
    //   415: iload_2
    //   416: istore #30
    //   418: aload #26
    //   420: invokevirtual getBehavior : ()Landroid/support/design/widget/CoordinatorLayout$Behavior;
    //   423: astore #31
    //   425: aload #31
    //   427: ifnull -> 487
    //   430: aload #26
    //   432: astore #32
    //   434: iload #27
    //   436: istore #36
    //   438: iload #21
    //   440: istore #33
    //   442: iload #29
    //   444: istore #46
    //   446: iload #19
    //   448: istore #34
    //   450: iload #28
    //   452: istore #47
    //   454: iload #22
    //   456: istore #37
    //   458: iload #30
    //   460: istore #48
    //   462: iload #18
    //   464: istore #35
    //   466: aload #31
    //   468: aload_0
    //   469: aload #25
    //   471: iload #46
    //   473: iload #47
    //   475: iload #48
    //   477: iconst_0
    //   478: invokevirtual onMeasureChild : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;IIII)Z
    //   481: ifne -> 524
    //   484: goto -> 511
    //   487: aload #26
    //   489: astore #32
    //   491: iload #21
    //   493: istore #33
    //   495: iload #19
    //   497: istore #34
    //   499: iload #18
    //   501: istore #35
    //   503: iload #27
    //   505: istore #36
    //   507: iload #22
    //   509: istore #37
    //   511: aload_0
    //   512: aload #25
    //   514: iload #29
    //   516: iload #28
    //   518: iload #30
    //   520: iconst_0
    //   521: invokevirtual onMeasureChild : (Landroid/view/View;IIII)V
    //   524: iload #13
    //   526: aload #25
    //   528: invokevirtual getMeasuredWidth : ()I
    //   531: iadd
    //   532: istore #38
    //   534: aload #32
    //   536: astore #39
    //   538: iload #38
    //   540: aload #39
    //   542: getfield leftMargin : I
    //   545: iadd
    //   546: aload #39
    //   548: getfield rightMargin : I
    //   551: iadd
    //   552: istore #40
    //   554: iload #34
    //   556: iload #40
    //   558: invokestatic max : (II)I
    //   561: istore #41
    //   563: iload #14
    //   565: aload #25
    //   567: invokevirtual getMeasuredHeight : ()I
    //   570: iadd
    //   571: aload #39
    //   573: getfield topMargin : I
    //   576: iadd
    //   577: aload #39
    //   579: getfield bottomMargin : I
    //   582: iadd
    //   583: istore #42
    //   585: iload #36
    //   587: iload #42
    //   589: invokestatic max : (II)I
    //   592: istore #43
    //   594: aload #25
    //   596: invokevirtual getMeasuredState : ()I
    //   599: istore #44
    //   601: iload #33
    //   603: iload #44
    //   605: invokestatic combineMeasuredStates : (II)I
    //   608: istore #45
    //   610: iload #41
    //   612: istore #19
    //   614: iload #45
    //   616: istore #21
    //   618: iload #43
    //   620: istore #20
    //   622: iload #37
    //   624: iconst_1
    //   625: iadd
    //   626: istore #22
    //   628: iload #35
    //   630: istore #18
    //   632: goto -> 149
    //   635: iload #20
    //   637: istore #23
    //   639: iload #21
    //   641: istore #24
    //   643: aload_0
    //   644: iload #19
    //   646: iload_1
    //   647: ldc_w -16777216
    //   650: iload #24
    //   652: iand
    //   653: invokestatic resolveSizeAndState : (III)I
    //   656: iload #23
    //   658: iload_2
    //   659: iload #24
    //   661: bipush #16
    //   663: ishl
    //   664: invokestatic resolveSizeAndState : (III)I
    //   667: invokevirtual setMeasuredDimension : (II)V
    //   670: return
  }
  
  public void onMeasureChild(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    measureChildWithMargins(paramView, paramInt1, paramInt2, paramInt3, paramInt4);
  }
  
  public boolean onNestedFling(View paramView, float paramFloat1, float paramFloat2, boolean paramBoolean) {
    int i = getChildCount();
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isNestedScrollAccepted(0)) {
          Behavior<View> behavior = layoutParams.getBehavior();
          if (behavior != null)
            bool |= behavior.onNestedFling(this, view, paramView, paramFloat1, paramFloat2, paramBoolean); 
        } 
      } 
      b++;
    } 
    if (bool)
      a(1); 
    return bool;
  }
  
  public boolean onNestedPreFling(View paramView, float paramFloat1, float paramFloat2) {
    int i = getChildCount();
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isNestedScrollAccepted(0)) {
          Behavior<View> behavior = layoutParams.getBehavior();
          if (behavior != null)
            bool |= behavior.onNestedPreFling(this, view, paramView, paramFloat1, paramFloat2); 
        } 
      } 
      b++;
    } 
    return bool;
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint) {
    onNestedPreScroll(paramView, paramInt1, paramInt2, paramArrayOfint, 0);
  }
  
  public void onNestedPreScroll(View paramView, int paramInt1, int paramInt2, int[] paramArrayOfint, int paramInt3) {
    int i = getChildCount();
    boolean bool = false;
    byte b = 0;
    int j = 0;
    int k = 0;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isNestedScrollAccepted(paramInt3)) {
          Behavior<View> behavior = layoutParams.getBehavior();
          if (behavior != null) {
            int m;
            int n;
            int[] arrayOfInt = this.mTempIntPair;
            this.mTempIntPair[1] = 0;
            arrayOfInt[0] = 0;
            behavior.onNestedPreScroll(this, view, paramView, paramInt1, paramInt2, this.mTempIntPair, paramInt3);
            if (paramInt1 > 0) {
              m = Math.max(j, this.mTempIntPair[0]);
            } else {
              m = Math.min(j, this.mTempIntPair[0]);
            } 
            if (paramInt2 > 0) {
              n = Math.max(k, this.mTempIntPair[1]);
            } else {
              n = Math.min(k, this.mTempIntPair[1]);
            } 
            j = m;
            k = n;
            bool = true;
          } 
        } 
      } 
      b++;
    } 
    paramArrayOfint[0] = j;
    paramArrayOfint[1] = k;
    if (bool)
      a(1); 
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
    onNestedScroll(paramView, paramInt1, paramInt2, paramInt3, paramInt4, 0);
  }
  
  public void onNestedScroll(View paramView, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
    int i = getChildCount();
    boolean bool = false;
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        if (layoutParams.isNestedScrollAccepted(paramInt5)) {
          Behavior<View> behavior = layoutParams.getBehavior();
          if (behavior != null) {
            behavior.onNestedScroll(this, view, paramView, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
            bool = true;
          } 
        } 
      } 
    } 
    if (bool)
      a(1); 
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt) {
    onNestedScrollAccepted(paramView1, paramView2, paramInt, 0);
  }
  
  public void onNestedScrollAccepted(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    this.mNestedScrollingParentHelper.onNestedScrollAccepted(paramView1, paramView2, paramInt1, paramInt2);
    this.mNestedScrollingTarget = paramView2;
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (layoutParams.isNestedScrollAccepted(paramInt2)) {
        Behavior<View> behavior = layoutParams.getBehavior();
        if (behavior != null)
          behavior.onNestedScrollAccepted(this, view, paramView1, paramView2, paramInt1, paramInt2); 
      } 
    } 
  }
  
  protected void onRestoreInstanceState(Parcelable paramParcelable) {
    if (!(paramParcelable instanceof SavedState)) {
      super.onRestoreInstanceState(paramParcelable);
      return;
    } 
    SavedState savedState = (SavedState)paramParcelable;
    super.onRestoreInstanceState(savedState.getSuperState());
    SparseArray<Parcelable> sparseArray = savedState.a;
    byte b = 0;
    int i = getChildCount();
    while (b < i) {
      View view = getChildAt(b);
      int j = view.getId();
      Behavior<View> behavior = a(view).getBehavior();
      if (j != -1 && behavior != null) {
        Parcelable parcelable = (Parcelable)sparseArray.get(j);
        if (parcelable != null)
          behavior.onRestoreInstanceState(this, view, parcelable); 
      } 
      b++;
    } 
  }
  
  protected Parcelable onSaveInstanceState() {
    SavedState savedState = new SavedState(super.onSaveInstanceState());
    SparseArray<Parcelable> sparseArray = new SparseArray();
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      int j = view.getId();
      Behavior<View> behavior = ((LayoutParams)view.getLayoutParams()).getBehavior();
      if (j != -1 && behavior != null) {
        Parcelable parcelable = behavior.onSaveInstanceState(this, view);
        if (parcelable != null)
          sparseArray.append(j, parcelable); 
      } 
    } 
    savedState.a = sparseArray;
    return (Parcelable)savedState;
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt) {
    return onStartNestedScroll(paramView1, paramView2, paramInt, 0);
  }
  
  public boolean onStartNestedScroll(View paramView1, View paramView2, int paramInt1, int paramInt2) {
    int i = getChildCount();
    byte b = 0;
    boolean bool = false;
    while (b < i) {
      View view = getChildAt(b);
      if (view.getVisibility() != 8) {
        LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
        Behavior<View> behavior = layoutParams.getBehavior();
        if (behavior != null) {
          boolean bool1 = behavior.onStartNestedScroll(this, view, paramView1, paramView2, paramInt1, paramInt2);
          boolean bool2 = bool | bool1;
          layoutParams.setNestedScrollAccepted(paramInt2, bool1);
          bool = bool2;
        } else {
          layoutParams.setNestedScrollAccepted(paramInt2, false);
        } 
      } 
      b++;
    } 
    return bool;
  }
  
  public void onStopNestedScroll(View paramView) {
    onStopNestedScroll(paramView, 0);
  }
  
  public void onStopNestedScroll(View paramView, int paramInt) {
    this.mNestedScrollingParentHelper.onStopNestedScroll(paramView, paramInt);
    int i = getChildCount();
    for (byte b = 0; b < i; b++) {
      View view = getChildAt(b);
      LayoutParams layoutParams = (LayoutParams)view.getLayoutParams();
      if (layoutParams.isNestedScrollAccepted(paramInt)) {
        Behavior<View> behavior = layoutParams.getBehavior();
        if (behavior != null)
          behavior.onStopNestedScroll(this, view, paramView, paramInt); 
        layoutParams.a(paramInt);
        layoutParams.d();
      } 
    } 
    this.mNestedScrollingTarget = null;
  }
  
  public boolean onTouchEvent(MotionEvent paramMotionEvent) {
    // Byte code:
    //   0: aload_1
    //   1: invokevirtual getActionMasked : ()I
    //   4: istore_2
    //   5: aload_0
    //   6: getfield mBehaviorTouchView : Landroid/view/View;
    //   9: ifnonnull -> 32
    //   12: aload_0
    //   13: aload_1
    //   14: iconst_1
    //   15: invokespecial performIntercept : (Landroid/view/MotionEvent;I)Z
    //   18: istore_3
    //   19: iload_3
    //   20: ifeq -> 26
    //   23: goto -> 34
    //   26: iconst_0
    //   27: istore #5
    //   29: goto -> 67
    //   32: iconst_0
    //   33: istore_3
    //   34: aload_0
    //   35: getfield mBehaviorTouchView : Landroid/view/View;
    //   38: invokevirtual getLayoutParams : ()Landroid/view/ViewGroup$LayoutParams;
    //   41: checkcast android/support/design/widget/CoordinatorLayout$LayoutParams
    //   44: invokevirtual getBehavior : ()Landroid/support/design/widget/CoordinatorLayout$Behavior;
    //   47: astore #4
    //   49: aload #4
    //   51: ifnull -> 26
    //   54: aload #4
    //   56: aload_0
    //   57: aload_0
    //   58: getfield mBehaviorTouchView : Landroid/view/View;
    //   61: aload_1
    //   62: invokevirtual onTouchEvent : (Landroid/support/design/widget/CoordinatorLayout;Landroid/view/View;Landroid/view/MotionEvent;)Z
    //   65: istore #5
    //   67: aload_0
    //   68: getfield mBehaviorTouchView : Landroid/view/View;
    //   71: ifnonnull -> 90
    //   74: iload #5
    //   76: aload_0
    //   77: aload_1
    //   78: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   81: ior
    //   82: istore #5
    //   84: aconst_null
    //   85: astore #6
    //   87: goto -> 122
    //   90: aconst_null
    //   91: astore #6
    //   93: iload_3
    //   94: ifeq -> 122
    //   97: invokestatic uptimeMillis : ()J
    //   100: lstore #7
    //   102: lload #7
    //   104: lload #7
    //   106: iconst_3
    //   107: fconst_0
    //   108: fconst_0
    //   109: iconst_0
    //   110: invokestatic obtain : (JJIFFI)Landroid/view/MotionEvent;
    //   113: astore #6
    //   115: aload_0
    //   116: aload #6
    //   118: invokespecial onTouchEvent : (Landroid/view/MotionEvent;)Z
    //   121: pop
    //   122: aload #6
    //   124: ifnull -> 132
    //   127: aload #6
    //   129: invokevirtual recycle : ()V
    //   132: iload_2
    //   133: iconst_1
    //   134: if_icmpeq -> 142
    //   137: iload_2
    //   138: iconst_3
    //   139: if_icmpne -> 147
    //   142: aload_0
    //   143: iconst_0
    //   144: invokespecial resetTouchBehaviors : (Z)V
    //   147: iload #5
    //   149: ireturn
  }
  
  public boolean requestChildRectangleOnScreen(View paramView, Rect paramRect, boolean paramBoolean) {
    Behavior<View> behavior = ((LayoutParams)paramView.getLayoutParams()).getBehavior();
    return (behavior != null && behavior.onRequestChildRectangleOnScreen(this, paramView, paramRect, paramBoolean)) ? true : super.requestChildRectangleOnScreen(paramView, paramRect, paramBoolean);
  }
  
  public void requestDisallowInterceptTouchEvent(boolean paramBoolean) {
    super.requestDisallowInterceptTouchEvent(paramBoolean);
    if (paramBoolean && !this.mDisallowInterceptReset) {
      resetTouchBehaviors(false);
      this.mDisallowInterceptReset = true;
    } 
  }
  
  public void setFitsSystemWindows(boolean paramBoolean) {
    super.setFitsSystemWindows(paramBoolean);
    setupForInsets();
  }
  
  public void setOnHierarchyChangeListener(ViewGroup.OnHierarchyChangeListener paramOnHierarchyChangeListener) {
    this.e = paramOnHierarchyChangeListener;
  }
  
  public void setStatusBarBackground(@Nullable Drawable paramDrawable) {
    if (this.mStatusBarBackground != paramDrawable) {
      if (this.mStatusBarBackground != null)
        this.mStatusBarBackground.setCallback(null); 
      Drawable drawable = null;
      if (paramDrawable != null)
        drawable = paramDrawable.mutate(); 
      this.mStatusBarBackground = drawable;
      if (this.mStatusBarBackground != null) {
        boolean bool;
        if (this.mStatusBarBackground.isStateful())
          this.mStatusBarBackground.setState(getDrawableState()); 
        DrawableCompat.setLayoutDirection(this.mStatusBarBackground, ViewCompat.getLayoutDirection((View)this));
        Drawable drawable1 = this.mStatusBarBackground;
        if (getVisibility() == 0) {
          bool = true;
        } else {
          bool = false;
        } 
        drawable1.setVisible(bool, false);
        this.mStatusBarBackground.setCallback((Drawable.Callback)this);
      } 
      ViewCompat.postInvalidateOnAnimation((View)this);
    } 
  }
  
  public void setStatusBarBackgroundColor(@ColorInt int paramInt) {
    setStatusBarBackground((Drawable)new ColorDrawable(paramInt));
  }
  
  public void setStatusBarBackgroundResource(@DrawableRes int paramInt) {
    Drawable drawable;
    if (paramInt != 0) {
      drawable = ContextCompat.getDrawable(getContext(), paramInt);
    } else {
      drawable = null;
    } 
    setStatusBarBackground(drawable);
  }
  
  public void setVisibility(int paramInt) {
    boolean bool;
    super.setVisibility(paramInt);
    if (paramInt == 0) {
      bool = true;
    } else {
      bool = false;
    } 
    if (this.mStatusBarBackground != null && this.mStatusBarBackground.isVisible() != bool)
      this.mStatusBarBackground.setVisible(bool, false); 
  }
  
  protected boolean verifyDrawable(Drawable paramDrawable) {
    return (super.verifyDrawable(paramDrawable) || paramDrawable == this.mStatusBarBackground);
  }
  
  static {
    String str;
    Package package_ = CoordinatorLayout.class.getPackage();
    if (package_ != null) {
      str = package_.getName();
    } else {
      str = null;
    } 
    a = str;
    if (Build.VERSION.SDK_INT >= 21) {
      d = new ViewElevationComparator();
    } else {
      d = null;
    } 
  }
  
  public static interface AttachedBehavior {
    @NonNull
    CoordinatorLayout.Behavior getBehavior();
  }
  
  public static abstract class Behavior<V extends View> {
    public Behavior() {}
    
    public Behavior(Context param1Context, AttributeSet param1AttributeSet) {}
    
    public static Object getTag(View param1View) {
      return ((CoordinatorLayout.LayoutParams)param1View.getLayoutParams()).i;
    }
    
    public static void setTag(View param1View, Object param1Object) {
      ((CoordinatorLayout.LayoutParams)param1View.getLayoutParams()).i = param1Object;
    }
    
    public boolean blocksInteractionBelow(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (getScrimOpacity(param1CoordinatorLayout, param1V) > 0.0F);
    }
    
    public boolean getInsetDodgeRect(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull Rect param1Rect) {
      return false;
    }
    
    @ColorInt
    public int getScrimColor(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return -16777216;
    }
    
    @FloatRange(from = 0.0D, to = 1.0D)
    public float getScrimOpacity(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return 0.0F;
    }
    
    public boolean layoutDependsOn(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    @NonNull
    public WindowInsetsCompat onApplyWindowInsets(CoordinatorLayout param1CoordinatorLayout, V param1V, WindowInsetsCompat param1WindowInsetsCompat) {
      return param1WindowInsetsCompat;
    }
    
    public void onAttachedToLayoutParams(@NonNull CoordinatorLayout.LayoutParams param1LayoutParams) {}
    
    public boolean onDependentViewChanged(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {
      return false;
    }
    
    public void onDependentViewRemoved(CoordinatorLayout param1CoordinatorLayout, V param1V, View param1View) {}
    
    public void onDetachedFromLayoutParams() {}
    
    public boolean onInterceptTouchEvent(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
    
    public boolean onLayoutChild(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int) {
      return false;
    }
    
    public boolean onMeasureChild(CoordinatorLayout param1CoordinatorLayout, V param1V, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {
      return false;
    }
    
    public boolean onNestedFling(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, float param1Float1, float param1Float2, boolean param1Boolean) {
      return false;
    }
    
    public boolean onNestedPreFling(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, float param1Float1, float param1Float2) {
      return false;
    }
    
    @Deprecated
    public void onNestedPreScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, int param1Int1, int param1Int2, @NonNull int[] param1ArrayOfint) {}
    
    public void onNestedPreScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, int param1Int1, int param1Int2, @NonNull int[] param1ArrayOfint, int param1Int3) {
      if (param1Int3 == 0)
        onNestedPreScroll(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1ArrayOfint); 
    }
    
    @Deprecated
    public void onNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4) {}
    
    public void onNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, int param1Int1, int param1Int2, int param1Int3, int param1Int4, int param1Int5) {
      if (param1Int5 == 0)
        onNestedScroll(param1CoordinatorLayout, param1V, param1View, param1Int1, param1Int2, param1Int3, param1Int4); 
    }
    
    @Deprecated
    public void onNestedScrollAccepted(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View1, @NonNull View param1View2, int param1Int) {}
    
    public void onNestedScrollAccepted(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View1, @NonNull View param1View2, int param1Int1, int param1Int2) {
      if (param1Int2 == 0)
        onNestedScrollAccepted(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1); 
    }
    
    public boolean onRequestChildRectangleOnScreen(CoordinatorLayout param1CoordinatorLayout, V param1V, Rect param1Rect, boolean param1Boolean) {
      return false;
    }
    
    public void onRestoreInstanceState(CoordinatorLayout param1CoordinatorLayout, V param1V, Parcelable param1Parcelable) {}
    
    public Parcelable onSaveInstanceState(CoordinatorLayout param1CoordinatorLayout, V param1V) {
      return (Parcelable)View.BaseSavedState.EMPTY_STATE;
    }
    
    @Deprecated
    public boolean onStartNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View1, @NonNull View param1View2, int param1Int) {
      return false;
    }
    
    public boolean onStartNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View1, @NonNull View param1View2, int param1Int1, int param1Int2) {
      return (param1Int2 == 0) ? onStartNestedScroll(param1CoordinatorLayout, param1V, param1View1, param1View2, param1Int1) : false;
    }
    
    @Deprecated
    public void onStopNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View) {}
    
    public void onStopNestedScroll(@NonNull CoordinatorLayout param1CoordinatorLayout, @NonNull V param1V, @NonNull View param1View, int param1Int) {
      if (param1Int == 0)
        onStopNestedScroll(param1CoordinatorLayout, param1V, param1View); 
    }
    
    public boolean onTouchEvent(CoordinatorLayout param1CoordinatorLayout, V param1V, MotionEvent param1MotionEvent) {
      return false;
    }
  }
  
  @Deprecated
  @Retention(RetentionPolicy.RUNTIME)
  public static @interface DefaultBehavior {
    Class<? extends CoordinatorLayout.Behavior> value();
  }
  
  @Retention(RetentionPolicy.SOURCE)
  @RestrictTo({RestrictTo.Scope.LIBRARY_GROUP})
  public static @interface DispatchChangeEvent {}
  
  private class HierarchyChangeListener implements ViewGroup.OnHierarchyChangeListener {
    HierarchyChangeListener(CoordinatorLayout this$0) {}
    
    public void onChildViewAdded(View param1View1, View param1View2) {
      if (this.a.e != null)
        this.a.e.onChildViewAdded(param1View1, param1View2); 
    }
    
    public void onChildViewRemoved(View param1View1, View param1View2) {
      this.a.a(2);
      if (this.a.e != null)
        this.a.e.onChildViewRemoved(param1View1, param1View2); 
    }
  }
  
  public static class LayoutParams extends ViewGroup.MarginLayoutParams {
    CoordinatorLayout.Behavior a;
    
    public int anchorGravity = 0;
    
    boolean b = false;
    
    int c = -1;
    
    int d;
    
    public int dodgeInsetEdges = 0;
    
    int e;
    
    View f;
    
    View g;
    
    public int gravity = 0;
    
    final Rect h = new Rect();
    
    Object i;
    
    public int insetEdge = 0;
    
    public int keyline = -1;
    
    private boolean mDidAcceptNestedScrollNonTouch;
    
    private boolean mDidAcceptNestedScrollTouch;
    
    private boolean mDidBlockInteraction;
    
    private boolean mDidChangeAfterNestedScroll;
    
    public LayoutParams(int param1Int1, int param1Int2) {
      super(param1Int1, param1Int2);
    }
    
    LayoutParams(Context param1Context, AttributeSet param1AttributeSet) {
      super(param1Context, param1AttributeSet);
      TypedArray typedArray = param1Context.obtainStyledAttributes(param1AttributeSet, R.styleable.CoordinatorLayout_Layout);
      this.gravity = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_android_layout_gravity, 0);
      this.c = typedArray.getResourceId(R.styleable.CoordinatorLayout_Layout_layout_anchor, -1);
      this.anchorGravity = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_layout_anchorGravity, 0);
      this.keyline = typedArray.getInteger(R.styleable.CoordinatorLayout_Layout_layout_keyline, -1);
      this.insetEdge = typedArray.getInt(R.styleable.CoordinatorLayout_Layout_layout_insetEdge, 0);
      this.dodgeInsetEdges = typedArray.getInt(R.styleable.CoordinatorLayout_Layout_layout_dodgeInsetEdges, 0);
      this.b = typedArray.hasValue(R.styleable.CoordinatorLayout_Layout_layout_behavior);
      if (this.b)
        this.a = CoordinatorLayout.a(param1Context, param1AttributeSet, typedArray.getString(R.styleable.CoordinatorLayout_Layout_layout_behavior)); 
      typedArray.recycle();
      if (this.a != null)
        this.a.onAttachedToLayoutParams(this); 
    }
    
    public LayoutParams(LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.LayoutParams param1LayoutParams) {
      super(param1LayoutParams);
    }
    
    public LayoutParams(ViewGroup.MarginLayoutParams param1MarginLayoutParams) {
      super(param1MarginLayoutParams);
    }
    
    private void resolveAnchorView(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      this.f = param1CoordinatorLayout.findViewById(this.c);
      if (this.f != null) {
        if (this.f == param1CoordinatorLayout) {
          if (param1CoordinatorLayout.isInEditMode()) {
            this.g = null;
            this.f = null;
            return;
          } 
          throw new IllegalStateException("View can not be anchored to the the parent CoordinatorLayout");
        } 
        View view = this.f;
        for (ViewParent viewParent = this.f.getParent(); viewParent != param1CoordinatorLayout && viewParent != null; viewParent = viewParent.getParent()) {
          if (viewParent == param1View) {
            if (param1CoordinatorLayout.isInEditMode()) {
              this.g = null;
              this.f = null;
              return;
            } 
            throw new IllegalStateException("Anchor must not be a descendant of the anchored view");
          } 
          if (viewParent instanceof View)
            view = (View)viewParent; 
        } 
        this.g = view;
        return;
      } 
      if (param1CoordinatorLayout.isInEditMode()) {
        this.g = null;
        this.f = null;
        return;
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Could not find CoordinatorLayout descendant view with id ");
      stringBuilder.append(param1CoordinatorLayout.getResources().getResourceName(this.c));
      stringBuilder.append(" to anchor view ");
      stringBuilder.append(param1View);
      throw new IllegalStateException(stringBuilder.toString());
    }
    
    private boolean shouldDodge(View param1View, int param1Int) {
      int i = GravityCompat.getAbsoluteGravity(((LayoutParams)param1View.getLayoutParams()).insetEdge, param1Int);
      return (i != 0 && (i & GravityCompat.getAbsoluteGravity(this.dodgeInsetEdges, param1Int)) == i);
    }
    
    private boolean verifyAnchorView(View param1View, CoordinatorLayout param1CoordinatorLayout) {
      if (this.f.getId() != this.c)
        return false; 
      View view = this.f;
      for (ViewParent viewParent = this.f.getParent(); viewParent != param1CoordinatorLayout; viewParent = viewParent.getParent()) {
        if (viewParent == null || viewParent == param1View) {
          this.g = null;
          this.f = null;
          return false;
        } 
        if (viewParent instanceof View)
          view = (View)viewParent; 
      } 
      this.g = view;
      return true;
    }
    
    void a(int param1Int) {
      setNestedScrollAccepted(param1Int, false);
    }
    
    boolean a() {
      return (this.f == null && this.c != -1);
    }
    
    boolean a(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      boolean bool2;
      if (this.mDidBlockInteraction)
        return true; 
      boolean bool1 = this.mDidBlockInteraction;
      if (this.a != null) {
        bool2 = this.a.blocksInteractionBelow(param1CoordinatorLayout, param1View);
      } else {
        bool2 = false;
      } 
      boolean bool3 = bool2 | bool1;
      this.mDidBlockInteraction = bool3;
      return bool3;
    }
    
    boolean a(CoordinatorLayout param1CoordinatorLayout, View param1View1, View param1View2) {
      return (param1View2 == this.g || shouldDodge(param1View2, ViewCompat.getLayoutDirection((View)param1CoordinatorLayout)) || (this.a != null && this.a.layoutDependsOn(param1CoordinatorLayout, param1View1, param1View2)));
    }
    
    View b(CoordinatorLayout param1CoordinatorLayout, View param1View) {
      if (this.c == -1) {
        this.g = null;
        this.f = null;
        return null;
      } 
      if (this.f == null || !verifyAnchorView(param1View, param1CoordinatorLayout))
        resolveAnchorView(param1View, param1CoordinatorLayout); 
      return this.f;
    }
    
    boolean b() {
      if (this.a == null)
        this.mDidBlockInteraction = false; 
      return this.mDidBlockInteraction;
    }
    
    void c() {
      this.mDidBlockInteraction = false;
    }
    
    void d() {
      this.mDidChangeAfterNestedScroll = false;
    }
    
    void e() {
      this.g = null;
      this.f = null;
    }
    
    @IdRes
    public int getAnchorId() {
      return this.c;
    }
    
    @Nullable
    public CoordinatorLayout.Behavior getBehavior() {
      return this.a;
    }
    
    boolean getChangedAfterNestedScroll() {
      return this.mDidChangeAfterNestedScroll;
    }
    
    Rect getLastChildRect() {
      return this.h;
    }
    
    boolean isNestedScrollAccepted(int param1Int) {
      switch (param1Int) {
        default:
          return false;
        case 1:
          return this.mDidAcceptNestedScrollNonTouch;
        case 0:
          break;
      } 
      return this.mDidAcceptNestedScrollTouch;
    }
    
    public void setAnchorId(@IdRes int param1Int) {
      e();
      this.c = param1Int;
    }
    
    public void setBehavior(@Nullable CoordinatorLayout.Behavior param1Behavior) {
      if (this.a != param1Behavior) {
        if (this.a != null)
          this.a.onDetachedFromLayoutParams(); 
        this.a = param1Behavior;
        this.i = null;
        this.b = true;
        if (param1Behavior != null)
          param1Behavior.onAttachedToLayoutParams(this); 
      } 
    }
    
    void setChangedAfterNestedScroll(boolean param1Boolean) {
      this.mDidChangeAfterNestedScroll = param1Boolean;
    }
    
    void setLastChildRect(Rect param1Rect) {
      this.h.set(param1Rect);
    }
    
    void setNestedScrollAccepted(int param1Int, boolean param1Boolean) {
      switch (param1Int) {
        default:
          return;
        case 1:
          this.mDidAcceptNestedScrollNonTouch = param1Boolean;
          return;
        case 0:
          break;
      } 
      this.mDidAcceptNestedScrollTouch = param1Boolean;
    }
  }
  
  class OnPreDrawListener implements ViewTreeObserver.OnPreDrawListener {
    OnPreDrawListener(CoordinatorLayout this$0) {}
    
    public boolean onPreDraw() {
      this.a.a(0);
      return true;
    }
  }
  
  protected static class SavedState extends AbsSavedState {
    public static final Parcelable.Creator<SavedState> CREATOR = (Parcelable.Creator<SavedState>)new Parcelable.ClassLoaderCreator<SavedState>() {
        public CoordinatorLayout.SavedState createFromParcel(Parcel param2Parcel) {
          return new CoordinatorLayout.SavedState(param2Parcel, null);
        }
        
        public CoordinatorLayout.SavedState createFromParcel(Parcel param2Parcel, ClassLoader param2ClassLoader) {
          return new CoordinatorLayout.SavedState(param2Parcel, param2ClassLoader);
        }
        
        public CoordinatorLayout.SavedState[] newArray(int param2Int) {
          return new CoordinatorLayout.SavedState[param2Int];
        }
      };
    
    SparseArray<Parcelable> a;
    
    public SavedState(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      super(param1Parcel, param1ClassLoader);
      int i = param1Parcel.readInt();
      int[] arrayOfInt = new int[i];
      param1Parcel.readIntArray(arrayOfInt);
      Parcelable[] arrayOfParcelable = param1Parcel.readParcelableArray(param1ClassLoader);
      this.a = new SparseArray(i);
      for (byte b = 0; b < i; b++)
        this.a.append(arrayOfInt[b], arrayOfParcelable[b]); 
    }
    
    public SavedState(Parcelable param1Parcelable) {
      super(param1Parcelable);
    }
    
    public void writeToParcel(Parcel param1Parcel, int param1Int) {
      byte b2;
      super.writeToParcel(param1Parcel, param1Int);
      SparseArray<Parcelable> sparseArray = this.a;
      byte b1 = 0;
      if (sparseArray != null) {
        b2 = this.a.size();
      } else {
        b2 = 0;
      } 
      param1Parcel.writeInt(b2);
      int[] arrayOfInt = new int[b2];
      Parcelable[] arrayOfParcelable = new Parcelable[b2];
      while (b1 < b2) {
        arrayOfInt[b1] = this.a.keyAt(b1);
        arrayOfParcelable[b1] = (Parcelable)this.a.valueAt(b1);
        b1++;
      } 
      param1Parcel.writeIntArray(arrayOfInt);
      param1Parcel.writeParcelableArray(arrayOfParcelable, param1Int);
    }
  }
  
  static final class null implements Parcelable.ClassLoaderCreator<SavedState> {
    public CoordinatorLayout.SavedState createFromParcel(Parcel param1Parcel) {
      return new CoordinatorLayout.SavedState(param1Parcel, null);
    }
    
    public CoordinatorLayout.SavedState createFromParcel(Parcel param1Parcel, ClassLoader param1ClassLoader) {
      return new CoordinatorLayout.SavedState(param1Parcel, param1ClassLoader);
    }
    
    public CoordinatorLayout.SavedState[] newArray(int param1Int) {
      return new CoordinatorLayout.SavedState[param1Int];
    }
  }
  
  static class ViewElevationComparator implements Comparator<View> {
    public int compare(View param1View1, View param1View2) {
      float f1 = ViewCompat.getZ(param1View1);
      float f2 = ViewCompat.getZ(param1View2);
      return (f1 > f2) ? -1 : ((f1 < f2) ? 1 : 0);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\design\widget\CoordinatorLayout.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */