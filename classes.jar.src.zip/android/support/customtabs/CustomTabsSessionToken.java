package android.support.customtabs;

import android.content.Intent;
import android.os.Bundle;
import android.os.IBinder;
import android.os.RemoteException;
import android.support.v4.app.BundleCompat;
import android.util.Log;

public class CustomTabsSessionToken {
  private static final String TAG = "CustomTabsSessionToken";
  
  private final CustomTabsCallback mCallback;
  
  private final ICustomTabsCallback mCallbackBinder;
  
  CustomTabsSessionToken(ICustomTabsCallback paramICustomTabsCallback) {
    this.mCallbackBinder = paramICustomTabsCallback;
    this.mCallback = new CustomTabsCallback(this) {
        public void onNavigationEvent(int param1Int, Bundle param1Bundle) {
          try {
            CustomTabsSessionToken.a(this.a).onNavigationEvent(param1Int, param1Bundle);
            return;
          } catch (RemoteException remoteException) {
            Log.e("CustomTabsSessionToken", "RemoteException during ICustomTabsCallback transaction");
            return;
          } 
        }
      };
  }
  
  public static CustomTabsSessionToken getSessionTokenFromIntent(Intent paramIntent) {
    IBinder iBinder = BundleCompat.getBinder(paramIntent.getExtras(), "android.support.customtabs.extra.SESSION");
    return (iBinder == null) ? null : new CustomTabsSessionToken(ICustomTabsCallback.Stub.asInterface(iBinder));
  }
  
  public boolean equals(Object paramObject) {
    return !(paramObject instanceof CustomTabsSessionToken) ? false : ((CustomTabsSessionToken)paramObject).getCallbackBinder().equals(this.mCallbackBinder.asBinder());
  }
  
  public CustomTabsCallback getCallback() {
    return this.mCallback;
  }
  
  IBinder getCallbackBinder() {
    return this.mCallbackBinder.asBinder();
  }
  
  public int hashCode() {
    return getCallbackBinder().hashCode();
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\customtabs\CustomTabsSessionToken.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */