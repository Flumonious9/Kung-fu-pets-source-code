package android.support.customtabs;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.RemoteException;
import android.support.annotation.Nullable;
import android.support.annotation.RestrictTo;
import android.text.TextUtils;
import java.util.ArrayList;
import java.util.List;

public class CustomTabsClient {
  private final ICustomTabsService mService;
  
  private final ComponentName mServiceComponentName;
  
  @RestrictTo({RestrictTo.Scope.GROUP_ID})
  CustomTabsClient(ICustomTabsService paramICustomTabsService, ComponentName paramComponentName) {
    this.mService = paramICustomTabsService;
    this.mServiceComponentName = paramComponentName;
  }
  
  public static boolean bindCustomTabsService(Context paramContext, String paramString, CustomTabsServiceConnection paramCustomTabsServiceConnection) {
    Intent intent = new Intent("android.support.customtabs.action.CustomTabsService");
    if (!TextUtils.isEmpty(paramString))
      intent.setPackage(paramString); 
    return paramContext.bindService(intent, paramCustomTabsServiceConnection, 33);
  }
  
  public static boolean connectAndInitialize(Context paramContext, String paramString) {
    if (paramString == null)
      return false; 
    Context context = paramContext.getApplicationContext();
    CustomTabsServiceConnection customTabsServiceConnection = new CustomTabsServiceConnection(context) {
        public final void onCustomTabsServiceConnected(ComponentName param1ComponentName, CustomTabsClient param1CustomTabsClient) {
          param1CustomTabsClient.warmup(0L);
          this.a.unbindService(this);
        }
        
        public final void onServiceDisconnected(ComponentName param1ComponentName) {}
      };
    try {
      return bindCustomTabsService(context, paramString, customTabsServiceConnection);
    } catch (SecurityException securityException) {
      return false;
    } 
  }
  
  public static String getPackageName(Context paramContext, @Nullable List<String> paramList) {
    return getPackageName(paramContext, paramList, false);
  }
  
  public static String getPackageName(Context paramContext, @Nullable List<String> paramList, boolean paramBoolean) {
    List<String> list;
    PackageManager packageManager = paramContext.getPackageManager();
    if (paramList == null) {
      list = new ArrayList();
    } else {
      list = paramList;
    } 
    Intent intent1 = new Intent("android.intent.action.VIEW", Uri.parse("http://"));
    if (!paramBoolean) {
      ResolveInfo resolveInfo = packageManager.resolveActivity(intent1, 0);
      if (resolveInfo != null) {
        String str = resolveInfo.activityInfo.packageName;
        ArrayList<String> arrayList = new ArrayList(1 + list.size());
        arrayList.add(str);
        if (paramList != null)
          arrayList.addAll(paramList); 
        list = arrayList;
      } 
    } 
    Intent intent2 = new Intent("android.support.customtabs.action.CustomTabsService");
    for (String str : list) {
      intent2.setPackage(str);
      if (packageManager.resolveService(intent2, 0) != null)
        return str; 
    } 
    return null;
  }
  
  public Bundle extraCommand(String paramString, Bundle paramBundle) {
    try {
      return this.mService.extraCommand(paramString, paramBundle);
    } catch (RemoteException remoteException) {
      return null;
    } 
  }
  
  public CustomTabsSession newSession(CustomTabsCallback paramCustomTabsCallback) {
    ICustomTabsCallback.Stub stub = new ICustomTabsCallback.Stub(this, paramCustomTabsCallback) {
        public void extraCallback(String param1String, Bundle param1Bundle) {
          if (this.a != null)
            this.a.extraCallback(param1String, param1Bundle); 
        }
        
        public void onNavigationEvent(int param1Int, Bundle param1Bundle) {
          if (this.a != null)
            this.a.onNavigationEvent(param1Int, param1Bundle); 
        }
      };
    try {
      boolean bool = this.mService.newSession(stub);
      return !bool ? null : new CustomTabsSession(this.mService, stub, this.mServiceComponentName);
    } catch (RemoteException remoteException) {
      return null;
    } 
  }
  
  public boolean warmup(long paramLong) {
    try {
      return this.mService.warmup(paramLong);
    } catch (RemoteException remoteException) {
      return false;
    } 
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\customtabs\CustomTabsClient.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */