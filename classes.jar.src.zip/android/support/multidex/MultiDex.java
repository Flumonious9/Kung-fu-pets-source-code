package android.support.multidex;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.os.Build;
import android.util.Log;
import dalvik.system.DexFile;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Array;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;
import java.util.zip.ZipFile;

public final class MultiDex {
  private static final String CODE_CACHE_NAME = "code_cache";
  
  private static final String CODE_CACHE_SECONDARY_FOLDER_NAME = "secondary-dexes";
  
  private static final boolean IS_VM_MULTIDEX_CAPABLE = false;
  
  private static final int MAX_SUPPORTED_SDK_VERSION = 20;
  
  private static final int MIN_SDK_VERSION = 4;
  
  private static final String NO_KEY_PREFIX = "";
  
  private static final String OLD_SECONDARY_FOLDER_NAME = "secondary-dexes";
  
  private static final int VM_WITH_MULTIDEX_VERSION_MAJOR = 2;
  
  private static final int VM_WITH_MULTIDEX_VERSION_MINOR = 1;
  
  private static final Set<File> installedApk = new HashSet<File>();
  
  static {
    IS_VM_MULTIDEX_CAPABLE = a(System.getProperty("java.vm.version"));
  }
  
  static boolean a(String paramString) {
    // Byte code:
    //   0: iconst_0
    //   1: istore_1
    //   2: aload_0
    //   3: ifnull -> 70
    //   6: ldc '(\d+)\.(\d+)(\.\d+)?'
    //   8: invokestatic compile : (Ljava/lang/String;)Ljava/util/regex/Pattern;
    //   11: aload_0
    //   12: invokevirtual matcher : (Ljava/lang/CharSequence;)Ljava/util/regex/Matcher;
    //   15: astore #9
    //   17: aload #9
    //   19: invokevirtual matches : ()Z
    //   22: ifeq -> 70
    //   25: aload #9
    //   27: iconst_1
    //   28: invokevirtual group : (I)Ljava/lang/String;
    //   31: invokestatic parseInt : (Ljava/lang/String;)I
    //   34: istore #10
    //   36: aload #9
    //   38: iconst_2
    //   39: invokevirtual group : (I)Ljava/lang/String;
    //   42: invokestatic parseInt : (Ljava/lang/String;)I
    //   45: istore #11
    //   47: iload #10
    //   49: iconst_2
    //   50: if_icmpgt -> 65
    //   53: iload #10
    //   55: iconst_2
    //   56: if_icmpne -> 70
    //   59: iload #11
    //   61: iconst_1
    //   62: if_icmplt -> 70
    //   65: iconst_1
    //   66: istore_1
    //   67: goto -> 71
    //   70: pop
    //   71: new java/lang/StringBuilder
    //   74: dup
    //   75: invokespecial <init> : ()V
    //   78: astore_3
    //   79: aload_3
    //   80: ldc 'VM with version '
    //   82: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   85: pop
    //   86: aload_3
    //   87: aload_0
    //   88: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   91: pop
    //   92: iload_1
    //   93: ifeq -> 103
    //   96: ldc ' has multidex support'
    //   98: astore #6
    //   100: goto -> 107
    //   103: ldc ' does not have multidex support'
    //   105: astore #6
    //   107: aload_3
    //   108: aload #6
    //   110: invokevirtual append : (Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   113: pop
    //   114: ldc 'MultiDex'
    //   116: aload_3
    //   117: invokevirtual toString : ()Ljava/lang/String;
    //   120: invokestatic i : (Ljava/lang/String;Ljava/lang/String;)I
    //   123: pop
    //   124: iload_1
    //   125: ireturn
    // Exception table:
    //   from	to	target	type
    //   25	47	70	java/lang/NumberFormatException
  }
  
  private static void clearOldDexDir(Context paramContext) {
    File file = new File(paramContext.getFilesDir(), "secondary-dexes");
    if (file.isDirectory()) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("Clearing old secondary dex dir (");
      stringBuilder1.append(file.getPath());
      stringBuilder1.append(").");
      Log.i("MultiDex", stringBuilder1.toString());
      File[] arrayOfFile = file.listFiles();
      if (arrayOfFile == null) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to list secondary dex dir content (");
        stringBuilder.append(file.getPath());
        stringBuilder.append(").");
        Log.w("MultiDex", stringBuilder.toString());
        return;
      } 
      int i = arrayOfFile.length;
      for (byte b = 0; b < i; b++) {
        File file1 = arrayOfFile[b];
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Trying to delete old file ");
        stringBuilder.append(file1.getPath());
        stringBuilder.append(" of size ");
        stringBuilder.append(file1.length());
        Log.i("MultiDex", stringBuilder.toString());
        if (!file1.delete()) {
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("Failed to delete old file ");
          stringBuilder3.append(file1.getPath());
          Log.w("MultiDex", stringBuilder3.toString());
        } else {
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("Deleted old file ");
          stringBuilder3.append(file1.getPath());
          Log.i("MultiDex", stringBuilder3.toString());
        } 
      } 
      if (!file.delete()) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("Failed to delete secondary dex dir ");
        stringBuilder.append(file.getPath());
        Log.w("MultiDex", stringBuilder.toString());
        return;
      } 
      StringBuilder stringBuilder2 = new StringBuilder();
      stringBuilder2.append("Deleted old secondary dex dir ");
      stringBuilder2.append(file.getPath());
      Log.i("MultiDex", stringBuilder2.toString());
    } 
  }
  
  private static void doInstallation(Context paramContext, File paramFile1, File paramFile2, String paramString1, String paramString2, boolean paramBoolean) {
    synchronized (installedApk) {
      if (installedApk.contains(paramFile1))
        return; 
      installedApk.add(paramFile1);
      if (Build.VERSION.SDK_INT > 20) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append("MultiDex is not guaranteed to work in SDK version ");
        stringBuilder.append(Build.VERSION.SDK_INT);
        stringBuilder.append(": SDK version higher than ");
        stringBuilder.append(20);
        stringBuilder.append(" should be backed by ");
        stringBuilder.append("runtime with built-in multidex capabilty but it's not the ");
        stringBuilder.append("case here: java.vm.version=\"");
        stringBuilder.append(System.getProperty("java.vm.version"));
        stringBuilder.append("\"");
        Log.w("MultiDex", stringBuilder.toString());
      } 
      try {
        ClassLoader classLoader = paramContext.getClassLoader();
        if (classLoader == null) {
          Log.e("MultiDex", "Context class loader is null. Must be running in test mode. Skip patching.");
          return;
        } 
        try {
          clearOldDexDir(paramContext);
        } catch (Throwable throwable) {
          Log.w("MultiDex", "Something went wrong when trying to clear old MultiDex extraction, continuing without cleaning.", throwable);
        } 
        File file = getDexDir(paramContext, paramFile2, paramString1);
        MultiDexExtractor multiDexExtractor = new MultiDexExtractor(paramFile1, file);
        try {
          List<? extends File> list = multiDexExtractor.a(paramContext, paramString2, false);
          try {
            installSecondaryDexes(classLoader, file, list);
          } catch (IOException iOException1) {
            if (paramBoolean) {
              Log.w("MultiDex", "Failed to install extracted secondary dex files, retrying with forced extraction", iOException1);
              installSecondaryDexes(classLoader, file, multiDexExtractor.a(paramContext, paramString2, true));
            } else {
              throw iOException1;
            } 
          } 
          try {
            multiDexExtractor.close();
            iOException = null;
          } catch (IOException iOException) {}
          if (iOException == null)
            return; 
          throw iOException;
        } finally {
          try {
            multiDexExtractor.close();
          } catch (IOException iOException) {}
        } 
      } catch (RuntimeException runtimeException) {
        Log.w("MultiDex", "Failure while trying to obtain Context class loader. Must be running in test mode. Skip patching.", runtimeException);
        return;
      } 
    } 
  }
  
  private static void expandFieldArray(Object paramObject, String paramString, Object[] paramArrayOfObject) {
    Field field = findField(paramObject, paramString);
    Object[] arrayOfObject1 = (Object[])field.get(paramObject);
    Object[] arrayOfObject2 = (Object[])Array.newInstance(arrayOfObject1.getClass().getComponentType(), arrayOfObject1.length + paramArrayOfObject.length);
    System.arraycopy(arrayOfObject1, 0, arrayOfObject2, 0, arrayOfObject1.length);
    System.arraycopy(paramArrayOfObject, 0, arrayOfObject2, arrayOfObject1.length, paramArrayOfObject.length);
    field.set(paramObject, arrayOfObject2);
  }
  
  private static Field findField(Object paramObject, String paramString) {
    Class<?> clazz = paramObject.getClass();
    while (clazz != null) {
      try {
        Field field = clazz.getDeclaredField(paramString);
        if (!field.isAccessible())
          field.setAccessible(true); 
        return field;
      } catch (NoSuchFieldException noSuchFieldException) {
        clazz = clazz.getSuperclass();
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Field ");
    stringBuilder.append(paramString);
    stringBuilder.append(" not found in ");
    stringBuilder.append(paramObject.getClass());
    throw new NoSuchFieldException(stringBuilder.toString());
  }
  
  private static Method findMethod(Object paramObject, String paramString, Class<?>... paramVarArgs) {
    Class<?> clazz = paramObject.getClass();
    while (clazz != null) {
      try {
        Method method = clazz.getDeclaredMethod(paramString, paramVarArgs);
        if (!method.isAccessible())
          method.setAccessible(true); 
        return method;
      } catch (NoSuchMethodException noSuchMethodException) {
        clazz = clazz.getSuperclass();
      } 
    } 
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("Method ");
    stringBuilder.append(paramString);
    stringBuilder.append(" with parameters ");
    stringBuilder.append(Arrays.asList(paramVarArgs));
    stringBuilder.append(" not found in ");
    stringBuilder.append(paramObject.getClass());
    throw new NoSuchMethodException(stringBuilder.toString());
  }
  
  private static ApplicationInfo getApplicationInfo(Context paramContext) {
    try {
      return paramContext.getApplicationInfo();
    } catch (RuntimeException runtimeException) {
      Log.w("MultiDex", "Failure while trying to obtain ApplicationInfo from Context. Must be running in test mode. Skip patching.", runtimeException);
      return null;
    } 
  }
  
  private static File getDexDir(Context paramContext, File paramFile, String paramString) {
    File file1 = new File(paramFile, "code_cache");
    try {
      mkdirChecked(file1);
    } catch (IOException iOException) {
      file1 = new File(paramContext.getFilesDir(), "code_cache");
      mkdirChecked(file1);
    } 
    File file2 = new File(file1, paramString);
    mkdirChecked(file2);
    return file2;
  }
  
  public static void install(Context paramContext) {
    Log.i("MultiDex", "Installing application");
    if (IS_VM_MULTIDEX_CAPABLE) {
      Log.i("MultiDex", "VM has multidex support, MultiDex support library is disabled.");
      return;
    } 
    if (Build.VERSION.SDK_INT >= 4)
      try {
        ApplicationInfo applicationInfo = getApplicationInfo(paramContext);
        if (applicationInfo == null) {
          Log.i("MultiDex", "No ApplicationInfo available, i.e. running on a test Context: MultiDex support library is disabled.");
          return;
        } 
        doInstallation(paramContext, new File(applicationInfo.sourceDir), new File(applicationInfo.dataDir), "secondary-dexes", "", true);
        Log.i("MultiDex", "install done");
        return;
      } catch (Exception exception) {
        Log.e("MultiDex", "MultiDex installation failure", exception);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("MultiDex installation failed (");
        stringBuilder1.append(exception.getMessage());
        stringBuilder1.append(").");
        throw new RuntimeException(stringBuilder1.toString());
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MultiDex installation failed. SDK ");
    stringBuilder.append(Build.VERSION.SDK_INT);
    stringBuilder.append(" is unsupported. Min SDK version is ");
    stringBuilder.append(4);
    stringBuilder.append(".");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  public static void installInstrumentation(Context paramContext1, Context paramContext2) {
    Log.i("MultiDex", "Installing instrumentation");
    if (IS_VM_MULTIDEX_CAPABLE) {
      Log.i("MultiDex", "VM has multidex support, MultiDex support library is disabled.");
      return;
    } 
    if (Build.VERSION.SDK_INT >= 4)
      try {
        ApplicationInfo applicationInfo1 = getApplicationInfo(paramContext1);
        if (applicationInfo1 == null) {
          Log.i("MultiDex", "No ApplicationInfo available for instrumentation, i.e. running on a test Context: MultiDex support library is disabled.");
          return;
        } 
        ApplicationInfo applicationInfo2 = getApplicationInfo(paramContext2);
        if (applicationInfo2 == null) {
          Log.i("MultiDex", "No ApplicationInfo available, i.e. running on a test Context: MultiDex support library is disabled.");
          return;
        } 
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(paramContext1.getPackageName());
        stringBuilder1.append(".");
        String str = stringBuilder1.toString();
        File file1 = new File(applicationInfo2.dataDir);
        File file2 = new File(applicationInfo1.sourceDir);
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(str);
        stringBuilder2.append("secondary-dexes");
        doInstallation(paramContext2, file2, file1, stringBuilder2.toString(), str, false);
        doInstallation(paramContext2, new File(applicationInfo2.sourceDir), file1, "secondary-dexes", "", false);
        Log.i("MultiDex", "Installation done");
        return;
      } catch (Exception exception) {
        Log.e("MultiDex", "MultiDex installation failure", exception);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("MultiDex installation failed (");
        stringBuilder1.append(exception.getMessage());
        stringBuilder1.append(").");
        throw new RuntimeException(stringBuilder1.toString());
      }  
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MultiDex installation failed. SDK ");
    stringBuilder.append(Build.VERSION.SDK_INT);
    stringBuilder.append(" is unsupported. Min SDK version is ");
    stringBuilder.append(4);
    stringBuilder.append(".");
    throw new RuntimeException(stringBuilder.toString());
  }
  
  private static void installSecondaryDexes(ClassLoader paramClassLoader, File paramFile, List<? extends File> paramList) {
    if (!paramList.isEmpty()) {
      if (Build.VERSION.SDK_INT >= 19) {
        V19.a(paramClassLoader, paramList, paramFile);
        return;
      } 
      if (Build.VERSION.SDK_INT >= 14) {
        V14.a(paramClassLoader, paramList);
        return;
      } 
      V4.a(paramClassLoader, paramList);
    } 
  }
  
  private static void mkdirChecked(File paramFile) {
    paramFile.mkdir();
    if (!paramFile.isDirectory()) {
      File file = paramFile.getParentFile();
      if (file == null) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to create dir ");
        stringBuilder1.append(paramFile.getPath());
        stringBuilder1.append(". Parent file is null.");
        Log.e("MultiDex", stringBuilder1.toString());
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to create dir ");
        stringBuilder1.append(paramFile.getPath());
        stringBuilder1.append(". parent file is a dir ");
        stringBuilder1.append(file.isDirectory());
        stringBuilder1.append(", a file ");
        stringBuilder1.append(file.isFile());
        stringBuilder1.append(", exists ");
        stringBuilder1.append(file.exists());
        stringBuilder1.append(", readable ");
        stringBuilder1.append(file.canRead());
        stringBuilder1.append(", writable ");
        stringBuilder1.append(file.canWrite());
        Log.e("MultiDex", stringBuilder1.toString());
      } 
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to create directory ");
      stringBuilder.append(paramFile.getPath());
      throw new IOException(stringBuilder.toString());
    } 
  }
  
  private static final class V14 {
    private static final int EXTRACTED_SUFFIX_LENGTH = ".zip".length();
    
    private final ElementConstructor elementConstructor;
    
    private V14() {
      JBMR2ElementConstructor jBMR2ElementConstructor;
      Class<?> clazz = Class.forName("dalvik.system.DexPathList$Element");
      try {
        ICSElementConstructor iCSElementConstructor = new ICSElementConstructor(clazz);
      } catch (NoSuchMethodException noSuchMethodException) {
        try {
          JBMR11ElementConstructor jBMR11ElementConstructor = new JBMR11ElementConstructor(clazz);
        } catch (NoSuchMethodException noSuchMethodException1) {
          jBMR2ElementConstructor = new JBMR2ElementConstructor(clazz);
        } 
      } 
      this.elementConstructor = jBMR2ElementConstructor;
    }
    
    static void a(ClassLoader param1ClassLoader, List<? extends File> param1List) {
      Object object = MultiDex.a(param1ClassLoader, "pathList").get(param1ClassLoader);
      Object[] arrayOfObject = (new V14()).makeDexElements(param1List);
      try {
        MultiDex.a(object, "dexElements", arrayOfObject);
        return;
      } catch (NoSuchFieldException noSuchFieldException) {
        Log.w("MultiDex", "Failed find field 'dexElements' attempting 'pathElements'", noSuchFieldException);
        MultiDex.a(object, "pathElements", arrayOfObject);
        return;
      } 
    }
    
    private Object[] makeDexElements(List<? extends File> param1List) {
      Object[] arrayOfObject = new Object[param1List.size()];
      for (byte b = 0; b < arrayOfObject.length; b++) {
        File file = param1List.get(b);
        arrayOfObject[b] = this.elementConstructor.newInstance(file, DexFile.loadDex(file.getPath(), optimizedPathFor(file), 0));
      } 
      return arrayOfObject;
    }
    
    private static String optimizedPathFor(File param1File) {
      File file = param1File.getParentFile();
      String str = param1File.getName();
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append(str.substring(0, str.length() - EXTRACTED_SUFFIX_LENGTH));
      stringBuilder.append(".dex");
      return (new File(file, stringBuilder.toString())).getPath();
    }
    
    private static interface ElementConstructor {
      Object newInstance(File param2File, DexFile param2DexFile);
    }
    
    private static class ICSElementConstructor implements ElementConstructor {
      private final Constructor<?> elementConstructor;
      
      ICSElementConstructor(Class<?> param2Class) {
        this.elementConstructor = param2Class.getConstructor(new Class[] { File.class, ZipFile.class, DexFile.class });
        this.elementConstructor.setAccessible(true);
      }
      
      public Object newInstance(File param2File, DexFile param2DexFile) {
        Constructor<?> constructor = this.elementConstructor;
        Object[] arrayOfObject = new Object[3];
        arrayOfObject[0] = param2File;
        arrayOfObject[1] = new ZipFile(param2File);
        arrayOfObject[2] = param2DexFile;
        return constructor.newInstance(arrayOfObject);
      }
    }
    
    private static class JBMR11ElementConstructor implements ElementConstructor {
      private final Constructor<?> elementConstructor;
      
      JBMR11ElementConstructor(Class<?> param2Class) {
        this.elementConstructor = param2Class.getConstructor(new Class[] { File.class, File.class, DexFile.class });
        this.elementConstructor.setAccessible(true);
      }
      
      public Object newInstance(File param2File, DexFile param2DexFile) {
        return this.elementConstructor.newInstance(new Object[] { param2File, param2File, param2DexFile });
      }
    }
    
    private static class JBMR2ElementConstructor implements ElementConstructor {
      private final Constructor<?> elementConstructor;
      
      JBMR2ElementConstructor(Class<?> param2Class) {
        Class[] arrayOfClass = new Class[4];
        arrayOfClass[0] = File.class;
        arrayOfClass[1] = boolean.class;
        arrayOfClass[2] = File.class;
        arrayOfClass[3] = DexFile.class;
        this.elementConstructor = param2Class.getConstructor(arrayOfClass);
        this.elementConstructor.setAccessible(true);
      }
      
      public Object newInstance(File param2File, DexFile param2DexFile) {
        Constructor<?> constructor = this.elementConstructor;
        Object[] arrayOfObject = new Object[4];
        arrayOfObject[0] = param2File;
        arrayOfObject[1] = Boolean.FALSE;
        arrayOfObject[2] = param2File;
        arrayOfObject[3] = param2DexFile;
        return constructor.newInstance(arrayOfObject);
      }
    }
  }
  
  private static interface ElementConstructor {
    Object newInstance(File param1File, DexFile param1DexFile);
  }
  
  private static class ICSElementConstructor implements V14.ElementConstructor {
    private final Constructor<?> elementConstructor;
    
    ICSElementConstructor(Class<?> param1Class) {
      this.elementConstructor = param1Class.getConstructor(new Class[] { File.class, ZipFile.class, DexFile.class });
      this.elementConstructor.setAccessible(true);
    }
    
    public Object newInstance(File param1File, DexFile param1DexFile) {
      Constructor<?> constructor = this.elementConstructor;
      Object[] arrayOfObject = new Object[3];
      arrayOfObject[0] = param1File;
      arrayOfObject[1] = new ZipFile(param1File);
      arrayOfObject[2] = param1DexFile;
      return constructor.newInstance(arrayOfObject);
    }
  }
  
  private static class JBMR11ElementConstructor implements V14.ElementConstructor {
    private final Constructor<?> elementConstructor;
    
    JBMR11ElementConstructor(Class<?> param1Class) {
      this.elementConstructor = param1Class.getConstructor(new Class[] { File.class, File.class, DexFile.class });
      this.elementConstructor.setAccessible(true);
    }
    
    public Object newInstance(File param1File, DexFile param1DexFile) {
      return this.elementConstructor.newInstance(new Object[] { param1File, param1File, param1DexFile });
    }
  }
  
  private static class JBMR2ElementConstructor implements V14.ElementConstructor {
    private final Constructor<?> elementConstructor;
    
    JBMR2ElementConstructor(Class<?> param1Class) {
      Class[] arrayOfClass = new Class[4];
      arrayOfClass[0] = File.class;
      arrayOfClass[1] = boolean.class;
      arrayOfClass[2] = File.class;
      arrayOfClass[3] = DexFile.class;
      this.elementConstructor = param1Class.getConstructor(arrayOfClass);
      this.elementConstructor.setAccessible(true);
    }
    
    public Object newInstance(File param1File, DexFile param1DexFile) {
      Constructor<?> constructor = this.elementConstructor;
      Object[] arrayOfObject = new Object[4];
      arrayOfObject[0] = param1File;
      arrayOfObject[1] = Boolean.FALSE;
      arrayOfObject[2] = param1File;
      arrayOfObject[3] = param1DexFile;
      return constructor.newInstance(arrayOfObject);
    }
  }
  
  private static final class V19 {
    static void a(ClassLoader param1ClassLoader, List<? extends File> param1List, File param1File) {
      Object object = MultiDex.a(param1ClassLoader, "pathList").get(param1ClassLoader);
      ArrayList<IOException> arrayList = new ArrayList();
      MultiDex.a(object, "dexElements", makeDexElements(object, new ArrayList<File>(param1List), param1File, arrayList));
      if (arrayList.size() > 0) {
        IOException[] arrayOfIOException2;
        Iterator<IOException> iterator = arrayList.iterator();
        while (iterator.hasNext())
          Log.w("MultiDex", "Exception in makeDexElement", iterator.next()); 
        Field field = MultiDex.a(object, "dexElementsSuppressedExceptions");
        IOException[] arrayOfIOException1 = (IOException[])field.get(object);
        if (arrayOfIOException1 == null) {
          arrayOfIOException2 = arrayList.<IOException>toArray(new IOException[arrayList.size()]);
        } else {
          IOException[] arrayOfIOException = new IOException[arrayList.size() + arrayOfIOException1.length];
          arrayList.toArray(arrayOfIOException);
          System.arraycopy(arrayOfIOException1, 0, arrayOfIOException, arrayList.size(), arrayOfIOException1.length);
          arrayOfIOException2 = arrayOfIOException;
        } 
        field.set(object, arrayOfIOException2);
        IOException iOException = new IOException("I/O exception during makeDexElement");
        iOException.initCause(arrayList.get(0));
        throw iOException;
      } 
    }
    
    private static Object[] makeDexElements(Object param1Object, ArrayList<File> param1ArrayList, File param1File, ArrayList<IOException> param1ArrayList1) {
      return (Object[])MultiDex.a(param1Object, "makeDexElements", new Class[] { ArrayList.class, File.class, ArrayList.class }).invoke(param1Object, new Object[] { param1ArrayList, param1File, param1ArrayList1 });
    }
  }
  
  private static final class V4 {
    static void a(ClassLoader param1ClassLoader, List<? extends File> param1List) {
      int i = param1List.size();
      Field field = MultiDex.a(param1ClassLoader, "path");
      StringBuilder stringBuilder = new StringBuilder((String)field.get(param1ClassLoader));
      String[] arrayOfString = new String[i];
      File[] arrayOfFile = new File[i];
      ZipFile[] arrayOfZipFile = new ZipFile[i];
      DexFile[] arrayOfDexFile = new DexFile[i];
      ListIterator<? extends File> listIterator = param1List.listIterator();
      while (listIterator.hasNext()) {
        File file = listIterator.next();
        String str = file.getAbsolutePath();
        stringBuilder.append(':');
        stringBuilder.append(str);
        int j = listIterator.previousIndex();
        arrayOfString[j] = str;
        arrayOfFile[j] = file;
        arrayOfZipFile[j] = new ZipFile(file);
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append(str);
        stringBuilder1.append(".dex");
        arrayOfDexFile[j] = DexFile.loadDex(str, stringBuilder1.toString(), 0);
      } 
      field.set(param1ClassLoader, stringBuilder.toString());
      MultiDex.a(param1ClassLoader, "mPaths", (Object[])arrayOfString);
      MultiDex.a(param1ClassLoader, "mFiles", (Object[])arrayOfFile);
      MultiDex.a(param1ClassLoader, "mZips", (Object[])arrayOfZipFile);
      MultiDex.a(param1ClassLoader, "mDexs", (Object[])arrayOfDexFile);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\multidex\MultiDex.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */