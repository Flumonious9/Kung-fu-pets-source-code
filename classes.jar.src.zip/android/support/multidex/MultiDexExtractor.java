package android.support.multidex;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Build;
import android.util.Log;
import java.io.Closeable;
import java.io.File;
import java.io.FileFilter;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

final class MultiDexExtractor implements Closeable {
  private static final int BUFFER_SIZE = 16384;
  
  private static final String DEX_PREFIX = "classes";
  
  private static final String EXTRACTED_NAME_EXT = ".classes";
  
  private static final String KEY_CRC = "crc";
  
  private static final String KEY_DEX_CRC = "dex.crc.";
  
  private static final String KEY_DEX_NUMBER = "dex.number";
  
  private static final String KEY_DEX_TIME = "dex.time.";
  
  private static final String KEY_TIME_STAMP = "timestamp";
  
  private static final String LOCK_FILENAME = "MultiDex.lock";
  
  private static final int MAX_EXTRACT_ATTEMPTS = 3;
  
  private static final long NO_VALUE = -1L;
  
  private static final String PREFS_FILE = "multidex.version";
  
  private static final String TAG = "MultiDex";
  
  private final FileLock cacheLock;
  
  private final File dexDir;
  
  private final FileChannel lockChannel;
  
  private final RandomAccessFile lockRaf;
  
  private final File sourceApk;
  
  private final long sourceCrc;
  
  MultiDexExtractor(File paramFile1, File paramFile2) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MultiDexExtractor(");
    stringBuilder.append(paramFile1.getPath());
    stringBuilder.append(", ");
    stringBuilder.append(paramFile2.getPath());
    stringBuilder.append(")");
    Log.i("MultiDex", stringBuilder.toString());
    this.sourceApk = paramFile1;
    this.dexDir = paramFile2;
    this.sourceCrc = getZipCrc(paramFile1);
    File file = new File(paramFile2, "MultiDex.lock");
    this.lockRaf = new RandomAccessFile(file, "rw");
    try {
      this.lockChannel = this.lockRaf.getChannel();
      try {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Blocking on lock ");
        stringBuilder1.append(file.getPath());
        Log.i("MultiDex", stringBuilder1.toString());
        this.cacheLock = this.lockChannel.lock();
        StringBuilder stringBuilder2 = new StringBuilder();
        stringBuilder2.append(file.getPath());
        stringBuilder2.append(" locked");
        Log.i("MultiDex", stringBuilder2.toString());
        return;
      } catch (IOException|RuntimeException|Error iOException) {
        closeQuietly(this.lockChannel);
        throw iOException;
      } 
    } catch (IOException|RuntimeException|Error iOException) {
      closeQuietly(this.lockRaf);
      throw iOException;
    } 
  }
  
  private void clearDexDir() {
    File[] arrayOfFile = this.dexDir.listFiles(new FileFilter(this) {
          public boolean accept(File param1File) {
            return true ^ param1File.getName().equals("MultiDex.lock");
          }
        });
    if (arrayOfFile == null) {
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Failed to list secondary dex dir content (");
      stringBuilder.append(this.dexDir.getPath());
      stringBuilder.append(").");
      Log.w("MultiDex", stringBuilder.toString());
      return;
    } 
    int i = arrayOfFile.length;
    for (byte b = 0; b < i; b++) {
      File file = arrayOfFile[b];
      StringBuilder stringBuilder = new StringBuilder();
      stringBuilder.append("Trying to delete old file ");
      stringBuilder.append(file.getPath());
      stringBuilder.append(" of size ");
      stringBuilder.append(file.length());
      Log.i("MultiDex", stringBuilder.toString());
      if (!file.delete()) {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Failed to delete old file ");
        stringBuilder1.append(file.getPath());
        Log.w("MultiDex", stringBuilder1.toString());
      } else {
        StringBuilder stringBuilder1 = new StringBuilder();
        stringBuilder1.append("Deleted old file ");
        stringBuilder1.append(file.getPath());
        Log.i("MultiDex", stringBuilder1.toString());
      } 
    } 
  }
  
  private static void closeQuietly(Closeable paramCloseable) {
    try {
      paramCloseable.close();
      return;
    } catch (IOException iOException) {
      Log.w("MultiDex", "Failed to close resource", iOException);
      return;
    } 
  }
  
  private static void extract(ZipFile paramZipFile, ZipEntry paramZipEntry, File paramFile, String paramString) {
    InputStream inputStream = paramZipFile.getInputStream(paramZipEntry);
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append("tmp-");
    stringBuilder1.append(paramString);
    File file = File.createTempFile(stringBuilder1.toString(), ".zip", paramFile.getParentFile());
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append("Extracting ");
    stringBuilder2.append(file.getPath());
    Log.i("MultiDex", stringBuilder2.toString());
    try {
    
    } finally {
      closeQuietly(inputStream);
      file.delete();
    } 
  }
  
  private static SharedPreferences getMultiDexPreferences(Context paramContext) {
    byte b;
    if (Build.VERSION.SDK_INT < 11) {
      b = 0;
    } else {
      b = 4;
    } 
    return paramContext.getSharedPreferences("multidex.version", b);
  }
  
  private static long getTimeStamp(File paramFile) {
    long l = paramFile.lastModified();
    if (l == -1L)
      l--; 
    return l;
  }
  
  private static long getZipCrc(File paramFile) {
    long l = ZipUtil.a(paramFile);
    if (l == -1L)
      l--; 
    return l;
  }
  
  private static boolean isModified(Context paramContext, File paramFile, long paramLong, String paramString) {
    SharedPreferences sharedPreferences = getMultiDexPreferences(paramContext);
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(paramString);
    stringBuilder.append("timestamp");
    if (sharedPreferences.getLong(stringBuilder.toString(), -1L) == getTimeStamp(paramFile)) {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append(paramString);
      stringBuilder1.append("crc");
      if (sharedPreferences.getLong(stringBuilder1.toString(), -1L) == paramLong)
        return false; 
    } 
    return true;
  }
  
  private List<ExtractedDex> loadExistingExtractions(Context paramContext, String paramString) {
    Log.i("MultiDex", "loading existing secondary dex files");
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(this.sourceApk.getName());
    stringBuilder1.append(".classes");
    String str = stringBuilder1.toString();
    SharedPreferences sharedPreferences = getMultiDexPreferences(paramContext);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("dex.number");
    int i = sharedPreferences.getInt(stringBuilder2.toString(), 1);
    ArrayList<ExtractedDex> arrayList = new ArrayList(i - 1);
    byte b = 2;
    while (b <= i) {
      StringBuilder stringBuilder3 = new StringBuilder();
      stringBuilder3.append(str);
      stringBuilder3.append(b);
      stringBuilder3.append(".zip");
      String str1 = stringBuilder3.toString();
      ExtractedDex extractedDex = new ExtractedDex(this.dexDir, str1);
      if (extractedDex.isFile()) {
        extractedDex.crc = getZipCrc(extractedDex);
        StringBuilder stringBuilder5 = new StringBuilder();
        stringBuilder5.append(paramString);
        stringBuilder5.append("dex.crc.");
        stringBuilder5.append(b);
        long l1 = sharedPreferences.getLong(stringBuilder5.toString(), -1L);
        StringBuilder stringBuilder6 = new StringBuilder();
        stringBuilder6.append(paramString);
        stringBuilder6.append("dex.time.");
        stringBuilder6.append(b);
        long l2 = sharedPreferences.getLong(stringBuilder6.toString(), -1L);
        long l3 = extractedDex.lastModified();
        if (l2 == l3) {
          String str2 = str;
          SharedPreferences sharedPreferences1 = sharedPreferences;
          if (l1 == extractedDex.crc) {
            arrayList.add(extractedDex);
            b++;
            str = str2;
            sharedPreferences = sharedPreferences1;
            continue;
          } 
        } 
        StringBuilder stringBuilder7 = new StringBuilder();
        stringBuilder7.append("Invalid extracted dex: ");
        stringBuilder7.append(extractedDex);
        stringBuilder7.append(" (key \"");
        stringBuilder7.append(paramString);
        stringBuilder7.append("\"), expected modification time: ");
        stringBuilder7.append(l2);
        stringBuilder7.append(", modification time: ");
        stringBuilder7.append(l3);
        stringBuilder7.append(", expected crc: ");
        stringBuilder7.append(l1);
        stringBuilder7.append(", file crc: ");
        stringBuilder7.append(extractedDex.crc);
        throw new IOException(stringBuilder7.toString());
      } 
      StringBuilder stringBuilder4 = new StringBuilder();
      stringBuilder4.append("Missing extracted secondary dex file '");
      stringBuilder4.append(extractedDex.getPath());
      stringBuilder4.append("'");
      throw new IOException(stringBuilder4.toString());
    } 
    return arrayList;
  }
  
  private List<ExtractedDex> performExtractions() {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append(this.sourceApk.getName());
    stringBuilder.append(".classes");
    String str = stringBuilder.toString();
    clearDexDir();
    ArrayList<ExtractedDex> arrayList = new ArrayList();
    ZipFile zipFile = new ZipFile(this.sourceApk);
    byte b = 2;
    try {
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("classes");
      stringBuilder1.append(b);
      stringBuilder1.append(".dex");
      ZipEntry zipEntry = zipFile.getEntry(stringBuilder1.toString());
      label43: while (true) {
        if (zipEntry != null) {
          StringBuilder stringBuilder2 = new StringBuilder();
          stringBuilder2.append(str);
          stringBuilder2.append(b);
          stringBuilder2.append(".zip");
          String str1 = stringBuilder2.toString();
          ExtractedDex extractedDex = new ExtractedDex(this.dexDir, str1);
          arrayList.add(extractedDex);
          StringBuilder stringBuilder3 = new StringBuilder();
          stringBuilder3.append("Extraction is needed for file ");
          stringBuilder3.append(extractedDex);
          Log.i("MultiDex", stringBuilder3.toString());
          byte b1 = 0;
          boolean bool = false;
          while (true) {
            if (b1 < 3 && !bool) {
              String str2;
              b1++;
              extract(zipFile, zipEntry, extractedDex, str);
              try {
                extractedDex.crc = getZipCrc(extractedDex);
                bool = true;
              } catch (IOException iOException) {
                StringBuilder stringBuilder6 = new StringBuilder();
                stringBuilder6.append("Failed to read crc from ");
                stringBuilder6.append(extractedDex.getAbsolutePath());
                Log.w("MultiDex", stringBuilder6.toString(), iOException);
                bool = false;
              } 
              StringBuilder stringBuilder5 = new StringBuilder();
              stringBuilder5.append("Extraction ");
              if (bool) {
                str2 = "succeeded";
              } else {
                str2 = "failed";
              } 
              stringBuilder5.append(str2);
              stringBuilder5.append(" '");
              stringBuilder5.append(extractedDex.getAbsolutePath());
              stringBuilder5.append("': length ");
              stringBuilder5.append(extractedDex.length());
              stringBuilder5.append(" - crc: ");
              stringBuilder5.append(extractedDex.crc);
              Log.i("MultiDex", stringBuilder5.toString());
              if (!bool) {
                extractedDex.delete();
                if (extractedDex.exists()) {
                  StringBuilder stringBuilder6 = new StringBuilder();
                  stringBuilder6.append("Failed to delete corrupted secondary dex '");
                  stringBuilder6.append(extractedDex.getPath());
                  stringBuilder6.append("'");
                  Log.w("MultiDex", stringBuilder6.toString());
                } 
              } 
              continue;
            } 
            if (bool) {
              b++;
              StringBuilder stringBuilder5 = new StringBuilder();
              stringBuilder5.append("classes");
              stringBuilder5.append(b);
              stringBuilder5.append(".dex");
              zipEntry = zipFile.getEntry(stringBuilder5.toString());
              continue label43;
            } 
            StringBuilder stringBuilder4 = new StringBuilder();
            stringBuilder4.append("Could not create zip file ");
            stringBuilder4.append(extractedDex.getAbsolutePath());
            stringBuilder4.append(" for secondary dex (");
            stringBuilder4.append(b);
            stringBuilder4.append(")");
            throw new IOException(stringBuilder4.toString());
          } 
          break;
        } 
        try {
          return arrayList;
        } catch (IOException iOException) {
          return arrayList;
        } 
      } 
    } finally {
      try {
        zipFile.close();
      } catch (IOException iOException) {
        Log.w("MultiDex", "Failed to close resource", iOException);
      } 
    } 
  }
  
  private static void putStoredApkInfo(Context paramContext, String paramString, long paramLong1, long paramLong2, List<ExtractedDex> paramList) {
    SharedPreferences.Editor editor = getMultiDexPreferences(paramContext).edit();
    StringBuilder stringBuilder1 = new StringBuilder();
    stringBuilder1.append(paramString);
    stringBuilder1.append("timestamp");
    editor.putLong(stringBuilder1.toString(), paramLong1);
    StringBuilder stringBuilder2 = new StringBuilder();
    stringBuilder2.append(paramString);
    stringBuilder2.append("crc");
    editor.putLong(stringBuilder2.toString(), paramLong2);
    StringBuilder stringBuilder3 = new StringBuilder();
    stringBuilder3.append(paramString);
    stringBuilder3.append("dex.number");
    editor.putInt(stringBuilder3.toString(), 1 + paramList.size());
    Iterator<ExtractedDex> iterator = paramList.iterator();
    for (byte b = 2; iterator.hasNext(); b++) {
      ExtractedDex extractedDex = iterator.next();
      StringBuilder stringBuilder4 = new StringBuilder();
      stringBuilder4.append(paramString);
      stringBuilder4.append("dex.crc.");
      stringBuilder4.append(b);
      editor.putLong(stringBuilder4.toString(), extractedDex.crc);
      StringBuilder stringBuilder5 = new StringBuilder();
      stringBuilder5.append(paramString);
      stringBuilder5.append("dex.time.");
      stringBuilder5.append(b);
      editor.putLong(stringBuilder5.toString(), extractedDex.lastModified());
    } 
    editor.commit();
  }
  
  List<? extends File> a(Context paramContext, String paramString, boolean paramBoolean) {
    StringBuilder stringBuilder = new StringBuilder();
    stringBuilder.append("MultiDexExtractor.load(");
    stringBuilder.append(this.sourceApk.getPath());
    stringBuilder.append(", ");
    stringBuilder.append(paramBoolean);
    stringBuilder.append(", ");
    stringBuilder.append(paramString);
    stringBuilder.append(")");
    Log.i("MultiDex", stringBuilder.toString());
    if (this.cacheLock.isValid()) {
      List<ExtractedDex> list;
      if (!paramBoolean && !isModified(paramContext, this.sourceApk, this.sourceCrc, paramString)) {
        try {
          list = loadExistingExtractions(paramContext, paramString);
        } catch (IOException iOException) {
          Log.w("MultiDex", "Failed to reload existing extracted secondary dex files, falling back to fresh extraction", iOException);
          list = performExtractions();
          putStoredApkInfo(paramContext, paramString, getTimeStamp(this.sourceApk), this.sourceCrc, list);
        } 
      } else {
        if (paramBoolean) {
          Log.i("MultiDex", "Forced extraction must be performed.");
        } else {
          Log.i("MultiDex", "Detected that extraction must be performed.");
        } 
        list = performExtractions();
        putStoredApkInfo(paramContext, paramString, getTimeStamp(this.sourceApk), this.sourceCrc, list);
      } 
      StringBuilder stringBuilder1 = new StringBuilder();
      stringBuilder1.append("load found ");
      stringBuilder1.append(list.size());
      stringBuilder1.append(" secondary dex files");
      Log.i("MultiDex", stringBuilder1.toString());
      return (List)list;
    } 
    throw new IllegalStateException("MultiDexExtractor was closed");
  }
  
  public void close() {
    this.cacheLock.release();
    this.lockChannel.close();
    this.lockRaf.close();
  }
  
  private static class ExtractedDex extends File {
    public long crc = -1L;
    
    public ExtractedDex(File param1File, String param1String) {
      super(param1File, param1String);
    }
  }
}


/* Location:              C:\Users\4257600\Downloads\classes.jar!\android\support\multidex\MultiDexExtractor.class
 * Java compiler version: 6 (50.0)
 * JD-Core Version:       1.1.3
 */